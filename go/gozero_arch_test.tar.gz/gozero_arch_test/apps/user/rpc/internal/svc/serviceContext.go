package svc

import (
	"civet/apps/user/model"
	"civet/apps/user/rpc/internal/config"
	_ "github.com/lib/pq"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

type ServiceContext struct {
	Config config.Config
	// Code generated rpc model fields. DO NOT EDIT.
	// End generated rpc model fields.
}

func NewServiceContext(c config.Config) *ServiceContext {
	conn := sqlx.NewSqlConn(c.Pg.DriverName, c.Pg.DataSource)

	return &ServiceContext{
		Config: c,
		// Code generated rpc model init. DO NOT EDIT.
		// End generated rpc model init.
	}
}
