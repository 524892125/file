#!/usr/bin/env bash

set -euo pipefail
shopt -s nullglob

declare -A DB_MAP=(
  ["user"]="go-admin-user"
  ["admin"]="go-admin-common"
)

sql_has_gen() {
  local sql_file="$1"
  local target="$2"
  local line value item
  while IFS= read -r line; do
    line="${line#${line%%[![:space:]]*}}"
    [[ -z "$line" ]] && continue
    if [[ "$line" =~ ^--[[:space:]]*@gen[[:space:]]*:[[:space:]]*(.*)$ ]]; then
      value="${BASH_REMATCH[1]}"
      IFS=',' read -ra items <<< "$value"
      for item in "${items[@]}"; do
        item="${item#${item%%[![:space:]]*}}"
        item="${item%${item##*[![:space:]]}}"
        [[ "${item,,}" == "$target" ]] && return 0
      done
      return 1
    fi
    [[ "$line" == --* ]] && continue
    break
  done < "$sql_file"
  [[ "$target" == "model" || "$target" == "api" ]]
}

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TPL_DIR="${ROOT_DIR}/tools/goctl/tpl_1.10.1"

server=(
  "user"
  "admin"
)

cd tools/autogen && python3 autogen.py && cd ../../

for s in "${server[@]}"; do
  DATABASE_NAME="${DB_MAP[$s]:-}"
  if [[ -z "${DATABASE_NAME}" ]]; then
    echo "❌ No database config for service: $s"
    exit 1
  fi
  DATABASE_URL="postgres://postgres:123456@127.0.0.1:5432/${DATABASE_NAME}?sslmode=disable"
  echo "🚀 Service: $s → DB: $DATABASE_NAME"

  sql_files=( assets/sql/${s}/*.sql )
  if (( ${#sql_files[@]} == 0 )); then
    echo "skip model ddl: no sql files under assets/sql/${s}/"
  else
    model_sql_files=()
    for sql_file in "${sql_files[@]}"; do
      if sql_has_gen "$sql_file" model; then
        model_sql_files+=("$sql_file")
      fi
    done

    if (( ${#model_sql_files[@]} == 0 )); then
      echo "skip model ddl: no @gen model sql files under assets/sql/${s}/"
    else
      printf '%s\n' "${model_sql_files[@]}"

      for sql_file in "${model_sql_files[@]}"; do
        echo "Applying DDL: $sql_file"
        mkdir -p "apps/${s}/model"
        psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$sql_file"

        TABLE_REF=$(grep -iE 'CREATE[[:space:]]+TABLE' "$sql_file" | head -n1 | sed -E 's/.*CREATE[[:space:]]+TABLE([[:space:]]+IF[[:space:]]+NOT[[:space:]]+EXISTS)?[[:space:]]+//I; s/[[:space:]]*\(.*//')
        SCHEMA_NAME=$(echo "$TABLE_REF" | awk -F. 'NF>1 {gsub(/"/, "", $1); print $1}')
        TABLE_NAME=$(echo "$TABLE_REF" | awk -F. '{gsub(/"/, "", $NF); print $NF}')
        SCHEMA_NAME="${SCHEMA_NAME:-public}"

        if [[ -z "$TABLE_NAME" ]]; then
          echo "❌ Failed to parse table name from $sql_file"
          continue
        fi

        echo "✅ Table: ${SCHEMA_NAME}.${TABLE_NAME}"
        echo "Generating goctl pg model for ${TABLE_NAME}"
        goctl model pg datasource \
          --url "$DATABASE_URL" \
          --schema "$SCHEMA_NAME" \
          --table "$TABLE_NAME" \
          --dir "apps/${s}/model" \
          --style goZero \
          --home "${TPL_DIR}"
      done
    fi
  fi

  python3 tools/autogen/autogen_svc_models.py --root "${ROOT_DIR}" --service "${s}"

  # ...................................create api swagger docs...................................
  bash tools/goctl/goctl-api-build.sh "apps/${s}/api/${s}.api" "apps/${s}/api" "apps/${s}/api" "assets" "${s}"
  python3 tools/autogen/autogen_dbapi_list.py --root "${ROOT_DIR}" --service "${s}"

  python3 tools/autogen/autogen_pg_sql_rpc.py --root "${ROOT_DIR}" --service "${s}"
  cd apps/${s}/rpc/
  goctl rpc protoc "${s}.proto" --go_out=./ --go-grpc_out=./ --zrpc_out=./ --style=goZero --home "${TPL_DIR}"
  cd ../../../
  python3 tools/autogen/autogen_rpc_svc_models.py --root "${ROOT_DIR}" --service "${s}" --database "${DATABASE_NAME}"
  python3 tools/autogen/autogen_rpccrud_logic.py --root "${ROOT_DIR}" --service "${s}"
done
