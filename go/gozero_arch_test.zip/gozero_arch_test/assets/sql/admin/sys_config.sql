-- @gen: model,api,rpc
-- @api.middleware: PermissionMiddleware
CREATE TABLE IF NOT EXISTS "public"."sys_config" (
        id BIGSERIAL PRIMARY KEY,
        config_name VARCHAR(128),
        config_key VARCHAR(128) ,
        config_value VARCHAR(255),
        config_type VARCHAR(64) ,
        is_frontend VARCHAR(64),
        remark VARCHAR(128),
        create_by INT NOT NULL DEFAULT 0,
        update_by INT NOT NULL DEFAULT 0,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        deleted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
