import webapi from "./gocliRequest"
import * as components from "./adminComponents"
export * from "./adminComponents"

/**
 * @description 
 */
export function createAuth() {
	return webapi.post<null>(`/users/auth/create`)
}

/**
 * @description 
 */
export function getUser() {
	return webapi.get<components.Response>(`/users/id/${userId}`)
}

/**
 * @description 
 * @param params
 */
export function getSysConfig(params: components.SysConfigIdReqParams, id: number) {
	return webapi.get<components.SysConfig>(`/db/sys-config/${id}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysConfig(params: components.SysConfigIdReqParams, id: number) {
	return webapi.delete<components.SysConfigEmptyResp>(`/db/sys-config/${id}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysConfig(req: components.SysConfigCreateReq) {
	return webapi.post<components.SysConfigCreateResp>(`/db/sys-config/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysConfig(params: components.SysConfigListReqParams) {
	return webapi.get<components.SysConfigFindPageResp>(`/db/sys-config/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysConfig(params: components.SysConfigListReqParams) {
	return webapi.get<components.SysConfigListResp>(`/db/sys-config/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysConfig(req: components.SysConfigUpdateReq) {
	return webapi.post<components.SysConfigEmptyResp>(`/db/sys-config/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getAppRuntimeLog(params: components.AppRuntimeLogIdReqParams, id: number) {
	return webapi.get<components.AppRuntimeLog>(`/db/app-runtime-log/${id}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteAppRuntimeLog(params: components.AppRuntimeLogIdReqParams, id: number) {
	return webapi.delete<components.AppRuntimeLogEmptyResp>(`/db/app-runtime-log/${id}`, params)
}

/**
 * @description 
 * @param req
 */
export function createAppRuntimeLog(req: components.AppRuntimeLogCreateReq) {
	return webapi.post<components.AppRuntimeLogCreateResp>(`/db/app-runtime-log/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageAppRuntimeLog(params: components.AppRuntimeLogListReqParams) {
	return webapi.get<components.AppRuntimeLogFindPageResp>(`/db/app-runtime-log/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listAppRuntimeLog(params: components.AppRuntimeLogListReqParams) {
	return webapi.get<components.AppRuntimeLogListResp>(`/db/app-runtime-log/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateAppRuntimeLog(req: components.AppRuntimeLogUpdateReq) {
	return webapi.post<components.AppRuntimeLogEmptyResp>(`/db/app-runtime-log/update`, req)
}
