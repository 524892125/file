### 1. N/A

1. route definition

- Url: /users/auth/create
- Method: POST
- Request: `request`
- Response: `-`

2. request definition



```golang
type Request struct {
}
```


3. response definition


### 2. N/A

1. route definition

- Url: /users/id/:userId
- Method: GET
- Request: `request`
- Response: `response`

2. request definition



```golang
type Request struct {
}
```


3. response definition



```golang
type Response struct {
}
```

### 3. N/A

1. route definition

- Url: /db/app-runtime-log/:id
- Method: GET
- Request: `AppRuntimeLogIdReq`
- Response: `AppRuntimeLog`

2. request definition



```golang
type AppRuntimeLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type AppRuntimeLog struct {
	Id int64 `json:"id"`
	MessageId string `json:"messageId"`
	TraceId string `json:"traceId"`
	TenantCode string `json:"tenantCode"`
	ServiceName string `json:"serviceName"`
	Level string `json:"level"`
	Caller string `json:"caller"`
	Content string `json:"content"`
	FieldsJson string `json:"fieldsJson"`
	Source string `json:"source"`
	LoggedAt string `json:"loggedAt"`
	CreatedAt string `json:"createdAt"`
}
```

### 4. N/A

1. route definition

- Url: /db/app-runtime-log/:id
- Method: DELETE
- Request: `AppRuntimeLogIdReq`
- Response: `AppRuntimeLogEmptyResp`

2. request definition



```golang
type AppRuntimeLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type AppRuntimeLogEmptyResp struct {
}
```

### 5. N/A

1. route definition

- Url: /db/app-runtime-log/create
- Method: POST
- Request: `AppRuntimeLogCreateReq`
- Response: `AppRuntimeLogCreateResp`

2. request definition



```golang
type AppRuntimeLogCreateReq struct {
	MessageId string `json:"messageId"`
	TraceId string `json:"traceId"`
	TenantCode string `json:"tenantCode"`
	ServiceName string `json:"serviceName"`
	Level string `json:"level"`
	Caller string `json:"caller"`
	Content string `json:"content"`
	FieldsJson string `json:"fieldsJson"`
	Source string `json:"source"`
	LoggedAt string `json:"loggedAt"`
}
```


3. response definition



```golang
type AppRuntimeLogCreateResp struct {
	Id int64 `json:"id"`
}
```

### 6. N/A

1. route definition

- Url: /db/app-runtime-log/findPage
- Method: GET
- Request: `AppRuntimeLogListReq`
- Response: `AppRuntimeLogFindPageResp`

2. request definition



```golang
type AppRuntimeLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogFindPageResp struct {
	List []AppRuntimeLog `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 7. N/A

1. route definition

- Url: /db/app-runtime-log/list
- Method: GET
- Request: `AppRuntimeLogListReq`
- Response: `AppRuntimeLogListResp`

2. request definition



```golang
type AppRuntimeLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogListResp struct {
	List []AppRuntimeLog `json:"list"`
	Total int64 `json:"total"`
}
```

### 8. N/A

1. route definition

- Url: /db/app-runtime-log/update
- Method: POST
- Request: `AppRuntimeLogUpdateReq`
- Response: `AppRuntimeLogEmptyResp`

2. request definition



```golang
type AppRuntimeLogUpdateReq struct {
	Id int64 `json:"id"`
	MessageId *string `json:"messageId,optional"`
	TraceId *string `json:"traceId,optional"`
	TenantCode *string `json:"tenantCode,optional"`
	ServiceName *string `json:"serviceName,optional"`
	Level *string `json:"level,optional"`
	Caller *string `json:"caller,optional"`
	Content *string `json:"content,optional"`
	FieldsJson *string `json:"fieldsJson,optional"`
	Source *string `json:"source,optional"`
	LoggedAt *string `json:"loggedAt,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogEmptyResp struct {
}
```

### 9. N/A

1. route definition

- Url: /db/sys-config/:id
- Method: GET
- Request: `SysConfigIdReq`
- Response: `SysConfig`

2. request definition



```golang
type SysConfigIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type SysConfig struct {
	Id int64 `json:"id"`
	ConfigName string `json:"configName"`
	ConfigKey string `json:"configKey"`
	ConfigValue string `json:"configValue"`
	ConfigType string `json:"configType"`
	IsFrontend string `json:"isFrontend"`
	Remark string `json:"remark"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 10. N/A

1. route definition

- Url: /db/sys-config/:id
- Method: DELETE
- Request: `SysConfigIdReq`
- Response: `SysConfigEmptyResp`

2. request definition



```golang
type SysConfigIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type SysConfigEmptyResp struct {
}
```

### 11. N/A

1. route definition

- Url: /db/sys-config/create
- Method: POST
- Request: `SysConfigCreateReq`
- Response: `SysConfigCreateResp`

2. request definition



```golang
type SysConfigCreateReq struct {
	ConfigName string `json:"configName"`
	ConfigKey string `json:"configKey"`
	ConfigValue string `json:"configValue"`
	ConfigType string `json:"configType"`
	IsFrontend string `json:"isFrontend"`
	Remark string `json:"remark"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
}
```


3. response definition



```golang
type SysConfigCreateResp struct {
	Id int64 `json:"id"`
}
```

### 12. N/A

1. route definition

- Url: /db/sys-config/findPage
- Method: GET
- Request: `SysConfigListReq`
- Response: `SysConfigFindPageResp`

2. request definition



```golang
type SysConfigListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysConfigFindPageResp struct {
	List []SysConfig `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 13. N/A

1. route definition

- Url: /db/sys-config/list
- Method: GET
- Request: `SysConfigListReq`
- Response: `SysConfigListResp`

2. request definition



```golang
type SysConfigListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysConfigListResp struct {
	List []SysConfig `json:"list"`
	Total int64 `json:"total"`
}
```

### 14. N/A

1. route definition

- Url: /db/sys-config/update
- Method: POST
- Request: `SysConfigUpdateReq`
- Response: `SysConfigEmptyResp`

2. request definition



```golang
type SysConfigUpdateReq struct {
	Id int64 `json:"id"`
	ConfigName *string `json:"configName,optional"`
	ConfigKey *string `json:"configKey,optional"`
	ConfigValue *string `json:"configValue,optional"`
	ConfigType *string `json:"configType,optional"`
	IsFrontend *string `json:"isFrontend,optional"`
	Remark *string `json:"remark,optional"`
	CreateBy *int64 `json:"createBy,optional"`
	UpdateBy *int64 `json:"updateBy,optional"`
}
```


3. response definition



```golang
type SysConfigEmptyResp struct {
}
```

