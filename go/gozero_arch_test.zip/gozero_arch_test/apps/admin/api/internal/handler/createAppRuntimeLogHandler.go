// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package handler

import (
	"net/http"

	"civet/apps/admin/api/internal/logic"
	"civet/apps/admin/api/internal/svc"
	"civet/apps/admin/api/internal/types"
	"github.com/zeromicro/go-zero/rest/httpx"
)

func CreateAppRuntimeLogHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req types.AppRuntimeLogCreateReq
		if err := httpx.Parse(r, &req); err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
			return
		}

		l := logic.NewCreateAppRuntimeLogLogic(r.Context(), svcCtx)
		resp, err := l.CreateAppRuntimeLog(&req)
		if err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
		} else {
			httpx.OkJsonCtx(r.Context(), w, resp)
		}
	}
}
