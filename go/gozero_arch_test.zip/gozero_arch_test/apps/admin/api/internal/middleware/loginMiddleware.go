// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package middleware

import "net/http"

type LoginMiddleware struct {
}

func NewLoginMiddleware() *LoginMiddleware {
	return &LoginMiddleware{}
}

func (m *LoginMiddleware) Handle(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		// TODO generate middleware implement function, delete after code implementation
		// 辅导费
		// Passthrough to next handler if need
		next(w, r)
	}
}
