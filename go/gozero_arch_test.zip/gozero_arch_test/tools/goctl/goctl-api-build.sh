#!/usr/bin/env bash

set -euo pipefail

API_FILE="${1:-greet/api/greet.api}"
API_DIR="${2:-greet/api}"
GEN_DIR="${3:-greet/api}"
DOCS_DIR="${4:-greet/docs}"
STYLE="${GOCTL_STYLE:-goZero}"
SERVER_NAME="${5:-greet}"

usage() {
  cat <<'EOF'
Usage:
  goctl-api-build.sh [api_file] [api_dir] [gen_dir] [docs_dir]

Defaults:
  api_file = greet/api/greet.api
  api_dir  = greet/api
  gen_dir  = greet/api
  docs_dir = greet/docs

Env:
  GOCTL_STYLE   Naming style, default: goZero
EOF
}

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "missing command: $1" >&2
    exit 1
  fi
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

require_cmd goctl

if [[ ! -f "$API_FILE" ]]; then
  echo "api file not found: $API_FILE" >&2
  exit 1
fi

if [[ ! -d "$API_DIR" ]]; then
  echo "api dir not found: $API_DIR" >&2
  exit 1
fi

mkdir -p "$GEN_DIR" "$DOCS_DIR"

echo "==> format api files"
goctl api format --dir "$API_DIR"

echo "==> validate api file"
goctl api validate --api "$API_FILE"

echo "==> generate go api code"
goctl api go --api "$API_FILE" --dir "$GEN_DIR" --style "$STYLE"

# echo "==> generate swagger yaml"
# goctl api swagger --api "$API_FILE" --dir "$DOCS_DIR"/swagger/"$SERVER_NAME" --yaml

echo "==> generate markdown docs"
# goctl 1.10.x fails on repeated generation when markdown files already exist.
rm -rf "$DOCS_DIR"/api/"$SERVER_NAME"
goctl api doc --dir "$API_DIR" --o "$DOCS_DIR"/api/"$SERVER_NAME"

echo "==> generate typescript client"
goctl api ts --api "$API_FILE" --dir "$DOCS_DIR"/ts/"$SERVER_NAME"

echo "done"
