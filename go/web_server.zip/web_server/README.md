# web_server

`web_server` 是从 `vc_server` 抽出的最小可用微服务骨架，保留了它的 go-zero 目录风格和 `api -> rpc -> model` 分层，但移除了 Kafka、Redis、SQS、etcd、CMS、Jobs 等重依赖。

当前包含两个独立微服务：`bit` 与 `note`。默认都使用**内存存储**，所以不需要任何外部基础设施就能直接跑起来；如果你需要持久化，再切到 MySQL 模式。

## 架构

```
web_server/
├── apps/
│   ├── bit/
│   │   ├── api/          # HTTP API (port 30190)
│   │   ├── rpc/          # gRPC 服务 (port 30590)
│   │   └── model/        # 数据访问层
│   └── note/
│       ├── api/          # HTTP API (port 30191)
│       ├── rpc/          # gRPC 服务 (port 30591)
│       └── model/
├── common/               # 公共模块
│   ├── result/           # 统一响应
│   ├── xerr/             # 错误码
│   ├── middleware/       # 中间件
│   └── tool/             # 工具函数
├── bin/                  # 构建输出
│   ├── bit_api, bit_rpc
│   ├── note_api, note_rpc
│   ├── etc/              # 配置文件
│   └── logs/             # 日志
├── deploy/
│   └── docker-compose.yml
├── make.sh               # 构建脚本
├── run.sh                # 启动脚本
└── stop.sh               # 停止脚本
```

## 常用命令

### 构建与运行

```bash
# 构建所有服务
bash make.sh

# 启动所有服务（内存模式）
bash run.sh

# 启动所有服务（MySQL 模式）
BIT_RPC_CONFIG=etc/bit-mysql.yaml NOTE_RPC_CONFIG=etc/note-mysql.yaml bash run.sh

# 停止所有服务
bash stop.sh
```

### 单独构建

```bash
go build -o ./bin/bit_api ./apps/bit/api/bit.go
go build -o ./bin/bit_rpc ./apps/bit/rpc/bit.go
go build -o ./bin/note_api ./apps/note/api/note.go
go build -o ./bin/note_rpc ./apps/note/rpc/note.go
```

### 单独运行

```bash
# 从 bin 目录运行
./bit_api -f etc/bit-api.yaml
./bit_rpc -f etc/bit.yaml              # 内存模式
./bit_rpc -f etc/bit-mysql.yaml        # MySQL 模式
./note_api -f etc/note-api.yaml
./note_rpc -f etc/note.yaml            # 内存模式
./note_rpc -f etc/note-mysql.yaml      # MySQL 模式
```

### 测试

```bash
# 运行所有测试
go test ./...

# 测试指定包
go test ./common/tool/...
go test ./common/encrypt/...
go test ./common/mathx/...
```

### Docker / MySQL

```bash
# 启动 MySQL
docker compose -f deploy/docker-compose.yml up -d

# 停止 MySQL
docker compose -f deploy/docker-compose.yml down

# 重置 MySQL（删除数据卷）
docker compose -f deploy/docker-compose.yml down -v
```

### Proto 代码生成

修改 `.proto` 文件后重新生成：

```bash
# bit 服务
cd apps/bit/rpc
protoc --go_out=. --go-grpc_out=. bit.proto

# note 服务
cd apps/note/rpc
protoc --go_out=. --go-grpc_out=. note.proto
```

## API 端点

### Bit 服务 (port 30190)

```bash
# 健康检查
curl http://127.0.0.1:30190/bit/health

# 创建
curl -X POST http://127.0.0.1:30190/bit/bits \
  -H 'Content-Type: application/json' \
  -d '{"name":"hello","content":"test content"}'

# 列表
curl 'http://127.0.0.1:30190/bit/bits?page=1&page_size=10'
```

### Note 服务 (port 30191)

```bash
# 健康检查
curl http://127.0.0.1:30191/note/health

# 创建
curl -X POST http://127.0.0.1:30191/note/notes \
  -H 'Content-Type: application/json' \
  -d '{"name":"todo","content":"test note"}'

# 列表
curl 'http://127.0.0.1:30191/note/notes?page=1&page_size=10'
```

## 端口

| 服务 | 端口 |
|------|------|
| bit-api | 30190 |
| bit-rpc | 30590 |
| note-api | 30191 |
| note-rpc | 30591 |
| mysql | 13306 |

## 配置文件

| 服务 | 文件 | 说明 |
|------|------|------|
| bit-api | `apps/bit/api/etc/bit-api.yaml` | HTTP API 配置 |
| bit-rpc | `apps/bit/rpc/etc/bit.yaml` | 内存存储 |
| bit-rpc | `apps/bit/rpc/etc/bit-mysql.yaml` | MySQL 存储 |
| note-api | `apps/note/api/etc/note-api.yaml` | HTTP API 配置 |
| note-rpc | `apps/note/rpc/etc/note.yaml` | 内存存储 |
| note-rpc | `apps/note/rpc/etc/note-mysql.yaml` | MySQL 存储 |

## 技术栈

- **框架**: go-zero v1.5.4
- **Go 版本**: 1.22
- **RPC**: gRPC + Protocol Buffers
- **数据库**: MySQL 8.0 (可选)
- **配置**: YAML


最常用的几个命令是：
```bash
go install github.com/zeromicro/go-zero/tools/goctl@latest
goctl env check --install
goctl --version
```

创建一个 API 微服务：
```bash
goctl api new user
cd user
go mod tidy
go run user.go -f etc/user-api.yaml
```


goctl api new <serviceName> 是官方给出的“从零开始创建新 API 项目”的命令。

创建一个 RPC 微服务：
```bash
goctl rpc new user
cd user
go mod tidy
go run user.go -f etc/user.yaml

goctl rpc new <serviceName> 是官方给出的快速生成 RPC 服务命令。
```


如果你已经有 .api 或 .proto 文件，就不是 new，而是：
```bash

goctl api go -api user.api -dir .
goctl rpc protoc user.proto --go_out=. --go-grpc_out=. --zrpc_out=.
```
这两条分别是官方文档里的 API 和 RPC 代码生成方式。

新建微服务

```bash
cd D:\Code\KrBoom\krboom_stream\go\web_server
  .\scripts\new-app.ps1 -Name article
  ```

如果要指定端口：
```bash
  .\scripts\new-app.ps1 -Name article -ApiPort 30210 -RpcPort 30610
```

