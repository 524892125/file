#!/bin/bash

set -euo pipefail

stop_one() {
    local name="$1"
    local pid_file="./bin/run/${name}.pid"

    if [ ! -f "$pid_file" ]; then
        return
    fi

    local pid
    pid="$(cat "$pid_file")"

    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
        kill "$pid"
        echo "Stopped ${name} (${pid})"
    fi

    rm -f "$pid_file"
}

stop_one "note_api"
stop_one "bit_api"
stop_one "admin_api"
stop_one "note_rpc"
stop_one "bit_rpc"
stop_one "admin_rpc"
