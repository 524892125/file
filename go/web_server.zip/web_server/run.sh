#!/bin/bash

set -euo pipefail

bash stop.sh || true

mkdir -p ./bin/logs/console ./bin/run
cd ./bin

BIT_RPC_CONFIG="${BIT_RPC_CONFIG:-etc/bit.yaml}"
NOTE_RPC_CONFIG="${NOTE_RPC_CONFIG:-etc/note.yaml}"
ADMIN_RPC_CONFIG="${ADMIN_RPC_CONFIG:-etc/admin.yaml}"
BIT_API_CONFIG="${BIT_API_CONFIG:-etc/bit-api.yaml}"
NOTE_API_CONFIG="${NOTE_API_CONFIG:-etc/note-api.yaml}"
ADMIN_API_CONFIG="${ADMIN_API_CONFIG:-etc/admin-api.yaml}"

echo "Starting bit_rpc"
nohup ./bit_rpc -f "$BIT_RPC_CONFIG" >> ./logs/console/bit_rpc.log 2>&1 &
echo $! > ./run/bit_rpc.pid

echo "Starting note_rpc"
nohup ./note_rpc -f "$NOTE_RPC_CONFIG" >> ./logs/console/note_rpc.log 2>&1 &
echo $! > ./run/note_rpc.pid

echo "Starting admin_rpc"
nohup ./admin_rpc -f "$ADMIN_RPC_CONFIG" >> ./logs/console/admin_rpc.log 2>&1 &
echo $! > ./run/admin_rpc.pid

sleep 2

echo "Starting bit_api"
nohup ./bit_api -f "$BIT_API_CONFIG" >> ./logs/console/bit_api.log 2>&1 &
echo $! > ./run/bit_api.pid

echo "Starting note_api"
nohup ./note_api -f "$NOTE_API_CONFIG" >> ./logs/console/note_api.log 2>&1 &
echo $! > ./run/note_api.pid

echo "Starting admin_api"
nohup ./admin_api -f "$ADMIN_API_CONFIG" >> ./logs/console/admin_api.log 2>&1 &
echo $! > ./run/admin_api.pid
