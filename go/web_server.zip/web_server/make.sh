#!/bin/bash

set -euo pipefail

mkdir -p ./bin/etc

echo "Building bit_rpc"
go build -o ./bin/bit_rpc ./apps/bit/rpc/bit.go
cp ./apps/bit/rpc/etc/* ./bin/etc/

echo "Building note_rpc"
go build -o ./bin/note_rpc ./apps/note/rpc/note.go
cp ./apps/note/rpc/etc/* ./bin/etc/

echo "Building admin_rpc"
go build -o ./bin/admin_rpc ./apps/admin/rpc/admin.go
cp ./apps/admin/rpc/etc/* ./bin/etc/

echo "Building bit_api"
go build -o ./bin/bit_api ./apps/bit/api/bit.go
cp ./apps/bit/api/etc/* ./bin/etc/

echo "Building note_api"
go build -o ./bin/note_api ./apps/note/api/note.go
cp ./apps/note/api/etc/* ./bin/etc/

echo "Building admin_api"
go build -o ./bin/admin_api ./apps/admin/api/admin.go
cp ./apps/admin/api/etc/* ./bin/etc/
