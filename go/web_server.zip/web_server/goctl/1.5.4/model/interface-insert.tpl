Insert(ctx context.Context, data *{{.upperStartCamelObject}}) (sql.Result,error)
InsertList(ctx context.Context, list []*{{.upperStartCamelObject}}) (sql.Result,error)