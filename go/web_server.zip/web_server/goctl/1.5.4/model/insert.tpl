func (m *default{{.upperStartCamelObject}}Model) Insert(ctx context.Context, data *{{.upperStartCamelObject}}) (sql.Result,error) {
	{{if .withCache}}{{.keys}}
    ret, err := m.ExecCtx(ctx, func(ctx context.Context, conn sqlx.SqlConn) (result sql.Result, err error) {
		query := fmt.Sprintf("insert into %s (%s) values ({{.expression}})", m.table, {{.lowerStartCamelObject}}RowsExpectAutoSet)
		return conn.ExecCtx(ctx, query, {{.expressionValues}})
	}, {{.keyValues}}){{else}}query := fmt.Sprintf("insert into %s (%s) values ({{.expression}})", m.table, {{.lowerStartCamelObject}}RowsExpectAutoSet)
    ret,err:=m.conn.ExecCtx(ctx, query, {{.expressionValues}}){{end}}
	return ret,err
}

func (m *default{{.upperStartCamelObject}}Model) InsertList(ctx context.Context, list []*{{.upperStartCamelObject}}) (sql.Result,error) {
    args := make([]any,0,len(list)*len({{.lowerStartCamelObject}}RowsExpectAutoSetFieldNames))
    valueStr := strings.Builder{}
    ph := "{{.expression}}"
	for i, data := range list {
        args = append(args, {{.expressionValues}})
        valueStr.WriteString("(")
        valueStr.WriteString(ph)
        valueStr.WriteString(")")
        if i != len(list)-1 {
            valueStr.WriteString(",")
        }
    }

	query := fmt.Sprintf("insert into %s (%s) values %s", m.table, {{.lowerStartCamelObject}}RowsExpectAutoSet, valueStr.String())
    ret,err:=m.conn.ExecCtx(ctx, query, args...)
	return ret,err
}
