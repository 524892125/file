package {{.pkg}}
{{if .withCache}}
import (
        "github.com/zeromicro/go-zero/core/stores/cache"
        "github.com/zeromicro/go-zero/core/stores/sqlx"
)
{{else}}

import "github.com/zeromicro/go-zero/core/stores/sqlx"
{{end}}
var _ {{.upperStartCamelObject}}Model = (*custom{{.upperStartCamelObject}}Model)(nil)

type (
        // {{.upperStartCamelObject}}Model is an interface to be customized, add more methods here,
        // and implement the added methods in custom{{.upperStartCamelObject}}Model.
        {{.upperStartCamelObject}}Model interface {
                {{.lowerStartCamelObject}}Model
                ro{{.upperStartCamelObject}}Model
        }

        // ro{{.upperStartCamelObject}}Model is an interface to be customized, add more read only methods here.
        ro{{.upperStartCamelObject}}Model interface {
        }


        customRo{{.upperStartCamelObject}}Model struct {
            rdbConn sqlx.SqlConn
        }

        custom{{.upperStartCamelObject}}Model struct {
                *default{{.upperStartCamelObject}}Model
                *customRo{{.upperStartCamelObject}}Model
        }
)


// New{{.upperStartCamelObject}}Model returns a model for the database table.
func New{{.upperStartCamelObject}}Model(conn, rdbConn sqlx.SqlConn{{if .withCache}}, c cache.CacheConf, opts ...cache.Option{{end}}) {{.upperStartCamelObject}}Model {
        return &custom{{.upperStartCamelObject}}Model{
                default{{.upperStartCamelObject}}Model: new{{.upperStartCamelObject}}Model(conn{{if .withCache}}, c, opts...{{end}}),
                customRo{{.upperStartCamelObject}}Model: &customRo{{.upperStartCamelObject}}Model{
                    rdbConn: rdbConn,
                },

        }
}
