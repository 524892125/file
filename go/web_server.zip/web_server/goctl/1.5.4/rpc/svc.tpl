package svc

import {{.imports}}
import "github.com/zeromicro/go-zero/core/stores/sqlx"

type ServiceContext struct {
	Config config.Config
	DB sqlx.SqlConn
	RDB sqlx.SqlConn
}

func NewServiceContext(c config.Config) *ServiceContext {
    dbConn := sqlx.NewMysql(c.Mysql.DataSource)
    rdbConn := sqlx.NewMysql(c.Mysql.SlaveSource)
	return &ServiceContext{
		Config:c,
		DB: dbConn,
		RDB: rdbConn,
	}
}
