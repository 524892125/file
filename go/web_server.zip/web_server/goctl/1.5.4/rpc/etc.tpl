Name: {{.serviceName}}.rpc
ListenOn: 0.0.0.0:8080 # TODO your port
Etcd:
  Hosts:
  - 127.0.0.1:2379
  Key: {{.serviceName}}.rpc

Mysql:
  DataSource: # TODO your master datasource
  SlaveSource: # TODO your slave datasource

LogConf:
  ServiceName: {{.serviceName}}.rpc
  Mode: file # TODO your log mode
  Encoding: json
  Path: /your/log/path # TODO your log path
  Level: info
  Stat: true
  KeepDays: 7

