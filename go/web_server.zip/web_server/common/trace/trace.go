package trace

import (
	"context"
	"go.opentelemetry.io/otel/trace"
)

func CtxClone(oriCtx context.Context) context.Context {
	spanCtx := trace.SpanContextFromContext(oriCtx)
	return trace.ContextWithSpanContext(context.Background(), spanCtx)
}
