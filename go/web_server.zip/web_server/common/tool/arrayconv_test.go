package tool

import (
	"reflect"
	"testing"
)

func TestOneAsList(t *testing.T) {
	var tInt int
	type args[T any] struct {
		t T
	}
	type testCase[T any] struct {
		name string
		args args[T]
		want []T
	}
	tests := []testCase[*int]{
		{
			name: "nil pointer",
			args: args[*int]{t: nil},
			want: []*int{nil},
		},
		{
			name: "int pointer",
			args: args[*int]{t: &tInt},
			want: []*int{&tInt},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := OneAsList(tt.args.t); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("OneAsList() = %v, want %v", got, tt.want)
			}
		})
	}
}

//
// func TestTakeFieldListFrom(t *testing.T) {
// 	type temp struct {
// 		A string
// 		b int
// 		c *int
// 	}
// 	type args[T any, P any] struct {
// 		from []T
// 		take func(T) P
// 	}
// 	type testCase[T any, P any] struct {
// 		name    string
// 		args    args[T, P]
// 		wantRes []P
// 		wantErr bool
// 	}
// 	tests := []testCase[temp, uint]{
// 		{name: "no such type", args: args[temp, uint]{
// 			from: []temp{{
// 				A: "1",
// 				b: 1,
// 				c: nil,
// 			}},
// 			take: func(temp temp) uint {
// 				if temp.b > 1 {
// 					return uint(temp.b)
// 				}
// 				return 0
// 			},
// 		}, wantRes: []uint{0}, wantErr: false},
//
// 		{name: "have value", args: args[temp, uint]{
// 			from: []temp{{
// 				A: "1",
// 				b: 1,
// 				c: nil,
// 			}},
// 			take: func(temp temp) uint {
// 				return uint(temp.b)
// 			},
// 		}, wantRes: []uint{1}, wantErr: false},
//
// 		{name: "panic", args: args[temp, uint]{
// 			from: []temp{{
// 				A: "1",
// 				b: 1,
// 				c: nil,
// 			}},
// 			take: func(temp temp) uint {
// 				u := make([]int, 0)
// 				u[1] = 1
// 				return 1
// 			},
// 		}, wantRes: nil, wantErr: true},
// 	}
// 	for _, tt := range tests {
// 		t.Run(tt.name, func(t *testing.T) {
// 			gotRes, err := TakeFieldListFrom(tt.args.from, tt.args.take)
// 			if (err != nil) != tt.wantErr {
// 				t.Errorf("TakeFieldListFrom() error = %v, wantErr %v", err, tt.wantErr)
// 				return
// 			}
// 			if !reflect.DeepEqual(gotRes, tt.wantRes) {
// 				t.Errorf("TakeFieldListFrom() gotRes = %v, want %v", gotRes, tt.wantRes)
// 			}
// 		})
// 	}
// }
