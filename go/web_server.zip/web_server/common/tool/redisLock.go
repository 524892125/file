package tool

import (
	"context"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/stores/redis"
	"time"
)

func GetRedisLock(ctx context.Context, redisClient *redis.Redis, lockKey string, duration int) *redis.RedisLock {
	lock := redis.NewRedisLock(redisClient, lockKey)
	lock.SetExpire(duration)
	acquire, err := lock.AcquireCtx(ctx)
	if err != nil {
		logx.WithContext(ctx).Errorw("acquire lock", logx.Field("key", lockKey), logx.Field("err", err))
		return nil
	}

	if !acquire {
		return nil
	} else {
		return lock
	}
}

func GetRedisLockRetry(ctx context.Context, redisClient *redis.Redis, lockKey string, duration int) *redis.RedisLock {
	lock := redis.NewRedisLock(redisClient, lockKey)
	lock.SetExpire(duration)
	acquire, err := lock.AcquireCtx(ctx)
	if err != nil {
		logx.WithContext(ctx).Errorw("acquire lock", logx.Field("key", lockKey), logx.Field("err", err))
	}

	// 获取锁失败，重试
	if !acquire {
		for i := 0; i < 5; i++ {
			lock := redis.NewRedisLock(redisClient, lockKey)
			lock.SetExpire(duration)
			acquire, err := lock.AcquireCtx(ctx)
			if err != nil {
				logx.WithContext(ctx).Errorf("acquire lock time%d, key=%s, err=%s", i+1, lockKey, err.Error())
			}
			if !acquire {
				logx.WithContext(ctx).Infof("acquire lock fail time%d, key=%s", i+1, lockKey)
				time.Sleep(time.Millisecond * 300)
				continue
			}
			return lock
		}
	} else {
		return lock
	}
	return nil
}
