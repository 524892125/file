package tool

import (
	"github.com/spf13/cast"
	"math/rand"
	"reflect"
	"strings"
	"time"
)

// 判断obj是否在target中，target支持的类型array,slice,map
func Contain(obj interface{}, target interface{}) bool {
	targetValue := reflect.ValueOf(target)
	switch reflect.TypeOf(target).Kind() {
	case reflect.Slice, reflect.Array:
		for i := 0; i < targetValue.Len(); i++ {
			if targetValue.Index(i).Interface() == obj {
				return true
			}
		}
	case reflect.Map:
		if targetValue.MapIndex(reflect.ValueOf(obj)).IsValid() {
			return true
		}
	}

	return false
}

// 生成订单id
func GetOrderId(uid int64) string {
	now := time.Now()

	uidStr := cast.ToString(uid)
	yy := now.Format("060102150405.999")
	yy = strings.Replace(yy, ".", "", -1)
	r := GetRandomCodeFromNumber(3)
	if len(yy+r) != 18 {
		return GetOrderId(uid)
	}
	return uidStr + yy + r
}

// 获取n个随机的0-9的纯数字字符
func GetRandomCodeFromNumber(n int) string {
	letters := []rune("0123456789")
	rd := rand.New(rand.NewSource(time.Now().UnixNano()))
	b := make([]rune, n)
	for i := range b {
		b[i] = letters[rd.Intn(len(letters))]
	}
	return string(b)
}

func GenerateRandomString(length int) string {
	rand.New(rand.NewSource(time.Now().UnixNano()))

	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	result := make([]byte, length)
	for i := range result {
		result[i] = charset[rand.Intn(len(charset))]
	}

	return string(result)
}

// 去重
func Deduplicate[T any](arr []T) []T {
	keys := make(map[interface{}]struct{})
	deduplicated := make([]T, 0)

	for _, element := range arr {
		key := interface{}(element)

		if _, ok := keys[key]; !ok {
			keys[key] = struct{}{}
			deduplicated = append(deduplicated, element)
		}
	}

	return deduplicated
}

func ListContains[T comparable](tt []T, target T) bool {

	for _, t := range tt {
		if t == target {
			return true
		}
	}

	return false
}

func ListRemoveIfContains[T comparable](tt []T, target T) (bool, []T) {
	res := make([]T, 0, len(tt))
	var contains = false
	for _, t := range tt {
		if t == target {
			contains = true
			continue
		}
		res = append(res, t)
	}
	return contains, res
}

func Prepend[T any](tt []T, t T) []T {
	tt = append(tt, t)
	copy(tt[1:], tt)
	tt[0] = t
	return tt
}

// GetBit 获取指定二进制位的状态
func GetBit(num, bitPos uint) bool {
	return (num & (1 << bitPos)) != 0
}

// SetBit 将指定二进制位设置为1，其他位保持不变
func SetBit(num, bitPos uint) uint {
	return num | (1 << bitPos)
}

// ClearBit 将指定二进制位清零，其他位保持不变
func ClearBit(num, bitPos uint) uint {
	return num &^ (1 << bitPos)
}

// ToggleBit 切换指定二进制位，其他位保持不变
func ToggleBit(num, bitPos uint) uint {
	return num ^ (1 << bitPos)
}

// RandomIntBetween  记得初始化rand.Seed
func RandomIntBetween(min, max int64) int64 {
	// 记得初始化rand.Seed
	return rand.Int63n(max-min+1) + min
}
