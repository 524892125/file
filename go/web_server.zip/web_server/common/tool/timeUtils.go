package tool

import (
	"github.com/golang-module/carbon"
	"time"
)

// Riyadh 沙特时区
const Riyadh = "Asia/Riyadh"

var SpartyServerLocation, _ = time.LoadLocation("Asia/Shanghai")
var RiyadhServerLocation, _ = time.LoadLocation("Asia/Riyadh")

const (
	DateTimeSecondFormat = "Y-m-d H:i:s"
	ShortDateFormat      = "Ymd"
)

// 获取沙特本周开始时间
func GetArbWeekStartTime() carbon.Carbon {
	return carbon.Now(Riyadh).SetWeekStartsAt(carbon.Monday).StartOfWeek()
}

func GetArbWeekStartTimeByWeekOffset(weekOffset int) carbon.Carbon {
	return carbon.Now(Riyadh).SetWeekStartsAt(carbon.Monday).AddWeeks(weekOffset).StartOfWeek()
}

// 获取沙特本周结束时间
func GetArbWeekEndTime() carbon.Carbon {
	return carbon.Now(Riyadh).SetWeekStartsAt(carbon.Monday).EndOfWeek()
}

// 获取沙特上周开始时间
func GetArbLastWeekStartTime() carbon.Carbon {
	return carbon.Now(Riyadh).AddDays(-7).SetWeekStartsAt(carbon.Monday).StartOfWeek()
}

// 获取沙特上周结束时间
func GetArbLastWeekEndTime() carbon.Carbon {
	return carbon.Now(Riyadh).AddDays(-7).SetWeekStartsAt(carbon.Monday).EndOfWeek()
}

// 获取沙特本月开始时间
func GetArbThisMonthStartTime() carbon.Carbon {
	return carbon.Now(Riyadh).StartOfMonth()
}

// 获取沙特本月开始时间对应的北京时间
func GetThisMonthStartTime() carbon.Carbon {
	return carbon.Now(Riyadh).StartOfMonth().AddHours(5)
}

// 获取沙特今日开始时间对应的北京时间
func GetTodayStartTime() carbon.Carbon {
	return carbon.Now(Riyadh).StartOfDay().AddHours(5)
}

func GetTodayEndTime() carbon.Carbon {
	return carbon.Now(Riyadh).EndOfDay().AddHours(5)
}

// 根据北京时间(毫米级)获取沙特时间
func GetRiyadhTime(timestamp int64) carbon.Carbon {
	return carbon.CreateFromTimestampMilli(timestamp).SetWeekStartsAt(carbon.Monday).AddHours(-5)
}

// 根据timestamp(秒级)获取时间
func GetTimeByTimestamp(timestamp int64) carbon.Carbon {
	return carbon.CreateFromTimestamp(timestamp)
}

// 根据timestamp(毫米级)获取时间
func GetTimeByTimestampMilli(timestampMilli int64) carbon.Carbon {
	return carbon.CreateFromTimestampMilli(timestampMilli)
}

// 获取沙特当前时间
func GetRiyadhTimeNow() carbon.Carbon {
	return carbon.Now(Riyadh).SetWeekStartsAt(carbon.Monday)
}

func GetServerBeginOfMonth() time.Time {
	y, m, _ := time.Now().Date()
	return time.Date(y, m, 1, 0, 0, 0, 0, SpartyServerLocation)
}

// GetRiyadhEarlyMorningString 阿拉伯当天的凌晨时间
func GetRiyadhEarlyMorningString() string {
	return carbon.Now(Riyadh).Layout("20060102")
}

func FormatTimestamp(mills int64) string {
	return carbon.CreateFromTimestampMilli(mills).Format(DateTimeSecondFormat)
}

func FormatTimestampWithFormat(mills int64, format string) string {
	return carbon.CreateFromTimestampMilli(mills).Format(format)
}

func IsNowBetween(startTime, endTime int64) bool {
	now := time.Now().UnixMilli()
	return startTime <= now && now <= endTime
}

// DiffInDaysHoursMinutesSeconds 计算两个时间相差几天几时几分几秒
func DiffInDaysHoursMinutesSeconds(start carbon.Carbon, end carbon.Carbon) (days, hours, minutes, seconds int64) {
	days = start.DiffInDays(end)
	hours = start.DiffInHours(end) % 24
	minutes = start.DiffInMinutes(end) % 60
	seconds = start.DiffInSeconds(end) % 60
	return
}

// GetArbWeekStartTime 获取沙特本周开始时间对应北京时间
func GetWeekStartTime() carbon.Carbon {
	return carbon.Now(Riyadh).SetWeekStartsAt(carbon.Monday).StartOfWeek().SetLocation(SpartyServerLocation)
}

func GetArbWeekStartTimeByTs(mills int64) carbon.Carbon {
	return carbon.CreateFromTimestampMilli(mills, Riyadh).SetWeekStartsAt(carbon.Monday).StartOfWeek().SetLocation(SpartyServerLocation)
}

func GetArbMonthStartTimeByTs(mills int64) carbon.Carbon {
	return carbon.CreateFromTimestampMilli(mills, Riyadh).StartOfMonth().SetLocation(SpartyServerLocation)
}
