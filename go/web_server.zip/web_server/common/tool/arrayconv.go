package tool

import (
	"github.com/spf13/cast"
	"strconv"
	"strings"
)

func Int64sToStr(ii []int64) string {
	ss := make([]string, 0, len(ii))
	for _, i := range ii {
		ss = append(ss, strconv.FormatInt(i, 10))
	}
	return strings.Join(ss, ",")
}

func Int64sToStrs(ii []int64) []string {
	ss := make([]string, 0, len(ii))
	for _, i := range ii {
		ss = append(ss, strconv.FormatInt(i, 10))
	}
	return ss
}

func StrsToInt64(ss []string) []int64 {
	ii := make([]int64, 0, len(ss))
	for _, s := range ss {
		ii = append(ii, cast.ToInt64(s))
	}
	return ii
}

func ConvertAnyList[T any](ll []T) []any {
	res := make([]any, 0, len(ll))
	for _, l := range ll {
		res = append(res, l)
	}
	return res
}

func MapKeyToList[T comparable, V any](m map[T]V) []T {
	res := make([]T, 0, len(m))
	for t := range m {
		res = append(res, t)
	}
	return res
}

func OneAsList[T any](t T) []T {
	return []T{t}
}

func ListToSet[T comparable](ll []T) map[T]struct{} {
	m := make(map[T]struct{}, len(ll))
	for _, t := range ll {
		m[t] = struct{}{}
	}
	return m
}

// func TakeFieldListFrom[T any, P any](from []T, take func(T) P) (res []P, err error) {
// 	defer func() {
// 		if p := recover(); p != nil {
// 			res = nil
// 			err = fmt.Errorf("TakeFieldListFrom fail, err: %v", p)
// 		}
// 	}()
// 	res = make([]P, 0, len(from))
// 	for _, item := range from {
// 		res = append(res, take(item))
// 	}
// 	return
// }
