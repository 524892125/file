package tool

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
)

func GetRealIP(r *http.Request) string {
	// 获取 RemoteAddr 字段
	ip := r.RemoteAddr

	// 如果请求经过代理，通常代理会将真实地址存储在请求头中
	// 常见的代理头是 X-Real-IP 和 X-Forwarded-For
	// 您可以根据需要检查这些头以获取真实地址
	xRealIP := r.Header.Get("X-Real-IP")
	xForwardedFor := r.Header.Get("X-Forwarded-For")

	if xForwardedFor != "" {
		// 否则，如果 X-Forwarded-For 存在，通常它包含一个逗号分隔的 IP 地址列表
		// 第一个 IP 地址通常是真实地址
		ips := strings.Split(xForwardedFor, ",")
		if len(ips) > 0 {
			ip = strings.TrimSpace(ips[0])
		}
	} else if xRealIP != "" {
		// 如果 X-Real-IP 存在且合法，使用它
		ip = xRealIP
	}

	// 移除端口部分（如果有）
	idx := strings.LastIndex(ip, ":")
	if idx != -1 {
		ip = ip[:idx]
	}
	return ip
}

type IpInfoResult struct {
	Ret  int        `json:"ret"`
	Msg  string     `json:"msg"`
	Data DataIpInfo `json:"data"`
}

type DataIpInfo struct {
	Area      string `json:"area"`
	RegionId  string `json:"region_id"`
	Country   string `json:"country"`
	CountryId string `json:"country_id"`
}

func GetIPInfo(ip, appcode string) (ipInfo DataIpInfo) {
	url := "https://bf1c.api.huachen.cn/ip"
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		fmt.Println("Error creating request:", err)
		return
	}
	// 设置请求头
	req.Header.Set("Authorization", "APPCODE "+appcode)

	// 添加查询参数
	q := req.URL.Query()
	q.Add("ip", ip)
	req.URL.RawQuery = q.Encode()

	client := &http.Client{}

	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("Error sending request:", err)
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		fmt.Println("Response status:", resp.Status)
		return
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("Error reading response body:", err)
		return
	}

	data := new(IpInfoResult)
	json.Unmarshal(body, data)

	if data != nil {
		ipInfo = data.Data
	}
	return
}
