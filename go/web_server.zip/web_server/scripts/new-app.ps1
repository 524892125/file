param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[a-z][a-z0-9_]*$')]
    [string]$Name,

    [int]$ApiPort = 0,

    [int]$RpcPort = 0,

    [string]$Template = "bit",

    [switch]$Force,

    [switch]$SkipProtoRegenerate
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-PascalCase {
    param([Parameter(Mandatory = $true)][string]$Value)

    $parts = $Value -split '[_-]' | Where-Object { $_ }
    $words = foreach ($part in $parts) {
        if ($part.Length -eq 1) {
            $part.ToUpperInvariant()
            continue
        }

        $part.Substring(0, 1).ToUpperInvariant() + $part.Substring(1).ToLowerInvariant()
    }

    return ($words -join '')
}

function Get-PluralToken {
    param([Parameter(Mandatory = $true)][string]$Token)

    if ($Token -match '[^aeiou]y$') {
        return $Token.Substring(0, $Token.Length - 1) + 'ies'
    }

    if ($Token -match '(s|x|z|ch|sh)$') {
        return $Token + 'es'
    }

    return $Token + 's'
}

function Get-PluralName {
    param([Parameter(Mandatory = $true)][string]$Value)

    $parts = $Value -split '_'
    $lastIndex = $parts.Length - 1
    $parts[$lastIndex] = Get-PluralToken -Token $parts[$lastIndex]
    return ($parts -join '_')
}

function Get-MaxValue {
    param([int[]]$Values, [int]$Fallback)

    if (-not $Values -or $Values.Count -eq 0) {
        return $Fallback
    }

    return ($Values | Measure-Object -Maximum).Maximum
}

function Get-NextApiPort {
    param([Parameter(Mandatory = $true)][string]$AppsDir)

    $ports = @()
    Get-ChildItem -Path $AppsDir -Directory | ForEach-Object {
        $etcDir = Join-Path $_.FullName 'api\etc'
        if (-not (Test-Path $etcDir)) {
            return
        }

        Get-ChildItem -Path $etcDir -Filter '*-api.yaml' -File | ForEach-Object {
            $content = [System.IO.File]::ReadAllText($_.FullName)
            $match = [regex]::Match($content, '(?m)^\s*Port:\s*(\d+)\s*$')
            if ($match.Success) {
                $ports += [int]$match.Groups[1].Value
            }
        }
    }

    return (Get-MaxValue -Values $ports -Fallback 30189) + 1
}

function Get-NextRpcPort {
    param([Parameter(Mandatory = $true)][string]$AppsDir)

    $ports = @()
    Get-ChildItem -Path $AppsDir -Directory | ForEach-Object {
        $etcDir = Join-Path $_.FullName 'rpc\etc'
        if (-not (Test-Path $etcDir)) {
            return
        }

        Get-ChildItem -Path $etcDir -Filter '*.yaml' -File | ForEach-Object {
            $content = [System.IO.File]::ReadAllText($_.FullName)
            $match = [regex]::Match($content, '(?m)^\s*ListenOn:\s*[^:]+:(\d+)\s*$')
            if ($match.Success) {
                $ports += [int]$match.Groups[1].Value
            }
        }
    }

    return (Get-MaxValue -Values $ports -Fallback 30589) + 1
}

function Rename-TokenInTree {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$OldToken,
        [Parameter(Mandatory = $true)][string]$NewToken
    )

    $items = Get-ChildItem -Path $Root -Recurse -Force |
        Sort-Object { $_.FullName.Length } -Descending

    foreach ($item in $items) {
        if ($item.Name -notlike "*$OldToken*") {
            continue
        }

        $newName = $item.Name.Replace($OldToken, $NewToken)
        Rename-Item -LiteralPath $item.FullName -NewName $newName
    }
}

function Convert-TemplateContent {
    param(
        [Parameter(Mandatory = $true)][string]$Content,
        [Parameter(Mandatory = $true)][hashtable]$Tokens
    )

    $protectedModule = '__BIT_SERVER_MODULE__'
    $converted = $Content.Replace('web_server', $protectedModule)

    $replacements = @(
        @{ From = 'bit-api'; To = "$($Tokens.SingularLower)-api" },
        @{ From = 'bit_api'; To = "$($Tokens.SingularLower)_api" },
        @{ From = 'bit-rpc'; To = "$($Tokens.SingularLower)-rpc" },
        @{ From = 'bit_rpc'; To = "$($Tokens.SingularLower)_rpc" },
        @{ From = 'bit.rpc'; To = "$($Tokens.SingularLower).rpc" },
        @{ From = 'bitClient'; To = "$($Tokens.ClientPackage)" },
        @{ From = 'Bits'; To = "$($Tokens.PluralPascal)" },
        @{ From = 'bits'; To = "$($Tokens.PluralLower)" },
        @{ From = 'Bit'; To = "$($Tokens.SingularPascal)" },
        @{ From = 'bit'; To = "$($Tokens.SingularLower)" }
    )

    foreach ($replacement in $replacements) {
        $converted = $converted.Replace($replacement.From, $replacement.To)
    }

    $converted = $converted.Replace($protectedModule, 'web_server')

    $duplicateCode = "xerr.NewErrCode(xerr.$($Tokens.SingularPascal)NameExists)"
    $duplicateMsg = "xerr.NewErrCodeMsg(xerr.RequestParamError, `"$($Tokens.SingularLower) name already exists`")"
    $converted = $converted.Replace($duplicateCode, $duplicateMsg)

    return $converted
}

function Set-Utf8File {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Content
    )

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

function Update-ConfigPorts {
    param(
        [Parameter(Mandatory = $true)][string]$TargetDir,
        [Parameter(Mandatory = $true)][string]$ServiceName,
        [Parameter(Mandatory = $true)][int]$ResolvedApiPort,
        [Parameter(Mandatory = $true)][int]$ResolvedRpcPort
    )

    $apiConfig = Join-Path $TargetDir "api\etc\$ServiceName-api.yaml"
    $rpcConfigs = @(
        (Join-Path $TargetDir "rpc\etc\$ServiceName.yaml"),
        (Join-Path $TargetDir "rpc\etc\$ServiceName-mysql.yaml")
    )

    if (Test-Path $apiConfig) {
        $content = [System.IO.File]::ReadAllText($apiConfig)
        $content = [regex]::Replace($content, '(?m)^Port:\s*\d+\s*$', "Port: $ResolvedApiPort")
        $content = [regex]::Replace($content, '(?m)^(\s*-\s*127\.0\.0\.1:)\d+\s*$', "`$1$ResolvedRpcPort")
        Set-Utf8File -Path $apiConfig -Content $content
    }

    foreach ($rpcConfig in $rpcConfigs) {
        if (-not (Test-Path $rpcConfig)) {
            continue
        }

        $content = [System.IO.File]::ReadAllText($rpcConfig)
        $content = [regex]::Replace($content, '(?m)^ListenOn:\s*0\.0\.0\.0:\d+\s*$', "ListenOn: 0.0.0.0:$ResolvedRpcPort")
        Set-Utf8File -Path $rpcConfig -Content $content
    }
}

function Try-RegenerateProto {
    param(
        [Parameter(Mandatory = $true)][string]$RpcDir,
        [Parameter(Mandatory = $true)][string]$ProtoName
    )

    $protoc = Get-Command protoc -ErrorAction SilentlyContinue
    if (-not $protoc) {
        Write-Host "protoc not found, skipped pb regeneration."
        return
    }

    Push-Location $RpcDir
    try {
        & $protoc.Source --go_out=. --go-grpc_out=. "$ProtoName.proto"
        Write-Host "Regenerated proto stubs from $ProtoName.proto"
    }
    catch {
        Write-Warning "protoc failed, kept the transformed template pb files: $($_.Exception.Message)"
    }
    finally {
        Pop-Location
    }
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$webServerDir = Split-Path -Parent $scriptDir
$appsDir = Join-Path $webServerDir 'apps'
$templateDir = Join-Path $appsDir $Template
$targetDir = Join-Path $appsDir $Name

if (-not (Test-Path $templateDir)) {
    throw "Template app not found: $templateDir"
}

if (Test-Path $targetDir) {
    if (-not $Force) {
        throw "Target app already exists: $targetDir"
    }

    Remove-Item -LiteralPath $targetDir -Recurse -Force
}

$resolvedApiPort = if ($ApiPort -gt 0) { $ApiPort } else { Get-NextApiPort -AppsDir $appsDir }
$resolvedRpcPort = if ($RpcPort -gt 0) { $RpcPort } else { Get-NextRpcPort -AppsDir $appsDir }

$singularPascal = Get-PascalCase -Value $Name
$pluralLower = Get-PluralName -Value $Name
$pluralPascal = Get-PascalCase -Value $pluralLower

$tokens = @{
    SingularLower = $Name
    SingularPascal = $singularPascal
    PluralLower = $pluralLower
    PluralPascal = $pluralPascal
    ClientPackage = "${Name}Client"
}

Copy-Item -Path $templateDir -Destination $targetDir -Recurse -Force

Rename-TokenInTree -Root $targetDir -OldToken 'bitClient' -NewToken $tokens.ClientPackage
Rename-TokenInTree -Root $targetDir -OldToken 'bit-api' -NewToken "$Name-api"
Rename-TokenInTree -Root $targetDir -OldToken 'bit_api' -NewToken "${Name}_api"
Rename-TokenInTree -Root $targetDir -OldToken 'bit-rpc' -NewToken "$Name-rpc"
Rename-TokenInTree -Root $targetDir -OldToken 'bit_rpc' -NewToken "${Name}_rpc"
Rename-TokenInTree -Root $targetDir -OldToken 'bits' -NewToken $pluralLower
Rename-TokenInTree -Root $targetDir -OldToken 'bit' -NewToken $Name

Get-ChildItem -Path $targetDir -Recurse -File | ForEach-Object {
    $original = [System.IO.File]::ReadAllText($_.FullName)
    $converted = Convert-TemplateContent -Content $original -Tokens $tokens
    Set-Utf8File -Path $_.FullName -Content $converted
}

Update-ConfigPorts -TargetDir $targetDir -ServiceName $Name -ResolvedApiPort $resolvedApiPort -ResolvedRpcPort $resolvedRpcPort

if (-not $SkipProtoRegenerate) {
    Try-RegenerateProto -RpcDir (Join-Path $targetDir 'rpc') -ProtoName $Name
}

Write-Host "Generated app: $targetDir"
Write-Host "API port: $resolvedApiPort"
Write-Host "RPC port: $resolvedRpcPort"
Write-Host "Next steps:"
Write-Host "  1. cd $webServerDir"
Write-Host "  2. go test ./apps/$Name/..."
Write-Host "  3. If needed, wire the new service into make.sh/run.sh/stop.sh"
