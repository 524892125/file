# go-zero 分层约束

本文件约束 `web_server/apps/*/{api,rpc}` 的默认实现方式。目标是让入口层稳定保持 `router/handler/server -> logic -> model/client`。

## 入口层规则

- `api/internal/handler` 只处理 HTTP 相关事项：解析参数、读取上下文、调用 logic、回写响应。
- `rpc/internal/server` 只处理 RPC 相关事项：接收 protobuf 请求、调用 request-scoped logic、返回 protobuf 响应。
- `handler` 和 `server` 不直接访问数据库、GORM、原生 SQL、仓储、第三方 SDK、跨服务 RPC client。
- `handler` 和 `server` 不承载业务编排，不在入口层直接 `new service` 执行业务。

## Logic 规则

- 业务编排放在 `internal/logic`。
- logic 默认按请求构造；HTTP 入口优先使用 `NewXxxLogic(r.Context(), svcCtx)`，RPC 入口优先使用 `NewXxxLogic(ctx, svcCtx)`。
- 如果历史模块暂时保留聚合 service 形状，也必须由入口层按请求创建，不能把长生命周期业务对象挂进 `ServiceContext`。
- logic 通过 `svcCtx` 取依赖，再调用 model、repo、RPC client、cache、resolver。

## ServiceContext 规则

- `internal/svc/ServiceContext` 只保存稳定依赖。
- 允许放入 `Config`、已加载 `Settings`、GORM/DB handle、model、repo、RPC client、resolver、cache client、共享内存 store。
- 禁止放入 `*XxxLogic`、`*XxxService` 这类业务对象。
- 共享状态如果需要跨请求复用，应该作为依赖显式放进 `ServiceContext`，不要藏在 handler/server 的局部变量里。
- 这类共享依赖文件应放在 `internal/svc/`，不要再新增 `internal/deps/` 之类的并列依赖目录。

## Model 与数据访问规则

- PostgreSQL 相关数据访问优先放在 `model` 层并优先使用 GORM。
- 入口层禁止直接写 SQL。
- logic 如果需要访问数据库，应通过 `model/repository` 或 `svcCtx` 中的稳定数据依赖完成。

## 文件命名规则

- 新增 Go 文件默认使用 `snake_case.go`。
- 同一 go-zero 层目录内，优先使用能直接表达职责的命名，例如 `api_handler.go`、`trigger_builds_logic.go`、`log_rpc_server.go`。
- repo 内已存在并被 goctl 广泛生成的 `servicecontext.go`、`rpcserver.go` 等历史命名暂不强制批量改名；新写文件不要继续扩散同类合并命名。

## 例外处理

- 不能立即按标准收敛的历史路径，必须在执行计划中登记原因、风险和后续治理动作。
- 新增例外前，先确认是否可以通过抽 request-scoped logic 或下沉到 model/repository 解决。
