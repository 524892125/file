# 设计文档索引

本目录存放面向智能体的设计原则，不放临时讨论记录。

## 当前文档

- `core-beliefs.md`
  - 智能体优先的核心工作原则
- `go-zero-layering.md`
  - `web_server` 的 `handler/server -> logic -> model/client` 分层约束
- 后续建议继续补充
  - `service-boundaries.md`
  - `config-conventions.md`
  - `verification-ladder.md`

## 使用规则

- 这里描述“为什么这样设计”。
- 具体任务怎么做，放到 `docs/PLANS.md` 和 `docs/exec-plans/`。
- 具体命令、工具、路径，放到 `docs/references/`。
- 若原则已足够稳定并需要强制执行，应继续落为测试、lint 或脚本检查。
