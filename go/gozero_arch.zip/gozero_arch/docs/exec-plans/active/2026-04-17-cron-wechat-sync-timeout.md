# 执行计划

状态：`active`

## 背景

- 任务背景：`web_server/apps/cron/rpc/internal/task/function_registry.go` 中的 `WeChatAnalysisSyncSnapshot` 在执行时出现超时。
- 为什么现在做：这是 cron 长任务执行链路的可靠性问题，已经影响微信分析同步的稳定运行。

## 目标

- 定位 `WeChatAnalysisSyncSnapshot` 的真实超时来源。
- 修复 `cron_rpc` 与下游 `krboom_release_rpc` 的超时配置不一致问题。
- 收敛长任务 lease 配置，避免任务执行期间被过早重新捞起。

## 范围

- 会改什么：`cron/rpc` 的配置、最小必要测试和本次排查文档。
- 涉及目录：
  - `docs/exec-plans/active`
  - `web_server/apps/cron/rpc/etc`
  - `web_server/apps/cron/rpc/internal/config`
  - `web_server/apps/krboom_release/rpc/internal/config`

## 明确不做什么

- 不重写微信分析同步业务逻辑。
- 不扩展为新的任务执行框架改造。
- 不改前端或无关业务服务。

## 分阶段步骤

1. 梳理 `cron_rpc -> krboom_release_rpc -> WeChatAnalysisService` 的执行链路，锁定超时来源。
2. 修复超时和 lease 的配置不一致问题，并更新相关配置测试。
3. 运行受影响包测试，确认这次回归被覆盖。

## 每阶段验证

- 阶段 1：静态确认超时发生在 `cron_rpc` 上游上下文，而不是函数注册本身。
- 阶段 2：检查配置值、测试断言和默认行为保持一致。
- 阶段 3：运行受影响包 `go test`。

## 风险与回滚

- 风险：提高超时和 lease 会延长异常任务占用窗口。
- 回滚方式：回退本次 `cron/rpc` 配置和测试改动。

## 决策日志

- 2026-04-17：初始计划建立。
- 2026-04-17：确认 `cron_rpc` 生产配置超时为 90 秒，而 `krboom_release_rpc` 及测试配置已是 900 秒，存在明显不一致。

## 收尾状态

- 当前状态：进行中，正在修复 `WeChatAnalysisSyncSnapshot` 长任务超时与 lease 过短问题。
- 完成后移动到：`docs/exec-plans/completed/`
- 遗留事项登记到：`docs/exec-plans/tech-debt-tracker.md`
