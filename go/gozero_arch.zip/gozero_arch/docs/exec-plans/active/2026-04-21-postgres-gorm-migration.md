# PostgreSQL GORM Migration

状态：`active`

## 背景

- 任务背景：`web_server` 内多个服务和模型层直接使用 `database/sql`、`Query*`、`Exec*` 与 PostgreSQL 交互，SQL 语句分散在仓储实现中。
- 为什么现在做：用户要求统一改为优先使用 GORM 操作 PostgreSQL，并把该约束沉淀为代码侧可执行规则，而不是只留在对话里。

## 目标

- 为 `web_server` 建立统一的 GORM PostgreSQL 访问基础设施。
- 将项目内 PostgreSQL 交互从原生 `database/sql`/手写 SQL 逐步迁移到 GORM。
- 增加“PostgreSQL 优先使用 GORM”的仓库内约束，尽量用脚本/检查替代口头约束。

## 范围

- 会改什么：
- `web_server/go.mod` 与相关依赖。
- 公共数据库基础设施，提供 GORM Postgres 连接与复用入口。
- 受影响仓储/模型层，优先改造当前明确使用 PostgreSQL 的模块。
- 工程约束文档与检查脚本，限制新增原生 PostgreSQL SQL 写法。
- 涉及目录：
- `web_server/common/**`
- `web_server/apps/**/model/**`
- `web_server/apps/**/internal/svc/**`
- `web_server/scripts/**`
- `docs/**`

## 明确不做什么

- 不在本次改造里重写非 PostgreSQL 外部系统调用逻辑。
- 不为了“全部统一”重做业务接口契约或返回结构。
- 不无差别替换 migration 原生 SQL；migration runner 是否保留原生 SQL 将单独判断。

## 分阶段步骤

1. 建立基础设施：盘点原生 PostgreSQL 交互落点，引入 GORM Postgres 依赖和公共连接工厂。
2. 建立约束：增加项目内规范与检查脚本，阻止新增原生 PostgreSQL 操作。
3. 分模块迁移：按风险和影响面迁移仓储层，优先改造 `krboom_release`、`kiif_gm`、`cron`、`log` 这类自建仓储。
4. 收尾验证：执行受影响包测试/构建，记录未迁移范围与后续债务。

## 每阶段验证

- 阶段 1：`go test`/`go build` 覆盖新增公共基础设施所在包。
- 阶段 2：执行约束脚本，确认新增规则可运行且不会误报已允许的例外。
- 阶段 3：对每个迁移模块运行最小受影响包测试。
- 阶段 4：汇总运行主要受影响包测试，并静态检查文档、脚本、依赖一致性。

## 风险与回滚

- 风险：
- GORM 映射与现有表结构、软删除字段、JSON 字段、`ON CONFLICT` 语义可能不完全一致。
- 事务边界和查询性能可能因改写方式变化而回归。
- 范围较大，容易混入与 PostgreSQL/GORM 无关的重构。
- 回滚方式：
- 以模块为单位提交与验证，单模块异常时可局部回退到原仓储实现。
- 对难以安全迁移的落点保留明确例外，并记录到遗留事项。

## 决策日志

- 2026-04-21：初始计划建立，先做盘点、基础设施和约束，再按模块迁移。
- 2026-04-21：本轮先迁移 `krboom_release` 模块的 PostgreSQL 仓储，并用 allowlist 约束剩余未迁移原生 SQL 文件，避免一次性横扫全仓带来高风险回归。
- 2026-04-21：本轮继续把 `apps/admin/model/adminapi` 目录内各模型文件改成真正的 GORM 查询/写入实现，仅保留 `admin_api_model.go` 里的兼容执行层作为过渡。
- 2026-04-21：`apps/kiif_gm/model/repository.go` 与 `apps/cron/rpc/internal/task/repository.go` 统一切到 GORM SQL runner / 事务入口，保留原有 SQL 语义以降低调度与租户数据源逻辑回归风险。
- 2026-04-21：`apps/kiif_gm/rpc/internal/service/data_source_probe_service.go` 的 `SELECT 1` 探活改为通过 GORM 发起，仓库级 allowlist 收缩到 1 个兼容文件。
- 2026-04-21：`apps/admin/model/adminapi/admin_api_model.go` 的原生 SQL 兼容执行层已移除，`dept_model.go` 中的 `Raw("replace(...)")` 也改成 `gorm.Expr(...)`，allowlist 清空。
- 2026-04-21：`apps/kiif_gm/model/repository.go` 的租户数据源与物料目录查询改为 GORM builder + 行扫描，避免重复列名导致字段映射丢失，同时保留无原生 SQL 文本的实现。
- 2026-04-21：删除未使用的 `common/postgres/sql_runner.go`，并把 `common/postgres` 纳入 `check_postgres_gorm.sh` 约束范围。

## 收尾状态

- 当前状态：执行中，已完成 GORM 基础设施、仓库级约束脚本，`krboom_release/model/{oceanengine,wechat_analysis}`、`apps/admin/model/adminapi`、`apps/kiif_gm/model`、`apps/cron/rpc/internal/task`、`apps/log/model` 的本轮目标迁移；当前 allowlist 已清空，脚本同时覆盖 `common/postgres` 残留入口。
- 完成后移动到：`docs/exec-plans/completed/`
- 遗留事项登记到：`docs/exec-plans/tech-debt-tracker.md`
