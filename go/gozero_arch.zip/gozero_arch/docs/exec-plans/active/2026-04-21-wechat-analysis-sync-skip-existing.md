# WeChat Analysis 同步跳过已存在快照

状态：`active`

## 目标

- 修正 `/api/v1/krboom-publish/wechat-analysis/sync` 在异步轮询过程中的返回，使前端能区分“执行中”和“已完成明细”。
- 同步前按快照唯一键判断数据库是否已有数据，已有则跳过，减少无效微信接口请求。
- 前后端同时补充“跳过数量 / 写入数量 / 明细列表”的展示。

## 范围

- `web_server/apps/krboom_release/common/types/wechat_analysis.go`
- `web_server/apps/krboom_release/model/wechatanalysis/**`
- `web_server/apps/krboom_release/rpc/internal/logic/wechat_analysis_service.go`
- `go-admin-ui-vue3/src/views/krboom-publish/wechat-analysis/index.vue`

## 步骤

1. 为快照仓库增加按 `request_hash` 查询/批量查询能力。
2. 在同步逻辑中先判断哪些请求已存在，已存在则跳过微信请求并记录跳过结果。
3. 扩展同步响应，返回跳过统计和更完整的异步状态数据。
4. 更新前端统计和明细展示。
5. 运行后端定向测试与前端构建。
