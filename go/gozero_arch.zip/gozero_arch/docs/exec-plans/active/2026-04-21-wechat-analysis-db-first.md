# WeChat Analysis 数据库优先收敛

状态：`active`

## 背景

- 当前微信分析页面虽然已经拆成总览、同步、快照、实时调试，但“实时调试”仍然占据过重位置。
- 当前自动创建的微信分析 cron 任务默认参数是 `{"sync_all_apps":true,"recent_periods":1}`，会压掉服务端针对留存、LTV 等指标的 `RecommendedDaysAgo` 调度策略。
- 用户要求把微信数据以“定时任务同步到本地数据库，然后主要从数据库查看”为主，实时查询只保留为小功能。

## 目标

- 自动同步路径默认对准“全量指标、全应用、按指标推荐窗口回补”。
- 页面主路径收敛成“总览 + 快照查询 + 补数回灌”，实时查询降级为高级调试能力。
- 兼容已存在的旧 cron 任务配置，避免只改模板不改线上现存任务。

## 范围

- `web_server/apps/admin/api/internal/handler/krboom_publish_handler.go`
- `web_server/apps/admin/api/internal/handler/krboom_publish_handler_test.go`
- `go-admin-ui-vue3/src/views/krboom-publish/wechat-analysis/index.vue`

## 明确不做什么

- 本轮不新增新的路由或菜单。
- 本轮不引入新的后端 summary RPC / API。
- 本轮不重写微信请求拆窗执行器。

## 分阶段步骤

1. 调整微信 cron 模板默认参数，去掉强制 `recent_periods=1`。
2. 修改 cron 自动创建逻辑，使已有旧任务在发现模板变化时可以自动更新。
3. 调整前端页面，把数据库查询前置，把实时查询降为同步区内的小功能。
4. 跑受影响后端测试和前端构建验证。

## 每阶段验证

- 阶段 1：确认 cron 模板和 schedule 分支逻辑一致，不再覆盖指标推荐窗口。
- 阶段 2：新增或更新 handler 单测，覆盖微信 cron 模板更新。
- 阶段 3：前端 `npm run build` 通过。

## 风险与回滚

- 风险：
- 老租户若从未打开过微信分析页，旧 cron 任务不会立刻被修正，仍需依赖后续访问触发自修复。
- 去掉 `recent_periods=1` 后，定时同步会按指标推荐窗口抓取，执行分布会变化，需要关注 cron 执行时长。
- 回滚方式：
- 恢复 cron 模板参数和页面入口布局，保留数据库表与已有快照不变。

## 决策日志

- 2026-04-21：本轮优先修正“数据库优先”的默认路径，而不是继续扩展实时查询能力。
- 2026-04-21：cron 任务优先使用服务端已存在的 `RecommendedDaysAgo` 逻辑，而不是在任务参数里强行覆盖为 `recent_periods=1`。

## 收尾状态

- 当前状态：执行中。
- 完成后移动到：`docs/exec-plans/completed/`
- 遗留事项登记到：`docs/exec-plans/tech-debt-tracker.md`
