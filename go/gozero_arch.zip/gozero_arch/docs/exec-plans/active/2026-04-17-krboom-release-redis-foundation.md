# 执行计划

状态：`active`

## 背景

- 任务背景：`krboom_release/rpc` 需要接入 Redis，但不希望把 Redis 连接逻辑散落在业务服务里，要求统一沉淀到 `web_server/common/redis/redis_tools.go`。
- 为什么现在做：当前 `web_server/common/redis/redis_tools.go` 为空文件，`krboom_release/rpc` 也还没有正式的 Redis 注入链路。如果现在直接在业务里各自创建 Redis client，后面会迅速长成一堆复制代码。
- 已拍板约束：本次不再走 `krboom_release/rpc` 私有 Redis 配置，统一复用现有 multi-tenant Redis 配置骨架；Redis key 规则统一为 `文件名:json里的Key:参数`。

## 目标

- 明确 `common/redis` 的职责边界，做成可复用的 Redis 底座。
- 复用 `admin/common/adminconfig` 现有 multi-tenant Redis 配置结构，避免出现双轨配置。
- 给出 `krboom_release/rpc` 的最小接入路径，保证业务层只依赖注入后的 client 与 key registry。
- 保持 Redis 配置、client 创建、key 模板与错误日志集中管理，避免业务代码直接耦合连接细节。

## 范围

- 会改什么：本次先沉淀 Redis 设计与接入方案，不直接实现代码。
- 涉及目录：
  - `docs/exec-plans/active`
  - `web_server/common/redis`
  - `web_server/apps/admin/common/adminconfig`
  - `web_server/apps/krboom_release/rpc/internal/svc`

## 明确不做什么

- 不在本次会话里直接修改 `krboom_release/rpc` 业务逻辑。
- 不扩展到所有服务统一迁移 Redis。
- 不引入新的 Redis 抽象层、repository 层或额外基础设施。
- 不做默认租户 Redis fallback，避免跨租户误用。
- 不把锁工具或其他无关 Redis 能力顺手并入这次改造。

## 分阶段步骤

1. 梳理当前仓库里的 Redis 使用方式、multi-tenant 配置入口与 `krboom_release/rpc` 注入点，确认复用边界。
2. 设计 `common/redis` 的职责边界，统一覆盖 client 创建、registry 读取、key 渲染和基础错误处理，不让 `redis_tools.go` 变成工具桶。
3. 设计启动时全量初始化租户 Redis client 的接入方式，只构造 client，不做逐租户 ping；对缺失 Redis 配置的租户不连接 Redis。
4. 固定 key registry 合同，使用 `common/redis/*.json` 文件名 + json 里的 key 模板 + 参数渲染最终 Redis key，统一格式为 `文件名:json里的Key:参数`。
5. 给出 `krboom_release/rpc` 的接入改动点与最小验证路径，要求业务层在请求无 Redis 配置租户时输出明确 `logx` 错误。

## 每阶段验证

- 阶段 1：静态确认现有 Redis 使用基于 go-zero `core/stores/redis`，multi-tenant Redis 配置结构已存在于 `admin/common/adminconfig`。
- 阶段 2：静态确认 `redis_tools.go` 只承载连接管理、registry 解析、key 渲染、基础读写辅助四类职责。
- 阶段 3：静态确认启动路径为“全量构造 client、不做重 ping、失败租户不拖死整体服务”。
- 阶段 4：静态确认 key 合同固定为 `文件名:json里的Key:参数`，业务层不再自由手拼 Redis key。
- 阶段 5：测试计划至少覆盖：
  - `ServiceContext` Redis 初始化三条分支：有配置初始化成功、没配置跳过并记日志、配置坏了报错。
  - key registry 到最终 key 的完整表驱动测试：成功、模板缺失、参数个数不匹配、输出稳定性。
  - 日志断言必须包含租户名、模块名、缺少 Redis 配置等关键信息。

## 失败模式

- 某租户未配置 Redis 但代码仍请求使用：返回显式错误，并输出包含租户名、模块名和缺失配置原因的 `logx` 日志。
- key 模板缺失或参数数量不匹配：拒绝构造 Redis key，并在测试中覆盖为合同错误路径。
- 某个租户 Redis 配置损坏：启动阶段记录明确错误，但不因单租户失败拖死整个服务。
- 启动阶段逐租户做重度探活：会放大租户数量对启动时间的影响，本次明确禁止。

## ASCII 数据流图

```text
adminconfig.MultiTenant
        │
        ├── tenant A redis config ──> common/redis registry loader ──> redis client map["tenantA"]
        ├── tenant B no redis      ──> skip init + remember nil
        └── tenant C bad redis     ──> logx error + no client

business code
    │
    └── request tenant redis
            ├── client exists -> use registry key -> redis op
            └── client missing -> explicit error + logx
```

## 风险与回滚

- 风险：启动时全量构造租户 Redis client，会把启动成本与租户数量绑定；如果后续租户数快速增长，需要重新评估 eager init 是否还成立。
- 风险：`文件名:json里的Key:参数` 这套 registry 合同如果不写进测试，后续很容易出现静默 key 漂移。
- 回滚方式：本次仅产出计划与设计，不涉及代码回滚。

## 决策日志

- 2026-04-17：初始计划建立。
- 2026-04-17：放弃 `krboom_release/rpc` 私有 Redis 配置，改为复用 `admin/common/adminconfig` 的 multi-tenant Redis 配置骨架。
- 2026-04-17：拍板无 Redis 配置租户不连接 Redis；若业务仍请求使用，则输出明确 `logx` 错误。
- 2026-04-17：拍板启动时全量构造租户 Redis client，但不做逐租户重度 ping。
- 2026-04-17：拍板 key 合同固定为 `文件名:json里的Key:参数`，并要求完整表驱动测试覆盖 registry 渲染。

## 收尾状态

- 当前状态：已完成计划评审，等待按拍板后的约束进入实现。
- 完成后移动到：`docs/exec-plans/completed/`
- 遗留事项登记到：`docs/exec-plans/tech-debt-tracker.md`
