# Redis Codegen Design

## 目标

通过 `assets/redis/keys.json` 作为唯一配置源，自动生成两类代码：

1. `com/rediskeys`
   只负责生成 Redis key 拼装函数，不依赖任何 Redis SDK。
2. `com/redistore`
   只负责生成业务可调用的 Redis 操作函数，依赖统一运行时接口 `core/redisx`。

底层 Redis 驱动支持两种实现：

1. `go-zero`：`github.com/zeromicro/go-zero/core/stores/redis`
2. 官方驱动：`github.com/redis/go-redis/v9`

业务层只能依赖 `redistore` 和 `rediskeys`，不能直接依赖具体 SDK。

## 目录组织

```text
assets/redis/
  keys.json                 # Redis key schema 唯一来源

com/rediskeys/
  keys_gen.go               # 自动生成，仅 key builder

core/redisx/
  types.go                  # Store 抽象接口
  codec.go                  # string/int32/int64 编解码
  gozero.go                 # go-zero 适配器
  goredis.go                # 官方 go-redis 适配器

com/redistore/
  store.go                  # 聚合 store，注入 redisx.Store
  account_gen.go            # 自动生成
  login_gen.go              # 自动生成
  zone_gen.go               # 自动生成
```

## 分层职责

### `assets/redis/keys.json`

定义领域 key，不关心运行时实现。建议长期保持以下语义：

- `scope`：按业务域分组，例如 `account`、`login`、`zone`
- `type`：`string/hash/list/set/zset`
- `params`：key path 参数
- `key`：hash/zset 的 field/member 参数
- `value`：值类型
- `expire`：默认 TTL，单位秒
- `include_node/services`
  历史兼容字段，可以保留为业务标签，但不再影响生成输出路径

### `com/rediskeys`

只生成 key builder，例如：

```go
func KeyUserOnlineAccountString(account string) string
```

这层不能出现：

- Redis client
- context
- 日志
- 业务语义

### `core/redisx`

统一所有 Redis driver 差异，提供稳定接口：

- 未命中统一返回 `redisx.ErrNotFound`
- `SetNX` 统一返回 `(bool, error)`
- `HDel/Del` 统一返回 `error`
- `int32/int64` 编解码统一收敛到 `codec.go`

### `com/redistore`

统一生成业务 store，例如：

```go
type Store struct {
    r redisx.Store
}

func New(r redisx.Store) *Store
```

自动生成的方法全部挂在 `*Store` 上，并显式接收 `context.Context`。

## 方法生成约定

### string

- `GetXxx(ctx, ...) (T, error)`
- `SetXxx(ctx, ..., value T) error`
- `SetXxxWithExpire(ctx, ..., value T, expireSeconds int) error`
- `SetNXXxx(ctx, ..., value T) (bool, error)`
- `SetNXXxxWithExpire(ctx, ..., value T, expireSeconds int) (bool, error)`
- `DelXxx(ctx, ...) error`

如果 key 配置里自带 `expire`，再额外生成：

- `SetXxxDefaultExpire(ctx, ..., value T) error`
- `SetNXXxxDefaultExpire(ctx, ..., value T) (bool, error)`

### hash

- `GetXxx(ctx, ..., field K) (V, error)`
- `GetAllXxx(ctx, ...) (map[K]V, error)`
- `SetXxx(ctx, ..., field K, value V) error`
- `SetNXXxx(ctx, ..., field K, value V) (bool, error)`
- `DelXxx(ctx, ..., field K) error`
- `ExistsXxx(ctx, ..., field K) (bool, error)`

### list

- `GetXxx(ctx, ...) ([]V, error)`
- `LPushXxx(ctx, ..., value V) (int64, error)`
- `LPushXxxWithLimit(ctx, ..., value V, limit int64) (int64, error)`
- `LPushXxxDefaultPolicy(ctx, ..., value V) (int64, error)`

如果 key 配置含 `limit`/`expire`，默认策略里自动做 trim/expire。

### set

- `GetXxxMembers(ctx, ...) ([]V, error)`
- `AddXxx(ctx, ..., value V) (int64, error)`

### zset

- `GetXxxScore(ctx, ..., member K) (int64, error)`
- `GetXxxCard(ctx, ...) (int64, error)`
- `AddXxx(ctx, ..., member K, score int64) (bool, error)`
- `AddNXXxx(ctx, ..., member K, score int64) (bool, error)`

## `ErrNotFound` 语义

生成代码不吞未命中。

推荐规则：

- Redis 未命中时返回业务零值 + `redisx.ErrNotFound`
- 调用方如果把“未命中”视为正常流程，自己 `errors.Is(err, redisx.ErrNotFound)`
- 不在生成代码里打印“not found”日志

这样能避免现在目录里“返回零值 nil 导致状态歧义”的问题。

## go-zero 注入方式

`apps/user/rpc/internal/config/config.go`

```go
type Config struct {
    zrpc.RpcServerConf
    Redis redis.RedisConf
}
```

`apps/user/rpc/internal/svc/serviceContext.go`

```go
type ServiceContext struct {
    Config     config.Config
    Redis      *gzredis.Redis
    RedisStore *redistore.Store
}

func NewServiceContext(c config.Config) *ServiceContext {
    rds := gzredis.MustNewRedis(c.Redis)
    return &ServiceContext{
        Config:     c,
        Redis:      rds,
        RedisStore: redistore.New(redisx.NewGoZeroStore(rds)),
    }
}
```

## 官方 go-redis 注入方式

如果某个服务不使用 go-zero Redis，可以改为：

```go
client := redis.NewClient(&redis.Options{Addr: "127.0.0.1:6379"})
store := redistore.New(redisx.NewGoRedisStore(client))
```

业务层调用无需变化。

## 迁移策略

### 先做

1. 保留 `assets/redis/keys.json` 作为配置源
2. 新增 `core/redisx`
3. 新增 `com/rediskeys`
4. 新生成 `com/redistore`

### 再做

1. 停止向 `apps/<service>/rpc/redis` 生成旧代码
2. 将旧业务调用迁移到 `svcCtx.RedisStore`
3. 删除旧模板中这些做法：
   - 全局 `RedisClient`
   - `context.Background()`
   - 直接绑 `github.com/go-redis/redis/v9`
   - 未命中返回零值 `nil`
   - 永久 key 和临时 key 混用

## 当前旧实现的主要问题

`apps/user/rpc/redis/*.go` 当前有这些结构性问题：

1. 强绑旧包路径和外部模块，当前仓库无法编译。
2. 所有方法都用 `context.Background()`，无法跟随请求取消和超时。
3. `SetNX` 只返回 `error`，调用方拿不到是否抢占成功。
4. Redis 未命中返回零值 `nil`，无法区分“真值为零”和“未命中”。
5. 生成代码依赖全局变量，无法按服务注入、无法测试、无法多实例。

这也是新设计必须拆 runtime 的原因。

## 生成命令

```bash
python3 tools/autogen/autogen.py
gofmt -w com/rediskeys/*.go com/redistore/*.go
```

当前生成器统一输出：

```text
com/redistore
```

## 业务调用示例

```go
ok, err := l.svcCtx.RedisStore.SetNXUserLoginingUseStateNewDefaultExpire(
    l.ctx,
    account,
    "1",
)
if err != nil {
    return nil, err
}
if !ok {
    // 已有登录流程在进行中
}
```

读取时显式处理未命中：

```go
state, err := l.svcCtx.RedisStore.GetUserLoginingUseStateNew(l.ctx, account)
if errors.Is(err, redisx.ErrNotFound) {
    // 未登录中
}
if err != nil {
    return nil, err
}
_ = state
```
