# ARCHITECTURE

## 目标

本文件是 `krboom_stream/go` 的顶层结构地图。它服务于智能体可读性，而不是面向人类的散文说明。进入仓库后，先读这里，再决定深入哪些目录。

## 仓库结构

### 1. `web_server`

主后端系统，采用 go-zero 风格的多服务布局。

- `apps/admin`
  - `api`: 唯一对外HTTP 入口，当前最显式的测试路由是 `GET /from/:name`
  - `rpc`: 后台核心 RPC 服务
- `apps/git_webhook`
  - `api`: 对外 webhook 入口，当前最显式的健康路由是 `GET /healthz`
  - `rpc`: 触发 Jenkins、处理回调
- `apps/log`
  - `rpc`: 中央日志 RPC，依赖 Kafka / Postgres
- `apps/cron`
  - `rpc`: 定时任务调度与执行，依赖 Postgres，部分路径依赖 Kafka
- `apps/kiif_gm`
  - `rpc`: KIIF GM 相关业务 RPC
- `apps/krboom_release`
  - `rpc`: 发布与 OceanEngine 相关业务 RPC
- `common`
  - 公共工具和通用追踪能力
- `migrate`
  - migration runner 与已登记 schema 变更
- `scripts`
  - 构建、批量启动、停止、新增 app 等工程脚本

### 2. `go-admin-ui-vue3`

前端管理台工作区。除非任务明确影响接口契约、页面流程、管理后台联动，否则默认不要进入。
- 前端主要给运营，qa看的，ui侧重这个方面

## 关键依赖关系

以下关系来自代码入口和配置，不要基于旧 README 猜测：

- `admin_api` 依赖 `admin_rpc`
- `admin_api` 在配置中还引用 `log_rpc`、`krboom_release_rpc`、`kiif_gm_rpc`、`cron_rpc`
- `git_webhook_api` 依赖 `git_webhook_rpc`
- `cron_rpc`、`kiif_gm_rpc`、`krboom_release_rpc` 可接入 `log_rpc` 做 central log
- `log_rpc` 自身依赖 Kafka 和 Postgres
- `admin_rpc` 依赖 Postgres / Redis / 多租户配置 / Feishu 配置
- `cron_rpc` 依赖 Postgres，部分执行链路依赖 Kafka

## 目录判断规则

修改前先判断任务落在哪一层：

- 入口启动与服务编排：`apps/*/{api,rpc}/*.go`、`scripts/**`
- 配置形状与默认行为：`apps/*/{api,rpc}/etc/**`、内部 `config`
- 业务逻辑：`apps/*/{api,rpc}/internal/logic/**`
- 服务依赖注入：`apps/*/{api,rpc}/internal/svc/**`
- 公共能力：`common/**`
- 数据模型：`apps/*/model/**`
- schema 变更：`migrate/**`
- 前端联动：`go-admin-ui-vue3/src/**`

## 工程优先级

对于 harness engineering，优先改这些地方：

1. `docs/**`
2. `web_server/scripts/**`
3. `web_server/migrate/**`
4. `web_server/common/**`
5. 测试文件
6. 最小必要的服务入口或配置

只有在 harness 无法改进时，才触碰业务逻辑本身。

## 运行与验证入口

### 后端

- 批量启动：`bash web_server/scripts/run_all_services.sh start`
- 批量停止：`bash web_server/scripts/run_all_services.sh stop`
- 全量测试：在 `web_server` 内运行 `go test ./...`
- 定向构建：在 `web_server` 内运行受影响入口的 `go build`

### 推荐的最小冒烟路径

- `git_webhook_api`: `GET /healthz`
- `admin_api`: `GET /from/:name`
- migration: 先检查 `migrate/` 对应 scope，再决定是否需要连接数据库验证

## 架构不变量

- `web_server` 默认遵循 go-zero 分层：`router/handler/server -> logic -> model/client`。
- `ServiceContext` 只保存稳定依赖，禁止挂长生命周期业务对象；详细约束见 `docs/design-docs/go-zero-layering.md`。
- 新知识优先落到仓库内 Markdown，而不是对话描述。
- 配置路径、服务依赖、脚本入口必须可被智能体直接发现。
- 能通过脚本、测试、lint、模板强制的规则，不要只写成文案。
- 不要假设隐藏上下文存在。
- 不要让 README 与真实源码结构长期漂移。
