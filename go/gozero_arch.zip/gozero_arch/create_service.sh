#!/usr/bin/env bash

set -euo pipefail

SERVICE_NAME="${1:-}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TPL_DIR="${ROOT_DIR}/tools/goctl/tpl_1.10.1"

if [[ -z "${SERVICE_NAME}" ]]; then
  echo "usage: bash create_service_new.sh <service_name>" >&2
  exit 1
fi

if [[ ! -d "${TPL_DIR}" ]]; then
  echo "goctl template dir not found: ${TPL_DIR}" >&2
  exit 1
fi

# ..................................create api service...................................
cd "${ROOT_DIR}/apps"
mkdir -p "${SERVICE_NAME}"
cd "${SERVICE_NAME}"

goctl api -o "${SERVICE_NAME}.api" --home "${TPL_DIR}"
goctl api go --api "${SERVICE_NAME}.api" --dir api --style goZero --home "${TPL_DIR}"
mv "${SERVICE_NAME}.api" api/

# ..................................create rpc service...................................
cd "${ROOT_DIR}/apps"
mkdir -p "${SERVICE_NAME}"
cd "${SERVICE_NAME}"

goctl rpc -o "${SERVICE_NAME}.proto" --home "${TPL_DIR}"
goctl rpc protoc "${SERVICE_NAME}.proto" --go_out=rpc/ --go-grpc_out=rpc/ --zrpc_out=rpc/ --style=gozero --style goZero --home "${TPL_DIR}"
mv "${SERVICE_NAME}.proto" rpc/

mkdir -p ${ROOT_DIR}/assets/sql/"${SERVICE_NAME}"
