$ErrorActionPreference = 'Stop'

$services = @(
    'user',
    'admin',
    'kbrelease',
    'cron'
)

$root = $PSScriptRoot
$binDir = Join-Path $root 'bin'
$etcDir = Join-Path $binDir 'etc'

$previousGoos = $env:GOOS
$previousGoarch = $env:GOARCH
$previousCgoEnabled = $env:CGO_ENABLED

try {
    Set-Location $root

    New-Item -ItemType Directory -Force -Path $binDir | Out-Null
    New-Item -ItemType Directory -Force -Path $etcDir | Out-Null

    $env:GOOS = 'linux'
    $env:GOARCH = 'amd64'
    $env:CGO_ENABLED = '0'

    foreach ($service in $services) {
        $apiEntry = "./apps/$service/api/$service.go"
        $apiEtc = "./apps/$service/api/etc/*"
        $apiOutput = "./bin/$service-api"

        $rpcEntry = "./apps/$service/rpc/$service.go"
        $rpcEtc = "./apps/$service/rpc/etc/*"
        $rpcOutput = "./bin/$service"

        if (-not (Test-Path $apiEntry)) {
            throw "API entry not found: $apiEntry"
        }
        if (-not (Test-Path $rpcEntry)) {
            throw "RPC entry not found: $rpcEntry"
        }

        Write-Host "Building $service api -> $apiOutput"
        go build -o $apiOutput -ldflags='-s -w' -tags no_k8s $apiEntry
        Copy-Item -Path $apiEtc -Destination $etcDir -Force

        Write-Host "Building $service rpc -> $rpcOutput"
        go build -o $rpcOutput -ldflags='-s -w' -tags no_k8s $rpcEntry
        Copy-Item -Path $rpcEtc -Destination $etcDir -Force
    }

    Write-Host 'Linux amd64 build completed.'
}
finally {
    $env:GOOS = $previousGoos
    $env:GOARCH = $previousGoarch
    $env:CGO_ENABLED = $previousCgoEnabled
}
