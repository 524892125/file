$ErrorActionPreference = 'Stop'

$services = @(
    'admin/api',
    'cron/rpc',
    'kbrelease/rpc'
)

$root = $PSScriptRoot
$binDir = Join-Path $root 'bin'
$etcDir = Join-Path $binDir 'etc'

$previousGoos = $env:GOOS
$previousGoarch = $env:GOARCH
$previousCgoEnabled = $env:CGO_ENABLED

try {
    Set-Location $root

    New-Item -ItemType Directory -Force -Path $binDir | Out-Null
    New-Item -ItemType Directory -Force -Path $etcDir | Out-Null

    $env:GOOS = 'linux'
    $env:GOARCH = 'amd64'
    $env:CGO_ENABLED = '0'

    foreach ($service in $services) {
        $parts = $service.Split('/')
        if ($parts.Length -ne 2) {
            throw "Invalid service path: $service"
        }

        $name = $parts[0]
        $kind = $parts[1]
        $entry = "./apps/$service/$name.go"
        $etc = "./apps/$service/etc/*"

        if ($kind -eq 'api') {
            $output = "./bin/$name-api"
        } elseif ($kind -eq 'rpc') {
            $output = "./bin/$name-rpc"
        } else {
            throw "Invalid service kind: $service"
        }

        if (-not (Test-Path $entry)) {
            throw "Entry not found: $entry"
        }

        Write-Host "Building $service -> $output"
        go build -o $output -ldflags='-s -w' -tags no_k8s $entry
        Copy-Item -Path $etc -Destination $etcDir -Force
    }

    Write-Host 'Linux amd64 build completed.'
}
finally {
    $env:GOOS = $previousGoos
    $env:GOARCH = $previousGoarch
    $env:CGO_ENABLED = $previousCgoEnabled
}
