--
-- PostgreSQL database dump
--

\restrict aC2hmujTn2r9ugMj49aHOYuwE3VfCDFswjdk0wkwZOpAb8uZzZzrwsXzaIXmmgV

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: casbin_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.casbin_rule (
    id bigint NOT NULL,
    ptype character varying(100),
    v0 character varying(100),
    v1 character varying(100),
    v2 character varying(100),
    v3 character varying(100),
    v4 character varying(100),
    v5 character varying(100)
);


ALTER TABLE public.casbin_rule OWNER TO postgres;

--
-- Name: casbin_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.casbin_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.casbin_rule_id_seq OWNER TO postgres;

--
-- Name: casbin_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.casbin_rule_id_seq OWNED BY public.casbin_rule.id;


--
-- Name: ocean_engine_daily_report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ocean_engine_daily_report (
    id bigint NOT NULL,
    report_date character varying(10),
    data_topic character varying(64),
    advertiser_id bigint,
    advertiser_name character varying(255),
    dimensions text,
    metrics text,
    columns text,
    rows text,
    summary text,
    row_count bigint,
    sync_mode character varying(32),
    synced_at character varying(32),
    request_payload text,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.ocean_engine_daily_report OWNER TO postgres;

--
-- Name: COLUMN ocean_engine_daily_report.report_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.report_date IS '报表日期';


--
-- Name: COLUMN ocean_engine_daily_report.data_topic; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.data_topic IS '数据主题';


--
-- Name: COLUMN ocean_engine_daily_report.advertiser_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.advertiser_id IS '广告主ID';


--
-- Name: COLUMN ocean_engine_daily_report.advertiser_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.advertiser_name IS '广告主名称';


--
-- Name: COLUMN ocean_engine_daily_report.dimensions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.dimensions IS '维度JSON';


--
-- Name: COLUMN ocean_engine_daily_report.metrics; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.metrics IS '指标JSON';


--
-- Name: COLUMN ocean_engine_daily_report.columns; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.columns IS '列配置JSON';


--
-- Name: COLUMN ocean_engine_daily_report.rows; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.rows IS '报表行JSON';


--
-- Name: COLUMN ocean_engine_daily_report.summary; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.summary IS '汇总JSON';


--
-- Name: COLUMN ocean_engine_daily_report.row_count; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.row_count IS '报表行数';


--
-- Name: COLUMN ocean_engine_daily_report.sync_mode; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.sync_mode IS '同步模式';


--
-- Name: COLUMN ocean_engine_daily_report.synced_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.synced_at IS '同步时间';


--
-- Name: COLUMN ocean_engine_daily_report.request_payload; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.request_payload IS '同步请求JSON';


--
-- Name: COLUMN ocean_engine_daily_report.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.create_by IS '创建者';


--
-- Name: COLUMN ocean_engine_daily_report.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.update_by IS '更新者';


--
-- Name: COLUMN ocean_engine_daily_report.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.created_at IS '创建时间';


--
-- Name: COLUMN ocean_engine_daily_report.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.updated_at IS '最后更新时间';


--
-- Name: COLUMN ocean_engine_daily_report.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_daily_report.deleted_at IS '删除时间';


--
-- Name: ocean_engine_daily_report_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ocean_engine_daily_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ocean_engine_daily_report_id_seq OWNER TO postgres;

--
-- Name: ocean_engine_daily_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ocean_engine_daily_report_id_seq OWNED BY public.ocean_engine_daily_report.id;


--
-- Name: ocean_engine_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ocean_engine_token (
    id bigint NOT NULL,
    app_id bigint,
    access_token text,
    refresh_token text,
    expires_at character varying(32),
    refresh_token_expires_at character varying(32),
    advertiser_ids text,
    cc_account_id bigint,
    sync_start_date character varying(10),
    last_synced_date character varying(10),
    last_sync_at character varying(32),
    last_sync_status character varying(32),
    last_sync_message text,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.ocean_engine_token OWNER TO postgres;

--
-- Name: COLUMN ocean_engine_token.app_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.app_id IS 'OceanEngine应用ID';


--
-- Name: COLUMN ocean_engine_token.access_token; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.access_token IS '访问令牌';


--
-- Name: COLUMN ocean_engine_token.refresh_token; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.refresh_token IS '刷新令牌';


--
-- Name: COLUMN ocean_engine_token.expires_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.expires_at IS '访问令牌过期时间';


--
-- Name: COLUMN ocean_engine_token.refresh_token_expires_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.refresh_token_expires_at IS '刷新令牌过期时间';


--
-- Name: COLUMN ocean_engine_token.advertiser_ids; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.advertiser_ids IS '广告主ID列表JSON';


--
-- Name: COLUMN ocean_engine_token.cc_account_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.cc_account_id IS '穿山甲工作台账户ID';


--
-- Name: COLUMN ocean_engine_token.sync_start_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.sync_start_date IS '全量重载起始日期';


--
-- Name: COLUMN ocean_engine_token.last_synced_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.last_synced_date IS '最近同步日期';


--
-- Name: COLUMN ocean_engine_token.last_sync_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.last_sync_at IS '最近同步时间';


--
-- Name: COLUMN ocean_engine_token.last_sync_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.last_sync_status IS '最近同步状态';


--
-- Name: COLUMN ocean_engine_token.last_sync_message; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.last_sync_message IS '最近同步结果';


--
-- Name: COLUMN ocean_engine_token.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.create_by IS '创建者';


--
-- Name: COLUMN ocean_engine_token.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.update_by IS '更新者';


--
-- Name: COLUMN ocean_engine_token.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.created_at IS '创建时间';


--
-- Name: COLUMN ocean_engine_token.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.updated_at IS '最后更新时间';


--
-- Name: COLUMN ocean_engine_token.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ocean_engine_token.deleted_at IS '删除时间';


--
-- Name: ocean_engine_token_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ocean_engine_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ocean_engine_token_id_seq OWNER TO postgres;

--
-- Name: ocean_engine_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ocean_engine_token_id_seq OWNED BY public.ocean_engine_token.id;


--
-- Name: sys_api; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_api (
    id bigint NOT NULL,
    handle character varying(128),
    title character varying(128),
    path character varying(128),
    type character varying(16),
    action character varying(16),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    create_by bigint,
    update_by bigint
);


ALTER TABLE public.sys_api OWNER TO postgres;

--
-- Name: COLUMN sys_api.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_api.id IS '主键编码';


--
-- Name: COLUMN sys_api.handle; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_api.handle IS 'handle';


--
-- Name: COLUMN sys_api.title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_api.title IS '标题';


--
-- Name: COLUMN sys_api.path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_api.path IS '地址';


--
-- Name: COLUMN sys_api.type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_api.type IS '接口类型';


--
-- Name: COLUMN sys_api.action; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_api.action IS '请求类型';


--
-- Name: COLUMN sys_api.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_api.created_at IS '创建时间';


--
-- Name: COLUMN sys_api.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_api.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_api.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_api.deleted_at IS '删除时间';


--
-- Name: COLUMN sys_api.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_api.create_by IS '创建者';


--
-- Name: COLUMN sys_api.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_api.update_by IS '更新者';


--
-- Name: sys_api_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_api_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_api_id_seq OWNER TO postgres;

--
-- Name: sys_api_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_api_id_seq OWNED BY public.sys_api.id;


--
-- Name: sys_columns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_columns (
    column_id bigint NOT NULL,
    table_id bigint,
    column_name character varying(128),
    column_comment character varying(128),
    column_type character varying(128),
    go_type character varying(128),
    go_field character varying(128),
    json_field character varying(128),
    is_pk character varying(4),
    is_increment character varying(4),
    is_required character varying(4),
    is_insert character varying(4),
    is_edit character varying(4),
    is_list character varying(4),
    is_query character varying(4),
    query_type character varying(128),
    html_type character varying(128),
    dict_type character varying(128),
    sort bigint,
    list character varying(1),
    pk boolean,
    required boolean,
    super_column boolean,
    usable_column boolean,
    increment boolean,
    insert boolean,
    edit boolean,
    query boolean,
    remark character varying(255),
    fk_table_name text,
    fk_table_name_class text,
    fk_table_name_package text,
    fk_label_id text,
    fk_label_name character varying(255),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    create_by bigint,
    update_by bigint
);


ALTER TABLE public.sys_columns OWNER TO postgres;

--
-- Name: COLUMN sys_columns.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_columns.created_at IS '创建时间';


--
-- Name: COLUMN sys_columns.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_columns.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_columns.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_columns.deleted_at IS '删除时间';


--
-- Name: COLUMN sys_columns.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_columns.create_by IS '创建者';


--
-- Name: COLUMN sys_columns.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_columns.update_by IS '更新者';


--
-- Name: sys_columns_column_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_columns_column_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_columns_column_id_seq OWNER TO postgres;

--
-- Name: sys_columns_column_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_columns_column_id_seq OWNED BY public.sys_columns.column_id;


--
-- Name: sys_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_config (
    id bigint NOT NULL,
    config_name character varying(128),
    config_key character varying(128),
    config_value character varying(255),
    config_type character varying(64),
    is_frontend character varying(64),
    remark character varying(128),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_config OWNER TO postgres;

--
-- Name: COLUMN sys_config.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.id IS '主键编码';


--
-- Name: COLUMN sys_config.config_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_name IS 'ConfigName';


--
-- Name: COLUMN sys_config.config_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_key IS 'ConfigKey';


--
-- Name: COLUMN sys_config.config_value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_value IS 'ConfigValue';


--
-- Name: COLUMN sys_config.config_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_type IS 'ConfigType';


--
-- Name: COLUMN sys_config.is_frontend; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.is_frontend IS '是否前台';


--
-- Name: COLUMN sys_config.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.remark IS 'Remark';


--
-- Name: COLUMN sys_config.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.create_by IS '创建者';


--
-- Name: COLUMN sys_config.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.update_by IS '更新者';


--
-- Name: COLUMN sys_config.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.created_at IS '创建时间';


--
-- Name: COLUMN sys_config.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_config.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.deleted_at IS '删除时间';


--
-- Name: sys_config_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_config_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_config_config_id_seq OWNER TO postgres;

--
-- Name: sys_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_config_id_seq OWNER TO postgres;

--
-- Name: sys_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_config_id_seq OWNED BY public.sys_config.id;


--
-- Name: sys_dept; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_dept (
    dept_id bigint NOT NULL,
    parent_id bigint,
    dept_path character varying(255),
    dept_name character varying(128),
    sort smallint,
    leader character varying(128),
    phone character varying(11),
    email character varying(64),
    status smallint,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_dept OWNER TO postgres;

--
-- Name: COLUMN sys_dept.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dept.create_by IS '创建者';


--
-- Name: COLUMN sys_dept.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dept.update_by IS '更新者';


--
-- Name: COLUMN sys_dept.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dept.created_at IS '创建时间';


--
-- Name: COLUMN sys_dept.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dept.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_dept.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dept.deleted_at IS '删除时间';


--
-- Name: sys_dept_dept_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_dept_dept_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_dept_dept_id_seq OWNER TO postgres;

--
-- Name: sys_dept_dept_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_dept_dept_id_seq OWNED BY public.sys_dept.dept_id;


--
-- Name: sys_dict_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_dict_data (
    dict_code bigint NOT NULL,
    dict_sort bigint,
    dict_label character varying(128),
    dict_value character varying(255),
    dict_type character varying(64),
    css_class character varying(128),
    list_class character varying(128),
    is_default character varying(8),
    status smallint,
    "default" character varying(8),
    remark character varying(255),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_dict_data OWNER TO postgres;

--
-- Name: COLUMN sys_dict_data.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_data.create_by IS '创建者';


--
-- Name: COLUMN sys_dict_data.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_data.update_by IS '更新者';


--
-- Name: COLUMN sys_dict_data.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_data.created_at IS '创建时间';


--
-- Name: COLUMN sys_dict_data.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_data.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_dict_data.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_data.deleted_at IS '删除时间';


--
-- Name: sys_dict_data_dict_code_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_dict_data_dict_code_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_dict_data_dict_code_seq OWNER TO postgres;

--
-- Name: sys_dict_data_dict_code_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_dict_data_dict_code_seq OWNED BY public.sys_dict_data.dict_code;


--
-- Name: sys_dict_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_dict_type (
    dict_id bigint NOT NULL,
    dict_name character varying(128),
    dict_type character varying(128),
    status smallint,
    remark character varying(255),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_dict_type OWNER TO postgres;

--
-- Name: COLUMN sys_dict_type.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_type.create_by IS '创建者';


--
-- Name: COLUMN sys_dict_type.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_type.update_by IS '更新者';


--
-- Name: COLUMN sys_dict_type.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_type.created_at IS '创建时间';


--
-- Name: COLUMN sys_dict_type.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_type.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_dict_type.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_type.deleted_at IS '删除时间';


--
-- Name: sys_dict_type_dict_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_dict_type_dict_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_dict_type_dict_id_seq OWNER TO postgres;

--
-- Name: sys_dict_type_dict_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_dict_type_dict_id_seq OWNED BY public.sys_dict_type.dict_id;


--
-- Name: sys_job; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_job (
    job_id bigint NOT NULL,
    job_name character varying(255),
    job_group character varying(255),
    job_type smallint,
    cron_expression character varying(255),
    invoke_target character varying(255),
    args character varying(255),
    misfire_policy bigint,
    concurrent smallint,
    status smallint,
    entry_id smallint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    create_by bigint,
    update_by bigint
);


ALTER TABLE public.sys_job OWNER TO postgres;

--
-- Name: COLUMN sys_job.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_job.created_at IS '创建时间';


--
-- Name: COLUMN sys_job.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_job.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_job.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_job.deleted_at IS '删除时间';


--
-- Name: COLUMN sys_job.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_job.create_by IS '创建者';


--
-- Name: COLUMN sys_job.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_job.update_by IS '更新者';


--
-- Name: sys_job_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_job_id_seq OWNER TO postgres;

--
-- Name: sys_job_job_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_job_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_job_job_id_seq OWNER TO postgres;

--
-- Name: sys_job_job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_job_job_id_seq OWNED BY public.sys_job.job_id;


--
-- Name: sys_login_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_login_log (
    id bigint NOT NULL,
    username character varying(128),
    status character varying(4),
    ipaddr character varying(255),
    login_location character varying(255),
    browser character varying(255),
    os character varying(255),
    platform character varying(255),
    login_time timestamp without time zone,
    remark text,
    msg text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    create_by bigint,
    update_by bigint
);


ALTER TABLE public.sys_login_log OWNER TO postgres;

--
-- Name: COLUMN sys_login_log.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.id IS '主键编码';


--
-- Name: COLUMN sys_login_log.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.username IS 'username';


--
-- Name: COLUMN sys_login_log.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.status IS 'status';


--
-- Name: COLUMN sys_login_log.ipaddr; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.ipaddr IS 'ip address';


--
-- Name: COLUMN sys_login_log.login_location; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.login_location IS 'login location';


--
-- Name: COLUMN sys_login_log.browser; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.browser IS 'browser';


--
-- Name: COLUMN sys_login_log.os; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.os IS 'os';


--
-- Name: COLUMN sys_login_log.platform; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.platform IS 'platform';


--
-- Name: COLUMN sys_login_log.login_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.login_time IS 'login time';


--
-- Name: COLUMN sys_login_log.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.remark IS 'remark';


--
-- Name: COLUMN sys_login_log.msg; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.msg IS 'message';


--
-- Name: COLUMN sys_login_log.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.created_at IS 'created at';


--
-- Name: COLUMN sys_login_log.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.updated_at IS 'updated at';


--
-- Name: COLUMN sys_login_log.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.create_by IS '创建者';


--
-- Name: COLUMN sys_login_log.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.update_by IS '更新者';


--
-- Name: sys_login_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_login_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_login_log_id_seq OWNER TO postgres;

--
-- Name: sys_login_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_login_log_id_seq OWNED BY public.sys_login_log.id;


--
-- Name: sys_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_menu (
    menu_id bigint NOT NULL,
    menu_name character varying(128),
    title character varying(128),
    icon character varying(128),
    path character varying(128),
    paths character varying(128),
    menu_type character varying(1),
    action character varying(16),
    permission character varying(255),
    parent_id smallint,
    no_cache boolean,
    breadcrumb character varying(255),
    component character varying(255),
    sort smallint,
    visible character varying(1),
    is_frame character varying(1) DEFAULT '0'::character varying,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_menu OWNER TO postgres;

--
-- Name: COLUMN sys_menu.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.create_by IS '创建者';


--
-- Name: COLUMN sys_menu.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.update_by IS '更新者';


--
-- Name: COLUMN sys_menu.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.created_at IS '创建时间';


--
-- Name: COLUMN sys_menu.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_menu.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.deleted_at IS '删除时间';


--
-- Name: sys_menu_api_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_menu_api_rule (
    sys_menu_menu_id bigint NOT NULL,
    sys_api_id bigint NOT NULL
);


ALTER TABLE public.sys_menu_api_rule OWNER TO postgres;

--
-- Name: COLUMN sys_menu_api_rule.sys_api_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu_api_rule.sys_api_id IS '主键编码';


--
-- Name: sys_menu_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_menu_menu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_menu_menu_id_seq OWNER TO postgres;

--
-- Name: sys_menu_menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_menu_menu_id_seq OWNED BY public.sys_menu.menu_id;


--
-- Name: sys_migration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_migration (
    version text NOT NULL,
    apply_time timestamp with time zone,
    scope character varying(255)
);


ALTER TABLE public.sys_migration OWNER TO postgres;

--
-- Name: sys_opera_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_opera_log (
    id bigint NOT NULL,
    title character varying(255),
    business_type character varying(128),
    business_types character varying(128),
    method character varying(128),
    request_method character varying(128),
    operator_type character varying(128),
    oper_name character varying(128),
    dept_name character varying(128),
    oper_url character varying(255),
    oper_ip character varying(128),
    oper_location character varying(128),
    oper_param text,
    status character varying(4),
    oper_time timestamp without time zone,
    json_result character varying(255),
    remark character varying(255),
    latency_time character varying(128),
    user_agent character varying(255),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    create_by bigint,
    update_by bigint
);


ALTER TABLE public.sys_opera_log OWNER TO postgres;

--
-- Name: COLUMN sys_opera_log.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.id IS '主键编码';


--
-- Name: COLUMN sys_opera_log.title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.title IS '操作模块';


--
-- Name: COLUMN sys_opera_log.business_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.business_type IS '操作类型';


--
-- Name: COLUMN sys_opera_log.business_types; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.business_types IS 'BusinessTypes';


--
-- Name: COLUMN sys_opera_log.method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.method IS '函数';


--
-- Name: COLUMN sys_opera_log.request_method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.request_method IS '请求方式: GET POST PUT DELETE';


--
-- Name: COLUMN sys_opera_log.operator_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.operator_type IS '操作类型';


--
-- Name: COLUMN sys_opera_log.oper_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_name IS '操作者';


--
-- Name: COLUMN sys_opera_log.dept_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.dept_name IS '部门名称';


--
-- Name: COLUMN sys_opera_log.oper_url; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_url IS '访问地址';


--
-- Name: COLUMN sys_opera_log.oper_ip; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_ip IS '客户端ip';


--
-- Name: COLUMN sys_opera_log.oper_location; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_location IS '访问位置';


--
-- Name: COLUMN sys_opera_log.oper_param; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_param IS '请求参数';


--
-- Name: COLUMN sys_opera_log.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.status IS '操作状态 1:正常 2:关闭';


--
-- Name: COLUMN sys_opera_log.oper_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_time IS '操作时间';


--
-- Name: COLUMN sys_opera_log.json_result; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.json_result IS '返回数据';


--
-- Name: COLUMN sys_opera_log.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.remark IS '备注';


--
-- Name: COLUMN sys_opera_log.latency_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.latency_time IS '耗时';


--
-- Name: COLUMN sys_opera_log.user_agent; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.user_agent IS 'ua';


--
-- Name: COLUMN sys_opera_log.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.created_at IS '创建时间';


--
-- Name: COLUMN sys_opera_log.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_opera_log.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.create_by IS '创建者';


--
-- Name: COLUMN sys_opera_log.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.update_by IS '更新者';


--
-- Name: sys_opera_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_opera_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_opera_log_id_seq OWNER TO postgres;

--
-- Name: sys_opera_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_opera_log_id_seq OWNED BY public.sys_opera_log.id;


--
-- Name: sys_post; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_post (
    post_id bigint NOT NULL,
    post_name character varying(128),
    post_code character varying(128),
    sort smallint,
    status smallint,
    remark character varying(255),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_post OWNER TO postgres;

--
-- Name: COLUMN sys_post.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_post.create_by IS '创建者';


--
-- Name: COLUMN sys_post.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_post.update_by IS '更新者';


--
-- Name: COLUMN sys_post.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_post.created_at IS '创建时间';


--
-- Name: COLUMN sys_post.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_post.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_post.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_post.deleted_at IS '删除时间';


--
-- Name: sys_post_post_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_post_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_post_post_id_seq OWNER TO postgres;

--
-- Name: sys_post_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_post_post_id_seq OWNED BY public.sys_post.post_id;


--
-- Name: sys_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_role (
    role_id bigint NOT NULL,
    role_name character varying(128),
    status character varying(4),
    role_key character varying(128),
    role_sort bigint,
    flag character varying(128),
    remark character varying(255),
    admin boolean,
    data_scope character varying(128),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_role OWNER TO postgres;

--
-- Name: COLUMN sys_role.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_role.create_by IS '创建者';


--
-- Name: COLUMN sys_role.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_role.update_by IS '更新者';


--
-- Name: COLUMN sys_role.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_role.created_at IS '创建时间';


--
-- Name: COLUMN sys_role.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_role.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_role.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_role.deleted_at IS '删除时间';


--
-- Name: sys_role_dept; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_role_dept (
    role_id smallint NOT NULL,
    dept_id smallint NOT NULL
);


ALTER TABLE public.sys_role_dept OWNER TO postgres;

--
-- Name: sys_role_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_role_menu (
    role_id bigint NOT NULL,
    menu_id bigint NOT NULL
);


ALTER TABLE public.sys_role_menu OWNER TO postgres;

--
-- Name: sys_role_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_role_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_role_role_id_seq OWNER TO postgres;

--
-- Name: sys_role_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_role_role_id_seq OWNED BY public.sys_role.role_id;


--
-- Name: sys_tables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_tables (
    table_id bigint NOT NULL,
    table_name character varying(255),
    table_comment character varying(255),
    class_name character varying(255),
    tpl_category character varying(255),
    package_name character varying(255),
    module_name character varying(255),
    module_front_name character varying(255),
    business_name character varying(255),
    function_name character varying(255),
    function_author character varying(255),
    pk_column character varying(255),
    pk_go_field character varying(255),
    pk_json_field character varying(255),
    options character varying(255),
    tree_code character varying(255),
    tree_parent_code character varying(255),
    tree_name character varying(255),
    tree boolean DEFAULT false,
    crud boolean DEFAULT true,
    remark character varying(255),
    is_data_scope smallint,
    is_actions smallint,
    is_auth smallint,
    is_logical_delete character varying(1),
    logical_delete boolean,
    logical_delete_column character varying(128),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    create_by bigint,
    update_by bigint
);


ALTER TABLE public.sys_tables OWNER TO postgres;

--
-- Name: COLUMN sys_tables.module_front_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_tables.module_front_name IS '前端文件名';


--
-- Name: COLUMN sys_tables.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_tables.created_at IS '创建时间';


--
-- Name: COLUMN sys_tables.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_tables.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_tables.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_tables.deleted_at IS '删除时间';


--
-- Name: COLUMN sys_tables.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_tables.create_by IS '创建者';


--
-- Name: COLUMN sys_tables.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_tables.update_by IS '更新者';


--
-- Name: sys_tables_table_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_tables_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_tables_table_id_seq OWNER TO postgres;

--
-- Name: sys_tables_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_tables_table_id_seq OWNED BY public.sys_tables.table_id;


--
-- Name: sys_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_user (
    user_id bigint NOT NULL,
    username character varying(64),
    password character varying(128),
    nick_name character varying(128),
    phone character varying(11),
    role_id bigint,
    salt character varying(255),
    avatar character varying(255),
    sex character varying(255),
    email character varying(128),
    dept_id bigint,
    post_id bigint,
    remark character varying(255),
    status character varying(4),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    allow_password_login character varying(4) DEFAULT '2'::character varying
);


ALTER TABLE public.sys_user OWNER TO postgres;

--
-- Name: COLUMN sys_user.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.user_id IS '编码';


--
-- Name: COLUMN sys_user.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.username IS '用户名';


--
-- Name: COLUMN sys_user.password; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.password IS '密码';


--
-- Name: COLUMN sys_user.nick_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.nick_name IS '昵称';


--
-- Name: COLUMN sys_user.phone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.phone IS '手机号';


--
-- Name: COLUMN sys_user.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.role_id IS '角色ID';


--
-- Name: COLUMN sys_user.salt; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.salt IS '盐';


--
-- Name: COLUMN sys_user.avatar; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.avatar IS '头像';


--
-- Name: COLUMN sys_user.sex; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.sex IS '性别';


--
-- Name: COLUMN sys_user.email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.email IS '邮箱';


--
-- Name: COLUMN sys_user.dept_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.dept_id IS '部门';


--
-- Name: COLUMN sys_user.post_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.post_id IS '岗位';


--
-- Name: COLUMN sys_user.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.remark IS '备注';


--
-- Name: COLUMN sys_user.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.status IS '状态';


--
-- Name: COLUMN sys_user.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.create_by IS '创建者';


--
-- Name: COLUMN sys_user.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.update_by IS '更新者';


--
-- Name: COLUMN sys_user.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.created_at IS '创建时间';


--
-- Name: COLUMN sys_user.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_user.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.deleted_at IS '删除时间';


--
-- Name: COLUMN sys_user.allow_password_login; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.allow_password_login IS '是否允许账号密码登录';


--
-- Name: sys_user_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_user_access (
    user_id bigint NOT NULL,
    role_id bigint,
    dept_id bigint,
    post_id bigint,
    status character varying(4) DEFAULT '2'::character varying,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_user_access OWNER TO postgres;

--
-- Name: COLUMN sys_user_access.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user_access.user_id IS '用户ID';


--
-- Name: COLUMN sys_user_access.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user_access.role_id IS '角色ID';


--
-- Name: COLUMN sys_user_access.dept_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user_access.dept_id IS '部门';


--
-- Name: COLUMN sys_user_access.post_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user_access.post_id IS '岗位';


--
-- Name: COLUMN sys_user_access.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user_access.status IS '状态';


--
-- Name: COLUMN sys_user_access.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user_access.create_by IS '创建者';


--
-- Name: COLUMN sys_user_access.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user_access.update_by IS '更新者';


--
-- Name: COLUMN sys_user_access.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user_access.created_at IS '创建时间';


--
-- Name: COLUMN sys_user_access.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user_access.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_user_access.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user_access.deleted_at IS '删除时间';


--
-- Name: sys_user_access_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_user_access_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_user_access_user_id_seq OWNER TO postgres;

--
-- Name: sys_user_access_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_user_access_user_id_seq OWNED BY public.sys_user_access.user_id;


--
-- Name: sys_user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_user_user_id_seq OWNER TO postgres;

--
-- Name: sys_user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_user_user_id_seq OWNED BY public.sys_user.user_id;


--
-- Name: wechat_analysis_snapshot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wechat_analysis_snapshot (
    id bigint NOT NULL,
    metric_id character varying(64) NOT NULL,
    metric_name character varying(255) DEFAULT ''::character varying NOT NULL,
    granularity integer DEFAULT 24 NOT NULL,
    request_start_ts bigint DEFAULT 0 NOT NULL,
    request_end_ts bigint DEFAULT 0 NOT NULL,
    request_start_label character varying(64) DEFAULT ''::character varying NOT NULL,
    request_end_label character varying(64) DEFAULT ''::character varying NOT NULL,
    data_list text DEFAULT ''::text NOT NULL,
    row_count integer DEFAULT 0 NOT NULL,
    filter_list text DEFAULT ''::text NOT NULL,
    group_list text DEFAULT ''::text NOT NULL,
    request_payload text DEFAULT ''::text NOT NULL,
    request_hash character varying(64) DEFAULT ''::character varying NOT NULL,
    sync_source character varying(32) DEFAULT ''::character varying NOT NULL,
    synced_at character varying(32) DEFAULT ''::character varying NOT NULL,
    create_by bigint DEFAULT 0 NOT NULL,
    update_by bigint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    app_id character varying(128) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.wechat_analysis_snapshot OWNER TO postgres;

--
-- Name: wechat_analysis_snapshot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wechat_analysis_snapshot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wechat_analysis_snapshot_id_seq OWNER TO postgres;

--
-- Name: wechat_analysis_snapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wechat_analysis_snapshot_id_seq OWNED BY public.wechat_analysis_snapshot.id;


--
-- Name: wechat_analysis_sync_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wechat_analysis_sync_config (
    id bigint NOT NULL,
    granularity integer DEFAULT 24 NOT NULL,
    recent_periods integer DEFAULT 7 NOT NULL,
    metrics text DEFAULT ''::text NOT NULL,
    filter_list text DEFAULT ''::text NOT NULL,
    group_list text DEFAULT ''::text NOT NULL,
    schedule_enabled boolean DEFAULT false NOT NULL,
    interval_seconds bigint DEFAULT 86400 NOT NULL,
    last_sync_at character varying(32) DEFAULT ''::character varying NOT NULL,
    last_sync_status character varying(32) DEFAULT ''::character varying NOT NULL,
    last_sync_message text DEFAULT ''::text NOT NULL,
    create_by bigint DEFAULT 0 NOT NULL,
    update_by bigint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.wechat_analysis_sync_config OWNER TO postgres;

--
-- Name: wechat_analysis_sync_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wechat_analysis_sync_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wechat_analysis_sync_config_id_seq OWNER TO postgres;

--
-- Name: wechat_analysis_sync_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wechat_analysis_sync_config_id_seq OWNED BY public.wechat_analysis_sync_config.id;


--
-- Name: casbin_rule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.casbin_rule ALTER COLUMN id SET DEFAULT nextval('public.casbin_rule_id_seq'::regclass);


--
-- Name: ocean_engine_daily_report id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ocean_engine_daily_report ALTER COLUMN id SET DEFAULT nextval('public.ocean_engine_daily_report_id_seq'::regclass);


--
-- Name: ocean_engine_token id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ocean_engine_token ALTER COLUMN id SET DEFAULT nextval('public.ocean_engine_token_id_seq'::regclass);


--
-- Name: sys_api id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_api ALTER COLUMN id SET DEFAULT nextval('public.sys_api_id_seq'::regclass);


--
-- Name: sys_columns column_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_columns ALTER COLUMN column_id SET DEFAULT nextval('public.sys_columns_column_id_seq'::regclass);


--
-- Name: sys_config id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_config ALTER COLUMN id SET DEFAULT nextval('public.sys_config_id_seq'::regclass);


--
-- Name: sys_dept dept_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dept ALTER COLUMN dept_id SET DEFAULT nextval('public.sys_dept_dept_id_seq'::regclass);


--
-- Name: sys_dict_data dict_code; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dict_data ALTER COLUMN dict_code SET DEFAULT nextval('public.sys_dict_data_dict_code_seq'::regclass);


--
-- Name: sys_dict_type dict_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dict_type ALTER COLUMN dict_id SET DEFAULT nextval('public.sys_dict_type_dict_id_seq'::regclass);


--
-- Name: sys_job job_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_job ALTER COLUMN job_id SET DEFAULT nextval('public.sys_job_job_id_seq'::regclass);


--
-- Name: sys_login_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_login_log ALTER COLUMN id SET DEFAULT nextval('public.sys_login_log_id_seq'::regclass);


--
-- Name: sys_menu menu_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_menu ALTER COLUMN menu_id SET DEFAULT nextval('public.sys_menu_menu_id_seq'::regclass);


--
-- Name: sys_opera_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_opera_log ALTER COLUMN id SET DEFAULT nextval('public.sys_opera_log_id_seq'::regclass);


--
-- Name: sys_post post_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_post ALTER COLUMN post_id SET DEFAULT nextval('public.sys_post_post_id_seq'::regclass);


--
-- Name: sys_role role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role ALTER COLUMN role_id SET DEFAULT nextval('public.sys_role_role_id_seq'::regclass);


--
-- Name: sys_tables table_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_tables ALTER COLUMN table_id SET DEFAULT nextval('public.sys_tables_table_id_seq'::regclass);


--
-- Name: sys_user user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_user ALTER COLUMN user_id SET DEFAULT nextval('public.sys_user_user_id_seq'::regclass);


--
-- Name: sys_user_access user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_user_access ALTER COLUMN user_id SET DEFAULT nextval('public.sys_user_access_user_id_seq'::regclass);


--
-- Name: wechat_analysis_snapshot id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wechat_analysis_snapshot ALTER COLUMN id SET DEFAULT nextval('public.wechat_analysis_snapshot_id_seq'::regclass);


--
-- Name: wechat_analysis_sync_config id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wechat_analysis_sync_config ALTER COLUMN id SET DEFAULT nextval('public.wechat_analysis_sync_config_id_seq'::regclass);


--
-- Name: casbin_rule casbin_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.casbin_rule
    ADD CONSTRAINT casbin_rule_pkey PRIMARY KEY (id);


--
-- Name: ocean_engine_daily_report ocean_engine_daily_report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ocean_engine_daily_report
    ADD CONSTRAINT ocean_engine_daily_report_pkey PRIMARY KEY (id);


--
-- Name: ocean_engine_token ocean_engine_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ocean_engine_token
    ADD CONSTRAINT ocean_engine_token_pkey PRIMARY KEY (id);


--
-- Name: sys_api sys_api_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_api
    ADD CONSTRAINT sys_api_pkey PRIMARY KEY (id);


--
-- Name: sys_columns sys_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_columns
    ADD CONSTRAINT sys_columns_pkey PRIMARY KEY (column_id);


--
-- Name: sys_config sys_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_config
    ADD CONSTRAINT sys_config_pkey PRIMARY KEY (id);


--
-- Name: sys_dept sys_dept_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dept
    ADD CONSTRAINT sys_dept_pkey PRIMARY KEY (dept_id);


--
-- Name: sys_dict_data sys_dict_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dict_data
    ADD CONSTRAINT sys_dict_data_pkey PRIMARY KEY (dict_code);


--
-- Name: sys_dict_type sys_dict_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dict_type
    ADD CONSTRAINT sys_dict_type_pkey PRIMARY KEY (dict_id);


--
-- Name: sys_job sys_job_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_job
    ADD CONSTRAINT sys_job_pkey PRIMARY KEY (job_id);


--
-- Name: sys_login_log sys_login_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_login_log
    ADD CONSTRAINT sys_login_log_pkey PRIMARY KEY (id);


--
-- Name: sys_menu_api_rule sys_menu_api_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_menu_api_rule
    ADD CONSTRAINT sys_menu_api_rule_pkey PRIMARY KEY (sys_menu_menu_id, sys_api_id);


--
-- Name: sys_menu sys_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_menu
    ADD CONSTRAINT sys_menu_pkey PRIMARY KEY (menu_id);


--
-- Name: sys_migration sys_migration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_migration
    ADD CONSTRAINT sys_migration_pkey PRIMARY KEY (version);


--
-- Name: sys_opera_log sys_opera_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_opera_log
    ADD CONSTRAINT sys_opera_log_pkey PRIMARY KEY (id);


--
-- Name: sys_post sys_post_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_post
    ADD CONSTRAINT sys_post_pkey PRIMARY KEY (post_id);


--
-- Name: sys_role_dept sys_role_dept_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role_dept
    ADD CONSTRAINT sys_role_dept_pkey PRIMARY KEY (role_id, dept_id);


--
-- Name: sys_role_menu sys_role_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role_menu
    ADD CONSTRAINT sys_role_menu_pkey PRIMARY KEY (role_id, menu_id);


--
-- Name: sys_role sys_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role
    ADD CONSTRAINT sys_role_pkey PRIMARY KEY (role_id);


--
-- Name: sys_tables sys_tables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_tables
    ADD CONSTRAINT sys_tables_pkey PRIMARY KEY (table_id);


--
-- Name: sys_user_access sys_user_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_user_access
    ADD CONSTRAINT sys_user_access_pkey PRIMARY KEY (user_id);


--
-- Name: sys_user sys_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_user
    ADD CONSTRAINT sys_user_pkey PRIMARY KEY (user_id);


--
-- Name: wechat_analysis_snapshot wechat_analysis_snapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wechat_analysis_snapshot
    ADD CONSTRAINT wechat_analysis_snapshot_pkey PRIMARY KEY (id);


--
-- Name: wechat_analysis_sync_config wechat_analysis_sync_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wechat_analysis_sync_config
    ADD CONSTRAINT wechat_analysis_sync_config_pkey PRIMARY KEY (id);


--
-- Name: idx_casbin_rule; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_casbin_rule ON public.casbin_rule USING btree (ptype, v0, v1, v2, v3, v4, v5);


--
-- Name: idx_ocean_engine_daily_report_advertiser_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ocean_engine_daily_report_advertiser_id ON public.ocean_engine_daily_report USING btree (advertiser_id);


--
-- Name: idx_ocean_engine_daily_report_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ocean_engine_daily_report_create_by ON public.ocean_engine_daily_report USING btree (create_by);


--
-- Name: idx_ocean_engine_daily_report_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ocean_engine_daily_report_deleted_at ON public.ocean_engine_daily_report USING btree (deleted_at);


--
-- Name: idx_ocean_engine_daily_report_report_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ocean_engine_daily_report_report_date ON public.ocean_engine_daily_report USING btree (report_date);


--
-- Name: idx_ocean_engine_daily_report_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ocean_engine_daily_report_update_by ON public.ocean_engine_daily_report USING btree (update_by);


--
-- Name: idx_ocean_engine_token_app_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ocean_engine_token_app_id ON public.ocean_engine_token USING btree (app_id);


--
-- Name: idx_ocean_engine_token_cc_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ocean_engine_token_cc_account_id ON public.ocean_engine_token USING btree (cc_account_id);


--
-- Name: idx_ocean_engine_token_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ocean_engine_token_create_by ON public.ocean_engine_token USING btree (create_by);


--
-- Name: idx_ocean_engine_token_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ocean_engine_token_deleted_at ON public.ocean_engine_token USING btree (deleted_at);


--
-- Name: idx_ocean_engine_token_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ocean_engine_token_update_by ON public.ocean_engine_token USING btree (update_by);


--
-- Name: idx_sys_api_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_api_create_by ON public.sys_api USING btree (create_by);


--
-- Name: idx_sys_api_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_api_deleted_at ON public.sys_api USING btree (deleted_at);


--
-- Name: idx_sys_api_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_api_update_by ON public.sys_api USING btree (update_by);


--
-- Name: idx_sys_columns_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_columns_create_by ON public.sys_columns USING btree (create_by);


--
-- Name: idx_sys_columns_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_columns_deleted_at ON public.sys_columns USING btree (deleted_at);


--
-- Name: idx_sys_columns_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_columns_update_by ON public.sys_columns USING btree (update_by);


--
-- Name: idx_sys_config_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_create_by ON public.sys_config USING btree (create_by);


--
-- Name: idx_sys_config_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_deleted_at ON public.sys_config USING btree (deleted_at);


--
-- Name: idx_sys_config_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_update_by ON public.sys_config USING btree (update_by);


--
-- Name: idx_sys_dept_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dept_create_by ON public.sys_dept USING btree (create_by);


--
-- Name: idx_sys_dept_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dept_deleted_at ON public.sys_dept USING btree (deleted_at);


--
-- Name: idx_sys_dept_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dept_update_by ON public.sys_dept USING btree (update_by);


--
-- Name: idx_sys_dict_data_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_data_create_by ON public.sys_dict_data USING btree (create_by);


--
-- Name: idx_sys_dict_data_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_data_deleted_at ON public.sys_dict_data USING btree (deleted_at);


--
-- Name: idx_sys_dict_data_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_data_update_by ON public.sys_dict_data USING btree (update_by);


--
-- Name: idx_sys_dict_type_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_type_create_by ON public.sys_dict_type USING btree (create_by);


--
-- Name: idx_sys_dict_type_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_type_deleted_at ON public.sys_dict_type USING btree (deleted_at);


--
-- Name: idx_sys_dict_type_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_type_update_by ON public.sys_dict_type USING btree (update_by);


--
-- Name: idx_sys_job_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_job_create_by ON public.sys_job USING btree (create_by);


--
-- Name: idx_sys_job_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_job_deleted_at ON public.sys_job USING btree (deleted_at);


--
-- Name: idx_sys_job_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_job_update_by ON public.sys_job USING btree (update_by);


--
-- Name: idx_sys_login_log_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_login_log_create_by ON public.sys_login_log USING btree (create_by);


--
-- Name: idx_sys_login_log_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_login_log_update_by ON public.sys_login_log USING btree (update_by);


--
-- Name: idx_sys_menu_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_create_by ON public.sys_menu USING btree (create_by);


--
-- Name: idx_sys_menu_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_deleted_at ON public.sys_menu USING btree (deleted_at);


--
-- Name: idx_sys_menu_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_update_by ON public.sys_menu USING btree (update_by);


--
-- Name: idx_sys_opera_log_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_opera_log_create_by ON public.sys_opera_log USING btree (create_by);


--
-- Name: idx_sys_opera_log_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_opera_log_update_by ON public.sys_opera_log USING btree (update_by);


--
-- Name: idx_sys_post_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_post_create_by ON public.sys_post USING btree (create_by);


--
-- Name: idx_sys_post_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_post_deleted_at ON public.sys_post USING btree (deleted_at);


--
-- Name: idx_sys_post_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_post_update_by ON public.sys_post USING btree (update_by);


--
-- Name: idx_sys_role_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_role_create_by ON public.sys_role USING btree (create_by);


--
-- Name: idx_sys_role_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_role_deleted_at ON public.sys_role USING btree (deleted_at);


--
-- Name: idx_sys_role_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_role_update_by ON public.sys_role USING btree (update_by);


--
-- Name: idx_sys_tables_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_tables_create_by ON public.sys_tables USING btree (create_by);


--
-- Name: idx_sys_tables_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_tables_deleted_at ON public.sys_tables USING btree (deleted_at);


--
-- Name: idx_sys_tables_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_tables_update_by ON public.sys_tables USING btree (update_by);


--
-- Name: idx_sys_user_access_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_access_create_by ON public.sys_user_access USING btree (create_by);


--
-- Name: idx_sys_user_access_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_access_deleted_at ON public.sys_user_access USING btree (deleted_at);


--
-- Name: idx_sys_user_access_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_access_update_by ON public.sys_user_access USING btree (update_by);


--
-- Name: idx_sys_user_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_create_by ON public.sys_user USING btree (create_by);


--
-- Name: idx_sys_user_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_deleted_at ON public.sys_user USING btree (deleted_at);


--
-- Name: idx_sys_user_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_update_by ON public.sys_user USING btree (update_by);


--
-- Name: idx_wechat_analysis_snapshot_app_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wechat_analysis_snapshot_app_id ON public.wechat_analysis_snapshot USING btree (app_id);


--
-- Name: idx_wechat_analysis_snapshot_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wechat_analysis_snapshot_deleted_at ON public.wechat_analysis_snapshot USING btree (deleted_at);


--
-- Name: idx_wechat_analysis_snapshot_granularity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wechat_analysis_snapshot_granularity ON public.wechat_analysis_snapshot USING btree (granularity);


--
-- Name: idx_wechat_analysis_snapshot_metric_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wechat_analysis_snapshot_metric_id ON public.wechat_analysis_snapshot USING btree (metric_id);


--
-- Name: idx_wechat_analysis_snapshot_request_start_ts; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wechat_analysis_snapshot_request_start_ts ON public.wechat_analysis_snapshot USING btree (request_start_ts);


--
-- Name: idx_wechat_analysis_sync_config_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wechat_analysis_sync_config_deleted_at ON public.wechat_analysis_sync_config USING btree (deleted_at);


--
-- Name: uk_ocean_engine_daily_report; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uk_ocean_engine_daily_report ON public.ocean_engine_daily_report USING btree (report_date, data_topic, advertiser_id);


--
-- Name: uk_wechat_analysis_snapshot_request_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uk_wechat_analysis_snapshot_request_hash ON public.wechat_analysis_snapshot USING btree (request_hash);


--
-- Name: sys_menu_api_rule fk_sys_menu_api_rule_sys_api; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_menu_api_rule
    ADD CONSTRAINT fk_sys_menu_api_rule_sys_api FOREIGN KEY (sys_api_id) REFERENCES public.sys_api(id);


--
-- Name: sys_menu_api_rule fk_sys_menu_api_rule_sys_menu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_menu_api_rule
    ADD CONSTRAINT fk_sys_menu_api_rule_sys_menu FOREIGN KEY (sys_menu_menu_id) REFERENCES public.sys_menu(menu_id);


--
-- Name: sys_role_menu fk_sys_role_menu_sys_menu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role_menu
    ADD CONSTRAINT fk_sys_role_menu_sys_menu FOREIGN KEY (menu_id) REFERENCES public.sys_menu(menu_id);


--
-- Name: sys_role_menu fk_sys_role_menu_sys_role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role_menu
    ADD CONSTRAINT fk_sys_role_menu_sys_role FOREIGN KEY (role_id) REFERENCES public.sys_role(role_id);


--
-- PostgreSQL database dump complete
--

\unrestrict aC2hmujTn2r9ugMj49aHOYuwE3VfCDFswjdk0wkwZOpAb8uZzZzrwsXzaIXmmgV

