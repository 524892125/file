// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package logic

import (
	"context"

	"civet/apps/admin/api/internal/svc"
	"civet/apps/admin/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type ExtMenuTreeLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewExtMenuTreeLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ExtMenuTreeLogic {
	return &ExtMenuTreeLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ExtMenuTreeLogic) ExtMenuTree(req *types.MenuRoleReq) (resp *types.MenuRoleResp, err error) {
	menuList, _, err := l.svcCtx.SysMenuModel.FindPageByFields(l.ctx, 1, 999999, nil)
	items := make([]*types.MenuItem, 0, len(menuList))
	for _, item := range menuList {
		items = append(items, toMenuItem(item))
	}

	return &types.MenuRoleResp{Items: BuildMenuTree(items)}, nil
}
