// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package logic

import (
	"context"
	"errors"
	"net/http"
	"strings"

	"civet/apps/admin/api/internal/svc"
	"civet/apps/admin/api/internal/types"

	"github.com/golang-jwt/jwt/v4"
	"github.com/zeromicro/go-zero/core/logx"
)

type ExtGetInfoLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewExtGetInfoLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ExtGetInfoLogic {
	return &ExtGetInfoLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ExtGetInfoLogic) ExtGetInfo(req *types.GetInfoReq, r *http.Request) (resp *types.GetInfoResp, err error) {
	claims, err := l.parseAuthClaims(r)
	if err != nil {
		return nil, err
	}

	user, err := l.svcCtx.SysUserModel.FindOne(l.ctx, claims.UserId)
	if err != nil {
		return nil, err
	}

	return &types.GetInfoResp{
		Avatar:   strings.TrimSpace(user.Avatar.String),
		DeptId:   user.DeptId.Int64,
		Name:     strings.TrimSpace(user.NickName.String),
		UserId:   user.UserId,
		UserName: strings.TrimSpace(user.Username.String),
	}, nil
}

func (l *ExtGetInfoLogic) parseAuthClaims(r *http.Request) (*types.AuthClaims, error) {
	tokenString := strings.TrimSpace(r.Header.Get("Authorization"))
	if tokenString == "" {
		return nil, errors.New("missing authorization token")
	}
	if strings.HasPrefix(strings.ToLower(tokenString), "bearer ") {
		tokenString = strings.TrimSpace(tokenString[7:])
	}
	if tokenString == "" {
		return nil, errors.New("missing authorization token")
	}

	claims := new(types.AuthClaims)
	token, err := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, errors.New("token invalid")
		}
		return []byte(l.svcCtx.Config.Jwt.Secret), nil
	})
	if err != nil || !token.Valid {
		return nil, errors.New("token invalid")
	}
	return claims, nil
}
