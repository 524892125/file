// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package logic

import (
	"context"
	"errors"
	"sort"
	"strings"

	"civet/apps/admin/api/internal/middleware"
	"civet/apps/admin/api/internal/svc"
	"civet/apps/admin/api/internal/types"
	"civet/apps/admin/model"

	"github.com/zeromicro/go-zero/core/logx"
)

type ExtMenuRoleLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewExtMenuRoleLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ExtMenuRoleLogic {
	return &ExtMenuRoleLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ExtMenuRoleLogic) ExtMenuRole(req *types.MenuRoleReq) (resp *types.MenuRoleResp, err error) {
	claims, ok := middleware.AuthClaimsFromContext(l.ctx)
	if !ok {
		return nil, errors.New("token err")
	}

	menuList, _, err := l.svcCtx.SysMenuModel.FindPageByFields(l.ctx, 1, 999999, nil)
	if err != nil {
		return nil, err
	}

	var allowedMenuIds map[int64]struct{}
	if !isAdminRole(claims.RoleKey) {
		roleMenuList, _, err := l.svcCtx.SysRoleMenuModel.FindPageByFields(l.ctx, 1, 999999, []model.SysRoleMenuPageField{
			{
				Field: "role_id",
				Value: claims.RoleId,
				Op:    "=",
			},
		})

		if err != nil {
			return nil, err
		}

		allowedMenuIds = make(map[int64]struct{}, len(roleMenuList))
		for _, item := range roleMenuList {
			allowedMenuIds[item.MenuId] = struct{}{}
		}
		if len(allowedMenuIds) == 0 {
			return &types.MenuRoleResp{Items: nil}, nil
		}

		appendParentMenuIds(menuList, allowedMenuIds)
	}

	items := make([]*types.MenuItem, 0, len(menuList))
	for _, item := range menuList {
		if item.DeletedAt.Valid {
			continue
		}
		if !isAdminRole(claims.RoleKey) {
			if _, ok := allowedMenuIds[item.MenuId]; !ok {
				continue
			}
		}
		if strings.EqualFold(strings.TrimSpace(item.MenuType), "B") {
			continue
		}
		items = append(items, toMenuItem(item))
	}

	return &types.MenuRoleResp{Items: BuildMenuTree(items)}, nil
}

func isAdminRole(roleKey string) bool {
	return strings.EqualFold(strings.TrimSpace(roleKey), "admin")
}

func appendParentMenuIds(menuList []*model.SysMenu, menuIds map[int64]struct{}) {
	menuMap := make(map[int64]*model.SysMenu, len(menuList))
	for _, item := range menuList {
		menuMap[item.MenuId] = item
	}

	for {
		added := false
		for menuId := range menuIds {
			menu, ok := menuMap[menuId]
			if !ok || !menu.ParentId.Valid || menu.ParentId.Int64 == 0 {
				continue
			}
			if _, ok := menuIds[menu.ParentId.Int64]; ok {
				continue
			}
			menuIds[menu.ParentId.Int64] = struct{}{}
			added = true
		}
		if !added {
			return
		}
	}
}

func toMenuItem(item *model.SysMenu) *types.MenuItem {
	return &types.MenuItem{
		MenuId:     item.MenuId,
		MenuName:   item.MenuName,
		Title:      item.Title.String,
		Icon:       item.Icon.String,
		Path:       item.Path,
		MenuType:   item.MenuType,
		Action:     item.Action.String,
		Permission: item.Permission.String,
		ParentId:   item.ParentId.Int64,
		NoCache:    item.NoCache.Bool,
		Breadcrumb: item.Breadcrumb.String,
		Component:  item.Component.String,
		Sort:       int(item.Sort.Int64),
		Visible:    item.Visible.String,
		IsFrame:    item.IsFrame,
	}
}

func BuildMenuTree(items []*types.MenuItem) []*types.MenuItem {
	sort.Slice(items, func(i, j int) bool {
		if items[i].Sort != items[j].Sort {
			return items[i].Sort < items[j].Sort
		}
		return items[i].MenuId < items[j].MenuId
	})

	childrenMap := make(map[int64][]*types.MenuItem)
	for _, item := range items {
		childrenMap[item.ParentId] = append(childrenMap[item.ParentId], item)
	}

	var attach func(parentId int64) []*types.MenuItem
	attach = func(parentId int64) []*types.MenuItem {
		children := childrenMap[parentId]
		if len(children) == 0 {
			return nil
		}
		for _, child := range children {
			child.Children = attach(child.MenuId)
		}
		return children
	}

	return attach(0)
}
