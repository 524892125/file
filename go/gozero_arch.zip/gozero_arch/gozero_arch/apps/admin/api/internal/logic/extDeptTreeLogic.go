// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package logic

import (
	"context"
	"sort"

	"civet/apps/admin/api/internal/svc"
	"civet/apps/admin/api/internal/types"
	"civet/apps/admin/model"

	"github.com/zeromicro/go-zero/core/logx"
)

type ExtDeptTreeLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewExtDeptTreeLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ExtDeptTreeLogic {
	return &ExtDeptTreeLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ExtDeptTreeLogic) ExtDeptTree(req *types.ExtDeptTreeReq) (resp *types.ExtDeptTreeResp, err error) {
	deptList, _, err := l.svcCtx.SysDeptModel.FindPageByFields(l.ctx, 1, 999999, nil)
	if err != nil {
		return nil, err
	}

	items := make([]*types.ExtSysDept, 0, len(deptList))
	for _, d := range deptList {
		if d.DeletedAt.Valid {
			continue
		}
		items = append(items, toExtSysDept(d))
	}

	return &types.ExtDeptTreeResp{Items: buildDeptTree(items)}, nil
}

func toExtSysDept(d *model.SysDept) *types.ExtSysDept {
	return &types.ExtSysDept{
		DeptId:   d.DeptId,
		ParentId: d.ParentId.Int64,
		DeptPath: d.DeptPath.String,
		DeptName: d.DeptName.String,
		Sort:     d.Sort.Int64,
		Leader:   d.Leader.String,
		Phone:    d.Phone.String,
		Email:    d.Email.String,
		Status:   d.Status.Int64,
		CreateBy: d.CreateBy.Int64,
		UpdateBy: d.UpdateBy.Int64,
		CreatedAt: d.CreatedAt.Time.Format("2006-01-02 15:04:05"),
		UpdatedAt: d.UpdatedAt.Time.Format("2006-01-02 15:04:05"),
	}
}

func buildDeptTree(items []*types.ExtSysDept) []*types.ExtSysDept {
	sort.Slice(items, func(i, j int) bool {
		if items[i].Sort != items[j].Sort {
			return items[i].Sort < items[j].Sort
		}
		return items[i].DeptId < items[j].DeptId
	})

	childrenMap := make(map[int64][]*types.ExtSysDept)
	for _, item := range items {
		childrenMap[item.ParentId] = append(childrenMap[item.ParentId], item)
	}

	var attach func(parentId int64) []*types.ExtSysDept
	attach = func(parentId int64) []*types.ExtSysDept {
		children := childrenMap[parentId]
		if len(children) == 0 {
			return nil
		}
		for _, child := range children {
			child.Children = attach(child.DeptId)
		}
		return children
	}

	return attach(0)
}
