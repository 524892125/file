#!/usr/bin/python
# -*- coding: UTF-8 -*-

def args(content):
    print('\033[1;44m Args.@ ****** ' + content + '\033[0m')


def config(content):
    print('\033[1;44m Args.@ ****** ' + content + '\033[0m')

def step(content):
    print('\033[1;40m Step.@ ****** ' + content + '\033[0m')

def error(content):
    print('\033[1;31m Error.@ ' + content + '\033[0m')

def info(content):
    print('\033[1;44m Info.@ ' + content + '\033[0m')

def finish(content):
    print('\033[1;40m Finish.@ ' + content + '\033[0m')
