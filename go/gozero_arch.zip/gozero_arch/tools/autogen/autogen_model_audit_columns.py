#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import argparse
import re
import subprocess
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parents[2]
DELETE_COLUMNS = {"delete_at", "delete_time", "deleted_at"}


def lower_first(value: str) -> str:
    return value[:1].lower() + value[1:] if value else value


def parse_struct_fields(text: str, struct_name: str):
    match = re.search(rf"type\s+\(\s*.*?\n\s*{re.escape(struct_name)}\s+struct\s*\{{(.*?)\n\s*\}}", text, flags=re.S)
    if not match:
        match = re.search(rf"\b{re.escape(struct_name)}\s+struct\s*\{{(.*?)\n\s*\}}", text, flags=re.S)
    if not match:
        return []

    fields = []
    for line in match.group(1).splitlines():
        field_match = re.match(r"\s*([A-Z][A-Za-z0-9_]*)\s+[^\s`]+(?:\s+`db:\"([^\"]+)\"`)?", line)
        if not field_match:
            continue
        go_name, db_name = field_match.groups()
        if db_name:
            fields.append((go_name, db_name))
    return fields


def parse_primary_key(text: str, model_var: str):
    match = re.search(rf'{re.escape(model_var)}RowsWithPlaceHolder\s*=\s*builder\.PostgreSqlJoin\(stringx\.Remove\({re.escape(model_var)}FieldNames,\s*"([^"]+)"', text)
    if match:
        return match.group(1)
    match = re.search(rf'{re.escape(model_var)}RowsExpectAutoSet\s*=\s*strings\.Join\(stringx\.Remove\({re.escape(model_var)}FieldNames,\s*"([^"]+)"', text)
    if match:
        return match.group(1)
    return ""


def placeholders(count: int) -> str:
    return ", ".join(f"${idx}" for idx in range(1, count + 1))


def replace_func_body(text: str, func_pattern: str, replacer):
    match = re.search(func_pattern, text)
    if not match:
        return text
    start = match.start()
    brace_start = text.find("{", match.end() - 1)
    if brace_start == -1:
        return text
    depth = 0
    end = brace_start
    for index in range(brace_start, len(text)):
        char = text[index]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                end = index + 1
                break
    block = text[start:end]
    return text[:start] + replacer(block) + text[end:]


def update_model_file(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    struct_match = re.search(r"type\s+\(\s*.*?\n\s*([A-Z][A-Za-z0-9_]*)\s+struct\s*\{", text, flags=re.S)
    if not struct_match:
        return False

    struct_name = struct_match.group(1)
    model_var = lower_first(struct_name)
    fields = parse_struct_fields(text, struct_name)
    if not fields:
        return False

    primary_key = parse_primary_key(text, model_var)
    insert_fields = [(go_name, db_name) for go_name, db_name in fields if db_name != primary_key and db_name not in DELETE_COLUMNS]
    update_fields = insert_fields
    if not any(db_name in {"created_at", "create_at", "updated_at", "update_at"} for _, db_name in insert_fields):
        return False

    insert_remove_args = [f'"{primary_key}"'] if primary_key else []
    insert_remove_args.extend(f'"{column}"' for column in sorted(DELETE_COLUMNS))
    remove_expr = ", ".join(insert_remove_args)

    next_text = re.sub(
        rf'{re.escape(model_var)}RowsExpectAutoSet\s*=\s*strings\.Join\(stringx\.Remove\({re.escape(model_var)}FieldNames, .*?\), ","\)',
        f'{model_var}RowsExpectAutoSet = strings.Join(stringx.Remove({model_var}FieldNames, {remove_expr}), ",")',
        text,
        count=1,
    )
    next_text = re.sub(
        rf'{re.escape(model_var)}RowsWithPlaceHolder\s*=\s*builder\.PostgreSqlJoin\(stringx\.Remove\({re.escape(model_var)}FieldNames, .*?\)\)',
        f'{model_var}RowsWithPlaceHolder = builder.PostgreSqlJoin(stringx.Remove({model_var}FieldNames, {remove_expr}))',
        next_text,
        count=1,
    )

    insert_values = ", ".join(f"data.{go_name}" for go_name, _ in insert_fields)
    if primary_key:
        pk_go_name = next((go_name for go_name, db_name in fields if db_name == primary_key), "")
        update_field_names = [pk_go_name] + [go_name for go_name, _ in update_fields]
    else:
        update_field_names = [go_name for go_name, _ in update_fields]

    def replace_insert(block: str) -> str:
        returning_column = primary_key or "id"
        return re.sub(
            rf'query := fmt\.Sprintf\("insert into %s \(%s\) values \([^"]+\) returning [^"]+", m\.table, {re.escape(model_var)}RowsExpectAutoSet\)\n\s*var id int64\n\s*err := m\.conn\.QueryRowCtx\(ctx, &id, query, .*?\)',
            f'query := fmt.Sprintf("insert into %s (%s) values ({placeholders(len(insert_fields))}) returning {returning_column}", m.table, {model_var}RowsExpectAutoSet)\n\tvar id int64\n\terr := m.conn.QueryRowCtx(ctx, &id, query, {insert_values})',
            block,
            count=1,
            flags=re.S,
        )

    def replace_update(block: str) -> str:
        param_match = re.search(rf'Update\(ctx context\.Context,\s*(?:\w+\s+)?(\w+)\s+\*{re.escape(struct_name)}\)', block)
        data_var = param_match.group(1) if param_match else "data"
        update_values = ", ".join(f"{data_var}.{go_name}" for go_name in update_field_names)
        return re.sub(
            r'_, err := m\.conn\.ExecCtx\(ctx, query, .*?\)',
            f'_, err := m.conn.ExecCtx(ctx, query, {update_values})',
            block,
            count=1,
            flags=re.S,
        )

    next_text = replace_func_body(next_text, rf'func \(m \*default{re.escape(struct_name)}Model\) Insert\(', replace_insert)
    next_text = replace_func_body(next_text, rf'func \(m \*default{re.escape(struct_name)}Model\) Update\(', replace_update)

    if next_text == text:
        return False
    path.write_text(next_text, encoding="utf-8")
    subprocess.run(["gofmt", "-w", str(path)], check=True)
    return True


def sync_service(root_dir: Path, service: str):
    model_dir = root_dir / "apps" / service / "model"
    if not model_dir.is_dir():
        return []
    changed = []
    for path in sorted(model_dir.glob("*Model_gen.go")):
        if update_model_file(path):
            changed.append(path)
    return changed


def main():
    parser = argparse.ArgumentParser(description="Include audit time columns in generated go-zero model insert/update SQL")
    parser.add_argument("--root", default=str(ROOT_DIR))
    parser.add_argument("--service", required=True)
    args = parser.parse_args()

    root_dir = Path(args.root).resolve()
    changed = sync_service(root_dir, args.service)
    for path in changed:
        print(f"synced {path.relative_to(root_dir)}")
    print(f"synced model audit columns: {len(changed)} files")


if __name__ == "__main__":
    main()
