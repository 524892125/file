#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import argparse
import re
from pathlib import Path


METHOD_ORDER = {
    "GET": 0,
    "POST": 1,
    "PUT": 2,
    "PATCH": 3,
    "DELETE": 4,
}

WEBAPI_METHOD_ORDER = {
    "get": 0,
    "post": 1,
    "put": 2,
    "patch": 3,
    "delete": 4,
}


def normalize_newline(text: str) -> str:
    return text.rstrip() + "\n"


def sort_markdown_doc(path: Path) -> bool:
    if not path.exists():
        return False

    original = path.read_text(encoding="utf-8")
    blocks = re.split(r"(?m)(?=^###\s+\d+\.)", original.strip())
    blocks = [block.strip() for block in blocks if block.strip()]
    if not blocks:
        return False

    def key(item: tuple[int, str]) -> tuple[str, int, str, int]:
        index, block = item
        url_match = re.search(r"(?m)^- Url:\s*(.+)$", block)
        method_match = re.search(r"(?m)^- Method:\s*(\S+)", block)
        request_match = re.search(r"(?m)^- Request:\s*`?([^`\n]+)`?", block)
        url = url_match.group(1).strip() if url_match else ""
        method = method_match.group(1).strip().upper() if method_match else ""
        request = request_match.group(1).strip() if request_match else ""
        return (url, METHOD_ORDER.get(method, 99), request, index)

    sorted_blocks = []
    for new_index, (_, block) in enumerate(sorted(enumerate(blocks), key=key), start=1):
        sorted_blocks.append(re.sub(r"^###\s+\d+\.", f"### {new_index}.", block, count=1))

    updated = normalize_newline("\n\n".join(sorted_blocks))
    if updated == original:
        return False
    path.write_text(updated, encoding="utf-8")
    return True


def sort_ts_client(path: Path) -> bool:
    if not path.exists():
        return False

    original = path.read_text(encoding="utf-8")
    first_doc = original.find("/**")
    if first_doc < 0:
        return False

    header = original[:first_doc].rstrip()
    body = original[first_doc:].strip()
    blocks = re.split(r"\n(?=/\*\*\n)", body)
    blocks = [block.strip() for block in blocks if block.strip()]
    if not blocks:
        return False

    def key(item: tuple[int, str]) -> tuple[str, int, str, int]:
        index, block = item
        call_match = re.search(r"webapi\.(get|post|put|patch|delete)<[^>]+>\(`([^`]+)`", block)
        function_match = re.search(r"export\s+function\s+(\w+)", block)
        if call_match:
            method = call_match.group(1)
            url = call_match.group(2)
        else:
            method = ""
            url = ""
        function_name = function_match.group(1) if function_match else ""
        return (url, WEBAPI_METHOD_ORDER.get(method, 99), function_name, index)

    sorted_blocks = [block for _, block in sorted(enumerate(blocks), key=key)]
    updated = normalize_newline(header + "\n\n" + "\n\n".join(sorted_blocks))
    if updated == original:
        return False
    path.write_text(updated, encoding="utf-8")
    return True


def main() -> None:
    parser = argparse.ArgumentParser(description="Stabilize goctl API doc and TypeScript client output ordering")
    parser.add_argument("--markdown", action="append", default=[], help="markdown doc file to stabilize")
    parser.add_argument("--typescript", action="append", default=[], help="TypeScript client file to stabilize")
    args = parser.parse_args()

    changed = []
    for file_name in args.markdown:
        path = Path(file_name)
        if sort_markdown_doc(path):
            changed.append(str(path))
    for file_name in args.typescript:
        path = Path(file_name)
        if sort_ts_client(path):
            changed.append(str(path))

    for path in changed:
        print(f"stabilized {path}")
    print(f"stabilized api output files: {len(changed)}")


if __name__ == "__main__":
    main()
