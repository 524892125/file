#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import argparse
import re
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parents[2]


def sync_service_api_imports(root_dir: Path, service: str) -> bool:
    api_file = root_dir / "apps" / service / "api" / f"{service}.api"
    dbapi_dir = api_file.parent / "dbapi"
    if not api_file.exists() or not dbapi_dir.is_dir():
        return False

    imports = [f'\t"dbapi/{path.name}"' for path in sorted(dbapi_dir.glob("*.api"))]
    if not imports:
        return False

    text = api_file.read_text(encoding="utf-8")
    block = "import (\n" + "\n".join(imports) + "\n)"
    pattern = r'import\s*\(\s*(?:"dbapi/[^"]+"\s*)+\)'
    next_text, count = re.subn(pattern, block, text, count=1, flags=re.S)
    if count == 0 or next_text == text:
        return False

    api_file.write_text(next_text, encoding="utf-8")
    return True


def main():
    parser = argparse.ArgumentParser(description="Synchronize service API dbapi imports in stable order")
    parser.add_argument("--root", default=str(ROOT_DIR), help="repository root directory")
    parser.add_argument("--service", action="append", help="service name, can be specified multiple times")
    args = parser.parse_args()

    root_dir = Path(args.root).resolve()
    services = args.service or sorted(path.name for path in (root_dir / "apps").iterdir() if path.is_dir())
    changed = []
    for service in services:
        if sync_service_api_imports(root_dir, service):
            changed.append(service)
            print(f"synced apps/{service}/api/{service}.api imports")
    print(f"synced api import files: {len(changed)}")


if __name__ == "__main__":
    main()
