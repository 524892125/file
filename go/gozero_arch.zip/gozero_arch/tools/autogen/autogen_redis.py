#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys

import os
import sys
import copy
import json

import constant
import utils
import log

from collections import OrderedDict

temp_redis_keys_go = ""
temp_key_func = ""

temp_key_string = ""
temp_key_hash = ""
temp_key_list = ""
temp_key_set = ""
temp_key_zset = ""
temp_redis_sys_scope_go = ""

def read_template_content():
    global temp_redis_keys_go
    global temp_key_func
    global temp_key_string
    global temp_key_hash
    global temp_key_list
    global temp_key_set
    global temp_key_zset
    global temp_redis_sys_scope_go

    temp_redis_keys_go = utils.read_content(constant.temp_redis_dir + "redis_keys.go.tmp")
    temp_key_func = utils.read_content(constant.temp_redis_dir + "key_func.tmp")
    temp_key_string = utils.read_content(constant.temp_redis_dir + "key_string.tmp")
    temp_key_hash = utils.read_content(constant.temp_redis_dir + "key_hash.tmp")
    temp_key_list = utils.read_content(constant.temp_redis_dir + "key_list.tmp")
    temp_key_set = utils.read_content(constant.temp_redis_dir + "key_set.tmp")
    temp_key_zset = utils.read_content(constant.temp_redis_dir + "key_zset.tmp")
    temp_redis_sys_scope_go = utils.read_content(constant.temp_redis_dir + "redis_sys_scope.go.tmp")

def gen_key_func(key):
    func_key = key.replace("kiif", "")
    func_key = func_key.replace("%d", "")
    func_key = func_key.replace("%s", "")
    func_key = func_key.replace("{", "")
    func_key = func_key.replace("}", "")
    parts = func_key.split(":")
    func_name = "Key"
    for part in parts:
        if len(part) <= 0:
            continue
        func_name += part.capitalize()
    return func_name

def gen_key_call_func(key, key_type):
    func_key = key.replace("kiif", "")
    func_key = func_key.replace(key_type, "")
    func_key = func_key.replace("%d", "")
    func_key = func_key.replace("%s", "")
    func_key = func_key.replace("{", "")
    func_key = func_key.replace("}", "")
    parts = func_key.split(":")
    func_name = ""
    for part in parts:
        if len(part) <= 0:
            continue
        func_name += part.capitalize()
    return func_name

def get_key_format_tag(key):
    format_tags = []
    parts = key.split(":")
    for part in parts:
        if part.find("%") >= 0:
            part = part.replace("{", "")
            part = part.replace("}", "")
            format_tags.append(part)
    return format_tags

def is_format_tag_vs_params_equal(format_tag, param):
    data_type = param.split(" ")[1]
    if format_tag == "%s" and data_type == "string":
        return True
    if format_tag == "%d" and (
        data_type == "int" or
        data_type == "uint" or
        data_type == "int8" or
        data_type == "uint8" or
        data_type == "int16" or
        data_type == "uint16" or
        data_type == "int32" or
        data_type == "uint32" or
        data_type == "int64" or
        data_type == "uint64"
        ):
        return True
    return False

def gen_builder_str(key, params):
    if params is None:
        return "\tbuilder.WriteString(\"" + key + "\")"
    builder_str = ""
    parts = key.split("%")
    idx = 0
    for i in range(len(parts)):
        if i == 0:
            builder_str += "\tbuilder.WriteString(\"" + parts[i] + "\")\n"
        else:
            format_tag = "%" + parts[i][0]
            param_field = params[idx].split(" ")[0]
            if format_tag == "%s":
                builder_str += "\tbuilder.WriteString(" + param_field + ")\n"
            else:
                builder_str += "\tbuilder.WriteString(strconv.Itoa(int(" + param_field + ")))\n"
            idx += 1
            part = parts[i][1:]
            if len(part) > 0:
                builder_str += "\tbuilder.WriteString(\"" + part + "\")\n"
    if len(builder_str) > 0:
        builder_str = builder_str[:-1]
    return builder_str

def gen_key(key, key_info):
    desc = key_info.get('desc')
    type = key_info.get('type')
    params = key_info.get('params')
    if desc is None or type is None:
        log.error(key + " 缺少desc或type的配置")
        sys.exit(1)
    if key.find(":" + type) < 0:
        log.error(key + " 中类型与type不一致, type为" + type)
        sys.exit(1)
    note = """// #DESC#
// [ #TYPE# ] [ #KEY# ]"""
    note = note.replace("#DESC#", desc)
    note = note.replace("#KEY#", key)
    note = note.replace("#TYPE#", type)

    func_name = gen_key_func(key)
    format_tags = get_key_format_tag(key)
    if len(format_tags) > 0 and len(params) != len(format_tags):
        log.error(key + " 参数个数与格式化标签个数不一致, 请检查配置")
        sys.exit(1)
    if len(format_tags) > 0:
        for i in range(len(format_tags)):
            if not is_format_tag_vs_params_equal(format_tags[i], params[i]):
                log.error(key + " 格式化标签与参数类型不一致, 请检查配置")
                sys.exit(1)
    
    param_str = ""
    if params is not None and len(params) > 0:
        param_str = ", ".join(params)

    builder_str = gen_builder_str(key, params)

    global temp_key_func
    content = copy.deepcopy(temp_key_func)

    content = content.replace("#NOTE#", note)
    content = content.replace("#REDIS_KEY_FUNC#", func_name)
    content = content.replace("#REDIS_KEY_PARAMS#", param_str)
    content = content.replace("#REDIS_KEY_STRING_BUILDER#", builder_str)
    # print(content)
    return content


# 生成redis_keys.go
def gen_redis_keys():
    with open(constant.assets_database_redis_dir + "keys.json",'r') as f:
        data = json.load(f, object_pairs_hook=OrderedDict)

    global temp_redis_keys_go
    content = copy.deepcopy(temp_redis_keys_go)

    func_content = ""
    for sys, keys in data.items():
        func_content += "\n// ......................................." + sys + "...................................\n"
        for key in keys:
            for k, v in key.items():
                func_content += gen_key(k, v)
    content = content.replace("#REDIS_KEYS#", func_content)

    utils.write_content(constant.output_redis_dir + "redis_keys.go", content)


def gen_redis_key_funcs(sys, key, key_info):
    type = key_info.get('type')
    params = key_info.get('params')
    field = key_info.get('key')
    value = key_info.get('value')
    limit = key_info.get('limit')
    expire = key_info.get('expire')
    sys_scope = "Redis" + sys.capitalize() + "Scope"

    func_param = ""
    func_get_all_param = ""
    key_param = ""
    if params is not None and len(params) > 0:
        for param in params:
            key_param += param.split(" ")[0] + ", "
            func_param += param + ", "
            func_get_all_param += param + ", "
    if len(key_param) > 0:
        key_param = key_param[:-2]

    if field is not None:
        func_param += field + ", "

    func_set_param = func_param
    if value is not None:
        func_set_param += value + ", "

    if len(func_param) > 0:
        func_param = func_param[:-2]
    if len(func_get_all_param) > 0:
        func_get_all_param = func_get_all_param[:-2]
    if len(func_set_param) > 0:
        func_set_param = func_set_param[:-2]

    redis_key = gen_key_func(key) + "(" + key_param + ")"
    key_func = gen_key_call_func(key, type)
    
    input_field = ""
    input_exchange_field = ""
    input_value = ""
    return_type = ""
    return_redis_type = ""
    return_big_type = ""
    return_array_type = ""
    return_map_type = ""
    return_map_key = ""
    return_map_value = ""
    return_value = ""
    return_exchange_value = ""
    return_value_array = ""
    set_return_parse = ""
    set_return_skip = ""
    if field is not None:
        input_field = field.split(" ")[0]
        input_type = field.split(" ")[1]
        if input_type == "string":
            input_exchange_field = input_field
        else:
            input_exchange_field = "strconv.FormatUint(uint64(" + input_field + "), 10)"
    if value is not None:
        input_value = value.split(" ")[0]
        return_type = value.split(" ")[1]
        return_value = value.split(" ")[0]
        return_array_type = "[]" + return_type
        return_value_array = return_value + "s"
        if field is not None:
            map_key_type = field.split(" ")[1]
            map_value_type = return_type
            return_map_type = "map[" + field.split(" ")[1] + "]" + return_type
            if map_key_type == "string":
                return_map_key = "k"
            else:
                return_map_key = "util.StringTo" + map_key_type.capitalize() + "(k)"
            if map_value_type == "string":
                return_map_value = "v"
            else:
                return_map_value = "util.StringTo" + map_value_type.capitalize() + "(v)"
    if return_type == "string":
        return_redis_type = "Result"
        return_exchange_value = return_value
    else:
        return_redis_type = return_type.capitalize()
        if type == "hash" or type == "string":
            return_redis_type = "Uint64"
        return_exchange_value = return_type + "(" + return_value + ")"

    if return_type != "":
        return_big_type = return_type.capitalize()
        if return_type == "string":
            set_return_parse = "v"
            set_return_skip = "\t\tif val == \"\" {\n\t\t\tcontinue\n\t\t}"
        else:
            set_return_parse = "util.StringTo" + return_big_type + "(v)"
            set_return_skip = "\t\tif val == 0 {\n\t\t\tcontinue\n\t\t}"

    limit_str = "0"
    if limit is not None:
        limit_str = str(limit)
    expire_str = "0"
    if expire is not None:
        expire_str = str(expire)

    content = ""
    if type == "string":
        global temp_key_string
        content = copy.deepcopy(temp_key_string)
    elif type == "hash":
        global temp_key_hash
        content = copy.deepcopy(temp_key_hash)
    elif type == "list":
        global temp_key_list
        content = copy.deepcopy(temp_key_list)
    elif type == "set":
        global temp_key_set
        content = copy.deepcopy(temp_key_set)
    elif type == "zset":
        global temp_key_zset
        content = copy.deepcopy(temp_key_zset)
    else:
        log.error(key + " 类型错误, 请检查配置")
        sys.exit(1)

    content = content.replace("#SYSTEM_SCOPE#", sys_scope)
    content = content.replace("#KEY_FUNC#", key_func)
    content = content.replace("#PARAMS#", func_param)
    content = content.replace("#GET_ALL_PARAMS#", func_get_all_param)
    content = content.replace("#SET_PARAMS#", func_set_param)
    content = content.replace("#RETURN_TYPE#", return_type)
    content = content.replace("#RETURN_REDIS_TYPE#", return_redis_type)
    content = content.replace("#RETURN_BIG_TYPE#", return_big_type)
    content = content.replace("#RETURN_VALUE#", return_value)
    content = content.replace("#RETURN_EXCHANGE_VALUE#", return_exchange_value)
    content = content.replace("#RETURN_ARRAY_TYPE#", return_array_type)
    content = content.replace("#RETURN_MAP_TYPE#", return_map_type)
    content = content.replace("#MAP_KEY#", return_map_key)
    content = content.replace("#MAP_VALUE#", return_map_value)
    content = content.replace("#SET_RETURN_PARSE#", set_return_parse)
    content = content.replace("#SET_RETURN_SKIP#", set_return_skip)
    content = content.replace("#RETURN_VALUE_ARRAY#", return_value_array)
    content = content.replace("#REDIS_KEY#", "common." + redis_key)
    content = content.replace("#INPUT_FIELD#", input_field)
    content = content.replace("#INPUT_EXCHANGE_FIELD#", input_exchange_field)
    content = content.replace("#INPUT_VALUE#", input_value)
    content = content.replace("#LIMIT#", limit_str)
    content = content.replace("#EXPIRE#", expire_str)

    return content

def get_imports(keys, func_content):
    import_content = """
import (
    "context"
#STD_IMPORTS#
    "github.com/go-redis/redis/v9"
    "github.com/kiif/bear/com/common"
    "github.com/kiif/bear/core/logs"
#LOCAL_IMPORTS#
)"""
    std = dict()
    local = dict()
    std_str = ""
    local_str = ""

    if func_content.find("strconv.") >= 0:
        std["strconv"] = True
    if func_content.find("time.") >= 0:
        std["time"] = True
    if func_content.find("util") >= 0:
        local["github.com/kiif/bear/core/util"] = True

    for key in keys:
        for k, v in key.items():
            # if v.get('type') == 'zset':
            #     std["strconv"] = True
            # elif v.get('type') == 'hash' or v.get('type') =='set':
            #     local["github.com/kiif/bear/core/util"] = True
            # elif v.get('type') == 'string':
            #     std["time"] = True
            # if v.get("expire") is not None:
            #     std["time"] = True

            field = v.get('key')
            value = v.get('value')
            field_type = ""
            value_type = ""
            if field is not None:
                field_type = field.split(" ")[1]
            if value is not None:
                value_type = value.split(" ")[1]
            # if v.get('type') == 'hash' and (field_type != "string"):
            #     std["strconv"] = True

    for k, v in std.items():
        std_str += "\t\"" + k + "\"\n"
    for k, v in local.items():
        local_str += "\t\"" + k + "\""
    import_content = import_content.replace("#STD_IMPORTS#", std_str)
    import_content = import_content.replace("#LOCAL_IMPORTS#", local_str)
    return import_content

def gen_redis_sys_functions(sys, keys):
    global temp_redis_sys_scope_go
    content = copy.deepcopy(temp_redis_sys_scope_go)
    func_content = ""
    ext_func_content = dict()
    ext_keys = dict()
    for key in keys:
        for k, v in key.items():
            key_content = ""
            key_content += "// ...............................................................................\n"
            key_content += "// " + v.get('desc') + "\n"
            key_content += "// [" + v.get("type") + "] [" + k + "]\n"
            key_content += "// ...............................................................................\n\n"
            key_content += gen_redis_key_funcs(sys, k, v) + "\n\n"
            func_content += key_content
            if v.get("include_node") is not None:
                for include_node in v.get("include_node"):
                    if include_node not in ext_func_content:
                        ext_func_content[include_node] = key_content
                        ext_keys[include_node] = []
                        ext_keys[include_node].append(key)
                    else:
                        ext_func_content[include_node] += key_content
                        ext_keys[include_node].append(key)
    
    if len(func_content) > 0:
        func_content = func_content[:-1]

    # content = content.replace("#SYS#", sys.capitalize())
    # content = content.replace("#REDIS_FUNCTIONS#", func_content)
    # content = content.replace("#IMPORT#", get_imports(keys, func_content))
    # content = content.replace("#NODE#", "hall")
   
    # utils.write_content(constant.output_game_system_proj_dir + "redis_" + sys + "_auto.go", content)

    for include_node, func_content in ext_func_content.items():
        # global temp_redis_sys_scope_go
        content = copy.deepcopy(temp_redis_sys_scope_go)
        if len(func_content) > 0:
            func_content = func_content[:-1]
        content = content.replace("#SYS#", sys.capitalize())
        content = content.replace("#REDIS_FUNCTIONS#", func_content)
        content = content.replace("#IMPORT#", get_imports(ext_keys[include_node], func_content))
        content = content.replace("#NODE#", include_node)
        utils.write_content(constant.output_server_proj_dir + include_node + "/rpc/redis/redis_" + sys + "_auto.go", content)

def gen_redis_functions():
    with open(constant.assets_database_redis_dir + "keys.json",'r') as f:
        data = json.load(f, object_pairs_hook=OrderedDict)

    for sys, keys in data.items():
        gen_redis_sys_functions(sys, keys)

def do():
    read_template_content()
    
    log.info("正在基于keys.json配置生成redis_keys.go文件 ......")
    gen_redis_keys()

    log.info("正在基于keys.json配置生成redis操作函数 ......")
    gen_redis_functions()

    log.info("ok")

    os.system("cd " + constant.output_redis_dir + " && go fmt")
    # os.system("cd " + constant.output_game_system_proj_dir + " && go fmt")


if __name__ == '__main__':
    do()
