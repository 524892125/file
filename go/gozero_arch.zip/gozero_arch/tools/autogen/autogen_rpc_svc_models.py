#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import argparse
import re
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
FIELD_BEGIN = "\t// Code generated rpc model fields. DO NOT EDIT."
FIELD_END = "\t// End generated rpc model fields."
INIT_BEGIN = "\t\t// Code generated rpc model init. DO NOT EDIT."
INIT_END = "\t\t// End generated rpc model init."


def snake_to_camel(name):
    return "".join(part[:1].upper() + part[1:].lower() for part in re.split(r"[_\-\s]+", name) if part)


def parse_gen_targets(sql_path):
    for line in sql_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        match = re.match(r"--\s*@gen\s*:\s*(.+)$", stripped, flags=re.I)
        if match:
            return {item.strip().lower() for item in match.group(1).split(",") if item.strip()}
        if not stripped.startswith("--"):
            break
    return {"model", "api"}


def module_name(root_dir):
    for line in (root_dir / "go.mod").read_text(encoding="utf-8").splitlines():
        if line.startswith("module "):
            return line.split(None, 1)[1].strip()
    raise ValueError("module name not found")


def parse_table_name(sql_path):
    text = re.sub(r"/\*.*?\*/", "", sql_path.read_text(encoding="utf-8"), flags=re.S)
    text = "\n".join(line for line in text.splitlines() if not line.strip().startswith("--"))
    match = re.search(r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?P<name>[^\s(]+(?:\s*\.\s*[^\s(]+)?)", text, flags=re.I)
    if not match:
        raise ValueError(f"cannot parse table name: {sql_path}")
    raw = match.group("name").split(".")[-1].strip().strip('"')
    return raw.lower()


def ensure_import(text, import_path):
    if f'"{import_path}"' in text:
        return text
    single_match = re.search(r'import\s+"([^"]+)"', text)
    if single_match:
        existing = single_match.group(1)
        return text[:single_match.start()] + f'import (\n\t"{existing}"\n\t"{import_path}"\n)' + text[single_match.end():]
    block_match = re.search(r'import\s*\(\n(?P<body>.*?)\n\)', text, flags=re.S)
    if block_match:
        body = block_match.group("body").rstrip() + f'\n\t"{import_path}"'
        return text[:block_match.start("body")] + body + text[block_match.end("body"):]
    package_match = re.search(r'package\s+\w+\n', text)
    if not package_match:
        raise ValueError("package not found")
    return text[:package_match.end()] + f'\nimport "{import_path}"\n' + text[package_match.end():]


def ensure_blank_import(text, import_path):
    if f'_ "{import_path}"' in text:
        return text
    if f'"{import_path}"' in text:
        return text.replace(f'"{import_path}"', f'_ "{import_path}"')
    return ensure_import(text, import_path).replace(f'"{import_path}"', f'_ "{import_path}"')


def replace_or_insert_block(text, begin, end, lines, insert_pattern):
    block = "\n".join([begin, *lines, end])
    pattern = re.compile(re.escape(begin) + r".*?" + re.escape(end), flags=re.S)
    if pattern.search(text):
        return pattern.sub(block, text, count=1)
    match = re.search(insert_pattern, text)
    if not match:
        raise ValueError(f"insert point not found: {begin.strip()}")
    return text[:match.end()] + "\n" + block + text[match.end():]


def ensure_conn(text):
    match = re.search(r'func\s+NewServiceContext\s*\(c\s+config\.Config\)\s+\*ServiceContext\s*\{', text)
    if not match:
        raise ValueError("NewServiceContext not found")
    text = re.sub(r'\n\tconn\s*:=\s*sqlx\.New(?:Mysql|SqlConn)\([^\n]*\)\n', "\n", text)
    return text[:match.end()] + "\n\tconn := sqlx.NewSqlConn(c.Pg.DriverName, c.Pg.DataSource)\n" + text[match.end():]


def discover_rpc_models(root_dir, service):
    sql_dir = root_dir / "assets" / "sql" / service
    if not sql_dir.is_dir():
        return []
    models = []
    for sql_path in sorted(sql_dir.glob("*.sql")):
        if "rpc" not in parse_gen_targets(sql_path):
            continue
        name = snake_to_camel(parse_table_name(sql_path))
        models.append((f"{name}Model", f"model.{name}Model", f"model.New{name}Model(conn)"))
    return models


def sync_service_context(root_dir, service, models):
    module = module_name(root_dir)
    svc_path = root_dir / "apps" / service / "rpc" / "internal" / "svc" / "serviceContext.go"
    text = svc_path.read_text(encoding="utf-8")
    text = ensure_import(text, f"{module}/apps/{service}/model")
    text = ensure_blank_import(text, "github.com/lib/pq")
    text = ensure_import(text, "github.com/zeromicro/go-zero/core/stores/sqlx")
    text = replace_or_insert_block(text, FIELD_BEGIN, FIELD_END, [f"\t{field} {typ}" for field, typ, _ in models], r'type\s+ServiceContext\s+struct\s*\{\n\s*Config\s+config\.Config')
    text = ensure_conn(text)
    text = replace_or_insert_block(text, INIT_BEGIN, INIT_END, [f"\t\t{field}: {init}," for field, _, init in models], r'Config:\s*c,')
    svc_path.write_text(text, encoding="utf-8")
    return svc_path


def ensure_config(rpc_root):
    config_path = rpc_root / "internal" / "config" / "config.go"
    text = config_path.read_text(encoding="utf-8")
    if re.search(r"\bPg\s+sqlx\.SqlConf\b", text):
        return None
    text = ensure_import(text, "github.com/zeromicro/go-zero/core/stores/sqlx")
    next_text = re.sub(r'type\s+Config\s+struct\s*\{\s*zrpc\.RpcServerConf\s*\}', "type Config struct {\n\tzrpc.RpcServerConf\n\tPg sqlx.SqlConf\n}", text, flags=re.S)
    if next_text == text:
        raise ValueError(f"cannot insert Pg config into {config_path}")
    config_path.write_text(next_text, encoding="utf-8")
    return config_path


def ensure_yaml(rpc_root, service, database):
    yaml_path = rpc_root / "etc" / f"{service}.yaml"
    text = yaml_path.read_text(encoding="utf-8")
    block = f'Pg:\n  DataSource: "postgres://postgres:123456@127.0.0.1:5432/{database}?sslmode=disable"\n  DriverName: "postgres"\n'
    if re.search(r"(?m)^Pg:\s*$", text):
        text = re.sub(r'(?ms)^Pg:\n(?:  .+\n?)*', block, text)
    else:
        if text and not text.endswith("\n"):
            text += "\n"
        text += "\n" + block
    yaml_path.write_text(text, encoding="utf-8")
    return yaml_path


def sync_service(root_dir, service, database):
    models = discover_rpc_models(root_dir, service)
    rpc_root = root_dir / "apps" / service / "rpc"
    if not rpc_root.is_dir() or not models:
        return []
    changed = [sync_service_context(root_dir, service, models)]
    config_path = ensure_config(rpc_root)
    yaml_path = ensure_yaml(rpc_root, service, database)
    for path in (config_path, yaml_path):
        if path:
            changed.append(path)
    return changed


def main():
    parser = argparse.ArgumentParser(description="Sync rpc ServiceContext with @gen rpc models")
    parser.add_argument("--root", default=str(ROOT_DIR))
    parser.add_argument("--service", required=True)
    parser.add_argument("--database", required=True)
    args = parser.parse_args()
    changed = sync_service(Path(args.root).resolve(), args.service, args.database)
    for path in changed:
        print(f"synced {path.relative_to(Path(args.root).resolve())}")
    print(f"synced rpc service model contexts: {len(changed)} files")


if __name__ == "__main__":
    main()
