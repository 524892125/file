#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import argparse
import re
import subprocess
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
FIELD_BEGIN = "\t// Code generated model fields. DO NOT EDIT."
FIELD_END = "\t// End generated model fields."
INIT_BEGIN = "\t\t// Code generated model init. DO NOT EDIT."
INIT_END = "\t\t// End generated model init."
MIDDLEWARE_FIELD_BEGIN = "\t// Code generated middleware fields. DO NOT EDIT."
MIDDLEWARE_FIELD_END = "\t// End generated middleware fields."
MIDDLEWARE_INIT_BEGIN = "\t\t// Code generated middleware init. DO NOT EDIT."
MIDDLEWARE_INIT_END = "\t\t// End generated middleware init."


def module_name(root_dir):
    gomod = root_dir / "go.mod"
    if not gomod.exists():
        raise FileNotFoundError(f"go.mod not found: {gomod}")
    for line in gomod.read_text(encoding="utf-8").splitlines():
        if line.startswith("module "):
            return line.split(None, 1)[1].strip()
    raise ValueError(f"module name not found: {gomod}")


def discover_models(model_dir):
    models = []
    if not model_dir.is_dir():
        return models
    pattern = re.compile(r"func\s+New([A-Za-z0-9]+)Model\s*\(")
    for model_file in sorted(model_dir.glob("*Model.go")):
        text = model_file.read_text(encoding="utf-8")
        match = pattern.search(text)
        if match:
            name = match.group(1)
            models.append((f"{name}Model", f"model.{name}Model", f"model.New{name}Model(conn)"))
    return models


def discover_api_middlewares(service_api_dir):
    middlewares = set()
    dbapi_dir = service_api_dir / "dbapi"
    if not dbapi_dir.is_dir():
        return []

    for api_path in sorted(dbapi_dir.glob("*.api")):
        text = api_path.read_text(encoding="utf-8")
        for match in re.finditer(r"(?m)^\s*middleware\s*:\s*(.+)$", text):
            for item in match.group(1).split(","):
                middleware = item.strip()
                if middleware:
                    middlewares.add(middleware)

    return sorted(middlewares)


def ensure_import(text, import_path):
    if f'"{import_path}"' in text:
        return text

    single_match = re.search(r'import\s+"([^"]+)"', text)
    if single_match:
        existing = single_match.group(1)
        block = f'import (\n\t"{existing}"\n\t"{import_path}"\n)'
        return text[:single_match.start()] + block + text[single_match.end():]

    block_match = re.search(r'import\s*\(\n(?P<body>.*?)\n\)', text, flags=re.S)
    if block_match:
        body = block_match.group("body")
        body = body.rstrip() + f'\n\t"{import_path}"'
        return text[:block_match.start("body")] + body + text[block_match.end("body"):]

    package_match = re.search(r'package\s+svc\n', text)
    if not package_match:
        raise ValueError("package svc not found")
    return text[:package_match.end()] + f'\nimport "{import_path}"\n' + text[package_match.end():]


def ensure_blank_import(text, import_path):
    plain = f'"{import_path}"'
    blank = f'_ "{import_path}"'
    if blank in text:
        return text
    if plain in text:
        return text.replace(plain, blank)
    return ensure_import(text, import_path).replace(plain, blank)


def remove_import(text, import_path):
    line_pattern = re.compile(rf'\n\t(?:_\s+)?"{re.escape(import_path)}"')
    text = line_pattern.sub("", text)

    block_match = re.search(r'import\s*\(\n(?P<body>.*?)\n\)', text, flags=re.S)
    if block_match and not block_match.group("body").strip():
        text = text[:block_match.start()] + text[block_match.end():]

    single_match = re.search(rf'\nimport\s+(?:_\s+)?"{re.escape(import_path)}"\n', text)
    if single_match:
        text = text[:single_match.start()] + "\n" + text[single_match.end():]

    return text


def replace_or_insert_block(text, begin, end, lines, insert_pattern):
    block = "\n".join([begin, *lines, end])
    pattern = re.compile(re.escape(begin) + r".*?" + re.escape(end), flags=re.S)
    if pattern.search(text):
        return pattern.sub(block, text, count=1)

    match = re.search(insert_pattern, text)
    if not match:
        raise ValueError(f"insert point not found: {begin.strip()}")
    return text[:match.end()] + "\n" + block + text[match.end():]


def ensure_conn(text):
    match = re.search(r'func\s+NewServiceContext\s*\(c\s+config\.Config\)\s+\*ServiceContext\s*\{', text)
    if not match:
        raise ValueError("NewServiceContext not found")
    conn_line = "\n\tconn := sqlx.NewSqlConn(c.Pg.DriverName, c.Pg.DataSource)\n"
    text = re.sub(r'\n\tconn\s*:=\s*sqlx\.New(?:Mysql|SqlConn)\([^\n]*\)\n', "\n", text)
    return text[:match.end()] + conn_line + text[match.end():]


def sync_service_context(root_dir, service, models, middlewares):
    module = module_name(root_dir)
    svc_path = root_dir / "apps" / service / "api" / "internal" / "svc" / "serviceContext.go"
    text = svc_path.read_text(encoding="utf-8")
    if models:
        text = ensure_import(text, f"{module}/apps/{service}/model")
        text = ensure_blank_import(text, "github.com/lib/pq")
        text = ensure_import(text, "github.com/zeromicro/go-zero/core/stores/sqlx")
    else:
        text = remove_import(text, f"{module}/apps/{service}/model")
        text = remove_import(text, "github.com/lib/pq")
        text = remove_import(text, "github.com/zeromicro/go-zero/core/stores/sqlx")
    if middlewares:
        text = ensure_import(text, f"{module}/apps/{service}/api/internal/middleware")
    else:
        text = remove_import(text, f"{module}/apps/{service}/api/internal/middleware")
    if middlewares:
        text = ensure_import(text, "github.com/zeromicro/go-zero/rest")
    else:
        text = remove_import(text, "github.com/zeromicro/go-zero/rest")
    field_lines = [f"\t{field} {typ}" for field, typ, _ in models]
    init_lines = [f"\t\t{field}: {init}," for field, _, init in models]
    middleware_field_lines = [f"\t{name} rest.Middleware" for name in middlewares]
    middleware_init_lines = [f"\t\t{name}: middleware.New{name}().Handle," for name in middlewares]
    text = replace_or_insert_block(text, FIELD_BEGIN, FIELD_END, field_lines, r'type\s+ServiceContext\s+struct\s*\{\n\s*Config\s+config\.Config')
    text = replace_or_insert_block(text, MIDDLEWARE_FIELD_BEGIN, MIDDLEWARE_FIELD_END, middleware_field_lines, re.escape(FIELD_END))
    if models:
        text = ensure_conn(text)
    else:
        text = re.sub(r'\n\tconn\s*:=\s*sqlx\.New(?:Mysql|SqlConn)\([^\n]*\)\n', "\n", text)
    text = replace_or_insert_block(text, INIT_BEGIN, INIT_END, init_lines, r'Config:\s*c,')
    text = replace_or_insert_block(text, MIDDLEWARE_INIT_BEGIN, MIDDLEWARE_INIT_END, middleware_init_lines, re.escape(INIT_END))
    svc_path.write_text(text, encoding="utf-8")
    subprocess.run(["gofmt", "-w", str(svc_path)], check=True)
    return svc_path


def ensure_config_data_source(config_path):
    if not config_path.exists():
        return None
    text = config_path.read_text(encoding="utf-8")
    if re.search(r"\bPg\s+sqlx\.SqlConf\b", text):
        return None
    text = ensure_import(text, "github.com/zeromicro/go-zero/core/stores/sqlx")
    next_text = re.sub(
        r'type\s+Config\s+struct\s*\{\s*rest\.RestConf\s*(?:DataSource\s+string\s*)?\}',
        "type Config struct {\n\trest.RestConf\n\tPg sqlx.SqlConf\n}",
        text,
        flags=re.S,
    )
    if next_text == text and not re.search(r"\bPg\s+sqlx\.SqlConf\b", next_text):
        raise ValueError(f"cannot insert Pg config into {config_path}")
    config_path.write_text(next_text, encoding="utf-8")
    return config_path


def ensure_yaml_data_source(yaml_path):
    if not yaml_path.exists():
        return None
    text = yaml_path.read_text(encoding="utf-8")
    if re.search(r"(?m)^Pg:\s*$", text):
        return None
    text = re.sub(r'(?m)^DataSource:\s*.*\n?', "", text)
    if text and not text.endswith("\n"):
        text += "\n"
    text += "\nPg:\n  DataSource: \"postgres://postgres:123456@127.0.0.1:5432/database?sslmode=disable\"\n  DriverName: \"postgres\"\n"
    yaml_path.write_text(text, encoding="utf-8")
    return yaml_path


def sync_service(root_dir, service):
    models = discover_models(root_dir / "apps" / service / "model")
    middlewares = discover_api_middlewares(root_dir / "apps" / service / "api")
    if not models and not middlewares:
        return []

    api_root = root_dir / "apps" / service / "api"
    changed = [sync_service_context(root_dir, service, models, middlewares)]
    config_path = ensure_config_data_source(api_root / "internal" / "config" / "config.go")
    yaml_path = ensure_yaml_data_source(api_root / "etc" / f"{service}-api.yaml")
    for path in (config_path, yaml_path):
        if path:
            changed.append(path)
    return changed


def main():
    parser = argparse.ArgumentParser(description="Incrementally sync generated models into go-zero ServiceContext")
    parser.add_argument("--root", default=str(ROOT_DIR), help="repository root directory")
    parser.add_argument("--service", action="append", help="service name, can be specified multiple times")
    args = parser.parse_args()

    root_dir = Path(args.root).resolve()
    services = args.service or sorted(path.name for path in (root_dir / "apps").iterdir() if path.is_dir())
    changed = []
    for service in services:
        changed.extend(sync_service(root_dir, service))
    for path in changed:
        print(f"synced {path.relative_to(root_dir)}")
    print(f"synced service model contexts: {len(changed)} files")


if __name__ == "__main__":
    main()
