#!/usr/bin/python
# -*- coding: UTF-8 -*-

import hashlib
import json
import os
import socket
import time
from pathlib import Path


AUTOGEN_DIR = Path(__file__).resolve().parent
TEMPLATE_DIR = AUTOGEN_DIR / "assets" / "template"


# 格式化成2016-03-20 11:45:39形式
def format_time_now1():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


# 格式化成2016-03-20 11:45:39形式
def format_time_now2():
    return time.strftime("%Y-%m-%d_%H%M%S", time.localtime())


def execute(cmd):
    # print("antframe exec command: " + cmd)
    print('\033[1;36m Commond.@ ****** ' + cmd + '\033[0m')
    return os.system(cmd)


def args_log(content):
    print('\033[1;44m Args.@ ****** ' + content + '\033[0m')


def config_log(content):
    print('\033[1;44m Args.@ ****** ' + content + '\033[0m')


def step_log(content):
    print('\033[1;40m Step.@ ****** ' + content + '\033[0m')


def error_log(content):
    print('\033[1;31m Error.@ ****** ' + content + '\033[0m')

def info_log(content):
    print('\033[1;44m Info.@ ****** ' + content + '\033[0m')


def format_log(content):
    spacing1 = 5
    spacing2 = 10
    prefix1 = "%-" + str(spacing1) + "s"
    prefix2 = "%-" + str(spacing2) + "s"
    print((prefix1 + prefix2 + "%s") % ("", "content=", content))


def format_url(url):
    return url.replace('\\', '/')


def first_word_upper(str_val):
    if len(str_val) <= 0:
        return ""
    return str_val[0].upper() + str_val[1:]


def first_word_lower(str_val):
    if len(str_val) <= 0:
        return ""
    return str_val[0].lower() + str_val[1:]

def first_word_upper_other_lower(str_val):
    if len(str_val) <= 0:
        return ""
    return str_val[0].upper() + str_val[1:].lower()

def field_upper(field_name):
    if field_name.find("_") >= 0:
        arr = field_name.split("_")
        fname = ""
        for i in range(len(arr)):
            p = arr[i]
            if i != 0 and p[0] == p[0].upper():
                fname += "_"
            fname += p[0].upper() + p[1:]
        return fname
    else:
        return first_word_upper(field_name)
    
def field_lower(field_name):
    str = ""
    i = 0
    for w in field_name:
        if w.isupper() and i != 0:
            str += "_" + w.lower()
        else:
            str += w.lower()
        i += 1
    return str
    
def enum_to_name(enum_name):
    if enum_name.find("_") >= 0:
        arr = enum_name.split("_")
        fname = ""
        for i in range(len(arr)):
            p = arr[i]
            fname += p[0].upper() + p[1:].lower()
        return fname
    else:
        if len(enum_name) <= 0:
            return ""
        return enum_name[0].upper() + enum_name[1:].lower()
    
def name_to_lower(name, split):
    ret = ""
    for i in range(len(name)):
        if name[i].isupper() and i != 0:
            ret += split
        ret += name[i].lower()
    return ret
            

def get_file_md5(filename):
    if not os.path.isfile(filename):
        return ""
    fileHash = hashlib.md5()
    f = open(filename, 'rb')
    while True:
        b = f.read(8096)
        if not b:
            break
        fileHash.update(b)
    f.close()
    return fileHash.hexdigest()


def load_json(json_file):
    f = open(json_file)
    ctx = json.load(f)
    return ctx


def read_content(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()
    content = ""
    for line in lines:
        content += line
    return content

def load_template(relative_path):
    return (TEMPLATE_DIR / relative_path).read_text(encoding="utf-8")

def render_template(relative_path, values):
    content = load_template(relative_path)
    for key, value in values.items():
        content = content.replace("#" + key + "#", str(value))
    return content

def exec_cmd(cmd):
    r = os.popen(cmd)
    text = r.read()
    r.close()
    return text

def get_host_ip():
    """
    查询本机ip地址
    :return:
    """
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        s.connect(('8.8.8.8',80))
        ip=s.getsockname()[0]
    finally:
        s.close()

    return ip


def sub_word(line, prefix, suffix):
    start_index = line.find(prefix)
    end_index = line.find(suffix)
    return line[start_index: end_index+len(suffix)]

def common_sub_word(line, prefix):
    line = line.replace("\r\n", "")
    line = line.replace("\n", "")
    line = line.replace("\t", " ")
    line = line.replace("//", " ")
    line = line.replace("=", " ")
    start_index = line.find(prefix)
    if start_index < 0:
        return ""
    sub_str = line[start_index:]
    end_index = sub_str.find(" ")
    if end_index < 0:
        end_index = sub_str.find("//")
        if end_index < 0:
            return sub_str
    return sub_str[:end_index]

def common_sub_word1(line, prefix):
    line = line.replace("\r\n", "")
    line = line.replace("\n", "")
    line = line.replace("\t", " ")
    line = line.replace("//", " ")
    line = line.replace("=", " ")
    line = line.replace("{", " ")
    start_index = line.find(prefix)
    if start_index < 0:
        print(line, prefix, start_index)
        return ""
    sub_str = line[start_index:]
    end_index = sub_str.find(" ")
    if end_index < 0:
        end_index = sub_str.find("//")
        if end_index < 0:
            return sub_str
    return sub_str[:end_index]


def walk_filepaths(file_dir):
    file_paths = []
    for filename in os.listdir(file_dir):
        file_path = os.path.join(file_dir, filename)
        if not os.path.isfile(file_path):
            continue
        file_paths.append(file_path)
    return file_paths

def walk_filenames(file_dir):
    file_names = []
    for filename in os.listdir(file_dir):
        file_path = os.path.join(file_dir, filename)
        if not os.path.isfile(file_path):
            continue
        file_names.append(filename)
    return file_names

def walk_filenames_by_tag(file_dir, tag):
    filenames = []
    for filename in os.listdir(file_dir):
        file_path = os.path.join(file_dir, filename)
        if not os.path.isfile(file_path):
            continue
        if file_path.find(tag) >= 0:
            filenames.append(filename)
    filenames = sorted(filenames)
    return filenames

def os_system_noprint(cmd):
    devnull = open(os.devnull, 'w')
    os.system(cmd + " > " + os.devnull + " 2>&1")

def count_char_before_comment(message, char_to_count, comment_symbol):
    comment_pos = message.find(comment_symbol)
    if comment_pos != -1:
        message = message[:comment_pos]
    
    count = message.count(char_to_count)
    
    return count

def check_dir_exists(file_dir):
    if os.path.exists(file_dir) == False:
        os.makedirs(file_dir)

def write_content(file_path, content):
    file_dir = file_path[0:file_path.rfind("/")]
    check_dir_exists(file_dir)
    with open(file_path, 'w') as f:
        f.write(content)

def is_struct_type(field_type):
    base_type = field_type
    if field_type.startswith('[]'):
        base_type = field_type[2:]
    elif field_type.startswith('map<'):
        index = field_type.index(',')
        base_type = field_type[index+1:field_type.index('>')]
        base_type = base_type.replace(" ", "")
    return not is_type(base_type)

def is_type(base_type):
    if base_type == 'int' or \
        base_type == 'int8' or \
        base_type == 'int16' or \
        base_type == 'int32' or \
        base_type == 'int64' or \
        base_type == 'uint8' or \
        base_type == 'uint16' or \
        base_type == 'uint32' or \
        base_type == 'uint64' or \
        base_type == 'sint32' or \
        base_type == 'sint64' or \
        base_type == 'fixed32' or \
        base_type == 'fixed64' or \
        base_type == 'sfixed32' or \
        base_type == 'sfixed64' or \
        base_type == 'float' or \
        base_type == 'double' or \
        base_type == 'float32' or \
        base_type == 'float64' or \
        base_type == 'bool' or \
        base_type == 'string' or \
        base_type == 'byte' or \
        base_type == 'bytes':
        return True
    return False


if __name__ == '__main__':
    execute("ls -a")
    message = "Hello { {"
    char_to_count = "{"
    count = count_char_before_comment(message, char_to_count, "//")

    print("count", count)
