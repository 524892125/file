#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import argparse
import re
from pathlib import Path


DEFAULT_TARGETS = {"model", "api"}


def sql_has_gen(sql_file: Path, target: str) -> bool:
    for line in sql_file.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        match = re.match(r"--\s*@gen\s*:\s*(.*)$", stripped, flags=re.I)
        if match:
            items = {item.strip().lower() for item in match.group(1).split(",") if item.strip()}
            return target.lower() in items
        if stripped.startswith("--"):
            continue
        break
    return target.lower() in DEFAULT_TARGETS


def main():
    parser = argparse.ArgumentParser(description="Filter SQL files by -- @gen annotation target")
    parser.add_argument("--target", required=True, help="generation target, such as model/api/ui")
    parser.add_argument("sql_files", nargs="*", help="SQL files to check")
    args = parser.parse_args()

    for sql_file in args.sql_files:
        path = Path(sql_file)
        if path.is_file() and sql_has_gen(path, args.target):
            print(sql_file)


if __name__ == "__main__":
    main()
