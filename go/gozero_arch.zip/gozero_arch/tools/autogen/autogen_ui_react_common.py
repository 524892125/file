#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import re
import shutil
from dataclasses import dataclass
from pathlib import Path

from autogen_pg_sql_api import parse_gen_targets, parse_sql, snake_to_camel


AUTO_HIDE_FIELDS = {
    "created_at",
    "updated_at",
    "deleted_at",
    "create_at",
    "update_at",
    "delete_at",
    "salt",
}

SYSTEM_FIELDS = {
    "created_at",
    "updated_at",
    "deleted_at",
    "create_at",
    "update_at",
    "delete_at",
    "create_by",
    "update_by",
}


@dataclass(frozen=True)
class TableMeta:
    table_name: str
    model_name: str
    model_var: str
    file_stem: str
    route_segment: str
    columns: list
    primary_keys: list[str]
    id_column: str
    id_field: str
    gen_targets: set[str]


def camel_to_kebab(value: str) -> str:
    value = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", value)
    return value.replace("_", "-").lower()


def service_pascal(service: str) -> str:
    return snake_to_camel(service.replace("-", "_"))


def column_name(column) -> str:
    return column.name if hasattr(column, "name") else column[0]


def column_api_type(column) -> str:
    return column.api_type if hasattr(column, "api_type") else column[1]


def column_nullable(column) -> bool:
    return bool(column.nullable) if hasattr(column, "nullable") else False


def field_name(name: str) -> str:
    field = snake_to_camel(name, upper_first=False)
    if field in {"default", "class", "function"}:
        return f"{field}Value"
    return field


def raw_field_name(name: str) -> str:
    return snake_to_camel(name, upper_first=False)


def ts_type(api_type: str) -> str:
    if api_type in {"int64", "float64"}:
        return "number"
    if api_type == "bool":
        return "boolean"
    return "string"


def field_title(name: str) -> str:
    return snake_to_camel(name)


def form_type(name: str, api_type: str) -> str:
    lower = name.lower()
    if "password" in lower:
        return "password"
    if lower in {"remark", "description", "content"} or lower.endswith("_remark"):
        return "textarea"
    if api_type in {"int64", "float64"}:
        return "number"
    if api_type == "bool":
        return "checkbox"
    if "time" in lower or lower.endswith("_at") or lower.endswith("_date"):
        return "datetime-local"
    return "text"


def literal(value: str) -> str:
    return repr(value)


def ui_tables(root_dir: Path, service: str, target: str = "ui-react") -> list[TableMeta]:
    sql_dir = root_dir / "assets" / "sql" / service
    if not sql_dir.is_dir():
        raise FileNotFoundError(f"sql dir not found: {sql_dir}")

    tables = []
    for sql_path in sorted(sql_dir.glob("*.sql")):
        gen_targets = parse_gen_targets(sql_path)
        if target not in gen_targets:
            continue
        table_name, columns, primary_keys = parse_sql(sql_path)
        model_name = snake_to_camel(table_name)
        file_stem = table_name.replace("_", "-")
        id_column = primary_keys[0] if primary_keys else column_name(columns[0])
        tables.append(
            TableMeta(
                table_name=table_name,
                model_name=model_name,
                model_var=snake_to_camel(table_name, upper_first=False),
                file_stem=file_stem,
                route_segment=file_stem,
                columns=columns,
                primary_keys=primary_keys,
                id_column=id_column,
                id_field=field_name(id_column),
                gen_targets=gen_targets,
            )
        )
    return tables


def assert_generated_file(path: Path, marker: str | tuple[str, ...]):
    if not path.exists():
        return
    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise RuntimeError(f"refuse to overwrite non-text file: {path}") from exc
    markers = (marker,) if isinstance(marker, str) else marker
    if not content.startswith(markers):
        raise RuntimeError(f"refuse to overwrite non-generated file: {path}")


def write_generated(path: Path, content: str | None, marker: str | tuple[str, ...]):
    assert_generated_file(path, marker)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text((content or "").rstrip() + "\n", encoding="utf-8")


def remove_generated_file(path: Path, marker: str | tuple[str, ...]):
    if not path.exists():
        return False
    assert_generated_file(path, marker)
    path.unlink()
    return True


def remove_generated_dir(path: Path, marker: str | tuple[str, ...]):
    if not path.exists():
        return False
    if not path.is_dir():
        remove_generated_file(path, marker)
        return True

    files = [item for item in path.rglob("*") if item.is_file()]
    for file_path in files:
        assert_generated_file(file_path, marker)
    shutil.rmtree(path)
    return True


def prune_empty_dirs(path: Path, stop_at: Path):
    current = path
    stop_at = stop_at.resolve()
    while current.exists() and current.is_dir() and current.resolve() != stop_at:
        try:
            current.rmdir()
        except OSError:
            break
        current = current.parent
