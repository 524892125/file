#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import argparse
import re
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
BEGIN = "// Code generated rpc crud begin. DO NOT EDIT."
END = "// Code generated rpc crud end."
AUTO_SET_COLUMNS = {"id", "created_at", "updated_at", "deleted_at", "create_at", "update_at", "delete_at"}


def snake_to_camel(name, upper_first=True):
    parts = [part for part in re.split(r"[_\-\s]+", name) if part]
    value = "".join(part[:1].upper() + part[1:].lower() for part in parts)
    if upper_first or not value:
        return value
    return value[:1].lower() + value[1:]


def parse_gen_targets(sql_path):
    for line in sql_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        match = re.match(r"--\s*@gen\s*:\s*(.+)$", stripped, flags=re.I)
        if match:
            return {item.strip().lower() for item in match.group(1).split(",") if item.strip()}
        if not stripped.startswith("--"):
            break
    return {"model", "api"}


def strip_sql_comments(content):
    content = re.sub(r"/\*.*?\*/", "", content, flags=re.S)
    lines = []
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("--"):
            continue
        lines.append(line)
    return "\n".join(lines)


def split_columns(body):
    items, current = [], []
    depth = 0
    quote = None
    dollar_tag = None
    index = 0
    while index < len(body):
        char = body[index]
        if dollar_tag:
            current.append(char)
            if body.startswith(dollar_tag, index):
                current.extend(body[index + 1:index + len(dollar_tag)])
                index += len(dollar_tag)
                dollar_tag = None
                continue
            index += 1
            continue
        if quote:
            current.append(char)
            if char == quote:
                if quote == "'" and index + 1 < len(body) and body[index + 1] == "'":
                    current.append(body[index + 1])
                    index += 2
                    continue
                quote = None
            index += 1
            continue
        dollar_match = re.match(r"\$[A-Za-z0-9_]*\$", body[index:])
        if dollar_match:
            dollar_tag = dollar_match.group(0)
            current.append(dollar_tag)
            index += len(dollar_tag)
            continue
        if char in ("'", '"'):
            quote = char
            current.append(char)
            index += 1
            continue
        if char == "(":
            depth += 1
        elif char == ")" and depth > 0:
            depth -= 1
        if char == "," and depth == 0:
            item = "".join(current).strip()
            if item:
                items.append(item)
            current = []
            index += 1
            continue
        current.append(char)
        index += 1
    item = "".join(current).strip()
    if item:
        items.append(item)
    return items


def normalize_identifier(value):
    value = value.strip()
    if value.startswith('"') and value.endswith('"'):
        return value[1:-1].replace('""', '"')
    return value.lower()


def parse_table_name(raw_name):
    parts, token = [], []
    quote = False
    for char in raw_name.strip():
        if char == '"':
            quote = not quote
            token.append(char)
            continue
        if char == "." and not quote:
            parts.append("".join(token).strip())
            token = []
            continue
        token.append(char)
    if token:
        parts.append("".join(token).strip())
    return normalize_identifier(parts[-1])


def parse_column_name(line):
    match = re.match(r'"((?:[^"]|"")+?)"\s+(.+)', line)
    if match:
        return match.group(1).replace('""', '"'), match.group(2)
    match = re.match(r"([a-zA-Z_][a-zA-Z0-9_]*)\s+(.+)", line)
    if match:
        return match.group(1).lower(), match.group(2)
    return None, None


def parse_primary_key_columns(value):
    return [normalize_identifier(item.strip()) for item in value.split(",") if item.strip()]


def extract_pg_type(column_def):
    words = column_def.strip().split()
    if len(words) >= 3 and " ".join(words[:2]).lower() in {"timestamp with", "timestamp without", "time with", "time without"}:
        return " ".join(words[:3]).lower()
    if len(words) >= 2 and " ".join(words[:2]).lower() in {"double precision", "character varying"}:
        return " ".join(words[:2]).lower()
    return words[0].lower()


def pg_type_to_proto_type(pg_type):
    base_type = pg_type.split("(", 1)[0].lower()
    if base_type in {"smallint", "int2", "integer", "int", "int4"}:
        return "int32"
    if base_type in {"bigint", "int8", "smallserial", "serial", "serial4", "bigserial", "serial8"}:
        return "int64"
    if base_type in {"real", "float4"}:
        return "float"
    if base_type in {"double precision", "float8", "numeric", "decimal", "money"}:
        return "double"
    if base_type in {"boolean", "bool"}:
        return "bool"
    return "string"


def parse_sql(sql_path):
    content = strip_sql_comments(sql_path.read_text(encoding="utf-8"))
    match = re.search(
        r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?P<name>(?:\"(?:[^\"]|\"\")+\"|[a-zA-Z_][a-zA-Z0-9_]*)(?:\s*\.\s*(?:\"(?:[^\"]|\"\")+\"|[a-zA-Z_][a-zA-Z0-9_]*))?)\s*\((?P<body>.*)\)\s*;",
        content,
        flags=re.I | re.S,
    )
    if not match:
        raise ValueError(f"cannot parse create table: {sql_path}")
    columns, primary_keys = [], []
    for item in split_columns(match.group("body")):
        line = " ".join(item.split())
        if re.match(r"(?:CONSTRAINT\s+\S+\s+)?PRIMARY\s+KEY\s*\(", line, flags=re.I):
            primary_match = re.search(r"PRIMARY\s+KEY\s*\((.*?)\)", line, flags=re.I)
            if primary_match:
                primary_keys = parse_primary_key_columns(primary_match.group(1))
            continue
        if re.match(r"(?:CONSTRAINT|UNIQUE|CHECK|FOREIGN|EXCLUDE)\b", line, flags=re.I):
            continue
        column_name, column_def = parse_column_name(line)
        if not column_name:
            continue
        columns.append((column_name, pg_type_to_proto_type(extract_pg_type(column_def))))
        if re.search(r"\bPRIMARY\s+KEY\b", column_def, flags=re.I):
            primary_keys.append(column_name)
    if not columns:
        raise ValueError(f"no columns found: {sql_path}")
    return parse_table_name(match.group("name")), columns, primary_keys


def render_model(sql_path):
    table_name, columns, primary_keys = parse_sql(sql_path)
    model_name = snake_to_camel(table_name)
    id_column = primary_keys[0] if primary_keys else columns[0][0]
    id_name = snake_to_camel(id_column)
    lines = [f"// Source: {sql_path.relative_to(ROOT_DIR)}", f"message {model_name} {{"]
    for index, (column_name, proto_type) in enumerate(columns, 1):
        lines.append(f"  {proto_type} {snake_to_camel(column_name, False)} = {index};")
    lines.extend(["}", "", f"message {model_name}CreateReq {{"])
    field_no = 1
    for column_name, proto_type in columns:
        if column_name in AUTO_SET_COLUMNS:
            continue
        lines.append(f"  {proto_type} {snake_to_camel(column_name, False)} = {field_no};")
        field_no += 1
    lines.extend(["}", "", f"message {model_name}UpdateReq {{", f"  int64 {snake_to_camel(id_column, False)} = 1;"])
    field_no = 2
    for column_name, proto_type in columns:
        if column_name in AUTO_SET_COLUMNS or column_name == id_column:
            continue
        lines.append(f"  optional {proto_type} {snake_to_camel(column_name, False)} = {field_no};")
        field_no += 1
    lines.extend([
        "}",
        "",
        f"message {model_name}IdReq {{",
        f"  int64 {snake_to_camel(id_column, False)} = 1;",
        "}",
        "",
        f"message {model_name}ListReq {{",
        "  int64 page = 1;",
        "  int64 pageSize = 2;",
        "}",
        "",
        f"message {model_name}ListResp {{",
        f"  repeated {model_name} list = 1;",
        "  int64 total = 2;",
        "}",
        "",
        f"message {model_name}FindPageResp {{",
        f"  repeated {model_name} list = 1;",
        "  int64 pageIndex = 2;",
        "  int64 pageSize = 3;",
        "  int64 count = 4;",
        "}",
        "",
        f"message {model_name}CreateResp {{",
        f"  int64 {snake_to_camel(id_column, False)} = 1;",
        "}",
        "",
        f"message {model_name}EmptyResp {{}}",
    ])
    methods = [
        f"  rpc Create{model_name}({model_name}CreateReq) returns({model_name}CreateResp);",
        f"  rpc Get{model_name}({model_name}IdReq) returns({model_name});",
        f"  rpc List{model_name}({model_name}ListReq) returns({model_name}ListResp);",
        f"  rpc FindPage{model_name}({model_name}ListReq) returns({model_name}FindPageResp);",
        f"  rpc Update{model_name}({model_name}UpdateReq) returns({model_name}EmptyResp);",
        f"  rpc Delete{model_name}({model_name}IdReq) returns({model_name}EmptyResp);",
    ]
    return model_name, "\n".join(lines), methods


def replace_generated_block(text, block):
    wrapped = f"{BEGIN}\n{block}\n{END}"
    pattern = re.compile(re.escape(BEGIN) + r".*?" + re.escape(END), flags=re.S)
    if pattern.search(text):
        return pattern.sub(wrapped, text, count=1)
    service_match = re.search(r"service\s+\w+\s*\{(?P<body>.*?)\n\}", text, flags=re.S)
    if not service_match:
        raise ValueError("service block not found")
    return text[:service_match.start()] + wrapped + "\n\n" + text[service_match.start():]


def replace_service_methods(text, methods):
    method_block = "\n".join(methods)
    service_match = re.search(r"service\s+\w+\s*\{(?P<body>.*?)\n\}", text, flags=re.S)
    if not service_match:
        raise ValueError("service block not found")
    body = service_match.group("body")
    pattern = re.compile(r"\n\s*" + re.escape(BEGIN) + r".*?" + re.escape(END), flags=re.S)
    generated = f"\n  {BEGIN}\n{method_block}\n  {END}"
    if pattern.search(body):
        body = pattern.sub(generated, body, count=1)
    else:
        body = body.rstrip() + generated
    return text[:service_match.start("body")] + body + text[service_match.end("body"):]


def sync_service(root_dir, service):
    sql_dir = root_dir / "assets" / "sql" / service
    proto_path = root_dir / "apps" / service / "rpc" / f"{service}.proto"
    if not sql_dir.is_dir() or not proto_path.exists():
        return None
    sql_files = [path for path in sorted(sql_dir.glob("*.sql")) if "rpc" in parse_gen_targets(path)]
    if not sql_files:
        return None
    text = proto_path.read_text(encoding="utf-8")
    models, methods = [], []
    for sql_path in sql_files:
        _, model_block, model_methods = render_model(sql_path)
        models.append(model_block)
        methods.extend(model_methods)
    text = replace_generated_block(text, "\n\n".join(models))
    text = replace_service_methods(text, methods)
    proto_path.write_text(text, encoding="utf-8")
    return proto_path


def main():
    parser = argparse.ArgumentParser(description="Generate rpc CRUD proto blocks from PostgreSQL DDL")
    parser.add_argument("--root", default=str(ROOT_DIR))
    parser.add_argument("--service", action="append")
    args = parser.parse_args()
    root_dir = Path(args.root).resolve()
    services = args.service or sorted(path.name for path in (root_dir / "apps").iterdir() if path.is_dir())
    changed = []
    for service in services:
        path = sync_service(root_dir, service)
        if path:
            changed.append(path)
    for path in changed:
        print(f"generated {path.relative_to(root_dir)}")
    print(f"generated rpc proto files: {len(changed)}")


if __name__ == "__main__":
    main()
