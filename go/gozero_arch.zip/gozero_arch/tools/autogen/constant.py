#!/usr/bin/python3
# -*- coding: UTF-8 -*-


import os

workspace_dir = os.path.dirname(os.path.split(os.path.realpath(__file__))[0]) + '/'
tool_dir = workspace_dir + "autogen/"
project_dir = workspace_dir + "../"

temp_dir = tool_dir + "assets/template/"
temp_redis_dir = temp_dir + "redis/"
temp_static_dir = temp_dir + "static/"

assets_database_redis_dir = project_dir + "assets/redis/"

output_redis_dir = project_dir + "com/common/"

output_server_proj_dir = project_dir + "apps/"
# output_game_system_proj_dir = project_dir + "server/hall/"



