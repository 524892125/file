#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import argparse
import re
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parents[2]


def find_add_routes_blocks(text: str) -> list[tuple[int, int, str]]:
    blocks = []
    pattern = "\tserver.AddRoutes("
    index = 0
    while True:
        start = text.find(pattern, index)
        if start < 0:
            return blocks

        depth = 0
        end = start
        in_string = False
        escaped = False
        while end < len(text):
            char = text[end]
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
            else:
                if char == '"':
                    in_string = True
                elif char == "(":
                    depth += 1
                elif char == ")":
                    depth -= 1
                    if depth == 0:
                        end += 1
                        if end < len(text) and text[end] == "\n":
                            end += 1
                        blocks.append((start, end, text[start:end]))
                        index = end
                        break
            end += 1
        else:
            return blocks


def route_prefix(block: str) -> str:
    match = re.search(r'rest\.WithPrefix\("([^"]+)"\)', block)
    return match.group(1) if match else ""


def sync_routes(path: Path) -> bool:
    if not path.exists():
        return False

    text = path.read_text(encoding="utf-8")
    blocks = find_add_routes_blocks(text)
    db_blocks = [(route_prefix(block), block) for _, _, block in blocks if route_prefix(block).startswith("/api/v1/db/")]
    if len(db_blocks) < 2:
        return False

    first = min(start for start, _, block in blocks if route_prefix(block).startswith("/api/v1/db/"))
    last = max(end for _, end, block in blocks if route_prefix(block).startswith("/api/v1/db/"))
    pre = text[:first]
    middle = text[first:last]
    post = text[last:]

    middle_blocks = find_add_routes_blocks(middle)
    non_db_blocks = [block for _, _, block in middle_blocks if not route_prefix(block).startswith("/api/v1/db/")]
    sorted_db_blocks = [block for _, block in sorted(db_blocks, key=lambda item: item[0])]
    joined_blocks = "\n\n".join(block.rstrip() for block in [*non_db_blocks, *sorted_db_blocks]) + "\n"
    next_text = pre.rstrip() + "\n\n" + joined_blocks + post.lstrip("\n")
    if next_text == text:
        return False

    path.write_text(next_text, encoding="utf-8")
    return True


def main():
    parser = argparse.ArgumentParser(description="Normalize goctl generated API routes.go order")
    parser.add_argument("--root", default=str(ROOT_DIR), help="repository root directory")
    parser.add_argument("--service", action="append", help="service name, can be specified multiple times")
    args = parser.parse_args()

    root_dir = Path(args.root).resolve()
    services = args.service or sorted(path.name for path in (root_dir / "apps").iterdir() if path.is_dir())
    changed = []
    for service in services:
        routes_path = root_dir / "apps" / service / "api" / "internal" / "handler" / "routes.go"
        if sync_routes(routes_path):
            changed.append(routes_path.relative_to(root_dir))
            print(f"synced {routes_path.relative_to(root_dir)}")
    print(f"synced api route files: {len(changed)}")


if __name__ == "__main__":
    main()
