#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys

import os
import time

import log
import autogen_redis_v2
import autogen_sql_api
import autogen_pg_sql_api

curDir = os.getcwd();


if __name__ == "__main__":
    pre_ts = time.time()

    autogen_redis_v2.do()
    print("\n")

    print("autogen_pg_sql")
    autogen_pg_sql_api.generate(autogen_pg_sql_api.ROOT_DIR)
    print("\n")

    print("consume time:" + str(time.time() - pre_ts))
  
