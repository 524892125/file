#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys

import os
import time

import log
import autogen_redis_v2

curDir = os.getcwd();


if __name__ == "__main__":
    pre_ts = time.time()

    autogen_redis_v2.do()
    print("\n")

    print("consume time:" + str(time.time() - pre_ts))
  
