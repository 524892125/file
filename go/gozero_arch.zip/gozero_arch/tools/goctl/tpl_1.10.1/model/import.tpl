import (
	"context"
	{{$hasSql := false}}{{range .data.Fields}}{{if or (eq .DataType "sql.NullString") (eq .DataType "sql.NullInt64") (eq .DataType "sql.NullInt32") (eq .DataType "sql.NullFloat64") (eq .DataType "sql.NullBool") (eq .DataType "sql.NullTime")}}{{ $hasSql = true }}{{end}}{{end}}{{if $hasSql}}
	"database/sql"
	{{end}}
	"fmt"
	"strings"
	{{if .time}}"time"{{end}}

	{{if .containsPQ}}"github.com/lib/pq"{{end}}
	"github.com/zeromicro/go-zero/core/stores/builder"
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlc"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
	"github.com/zeromicro/go-zero/core/stringx"

	{{.third}}
)
