type (
	{{.lowerStartCamelObject}}Model interface{
		{{.method}}
		FindPageByFields(ctx context.Context, page, pageNum int64, fields []{{.upperStartCamelObject}}PageField) ([]*{{.upperStartCamelObject}}, int64, error)
	}

	default{{.upperStartCamelObject}}Model struct {
		{{if .withCache}}sqlc.CachedConn{{else}}conn sqlx.SqlConn{{end}}
		table string
	}

	{{.upperStartCamelObject}} struct {
		{{.fields}}
	}
)
