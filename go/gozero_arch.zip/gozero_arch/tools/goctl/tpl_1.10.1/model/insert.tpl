func (m *default{{.upperStartCamelObject}}Model) Insert(ctx context.Context, data *{{.upperStartCamelObject}}) (int64,error) {
	{{if .withCache}}{{.keys}}
    {{else}}query := fmt.Sprintf("insert into %s (%s) values ({{.expression}}) returning {{.originalPrimaryKey}}", m.table, {{.lowerStartCamelObject}}RowsExpectAutoSet)
    var id int64
    err:=m.conn.QueryRowCtx(ctx, &id, query, {{.expressionValues}})
    if err != nil {
        return 0, err
    }
    return id, nil{{end}}
}
