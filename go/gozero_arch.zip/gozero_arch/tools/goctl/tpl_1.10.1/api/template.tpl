syntax = "v1"

type request {
	// TODO: add members here and delete this comment 1
}

type response {
	// TODO: add members here and delete this comment
}

service {{.serviceName}} {
	@handler GetUser // TODO: set handler name and delete this comment
	get /users/id/:userId(request) returns(response)

	@handler CreateAuth // TODO: set handler name and delete this comment
	post /users/auth/create(request)
}
