#!/bin/bash

mkdir -p ./bin/logs/
cd ./bin

servers=(
	"user-api"
	"admin-api"

	"user"
	"admin"	
)


pid_list=()
pid_name_list=()

for ((i=0; i < ${#servers[*]}; i++))
do
	server_name=${servers[$i]}

		echo "正在关闭"${servers[$i]}"服务 ......"
		pids=`ps -ef | grep gozero-${servers[$i]} | grep -v grep | awk '{print $2}'`
		if [ "${pids}" != "" ]; then
			kill ${pids}
			
			for pid in $pids; do
				echo "PID: $pid"
				pid_list=("${pid_list[@]}" "${pid}")
				pid_name_list+=("${servers[$i]}")
			done
		fi
done


for ((i=0; i < ${#pid_list[*]}; i++))
do
	pid=${pid_list[$i]}
	pid_name=${pid_name_list[$i]}
    cnt=0
    while ps -p ${pid} > /dev/null; do
        echo "${pid_name} 服务 ...... 正在关闭中"
        ((cnt++))
        sleep 1
                
        # 如果等待超过5秒，强制关闭进程
        if [ $cnt -gt 5 ]; then
            echo "正在强制关闭 ${pid_name} 服务 ......"
            kill -9 ${pid}
        fi
    done
done


echo "关闭成功!!!"

echo "检查服务进程"
for ((i=0; i < ${#servers[*]}; i++))
do
	server_name=${servers[$i]}
	pss=`ps -ef | grep gozero-${server_name} | grep -v grep`
    if [ "${pss}" == "" ]; then
        echo "关闭成功" ${server_name}
	else
		echo "关闭失败 ${pss}"
	fi
done