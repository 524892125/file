--
-- PostgreSQL database dump
--

\restrict UJ00oJFqLXKvtHzQC8T3L2IFzL7IhoGWMAjPB6tyrWDLTSDpRe6Mc2jEUUTHWfr

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_runtime_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_runtime_log (
    id bigint NOT NULL,
    message_id character varying(64) NOT NULL,
    trace_id character varying(128),
    tenant_code character varying(64),
    service_name character varying(64) NOT NULL,
    level character varying(32) NOT NULL,
    caller character varying(255),
    content text,
    fields_json text,
    source character varying(64),
    logged_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.app_runtime_log OWNER TO postgres;

--
-- Name: app_runtime_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.app_runtime_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.app_runtime_log_id_seq OWNER TO postgres;

--
-- Name: app_runtime_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.app_runtime_log_id_seq OWNED BY public.app_runtime_log.id;


--
-- Name: cron_task_definition; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cron_task_definition (
    id bigint NOT NULL,
    tenant_code character varying(64) DEFAULT ''::character varying NOT NULL,
    task_key character varying(128) NOT NULL,
    task_name character varying(128) NOT NULL,
    task_type character varying(32) NOT NULL,
    schedule_type character varying(32) NOT NULL,
    interval_seconds bigint NOT NULL,
    payload_json text DEFAULT ''::text NOT NULL,
    status character varying(16) DEFAULT 'enabled'::character varying NOT NULL,
    next_run_at timestamp with time zone NOT NULL,
    last_run_at timestamp with time zone,
    lease_owner character varying(128) DEFAULT ''::character varying NOT NULL,
    lease_until timestamp with time zone,
    created_by bigint DEFAULT 0 NOT NULL,
    updated_by bigint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cron_task_definition OWNER TO postgres;

--
-- Name: cron_task_definition_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cron_task_definition_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cron_task_definition_id_seq OWNER TO postgres;

--
-- Name: cron_task_definition_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cron_task_definition_id_seq OWNED BY public.cron_task_definition.id;


--
-- Name: cron_task_demo_write; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cron_task_demo_write (
    id bigint NOT NULL,
    tenant_code character varying(64) DEFAULT ''::character varying NOT NULL,
    task_id bigint NOT NULL,
    task_key character varying(128) NOT NULL,
    message_id character varying(64) NOT NULL,
    payload_json text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cron_task_demo_write OWNER TO postgres;

--
-- Name: cron_task_demo_write_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cron_task_demo_write_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cron_task_demo_write_id_seq OWNER TO postgres;

--
-- Name: cron_task_demo_write_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cron_task_demo_write_id_seq OWNED BY public.cron_task_demo_write.id;


--
-- Name: cron_task_execution; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cron_task_execution (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    tenant_code character varying(64) DEFAULT ''::character varying NOT NULL,
    task_key character varying(128) NOT NULL,
    message_id character varying(64) NOT NULL,
    scheduled_at timestamp with time zone NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    status character varying(16) NOT NULL,
    attempt integer DEFAULT 1 NOT NULL,
    instance_id character varying(128) DEFAULT ''::character varying NOT NULL,
    error_message text DEFAULT ''::text NOT NULL,
    result_summary text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cron_task_execution OWNER TO postgres;

--
-- Name: cron_task_execution_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cron_task_execution_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cron_task_execution_id_seq OWNER TO postgres;

--
-- Name: cron_task_execution_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cron_task_execution_id_seq OWNED BY public.cron_task_execution.id;


--
-- Name: sys_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_config (
    id bigint NOT NULL,
    config_name character varying(128),
    config_key character varying(128),
    config_value character varying(255),
    config_type character varying(64),
    is_frontend character varying(64),
    remark character varying(128),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_config OWNER TO postgres;

--
-- Name: COLUMN sys_config.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.id IS '主键编码';


--
-- Name: COLUMN sys_config.config_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_name IS 'ConfigName';


--
-- Name: COLUMN sys_config.config_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_key IS 'ConfigKey';


--
-- Name: COLUMN sys_config.config_value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_value IS 'ConfigValue';


--
-- Name: COLUMN sys_config.config_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_type IS 'ConfigType';


--
-- Name: COLUMN sys_config.is_frontend; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.is_frontend IS '是否前台';


--
-- Name: COLUMN sys_config.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.remark IS 'Remark';


--
-- Name: COLUMN sys_config.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.create_by IS '创建者';


--
-- Name: COLUMN sys_config.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.update_by IS '更新者';


--
-- Name: COLUMN sys_config.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.created_at IS '创建时间';


--
-- Name: COLUMN sys_config.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_config.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.deleted_at IS '删除时间';


--
-- Name: sys_config_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_config_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_config_config_id_seq OWNER TO postgres;

--
-- Name: sys_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_config_id_seq OWNER TO postgres;

--
-- Name: sys_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_config_id_seq OWNED BY public.sys_config.id;


--
-- Name: sys_job_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_job_id_seq OWNER TO postgres;

--
-- Name: sys_login_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_login_log (
    id bigint NOT NULL,
    username character varying(128),
    status character varying(4),
    ipaddr character varying(255),
    login_location character varying(255),
    browser character varying(255),
    os character varying(255),
    platform character varying(255),
    login_time timestamp without time zone,
    remark text,
    msg text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    create_by bigint,
    update_by bigint
);


ALTER TABLE public.sys_login_log OWNER TO postgres;

--
-- Name: COLUMN sys_login_log.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.id IS '主键编码';


--
-- Name: COLUMN sys_login_log.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.username IS 'username';


--
-- Name: COLUMN sys_login_log.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.status IS 'status';


--
-- Name: COLUMN sys_login_log.ipaddr; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.ipaddr IS 'ip address';


--
-- Name: COLUMN sys_login_log.login_location; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.login_location IS 'login location';


--
-- Name: COLUMN sys_login_log.browser; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.browser IS 'browser';


--
-- Name: COLUMN sys_login_log.os; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.os IS 'os';


--
-- Name: COLUMN sys_login_log.platform; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.platform IS 'platform';


--
-- Name: COLUMN sys_login_log.login_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.login_time IS 'login time';


--
-- Name: COLUMN sys_login_log.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.remark IS 'remark';


--
-- Name: COLUMN sys_login_log.msg; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.msg IS 'message';


--
-- Name: COLUMN sys_login_log.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.created_at IS 'created at';


--
-- Name: COLUMN sys_login_log.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.updated_at IS 'updated at';


--
-- Name: COLUMN sys_login_log.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.create_by IS '创建者';


--
-- Name: COLUMN sys_login_log.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.update_by IS '更新者';


--
-- Name: sys_login_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_login_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_login_log_id_seq OWNER TO postgres;

--
-- Name: sys_login_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_login_log_id_seq OWNED BY public.sys_login_log.id;


--
-- Name: sys_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_menu (
    menu_id bigint NOT NULL,
    menu_name character varying(128),
    title character varying(128),
    icon character varying(128),
    path character varying(128),
    paths character varying(128),
    menu_type character varying(1),
    action character varying(16),
    permission character varying(255),
    parent_id smallint,
    no_cache boolean,
    breadcrumb character varying(255),
    component character varying(255),
    sort smallint,
    visible character varying(1),
    is_frame character varying(1) DEFAULT '0'::character varying,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_menu OWNER TO postgres;

--
-- Name: COLUMN sys_menu.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.create_by IS '创建者';


--
-- Name: COLUMN sys_menu.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.update_by IS '更新者';


--
-- Name: COLUMN sys_menu.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.created_at IS '创建时间';


--
-- Name: COLUMN sys_menu.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_menu.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.deleted_at IS '删除时间';


--
-- Name: sys_menu_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_menu_menu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_menu_menu_id_seq OWNER TO postgres;

--
-- Name: sys_menu_menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_menu_menu_id_seq OWNED BY public.sys_menu.menu_id;


--
-- Name: sys_migration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_migration (
    version text NOT NULL,
    apply_time timestamp with time zone,
    scope character varying(255)
);


ALTER TABLE public.sys_migration OWNER TO postgres;

--
-- Name: sys_opera_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_opera_log (
    id bigint NOT NULL,
    title character varying(255),
    business_type character varying(128),
    business_types character varying(128),
    method character varying(128),
    request_method character varying(128),
    operator_type character varying(128),
    oper_name character varying(128),
    dept_name character varying(128),
    oper_url character varying(255),
    oper_ip character varying(128),
    oper_location character varying(128),
    oper_param text,
    status character varying(4),
    oper_time timestamp without time zone,
    json_result character varying(255),
    remark character varying(255),
    latency_time character varying(128),
    user_agent character varying(255),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    create_by bigint,
    update_by bigint,
    "IOMMU" character varying(255),
    message_id character varying(255),
    trace_id character varying(255),
    tenant_code character varying(255),
    service_name character varying(255),
    user_id integer
);


ALTER TABLE public.sys_opera_log OWNER TO postgres;

--
-- Name: COLUMN sys_opera_log.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.id IS '主键编码';


--
-- Name: COLUMN sys_opera_log.title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.title IS '操作模块';


--
-- Name: COLUMN sys_opera_log.business_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.business_type IS '操作类型';


--
-- Name: COLUMN sys_opera_log.business_types; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.business_types IS 'BusinessTypes';


--
-- Name: COLUMN sys_opera_log.method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.method IS '函数';


--
-- Name: COLUMN sys_opera_log.request_method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.request_method IS '请求方式: GET POST PUT DELETE';


--
-- Name: COLUMN sys_opera_log.operator_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.operator_type IS '操作类型';


--
-- Name: COLUMN sys_opera_log.oper_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_name IS '操作者';


--
-- Name: COLUMN sys_opera_log.dept_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.dept_name IS '部门名称';


--
-- Name: COLUMN sys_opera_log.oper_url; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_url IS '访问地址';


--
-- Name: COLUMN sys_opera_log.oper_ip; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_ip IS '客户端ip';


--
-- Name: COLUMN sys_opera_log.oper_location; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_location IS '访问位置';


--
-- Name: COLUMN sys_opera_log.oper_param; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_param IS '请求参数';


--
-- Name: COLUMN sys_opera_log.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.status IS '操作状态 1:正常 2:关闭';


--
-- Name: COLUMN sys_opera_log.oper_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_time IS '操作时间';


--
-- Name: COLUMN sys_opera_log.json_result; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.json_result IS '返回数据';


--
-- Name: COLUMN sys_opera_log.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.remark IS '备注';


--
-- Name: COLUMN sys_opera_log.latency_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.latency_time IS '耗时';


--
-- Name: COLUMN sys_opera_log.user_agent; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.user_agent IS 'ua';


--
-- Name: COLUMN sys_opera_log.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.created_at IS '创建时间';


--
-- Name: COLUMN sys_opera_log.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_opera_log.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.create_by IS '创建者';


--
-- Name: COLUMN sys_opera_log.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.update_by IS '更新者';


--
-- Name: sys_opera_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_opera_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_opera_log_id_seq OWNER TO postgres;

--
-- Name: sys_opera_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_opera_log_id_seq OWNED BY public.sys_opera_log.id;


--
-- Name: sys_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_user (
    user_id bigint NOT NULL,
    username character varying(64),
    password character varying(128),
    nick_name character varying(128),
    phone character varying(11),
    role_id bigint,
    salt character varying(255),
    avatar character varying(255),
    sex character varying(255),
    email character varying(128),
    dept_id bigint,
    post_id bigint,
    remark character varying(255),
    status character varying(4),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    allow_password_login character varying(4) DEFAULT '2'::character varying
);


ALTER TABLE public.sys_user OWNER TO postgres;

--
-- Name: COLUMN sys_user.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.user_id IS '编码';


--
-- Name: COLUMN sys_user.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.username IS '用户名';


--
-- Name: COLUMN sys_user.password; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.password IS '密码';


--
-- Name: COLUMN sys_user.nick_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.nick_name IS '昵称';


--
-- Name: COLUMN sys_user.phone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.phone IS '手机号';


--
-- Name: COLUMN sys_user.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.role_id IS '角色ID';


--
-- Name: COLUMN sys_user.salt; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.salt IS '盐';


--
-- Name: COLUMN sys_user.avatar; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.avatar IS '头像';


--
-- Name: COLUMN sys_user.sex; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.sex IS '性别';


--
-- Name: COLUMN sys_user.email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.email IS '邮箱';


--
-- Name: COLUMN sys_user.dept_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.dept_id IS '部门';


--
-- Name: COLUMN sys_user.post_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.post_id IS '岗位';


--
-- Name: COLUMN sys_user.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.remark IS '备注';


--
-- Name: COLUMN sys_user.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.status IS '状态';


--
-- Name: COLUMN sys_user.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.create_by IS '创建者';


--
-- Name: COLUMN sys_user.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.update_by IS '更新者';


--
-- Name: COLUMN sys_user.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.created_at IS '创建时间';


--
-- Name: COLUMN sys_user.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_user.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.deleted_at IS '删除时间';


--
-- Name: COLUMN sys_user.allow_password_login; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.allow_password_login IS '是否允许账号密码登录';


--
-- Name: sys_user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_user_user_id_seq OWNER TO postgres;

--
-- Name: sys_user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_user_user_id_seq OWNED BY public.sys_user.user_id;


--
-- Name: wechat_analysis_snapshot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wechat_analysis_snapshot (
    id bigint NOT NULL,
    metric_id character varying(64) NOT NULL,
    metric_name character varying(255) DEFAULT ''::character varying NOT NULL,
    granularity integer DEFAULT 24 NOT NULL,
    request_start_ts bigint DEFAULT 0 NOT NULL,
    request_end_ts bigint DEFAULT 0 NOT NULL,
    request_start_label character varying(64) DEFAULT ''::character varying NOT NULL,
    request_end_label character varying(64) DEFAULT ''::character varying NOT NULL,
    data_list text DEFAULT ''::text NOT NULL,
    row_count integer DEFAULT 0 NOT NULL,
    filter_list text DEFAULT ''::text NOT NULL,
    group_list text DEFAULT ''::text NOT NULL,
    request_payload text DEFAULT ''::text NOT NULL,
    request_hash character varying(80) DEFAULT ''::character varying NOT NULL,
    sync_source character varying(32) DEFAULT ''::character varying NOT NULL,
    synced_at character varying(32) DEFAULT ''::character varying NOT NULL,
    create_by bigint DEFAULT 0 NOT NULL,
    update_by bigint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.wechat_analysis_snapshot OWNER TO postgres;

--
-- Name: wechat_analysis_snapshot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wechat_analysis_snapshot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wechat_analysis_snapshot_id_seq OWNER TO postgres;

--
-- Name: wechat_analysis_snapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wechat_analysis_snapshot_id_seq OWNED BY public.wechat_analysis_snapshot.id;


--
-- Name: app_runtime_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_runtime_log ALTER COLUMN id SET DEFAULT nextval('public.app_runtime_log_id_seq'::regclass);


--
-- Name: cron_task_definition id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cron_task_definition ALTER COLUMN id SET DEFAULT nextval('public.cron_task_definition_id_seq'::regclass);


--
-- Name: cron_task_demo_write id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cron_task_demo_write ALTER COLUMN id SET DEFAULT nextval('public.cron_task_demo_write_id_seq'::regclass);


--
-- Name: cron_task_execution id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cron_task_execution ALTER COLUMN id SET DEFAULT nextval('public.cron_task_execution_id_seq'::regclass);


--
-- Name: sys_config id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_config ALTER COLUMN id SET DEFAULT nextval('public.sys_config_id_seq'::regclass);


--
-- Name: sys_login_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_login_log ALTER COLUMN id SET DEFAULT nextval('public.sys_login_log_id_seq'::regclass);


--
-- Name: sys_menu menu_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_menu ALTER COLUMN menu_id SET DEFAULT nextval('public.sys_menu_menu_id_seq'::regclass);


--
-- Name: sys_opera_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_opera_log ALTER COLUMN id SET DEFAULT nextval('public.sys_opera_log_id_seq'::regclass);


--
-- Name: sys_user user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_user ALTER COLUMN user_id SET DEFAULT nextval('public.sys_user_user_id_seq'::regclass);


--
-- Name: wechat_analysis_snapshot id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wechat_analysis_snapshot ALTER COLUMN id SET DEFAULT nextval('public.wechat_analysis_snapshot_id_seq'::regclass);


--
-- Name: app_runtime_log app_runtime_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_runtime_log
    ADD CONSTRAINT app_runtime_log_pkey PRIMARY KEY (id);


--
-- Name: cron_task_definition cron_task_definition_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cron_task_definition
    ADD CONSTRAINT cron_task_definition_pkey PRIMARY KEY (id);


--
-- Name: cron_task_definition cron_task_definition_tenant_code_task_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cron_task_definition
    ADD CONSTRAINT cron_task_definition_tenant_code_task_key_key UNIQUE (tenant_code, task_key);


--
-- Name: cron_task_demo_write cron_task_demo_write_message_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cron_task_demo_write
    ADD CONSTRAINT cron_task_demo_write_message_id_key UNIQUE (message_id);


--
-- Name: cron_task_demo_write cron_task_demo_write_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cron_task_demo_write
    ADD CONSTRAINT cron_task_demo_write_pkey PRIMARY KEY (id);


--
-- Name: cron_task_execution cron_task_execution_message_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cron_task_execution
    ADD CONSTRAINT cron_task_execution_message_id_key UNIQUE (message_id);


--
-- Name: cron_task_execution cron_task_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cron_task_execution
    ADD CONSTRAINT cron_task_execution_pkey PRIMARY KEY (id);


--
-- Name: sys_config sys_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_config
    ADD CONSTRAINT sys_config_pkey PRIMARY KEY (id);


--
-- Name: sys_login_log sys_login_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_login_log
    ADD CONSTRAINT sys_login_log_pkey PRIMARY KEY (id);


--
-- Name: sys_menu sys_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_menu
    ADD CONSTRAINT sys_menu_pkey PRIMARY KEY (menu_id);


--
-- Name: sys_migration sys_migration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_migration
    ADD CONSTRAINT sys_migration_pkey PRIMARY KEY (version);


--
-- Name: sys_opera_log sys_opera_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_opera_log
    ADD CONSTRAINT sys_opera_log_pkey PRIMARY KEY (id);


--
-- Name: sys_user sys_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_user
    ADD CONSTRAINT sys_user_pkey PRIMARY KEY (user_id);


--
-- Name: wechat_analysis_snapshot wechat_analysis_snapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wechat_analysis_snapshot
    ADD CONSTRAINT wechat_analysis_snapshot_pkey PRIMARY KEY (id);


--
-- Name: idx_app_runtime_log_level_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_app_runtime_log_level_created_at ON public.app_runtime_log USING btree (level, created_at DESC);


--
-- Name: idx_app_runtime_log_message_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_app_runtime_log_message_id_unique ON public.app_runtime_log USING btree (message_id);


--
-- Name: idx_app_runtime_log_service_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_app_runtime_log_service_created_at ON public.app_runtime_log USING btree (service_name, created_at DESC);


--
-- Name: idx_cron_task_definition_due; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cron_task_definition_due ON public.cron_task_definition USING btree (status, next_run_at);


--
-- Name: idx_cron_task_execution_task; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cron_task_execution_task ON public.cron_task_execution USING btree (task_id, created_at DESC);


--
-- Name: idx_sys_config_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_create_by ON public.sys_config USING btree (create_by);


--
-- Name: idx_sys_config_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_deleted_at ON public.sys_config USING btree (deleted_at);


--
-- Name: idx_sys_config_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_update_by ON public.sys_config USING btree (update_by);


--
-- Name: idx_sys_login_log_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_login_log_create_by ON public.sys_login_log USING btree (create_by);


--
-- Name: idx_sys_login_log_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_login_log_update_by ON public.sys_login_log USING btree (update_by);


--
-- Name: idx_sys_menu_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_create_by ON public.sys_menu USING btree (create_by);


--
-- Name: idx_sys_menu_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_deleted_at ON public.sys_menu USING btree (deleted_at);


--
-- Name: idx_sys_menu_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_update_by ON public.sys_menu USING btree (update_by);


--
-- Name: idx_sys_opera_log_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_opera_log_create_by ON public.sys_opera_log USING btree (create_by);


--
-- Name: idx_sys_opera_log_message_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_sys_opera_log_message_id_unique ON public.sys_opera_log USING btree (message_id);


--
-- Name: idx_sys_opera_log_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_opera_log_update_by ON public.sys_opera_log USING btree (update_by);


--
-- Name: idx_sys_user_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_create_by ON public.sys_user USING btree (create_by);


--
-- Name: idx_sys_user_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_deleted_at ON public.sys_user USING btree (deleted_at);


--
-- Name: idx_sys_user_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_update_by ON public.sys_user USING btree (update_by);


--
-- PostgreSQL database dump complete
--

\unrestrict UJ00oJFqLXKvtHzQC8T3L2IFzL7IhoGWMAjPB6tyrWDLTSDpRe6Mc2jEUUTHWfr

