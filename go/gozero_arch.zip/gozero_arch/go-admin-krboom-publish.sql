--
-- PostgreSQL database dump
--

\restrict r1pm3as1o0cTULLHDJzuAmnLlSQUrPElUQ1kRUvdr4ZCtWqUtlaK8I2TuqftqjB

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: sys_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_config (
    id bigint NOT NULL,
    config_name character varying(128),
    config_key character varying(128),
    config_value character varying(255),
    config_type character varying(64),
    is_frontend character varying(64),
    remark character varying(128),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_config OWNER TO postgres;

--
-- Name: COLUMN sys_config.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.id IS '主键编码';


--
-- Name: COLUMN sys_config.config_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_name IS 'ConfigName';


--
-- Name: COLUMN sys_config.config_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_key IS 'ConfigKey';


--
-- Name: COLUMN sys_config.config_value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_value IS 'ConfigValue';


--
-- Name: COLUMN sys_config.config_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_type IS 'ConfigType';


--
-- Name: COLUMN sys_config.is_frontend; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.is_frontend IS '是否前台';


--
-- Name: COLUMN sys_config.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.remark IS 'Remark';


--
-- Name: COLUMN sys_config.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.create_by IS '创建者';


--
-- Name: COLUMN sys_config.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.update_by IS '更新者';


--
-- Name: COLUMN sys_config.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.created_at IS '创建时间';


--
-- Name: COLUMN sys_config.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_config.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.deleted_at IS '删除时间';


--
-- Name: sys_config_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_config_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_config_config_id_seq OWNER TO postgres;

--
-- Name: sys_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_config_id_seq OWNER TO postgres;

--
-- Name: sys_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_config_id_seq OWNED BY public.sys_config.id;


--
-- Name: sys_dept; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_dept (
    dept_id bigint NOT NULL,
    parent_id bigint,
    dept_path character varying(255),
    dept_name character varying(128),
    sort smallint,
    leader character varying(128),
    phone character varying(11),
    email character varying(64),
    status smallint,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_dept OWNER TO postgres;

--
-- Name: COLUMN sys_dept.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dept.create_by IS '创建者';


--
-- Name: COLUMN sys_dept.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dept.update_by IS '更新者';


--
-- Name: COLUMN sys_dept.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dept.created_at IS '创建时间';


--
-- Name: COLUMN sys_dept.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dept.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_dept.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dept.deleted_at IS '删除时间';


--
-- Name: sys_dept_dept_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_dept_dept_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_dept_dept_id_seq OWNER TO postgres;

--
-- Name: sys_dept_dept_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_dept_dept_id_seq OWNED BY public.sys_dept.dept_id;


--
-- Name: sys_dict_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_dict_data (
    dict_code bigint NOT NULL,
    dict_sort bigint,
    dict_label character varying(128),
    dict_value character varying(255),
    dict_type character varying(64),
    css_class character varying(128),
    list_class character varying(128),
    is_default character varying(8),
    status smallint,
    "default" character varying(8),
    remark character varying(255),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_dict_data OWNER TO postgres;

--
-- Name: COLUMN sys_dict_data.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_data.create_by IS '创建者';


--
-- Name: COLUMN sys_dict_data.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_data.update_by IS '更新者';


--
-- Name: COLUMN sys_dict_data.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_data.created_at IS '创建时间';


--
-- Name: COLUMN sys_dict_data.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_data.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_dict_data.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_data.deleted_at IS '删除时间';


--
-- Name: sys_dict_data_dict_code_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_dict_data_dict_code_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_dict_data_dict_code_seq OWNER TO postgres;

--
-- Name: sys_dict_data_dict_code_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_dict_data_dict_code_seq OWNED BY public.sys_dict_data.dict_code;


--
-- Name: sys_dict_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_dict_type (
    dict_id bigint NOT NULL,
    dict_name character varying(128),
    dict_type character varying(128),
    status smallint,
    remark character varying(255),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_dict_type OWNER TO postgres;

--
-- Name: COLUMN sys_dict_type.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_type.create_by IS '创建者';


--
-- Name: COLUMN sys_dict_type.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_type.update_by IS '更新者';


--
-- Name: COLUMN sys_dict_type.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_type.created_at IS '创建时间';


--
-- Name: COLUMN sys_dict_type.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_type.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_dict_type.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_dict_type.deleted_at IS '删除时间';


--
-- Name: sys_dict_type_dict_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_dict_type_dict_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_dict_type_dict_id_seq OWNER TO postgres;

--
-- Name: sys_dict_type_dict_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_dict_type_dict_id_seq OWNED BY public.sys_dict_type.dict_id;


--
-- Name: sys_job; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_job (
    job_id bigint NOT NULL,
    job_name character varying(255),
    job_group character varying(255),
    job_type smallint,
    cron_expression character varying(255),
    invoke_target character varying(255),
    args character varying(255),
    misfire_policy bigint,
    concurrent smallint,
    status smallint,
    entry_id smallint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    create_by bigint,
    update_by bigint
);


ALTER TABLE public.sys_job OWNER TO postgres;

--
-- Name: COLUMN sys_job.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_job.created_at IS '创建时间';


--
-- Name: COLUMN sys_job.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_job.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_job.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_job.deleted_at IS '删除时间';


--
-- Name: COLUMN sys_job.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_job.create_by IS '创建者';


--
-- Name: COLUMN sys_job.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_job.update_by IS '更新者';


--
-- Name: sys_job_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_job_id_seq OWNER TO postgres;

--
-- Name: sys_job_job_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_job_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_job_job_id_seq OWNER TO postgres;

--
-- Name: sys_job_job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_job_job_id_seq OWNED BY public.sys_job.job_id;


--
-- Name: sys_login_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_login_log (
    id bigint NOT NULL,
    username character varying(128),
    status character varying(4),
    ipaddr character varying(255),
    login_location character varying(255),
    browser character varying(255),
    os character varying(255),
    platform character varying(255),
    login_time timestamp without time zone,
    remark text,
    msg text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    create_by bigint,
    update_by bigint
);


ALTER TABLE public.sys_login_log OWNER TO postgres;

--
-- Name: COLUMN sys_login_log.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.id IS '主键编码';


--
-- Name: COLUMN sys_login_log.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.username IS 'username';


--
-- Name: COLUMN sys_login_log.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.status IS 'status';


--
-- Name: COLUMN sys_login_log.ipaddr; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.ipaddr IS 'ip address';


--
-- Name: COLUMN sys_login_log.login_location; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.login_location IS 'login location';


--
-- Name: COLUMN sys_login_log.browser; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.browser IS 'browser';


--
-- Name: COLUMN sys_login_log.os; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.os IS 'os';


--
-- Name: COLUMN sys_login_log.platform; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.platform IS 'platform';


--
-- Name: COLUMN sys_login_log.login_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.login_time IS 'login time';


--
-- Name: COLUMN sys_login_log.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.remark IS 'remark';


--
-- Name: COLUMN sys_login_log.msg; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.msg IS 'message';


--
-- Name: COLUMN sys_login_log.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.created_at IS 'created at';


--
-- Name: COLUMN sys_login_log.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.updated_at IS 'updated at';


--
-- Name: COLUMN sys_login_log.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.create_by IS '创建者';


--
-- Name: COLUMN sys_login_log.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.update_by IS '更新者';


--
-- Name: sys_login_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_login_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_login_log_id_seq OWNER TO postgres;

--
-- Name: sys_login_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_login_log_id_seq OWNED BY public.sys_login_log.id;


--
-- Name: sys_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_menu (
    menu_id bigint NOT NULL,
    menu_name character varying(128),
    title character varying(128),
    icon character varying(128),
    path character varying(128),
    paths character varying(128),
    menu_type character varying(1),
    action character varying(16),
    permission character varying(255),
    parent_id smallint,
    no_cache boolean,
    breadcrumb character varying(255),
    component character varying(255),
    sort smallint,
    visible character varying(1),
    is_frame character varying(1) DEFAULT '0'::character varying,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_menu OWNER TO postgres;

--
-- Name: COLUMN sys_menu.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.create_by IS '创建者';


--
-- Name: COLUMN sys_menu.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.update_by IS '更新者';


--
-- Name: COLUMN sys_menu.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.created_at IS '创建时间';


--
-- Name: COLUMN sys_menu.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_menu.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.deleted_at IS '删除时间';


--
-- Name: sys_menu_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_menu_menu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_menu_menu_id_seq OWNER TO postgres;

--
-- Name: sys_menu_menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_menu_menu_id_seq OWNED BY public.sys_menu.menu_id;


--
-- Name: sys_opera_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_opera_log (
    id bigint NOT NULL,
    title character varying(255),
    business_type character varying(128),
    business_types character varying(128),
    method character varying(128),
    request_method character varying(128),
    operator_type character varying(128),
    oper_name character varying(128),
    dept_name character varying(128),
    oper_url character varying(255),
    oper_ip character varying(128),
    oper_location character varying(128),
    oper_param text,
    status character varying(4),
    oper_time timestamp without time zone,
    json_result character varying(255),
    remark character varying(255),
    latency_time character varying(128),
    user_agent character varying(255),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    create_by bigint,
    update_by bigint
);


ALTER TABLE public.sys_opera_log OWNER TO postgres;

--
-- Name: COLUMN sys_opera_log.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.id IS '主键编码';


--
-- Name: COLUMN sys_opera_log.title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.title IS '操作模块';


--
-- Name: COLUMN sys_opera_log.business_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.business_type IS '操作类型';


--
-- Name: COLUMN sys_opera_log.business_types; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.business_types IS 'BusinessTypes';


--
-- Name: COLUMN sys_opera_log.method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.method IS '函数';


--
-- Name: COLUMN sys_opera_log.request_method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.request_method IS '请求方式: GET POST PUT DELETE';


--
-- Name: COLUMN sys_opera_log.operator_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.operator_type IS '操作类型';


--
-- Name: COLUMN sys_opera_log.oper_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_name IS '操作者';


--
-- Name: COLUMN sys_opera_log.dept_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.dept_name IS '部门名称';


--
-- Name: COLUMN sys_opera_log.oper_url; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_url IS '访问地址';


--
-- Name: COLUMN sys_opera_log.oper_ip; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_ip IS '客户端ip';


--
-- Name: COLUMN sys_opera_log.oper_location; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_location IS '访问位置';


--
-- Name: COLUMN sys_opera_log.oper_param; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_param IS '请求参数';


--
-- Name: COLUMN sys_opera_log.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.status IS '操作状态 1:正常 2:关闭';


--
-- Name: COLUMN sys_opera_log.oper_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_time IS '操作时间';


--
-- Name: COLUMN sys_opera_log.json_result; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.json_result IS '返回数据';


--
-- Name: COLUMN sys_opera_log.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.remark IS '备注';


--
-- Name: COLUMN sys_opera_log.latency_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.latency_time IS '耗时';


--
-- Name: COLUMN sys_opera_log.user_agent; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.user_agent IS 'ua';


--
-- Name: COLUMN sys_opera_log.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.created_at IS '创建时间';


--
-- Name: COLUMN sys_opera_log.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_opera_log.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.create_by IS '创建者';


--
-- Name: COLUMN sys_opera_log.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.update_by IS '更新者';


--
-- Name: sys_opera_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_opera_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_opera_log_id_seq OWNER TO postgres;

--
-- Name: sys_opera_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_opera_log_id_seq OWNED BY public.sys_opera_log.id;


--
-- Name: sys_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_role (
    role_id bigint NOT NULL,
    role_name character varying(128),
    status character varying(4),
    role_key character varying(128),
    role_sort bigint,
    flag character varying(128),
    remark character varying(255),
    admin boolean,
    data_scope character varying(128),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_role OWNER TO postgres;

--
-- Name: COLUMN sys_role.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_role.create_by IS '创建者';


--
-- Name: COLUMN sys_role.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_role.update_by IS '更新者';


--
-- Name: COLUMN sys_role.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_role.created_at IS '创建时间';


--
-- Name: COLUMN sys_role.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_role.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_role.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_role.deleted_at IS '删除时间';


--
-- Name: sys_role_dept; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_role_dept (
    id bigint NOT NULL,
    role_id smallint NOT NULL,
    dept_id smallint NOT NULL
);


ALTER TABLE public.sys_role_dept OWNER TO postgres;

--
-- Name: sys_role_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_role_menu (
    id bigint NOT NULL,
    role_id bigint NOT NULL,
    menu_id bigint NOT NULL
);


ALTER TABLE public.sys_role_menu OWNER TO postgres;

--
-- Name: sys_role_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_role_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_role_role_id_seq OWNER TO postgres;

--
-- Name: sys_role_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_role_role_id_seq OWNED BY public.sys_role.role_id;


--
-- Name: sys_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_user (
    user_id bigint NOT NULL,
    username character varying(64),
    password character varying(128),
    nick_name character varying(128),
    phone character varying(11),
    role_id bigint,
    salt character varying(255),
    avatar character varying(255),
    sex character varying(255),
    email character varying(128),
    dept_id bigint,
    post_id bigint,
    remark character varying(255),
    status character varying(4),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    allow_password_login character varying(4) DEFAULT '2'::character varying
);


ALTER TABLE public.sys_user OWNER TO postgres;

--
-- Name: COLUMN sys_user.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.user_id IS '编码';


--
-- Name: COLUMN sys_user.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.username IS '用户名';


--
-- Name: COLUMN sys_user.password; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.password IS '密码';


--
-- Name: COLUMN sys_user.nick_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.nick_name IS '昵称';


--
-- Name: COLUMN sys_user.phone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.phone IS '手机号';


--
-- Name: COLUMN sys_user.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.role_id IS '角色ID';


--
-- Name: COLUMN sys_user.salt; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.salt IS '盐';


--
-- Name: COLUMN sys_user.avatar; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.avatar IS '头像';


--
-- Name: COLUMN sys_user.sex; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.sex IS '性别';


--
-- Name: COLUMN sys_user.email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.email IS '邮箱';


--
-- Name: COLUMN sys_user.dept_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.dept_id IS '部门';


--
-- Name: COLUMN sys_user.post_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.post_id IS '岗位';


--
-- Name: COLUMN sys_user.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.remark IS '备注';


--
-- Name: COLUMN sys_user.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.status IS '状态';


--
-- Name: COLUMN sys_user.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.create_by IS '创建者';


--
-- Name: COLUMN sys_user.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.update_by IS '更新者';


--
-- Name: COLUMN sys_user.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.created_at IS '创建时间';


--
-- Name: COLUMN sys_user.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_user.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.deleted_at IS '删除时间';


--
-- Name: COLUMN sys_user.allow_password_login; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.allow_password_login IS '是否允许账号密码登录';


--
-- Name: sys_user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_user_user_id_seq OWNER TO postgres;

--
-- Name: sys_user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_user_user_id_seq OWNED BY public.sys_user.user_id;


--
-- Name: sys_config id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_config ALTER COLUMN id SET DEFAULT nextval('public.sys_config_id_seq'::regclass);


--
-- Name: sys_dept dept_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dept ALTER COLUMN dept_id SET DEFAULT nextval('public.sys_dept_dept_id_seq'::regclass);


--
-- Name: sys_dict_data dict_code; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dict_data ALTER COLUMN dict_code SET DEFAULT nextval('public.sys_dict_data_dict_code_seq'::regclass);


--
-- Name: sys_dict_type dict_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dict_type ALTER COLUMN dict_id SET DEFAULT nextval('public.sys_dict_type_dict_id_seq'::regclass);


--
-- Name: sys_job job_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_job ALTER COLUMN job_id SET DEFAULT nextval('public.sys_job_job_id_seq'::regclass);


--
-- Name: sys_login_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_login_log ALTER COLUMN id SET DEFAULT nextval('public.sys_login_log_id_seq'::regclass);


--
-- Name: sys_menu menu_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_menu ALTER COLUMN menu_id SET DEFAULT nextval('public.sys_menu_menu_id_seq'::regclass);


--
-- Name: sys_opera_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_opera_log ALTER COLUMN id SET DEFAULT nextval('public.sys_opera_log_id_seq'::regclass);


--
-- Name: sys_role role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role ALTER COLUMN role_id SET DEFAULT nextval('public.sys_role_role_id_seq'::regclass);


--
-- Name: sys_user user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_user ALTER COLUMN user_id SET DEFAULT nextval('public.sys_user_user_id_seq'::regclass);


--
-- Data for Name: sys_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_config (id, config_name, config_key, config_value, config_type, is_frontend, remark, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
1	皮肤样式	sys_index_skinName	skin-green	Y	0	主框架页-默认皮肤样式名称:蓝色 skin-blue、绿色 skin-green、紫色 skin-purple、红色 skin-red、黄色 skin-yellow	1	1	2021-05-13 19:56:37.913+08	2021-06-05 13:50:13.123+08	\N
2	初始密码	sys_user_initPassword	123456	Y	0	用户管理-账号初始密码:123456	1	1	2021-05-13 19:56:37.913+08	2021-05-13 19:56:37.913+08	\N
3	侧栏主题	sys_index_sideTheme	theme-dark	Y	0	主框架页-侧边栏主题:深色主题theme-dark，浅色主题theme-light	1	1	2021-05-13 19:56:37.913+08	2021-05-13 19:56:37.913+08	\N
4	系统名称	sys_app_name	管理系统	Y	1		1	0	2021-03-17 08:52:06.067+08	2021-05-28 10:08:25.248+08	\N
5	系统logo	sys_app_logo	https://kiif-ase-web.kiifstudio.com/gw/20260105/20260409-152645.jpg	Y	1		1	1	2021-03-17 08:53:19.462+08	2026-04-21 13:54:07.918618+08	\N
\.


--
-- Data for Name: sys_dept; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_dept (dept_id, parent_id, dept_path, dept_name, sort, leader, phone, email, status, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
7	1	/0/1/7/	研发部	1	aituo	13782218188	atuo@aituo.com	2	1	1	2021-05-13 19:56:37.913+08	2021-06-16 21:35:00.109+08	\N
9	1	/0/1/9/	客服部	0	aituo	13782218188	atuo@aituo.com	2	1	1	2021-05-13 19:56:37.913+08	2021-06-05 17:07:05.993+08	\N
10	1	/0/1/10/	人力资源	3	aituo	13782218188	atuo@aituo.com	1	1	1	2021-05-13 19:56:37.913+08	2021-06-05 17:07:08.503+08	\N
8	1	/0/1/8/	运维部	0	aituo	13782218188	atuo@aituo.com	2	1	1	2021-05-13 19:56:37.913+08	2026-04-21 12:43:58.121666+08	\N
1	0	/0/1/	科技	0	aituo	13782218188	atuo@aituo.com	2	1	1	2021-05-13 19:56:37.913+08	2026-04-21 13:53:44.732972+08	\N
\.


--
-- Data for Name: sys_dict_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_dict_data (dict_code, dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, "default", remark, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
2	0	停用	1	sys_normal_disable				2		系统停用	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
3	0	男	0	sys_user_sex				2		性别男	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
4	0	女	1	sys_user_sex				2		性别女	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
5	0	未知	2	sys_user_sex				2		性别未知	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
6	0	显示	0	sys_show_hide				2		显示菜单	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
7	0	隐藏	1	sys_show_hide				2		隐藏菜单	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
8	0	是	Y	sys_yes_no				2		系统默认是	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
9	0	否	N	sys_yes_no				2		系统默认否	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
10	0	正常	2	sys_job_status				2		正常状态	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
11	0	停用	1	sys_job_status				2		停用状态	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
12	0	默认	DEFAULT	sys_job_group				2		默认分组	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
13	0	系统	SYSTEM	sys_job_group				2		系统分组	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
14	0	通知	1	sys_notice_type				2		通知	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
15	0	公告	2	sys_notice_type				2		公告	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
16	0	正常	2	sys_common_status				2		正常状态	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
17	0	关闭	1	sys_common_status				2		关闭状态	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
18	0	新增	1	sys_oper_type				2		新增操作	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
19	0	修改	2	sys_oper_type				2		修改操作	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
20	0	删除	3	sys_oper_type				2		删除操作	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
21	0	授权	4	sys_oper_type				2		授权操作	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
22	0	导出	5	sys_oper_type				2		导出操作	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
23	0	导入	6	sys_oper_type				2		导入操作	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
24	0	强退	7	sys_oper_type				2		强退操作	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
25	0	生成代码	8	sys_oper_type				2		生成操作	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
26	0	清空数据	9	sys_oper_type				2		清空操作	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
27	0	成功	0	sys_notice_status				2		成功状态	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
28	0	失败	1	sys_notice_status				2		失败状态	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
29	0	登录	10	sys_oper_type				2		登录操作	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
30	0	退出	11	sys_oper_type				2			1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
31	0	获取验证码	12	sys_oper_type				2		获取验证码	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
32	0	正常	1	sys_content_status				1			1	1	2021-05-13 19:56:40.845+08	2021-05-13 19:56:40.845+08	\N
33	1	禁用	2	sys_content_status				1			1	1	2021-05-13 19:56:40.845+08	2021-05-13 19:56:40.845+08	\N
1	0	正常	2	sys_normal_disable				2		系统正常	1	1	2021-05-13 19:56:37.914+08	2026-04-21 13:53:56.049148+08	\N
\.


--
-- Data for Name: sys_dict_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_dict_type (dict_id, dict_name, dict_type, status, remark, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
2	用户性别	sys_user_sex	2	用户性别列表	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
3	菜单状态	sys_show_hide	2	菜单状态列表	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
4	系统是否	sys_yes_no	2	系统是否列表	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
5	任务状态	sys_job_status	2	任务状态列表	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
6	任务分组	sys_job_group	2	任务分组列表	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
7	通知类型	sys_notice_type	2	通知类型列表	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
8	系统状态	sys_common_status	2	登录状态列表	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
9	操作类型	sys_oper_type	2	操作类型列表	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
10	通知状态	sys_notice_status	2	通知状态列表	1	1	2021-05-13 19:56:37.914+08	2021-05-13 19:56:37.914+08	\N
11	内容状态	sys_content_status	2		1	1	2021-05-13 19:56:40.813+08	2021-05-13 19:56:40.813+08	\N
1	系统开关	sys_normal_disable	2	系统开关列表	1	1	2021-05-13 19:56:37.914+08	2026-04-21 13:53:51.53869+08	\N
\.


--
-- Data for Name: sys_job; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_job (job_id, job_name, job_group, job_type, cron_expression, invoke_target, args, misfire_policy, concurrent, status, entry_id, created_at, updated_at, deleted_at, create_by, update_by) FROM stdin;
1	接口测试	DEFAULT	1	0/5 * * * * 	http://localhost:8000		1	1	1	0	2021-05-13 19:56:37.914+08	2021-06-14 20:59:55.417+08	\N	1	1
2	函数测试	DEFAULT	2	0/5 * * * * 	ExamplesOne	参数	1	1	1	0	2021-05-13 19:56:37.914+08	2021-05-31 23:55:37.221+08	\N	1	1
4	OceanEngine Daily Report Sync	SYSTEM	2	0 5 2 * * *	OceanEngineSyncDailyReport		1	1	2	1	2026-03-16 16:44:14.88482+08	2026-03-19 16:49:53.708911+08	\N	0	0
3	测试kk	DEFAULT	2	*/10 * * * * *	ExamplesThree	krboom	1	1	2	2	2026-03-16 10:55:11.829694+08	2026-03-19 16:49:53.710467+08	\N	1	1
\.


--
-- Data for Name: sys_login_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_login_log (id, username, status, ipaddr, login_location, browser, os, platform, login_time, remark, msg, created_at, updated_at, create_by, update_by) FROM stdin;
\.


--
-- Data for Name: sys_menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_menu (menu_id, menu_name, title, icon, path, paths, menu_type, action, permission, parent_id, no_cache, breadcrumb, component, sort, visible, is_frame, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
545		巨量报表		/ocean-engine-report/index	/0/544/545	C			544	f		/krboom-publish/ocean-engine-report/index	0	0	1	1	1	2026-03-11 11:35:22.000948+08	2026-03-11 14:01:00.024997+08	\N
544	OceanEngine	巨量		/ocean-engine	/0/544	M			0	f		Layout	50	0	1	1	1	2026-03-11 11:34:52.362125+08	2026-03-11 14:01:00.025645+08	\N
537	SysTools	系统工具	system-tools	/sys-tools	/0/537	M			0	f		Layout	30	0	1	1	1	2021-05-21 11:13:32.166+08	2026-03-09 10:08:51.79253+08	\N
3	SysUserManage	用户管理	user	/admin/sys-user	/0/2/3	C	无	admin:sysUser:list	2	f		/admin/sys-user/index	10	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.793772+08	\N
51	SysMenuManage	菜单管理	tree-table	/admin/sys-menu	/0/2/51	C	无	admin:sysMenu:list	2	t		/admin/sys-menu/index	30	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.794785+08	\N
52	SysRoleManage	角色管理	peoples	/admin/sys-role	/0/2/52	C	无	admin:sysRole:list	2	t		/admin/sys-role/index	20	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.795303+08	\N
56	SysDeptManage	部门管理	tree	/admin/sys-dept	/0/2/56	C	无	admin:sysDept:list	2	f		/admin/sys-dept/index	40	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.796308+08	\N
57	SysPostManage	岗位管理	pass	/admin/sys-post	/0/2/57	C	无	admin:sysPost:list	2	f		/admin/sys-post/index	50	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.79741+08	\N
58	Dict	字典管理	education	/admin/dict	/0/2/58	C	无	admin:sysDictType:list	2	f		/admin/dict/index	60	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.797913+08	\N
59	SysDictDataManage	字典数据	education	/admin/dict/data/:dictId	/0/2/59	C	无	admin:sysDictData:list	2	f		/admin/dict/data	100	1	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.798733+08	\N
62	SysConfigManage	参数管理	swagger	/admin/sys-config	/0/2/62	C	无	admin:sysConfig:list	2	f		/admin/sys-config/index	70	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.799833+08	\N
211	Log	日志管理	log	/log	/0/2/211	M			2	f		/log/index	80	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.80099+08	\N
528	SysApiManage	接口管理	api-doc	/admin/sys-api	/0/2/528	C	无	admin:sysApi:list	2	f		/admin/sys-api/index	0	0	0	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.802215+08	\N
43		新增管理员	app-group-fill		/0/2/3/43	F	POST	admin:sysUser:add	3	f			10	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.803532+08	\N
44		查询管理员	app-group-fill		/0/2/3/44	F	GET	admin:sysUser:query	3	f			40	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.804554+08	\N
45		修改管理员	app-group-fill		/0/2/3/45	F	PUT	admin:sysUser:edit	3	f			30	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.805814+08	\N
46		删除管理员	app-group-fill		/0/2/3/46	F	DELETE	admin:sysUser:remove	3	f			20	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.806318+08	\N
220		新增菜单	app-group-fill		/0/2/51/220	F		admin:sysMenu:add	51	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.807058+08	\N
221		修改菜单	app-group-fill		/0/2/51/221	F		admin:sysMenu:edit	51	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.808587+08	\N
222		查询菜单	app-group-fill		/0/2/51/222	F		admin:sysMenu:query	51	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.809592+08	\N
223		删除菜单	app-group-fill		/0/2/51/223	F		admin:sysMenu:remove	51	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.810097+08	\N
224		新增角色	app-group-fill		/0/2/52/224	F		admin:sysRole:add	52	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.810913+08	\N
225		查询角色	app-group-fill		/0/2/52/225	F		admin:sysRole:query	52	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.812097+08	\N
226		修改角色	app-group-fill		/0/2/52/226	F		admin:sysRole:update	52	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.812601+08	\N
227		删除角色	app-group-fill		/0/2/52/227	F		admin:sysRole:remove	52	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.813236+08	\N
228		查询部门	app-group-fill		/0/2/56/228	F		admin:sysDept:query	56	f			40	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.814246+08	\N
229		新增部门	app-group-fill		/0/2/56/229	F		admin:sysDept:add	56	f			10	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.814786+08	\N
230		修改部门	app-group-fill		/0/2/56/230	F		admin:sysDept:edit	56	f			30	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.815412+08	\N
231		删除部门	app-group-fill		/0/2/56/231	F		admin:sysDept:remove	56	f			20	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.816548+08	\N
232		查询岗位	app-group-fill		/0/2/57/232	F		admin:sysPost:query	57	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.817051+08	\N
233		新增岗位	app-group-fill		/0/2/57/233	F		admin:sysPost:add	57	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.817815+08	\N
234		修改岗位	app-group-fill		/0/2/57/234	F		admin:sysPost:edit	57	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.818917+08	\N
235		删除岗位	app-group-fill		/0/2/57/235	F		admin:sysPost:remove	57	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.819421+08	\N
236		查询字典	app-group-fill		/0/2/58/236	F		admin:sysDictType:query	58	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.819928+08	\N
237		新增类型	app-group-fill		/0/2/58/237	F		admin:sysDictType:add	58	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.82102+08	\N
238		修改类型	app-group-fill		/0/2/58/238	F		admin:sysDictType:edit	58	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.821523+08	\N
239		删除类型	app-group-fill		/0/2/58/239	F		system:sysdicttype:remove	58	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.82203+08	\N
240		查询数据	app-group-fill		/0/2/59/240	F		admin:sysDictData:query	59	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.822554+08	\N
241		新增数据	app-group-fill		/0/2/59/241	F		admin:sysDictData:add	59	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.823573+08	\N
242		修改数据	app-group-fill		/0/2/59/242	F		admin:sysDictData:edit	59	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.824566+08	\N
243		删除数据	app-group-fill		/0/2/59/243	F		admin:sysDictData:remove	59	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.826113+08	\N
61	Swagger	系统接口	guide	/dev-tools/swagger	/0/60/61	C	无		60	f		/dev-tools/swagger/index	1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.82663+08	\N
261	Gen	代码生成	code	/dev-tools/gen	/0/60/261	C			60	f		/dev-tools/gen/index	2	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.827333+08	\N
262	EditTable	代码生成修改	build	/dev-tools/editTable	/0/60/262	C			60	f		/dev-tools/gen/editTable	100	1	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.828434+08	\N
60	Tools	开发工具	dev-tools	/dev-tools	/0/60	M	无		0	f		Layout	40	0	1	1	1	2020-04-11 15:52:48+08	2026-04-10 17:43:04.030158+08	2026-04-10 17:43:04.030158+08
459	Schedule	定时任务	time-range	/schedule	/0/459	M	无		0	f		Layout	20	0	1	1	1	2020-08-03 09:17:37+08	2026-04-21 13:53:23.243759+08	\N
2	Admin	系统管理	Ri4kLine	/admin	/0/2	M	无		0	t		Layout	10	0	1	0	1	2021-05-20 21:58:45.679+08	2026-04-21 12:43:13.368335+08	\N
264	Build	表单构建	build	/dev-tools/build	/0/60/264	C			60	f		/dev-tools/build/index	1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.828937+08	\N
244		查询参数	app-group-fill		/0/2/62/244	F		admin:sysConfig:query	62	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.82951+08	\N
245		新增参数	app-group-fill		/0/2/62/245	F		admin:sysConfig:add	62	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.83052+08	\N
246		修改参数	app-group-fill		/0/2/62/246	F		admin:sysConfig:edit	62	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.831053+08	\N
247		删除参数	app-group-fill		/0/2/62/247	F		admin:sysConfig:remove	62	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.831562+08	\N
212	SysLoginLogManage	登录日志	logininfor	/admin/sys-login-log	/0/2/211/212	C		admin:sysLoginLog:list	211	f		/admin/sys-login-log/index	1	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.832085+08	\N
216	OperLog	操作日志	skill	/admin/sys-oper-log	/0/2/211/216	C		admin:sysOperLog:list	211	f		/admin/sys-oper-log/index	1	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.833106+08	\N
248		查询登录日志	app-group-fill		/0/2/211/212/248	F		admin:sysLoginLog:query	212	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.834335+08	\N
249		删除登录日志	app-group-fill		/0/2/211/212/249	F		admin:sysLoginLog:remove	212	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.834853+08	\N
250		查询操作日志	app-group-fill		/0/2/211/216/250	F		admin:sysOperLog:query	216	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.835536+08	\N
251		删除操作日志	app-group-fill		/0/2/211/216/251	F		admin:sysOperLog:remove	216	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:08:51.836607+08	\N
461	sys_job	分页获取定时任务	app-group-fill		/0/459/460/461	F	无	job:sysJob:query	460	f			0	0	1	1	1	2020-08-03 09:17:37+08	2026-03-09 10:08:51.839853+08	\N
462	sys_job	创建定时任务	app-group-fill		/0/459/460/462	F	无	job:sysJob:add	460	f			0	0	1	1	1	2020-08-03 09:17:37+08	2026-03-09 10:08:51.844204+08	\N
463	sys_job	修改定时任务	app-group-fill		/0/459/460/463	F	无	job:sysJob:edit	460	f			0	0	1	1	1	2020-08-03 09:17:37+08	2026-03-09 10:08:51.849497+08	\N
464	sys_job	删除定时任务	app-group-fill		/0/459/460/464	F	无	job:sysJob:remove	460	f			0	0	1	1	1	2020-08-03 09:17:37+08	2026-03-09 10:08:51.853865+08	\N
529		查询接口	app-group-fill		/0/2/528/529	F	无	admin:sysApi:query	528	f			40	0	0	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.858362+08	\N
531		修改接口	app-group-fill		/0/2/528/531	F	无	admin:sysApi:edit	528	f			30	0	0	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:08:51.861567+08	\N
542		修改	upload		/0/2/540/542	F		admin:sysConfigSet:update	540	f			0	0	1	1	1	2021-06-13 11:45:48.67+08	2026-03-09 10:08:51.862599+08	\N
546		数据分析	RiAccountCircle2Line	/analysis	/0/546	M			0	f		Layout	60	0	1	1	1	2026-04-09 11:27:25.831735+08	2026-04-09 11:27:35.110194+08	\N
547		微信数据		/krboom-publish/wechat-analysis/index	/0/546/547	C			546	f		/krboom-publish/wechat-analysis/index	0	0	1	1	1	2026-04-09 11:30:01.4894+08	2026-04-09 11:30:01.4894+08	\N
548		定时任务		/cron/index	/0/459/548	C			459	f		/cron/index	0	0	1	1	1	2026-04-10 17:42:44.210983+08	2026-04-10 17:42:44.210983+08	\N
460	ScheduleManage	Schedule	job	/schedule/manage	/0/459/460	C	无	job:sysJob:list	459	f		/schedule/index	0	0	1	1	1	2020-08-03 09:17:37+08	2026-04-10 17:42:52.623619+08	2026-04-10 17:42:52.623619+08
540	SysConfigSet	参数设置	system-tools	/admin/sys-config/set	/0/2/540	C		admin:sysConfigSet:list	2	f		/admin/sys-config/set	0	0	1	1	1	2021-05-25 16:06:52.56+08	2026-04-10 17:44:01.192297+08	2026-04-10 17:44:01.192297+08
471	JobLog	日志	bug	/schedule/log	/0/459/471	C		2	459	f		/schedule/log	0	1	1	1	1	2020-08-05 21:24:46+08	2026-04-21 13:53:32.529237+08	\N
269	ServerMonitor	服务监控	druid	/sys-tools/monitor	/0/537/269	C		sysTools:serverMonitor:list	537	f		/sys-tools/monitor	0	0	1	1	1	2020-04-14 00:28:19+08	2026-04-22 10:33:07.250723+08	2026-04-22 10:33:07.250723+08
549		数据源		/kiif-gm/data-source/index	/0/537/549	C			537	f		/kiif-gm/data-source/index	0	0	1	1	1	2026-04-22 10:33:28.958832+08	2026-04-22 10:34:14.377158+08	2026-04-22 10:34:14.377158+08
\.


--
-- Data for Name: sys_opera_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_opera_log (id, title, business_type, business_types, method, request_method, operator_type, oper_name, dept_name, oper_url, oper_ip, oper_location, oper_param, status, oper_time, json_result, remark, latency_time, user_agent, created_at, updated_at, create_by, update_by) FROM stdin;
1	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin		/api/v1/menu	192.168.32.128		{"menuType":"M","sort":0,"isFrame":"1","visible":"0","component":"Layout","title":"数据分析","path":"/analysis","icon":"RiAccountCircle2Line"}	1	2026-04-09 11:27:25.817633	{"code":200,"data":546,"msg":"success"}		36.915563ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-09 11:27:25.856073+08	2026-04-09 11:27:25.856073+08	1	1
2	编辑菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Update-fm	PUT	BUS	admin		/api/v1/menu/546	192.168.32.128		{"menuType":"M","sort":60,"isFrame":"1","visible":"0","component":"Layout","title":"数据分析","path":"/analysis","icon":"RiAccountCircle2Line","parentId":0,"menuName":"","menuId":546,"paths":"/0/546","action":"","permission":"","noCache":false,"breadcrumb":"","apis":[],"sysApi":[]}	1	2026-04-09 11:27:35.105963	{"code":200,"data":546,"msg":"success"}		6.827476ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-09 11:27:35.120267+08	2026-04-09 11:27:35.120267+08	1	1
3	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin		/api/v1/menu	192.168.32.128		{"menuType":"C","sort":0,"isFrame":"1","visible":"0","component":"/krboom-publish/wechat-analysis/index","title":"微信数据","path":"/krboom-publish/wechat-analysis/index","parentId":546,"menuId":null,"paths":"/0/546","action":"","permission":"","noCache":false,"breadcrumb":"","apis":[],"sysApi":[]}	1	2026-04-09 11:30:01.485419	{"code":200,"data":547,"msg":"success"}		12.099146ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-09 11:30:01.4999+08	2026-04-09 11:30:01.4999+08	1	1
4	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin		/api/v1/menu	192.168.32.128		{"menuType":"C","sort":0,"isFrame":"1","visible":"0","component":"/cron/index","parentId":459,"path":"/cron/index","title":"定时任务"}	1	2026-04-10 17:42:44.205701	{"code":200,"data":548,"msg":"success"}		22.608892ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-10 17:42:44.230016+08	2026-04-10 17:42:44.230016+08	1	1
5	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin		/api/v1/menu	192.168.32.128		{"ids":[460]}	1	2026-04-10 17:42:52.621547	{"code":200,"data":[460],"msg":"success"}		5.777443ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-10 17:42:52.628567+08	2026-04-10 17:42:52.628567+08	1	1
6	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin		/api/v1/menu	192.168.32.128		{"ids":[60]}	1	2026-04-10 17:43:04.02871	{"code":200,"data":[60],"msg":"success"}		4.311391ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-10 17:43:04.034236+08	2026-04-10 17:43:04.034236+08	1	1
7	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin		/api/v1/menu	192.168.32.128		{"ids":[540]}	1	2026-04-10 17:44:01.189354	{"code":200,"data":[540],"msg":"success"}		6.020891ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-10 17:44:01.198023+08	2026-04-10 17:44:01.198023+08	1	1
8	/api/v1/cron/task/5/trigger			POST /api/v1/cron/task/5/trigger	POST		admin		/api/v1/cron/task/5/trigger	192.168.32.128			1	2026-04-10 17:57:01.734263	{"code":200,"data":{"id":7894,"task_id":5,"tenant_code":"krboom-publish","task_key":"ocean_engine_da		18.539358ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-10 17:57:01.761054+08	2026-04-10 17:57:01.761054+08	1	1
9	/api/v1/cron/task			POST /api/v1/cron/task	POST		admin		/api/v1/cron/task	192.168.32.128		{"taskKey":"test","taskName":"尔特","scheduleType":"interval","intervalSeconds":5,"scheduledAt":"2026-04-13T02:58:10.000Z","payload":{"invokeTarget":"EchoArgs","args":"testt"}}	1	2026-04-13 10:57:31.448286	{"code":200,"data":{"id":6,"tenant_code":"krboom-publish","task_key":"test","task_name":"尔特","ta		10.650015ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-13 10:57:31.472634+08	2026-04-13 10:57:31.472634+08	1	1
10	/api/v1/cron/task/6/status			PUT /api/v1/cron/task/6/status	PUT		admin		/api/v1/cron/task/6/status	192.168.32.128		{"status":"disabled"}	1	2026-04-13 10:58:27.278246	{"code":200,"data":{"id":6,"tenant_code":"krboom-publish","task_key":"test","task_name":"尔特","ta		4.701952ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-13 10:58:27.28795+08	2026-04-13 10:58:27.28795+08	1	1
11	编辑菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Update-fm	PUT	BUS	admin		/api/v1/menu/2	192.168.32.128		{"menuType":"M","sort":10,"isFrame":"1","visible":"0","component":"Layout","menuId":2,"menuName":"Admin","title":"系统管理","icon":"Ri4kLine","path":"/admin","paths":"/0/2","action":"无","permission":"","parentId":0,"noCache":true,"breadcrumb":"","apis":[],"sysApi":[]}	1	2026-04-13 14:30:25.225658	{"code":200,"data":2,"msg":"success"}		10.331827ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-13 14:30:25.239549+08	2026-04-13 14:30:25.239549+08	1	1
12	/api/v1/cron/task/7/trigger			POST /api/v1/cron/task/7/trigger	POST		admin		/api/v1/cron/task/7/trigger	192.168.32.128			2	2026-04-14 16:19:45.317675	{"code":500,"msg":"rpc error: code = Unavailable desc = last connection error: connection error: des		1.373089ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-14 16:19:45.323452+08	2026-04-14 16:19:45.323452+08	1	1
13	/api/v1/cron/task/7/trigger			POST /api/v1/cron/task/7/trigger	POST		admin		/api/v1/cron/task/7/trigger	192.168.32.128			1	2026-04-14 16:19:50.364382	{"code":200,"data":{"id":7921,"task_id":7,"tenant_code":"krboom-publish","task_key":"refresh_token",		4.893855ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-14 16:19:50.37408+08	2026-04-14 16:19:50.37408+08	1	1
14	/api/v1/cron/task/7/trigger			POST /api/v1/cron/task/7/trigger	POST		admin		/api/v1/cron/task/7/trigger	192.168.32.128			1	2026-04-14 16:20:09.971573	{"code":200,"data":{"id":7926,"task_id":7,"tenant_code":"krboom-publish","task_key":"refresh_token",		8.499337ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-14 16:20:09.98421+08	2026-04-14 16:20:09.98421+08	1	1
15	/api/v1/cron/task/6/status			PUT /api/v1/cron/task/6/status	PUT		admin		/api/v1/cron/task/6/status	192.168.32.128		{"status":"enabled"}	1	2026-04-15 13:51:00.872323	{"code":200,"data":{"id":6,"tenant_code":"krboom-publish","task_key":"test","task_name":"尔特","ta		10.9562ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-15 13:51:00.88893+08	2026-04-15 13:51:00.88893+08	1	1
16	/api/v1/cron/task/6			PUT /api/v1/cron/task/6	PUT		admin		/api/v1/cron/task/6	192.168.32.128		{"taskName":"尔特","scheduleType":"interval","intervalSeconds":5,"scheduledAt":"2026-04-15T05:53:15.000Z","payload":{"invokeTarget":"EchoArgs","args":"testt"}}	1	2026-04-15 13:51:20.480825	{"code":200,"data":{"id":6,"tenant_code":"krboom-publish","task_key":"test","task_name":"尔特","ta		10.124795ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-15 13:51:20.495882+08	2026-04-15 13:51:20.495882+08	1	1
17	/api/v1/cron/task/6/status			PUT /api/v1/cron/task/6/status	PUT		admin		/api/v1/cron/task/6/status	192.168.32.128		{"status":"disabled"}	1	2026-04-15 13:53:29.872854	{"code":200,"data":{"id":6,"tenant_code":"krboom-publish","task_key":"test","task_name":"尔特","ta		8.121481ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-15 13:53:29.884953+08	2026-04-15 13:53:29.884953+08	1	1
18	/api/v1/cron/task/8/trigger			POST /api/v1/cron/task/8/trigger	POST		admin		/api/v1/cron/task/8/trigger	192.168.32.128			2	2026-04-17 10:28:59.220168	{"code":500,"msg":"rpc error: code = Unknown desc = cron kafka producer unavailable: kafka: client h		21.500886ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-17 10:28:59.252487+08	2026-04-17 10:28:59.252487+08	1	1
19	/api/v1/cron/task/8/trigger			POST /api/v1/cron/task/8/trigger	POST		admin		/api/v1/cron/task/8/trigger	192.168.32.128			1	2026-04-17 10:32:34.591951	{"code":200,"data":{"id":27638,"task_id":8,"tenant_code":"krboom-publish","task_key":"wechat_analysi		22.459079ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-17 10:32:34.624167+08	2026-04-17 10:32:34.624167+08	1	1
20	/api/v1/cron/task/5/status			PUT /api/v1/cron/task/5/status	PUT		admin		/api/v1/cron/task/5/status	192.168.32.128		{"status":"disabled"}	1	2026-04-17 11:02:00.113345	{"code":200,"data":{"id":5,"tenant_code":"krboom-publish","task_key":"ocean_engine_daily_report_sync		10.62113ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-17 11:02:00.126592+08	2026-04-17 11:02:00.126592+08	1	1
21	/api/v1/cron/task/8/trigger			POST /api/v1/cron/task/8/trigger	POST		admin		/api/v1/cron/task/8/trigger	192.168.32.128			1	2026-04-17 11:02:25.877277	{"code":200,"data":{"id":27938,"task_id":8,"tenant_code":"krboom-publish","task_key":"wechat_analysi		4.097164ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-17 11:02:25.886389+08	2026-04-17 11:02:25.886389+08	1	1
22	/api/v1/cron/task/8/trigger			POST /api/v1/cron/task/8/trigger	POST		admin		/api/v1/cron/task/8/trigger	192.168.32.128			1	2026-04-17 11:26:51.705361	{"code":200,"data":{"id":27939,"task_id":8,"tenant_code":"krboom-publish","task_key":"wechat_analysi		8.033484ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-17 11:26:51.720802+08	2026-04-17 11:26:51.720802+08	1	1
23	/api/v1/cron/task/8/trigger			POST /api/v1/cron/task/8/trigger	POST		admin		/api/v1/cron/task/8/trigger	192.168.32.128			1	2026-04-17 11:45:16.735639	{"code":200,"data":{"id":27940,"task_id":8,"tenant_code":"krboom-publish","task_key":"wechat_analysi		22.794008ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-17 11:45:16.760726+08	2026-04-17 11:45:16.760726+08	1	1
25	接口编辑	BUS	BUS	go-admin/app/admin/apis.SysApi.Update-fm	PUT	BUS	admin		/api/v1/sys-api/159	192.168.32.128		{"id":159,"handle":"github.com/gin-gonic/gin.(*RouterGroup).createStaticHandler.func1","title":"让他","path":"/form-generator/*filepath","action":"HEAD","type":"","createdAt":"2021-06-13T19:25:02.808+08:00","updatedAt":"2021-06-13T20:53:52.838+08:00"}	2	2026-04-21 10:45:06.229984	{"code":400,"msg":"invalid request"}		1.275046ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 10:45:06.245982+08	2026-04-21 10:45:06.245982+08	1	1
26	管理员编辑	BUS	BUS	go-admin/app/admin/apis.SysUser.Update-fm	PUT	BUS	admin		/api/v1/sys-user	192.168.32.128		{"userId":6,"username":"1234","password":"","nickName":"1234","phone":"1234","roleId":1,"avatar":"","sex":"","email":"1234@qq.com","deptId":7,"postId":0,"remark":"","status":"2","allowPasswordLogin":"1","deptIds":[7],"postIds":[0],"roleIds":[1],"createBy":1,"updateBy":0,"dept":{"deptId":7,"parentId":1,"deptPath":"/0/1/7/","deptName":"研发部","sort":1,"leader":"aituo","phone":"13782218188","email":"atuo@aituo.com","status":2,"createdAt":"0001-01-01T00:00:00Z","updatedAt":"0001-01-01T00:00:00Z","children":[]},"createdAt":"2026-03-13T18:42:15.087875+08:00","updatedAt":"2026-03-13T18:42:51.908351+08:00"}	1	2026-04-21 10:45:21.702756	{"code":200,"data":6,"msg":"update success"}		20.665268ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 10:45:21.724974+08	2026-04-21 10:45:21.724974+08	1	1
27	管理员编辑	BUS	BUS	go-admin/app/admin/apis.SysUser.Update-fm	PUT	BUS	admin		/api/v1/sys-user	192.168.32.128		{"userId":6,"username":"1234","password":"","nickName":"12345","phone":"1234","roleId":1,"avatar":"","sex":"","email":"1234@qq.com","deptId":7,"postId":0,"remark":"","status":"2","allowPasswordLogin":"1","deptIds":[7],"postIds":[0],"roleIds":[1],"createBy":1,"updateBy":1,"dept":{"deptId":7,"parentId":1,"deptPath":"/0/1/7/","deptName":"研发部","sort":1,"leader":"aituo","phone":"13782218188","email":"atuo@aituo.com","status":2,"createdAt":"0001-01-01T00:00:00Z","updatedAt":"0001-01-01T00:00:00Z","children":[]},"createdAt":"2026-03-13T18:42:15.087875+08:00","updatedAt":"2026-04-21T10:45:21.718039+08:00"}	1	2026-04-21 10:45:26.980097	{"code":200,"data":6,"msg":"update success"}		8.804627ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 10:45:26.990567+08	2026-04-21 10:45:26.990567+08	1	1
28	角色编辑	BUS	BUS	go-admin/app/admin/apis.SysRole.Update-fm	PUT	BUS	admin		/api/v1/role/1	192.168.32.128		{"sort":0,"status":"2","roleId":1,"roleName":"系统管理员","roleKey":"admin","roleSort":1,"flag":"","remark":"","admin":true,"dataScope":"","menuIds":[],"deptIds":null,"sysMenu":null,"createdAt":"2021-05-13T19:56:37.913+08:00","updatedAt":"2021-05-13T19:56:37.913+08:00"}	1	2026-04-21 10:45:56.820464	{"code":200,"data":1,"msg":"success"}		11.565425ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 10:45:56.837106+08	2026-04-21 10:45:56.837106+08	1	1
29	角色创建	BUS	BUS	go-admin/app/admin/apis.SysRole.Insert-fm	POST	BUS	admin		/api/v1/role	192.168.32.128		{"sort":0,"status":"2","roleId":null,"roleName":"34","roleKey":"423","roleSort":2,"flag":"","admin":true,"dataScope":"","menuIds":[459,471,548],"deptIds":null,"sysMenu":null,"createdAt":"2021-05-13T19:56:37.913+08:00","updatedAt":"2021-05-13T19:56:37.913+08:00"}	1	2026-04-21 10:46:03.58856	{"code":200,"data":5,"msg":"success"}		13.31411ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 10:46:03.60705+08	2026-04-21 10:46:03.60705+08	1	1
30	管理员编辑	BUS	BUS	go-admin/app/admin/apis.SysUser.Update-fm	PUT	BUS	admin		/api/v1/sys-user	192.168.32.128		{"userId":1,"username":"admin","password":"","nickName":"zhangwj","phone":"18612529003","roleId":1,"avatar":"","sex":"1","email":"1@qq.com","deptId":1,"postId":1,"remark":"","status":"2","allowPasswordLogin":"2","deptIds":[1],"postIds":[1],"roleIds":[1],"createBy":1,"updateBy":1,"dept":{"deptId":1,"parentId":0,"deptPath":"/0/1/","deptName":"爱拓科技","sort":0,"leader":"aituo","phone":"13782218188","email":"atuo@aituo.com","status":2,"createdAt":"0001-01-01T00:00:00Z","updatedAt":"0001-01-01T00:00:00Z","children":[]},"createdAt":"2021-05-13T19:56:37.914+08:00","updatedAt":"2021-05-13T19:56:40.205+08:00"}	1	2026-04-21 12:43:50.022126	{"code":200,"data":1,"msg":"update success"}		16.799441ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 12:43:50.04006+08	2026-04-21 12:43:50.04006+08	1	1
31	管理员编辑	BUS	BUS	go-admin/app/admin/apis.SysUser.Update-fm	PUT	BUS	admin		/api/v1/sys-user	192.168.32.128		{"userId":6,"username":"1234","password":"","nickName":"12345","phone":"1234","roleId":1,"avatar":"","sex":"","email":"1234@qq.com","deptId":7,"postId":0,"remark":"","status":"2","allowPasswordLogin":"1","deptIds":[7],"postIds":[0],"roleIds":[1],"createBy":1,"updateBy":1,"dept":{"deptId":7,"parentId":1,"deptPath":"/0/1/7/","deptName":"研发部","sort":1,"leader":"aituo","phone":"13782218188","email":"atuo@aituo.com","status":2,"createdAt":"0001-01-01T00:00:00Z","updatedAt":"0001-01-01T00:00:00Z","children":[]},"createdAt":"2026-03-13T18:42:15.087875+08:00","updatedAt":"2026-04-21T10:45:26.984838+08:00"}	1	2026-04-21 13:54:27.398584	{"code":200,"data":6,"msg":"update success"}		12.195039ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 13:54:27.413481+08	2026-04-21 13:54:27.413481+08	1	1
32	/api/v1/user/status			go-admin/app/admin/apis.SysUser.UpdateStatus-fm	PUT		admin		/api/v1/user/status	192.168.32.128		{"userId":6,"status":"1"}	1	2026-04-22 10:32:14.338431	{"code":200,"data":6,"msg":"update success"}		25.130761ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:32:14.366004+08	2026-04-22 10:32:14.366004+08	1	1
33	/api/v1/user/status			go-admin/app/admin/apis.SysUser.UpdateStatus-fm	PUT		admin		/api/v1/user/status	192.168.32.128		{"userId":6,"status":"2"}	1	2026-04-22 10:32:20.050457	{"code":200,"data":6,"msg":"update success"}		10.203911ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:32:20.062434+08	2026-04-22 10:32:20.062434+08	1	1
34	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin		/api/v1/menu	192.168.32.128		{"ids":[269]}	1	2026-04-22 10:33:07.248965	{"code":200,"data":[269],"msg":"success"}		13.640113ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:33:07.263612+08	2026-04-22 10:33:07.263612+08	1	1
35	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin		/api/v1/menu	192.168.32.128		{"menuType":"C","sort":0,"isFrame":"1","visible":"0","component":"/kiif-gm/data-source/index","parentId":537,"menuName":"","path":"/kiif-gm/data-source/index","title":"数据源"}	1	2026-04-22 10:33:28.955219	{"code":200,"data":549,"msg":"success"}		51.256943ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:33:29.00771+08	2026-04-22 10:33:29.00771+08	1	1
36	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin		/api/v1/menu	192.168.32.128		{"ids":[549]}	1	2026-04-22 10:34:14.373925	{"code":200,"data":[549],"msg":"success"}		5.683232ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:34:14.381678+08	2026-04-22 10:34:14.381678+08	1	1
\.


--
-- Data for Name: sys_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_role (role_id, role_name, status, role_key, role_sort, flag, remark, admin, data_scope, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
5	341	2	423	2			t		1	1	2026-04-21 10:46:03.593205+08	2026-04-21 12:43:44.688551+08	\N
1	系统管理员	2	admin	1			t		1	1	2021-05-13 19:56:37.913+08	2026-04-21 13:53:17.423576+08	\N
\.


--
-- Data for Name: sys_role_dept; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_role_dept (id, role_id, dept_id) FROM stdin;
\.


--
-- Data for Name: sys_role_menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_role_menu (id, role_id, menu_id) FROM stdin;
\.


--
-- Data for Name: sys_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_user (user_id, username, password, nick_name, phone, role_id, salt, avatar, sex, email, dept_id, post_id, remark, status, create_by, update_by, created_at, updated_at, deleted_at, allow_password_login) FROM stdin;
1	admin	$2a$10$/Glr4g9Svr6O0kvjsRJCXu3f0W8/dsP3XZyVNi1019ratWpSPMyw.	zhangwj	18612529003	1			1	1@qq.com	1	1		2	1	1	2021-05-13 19:56:37.914+08	2026-04-21 12:43:50.035854+08	\N	2
6	1234	$2a$10$DYRZeWf3CqUGUsiEKMEQ7ujd980trdbmz2t9zHiy4wOUQoFumCWLi	12345	1234	1				1234@qq.com	7	0		2	1	1	2026-03-13 18:42:15.087875+08	2026-04-22 10:32:20.057571+08	\N	1
\.


--
-- Name: sys_config_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_config_config_id_seq', 6, true);


--
-- Name: sys_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_config_id_seq', 1, true);


--
-- Name: sys_dept_dept_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_dept_dept_id_seq', 11, true);


--
-- Name: sys_dict_data_dict_code_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_dict_data_dict_code_seq', 34, true);


--
-- Name: sys_dict_type_dict_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_dict_type_dict_id_seq', 12, true);


--
-- Name: sys_job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_job_id_seq', 3, true);


--
-- Name: sys_job_job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_job_job_id_seq', 4, true);


--
-- Name: sys_login_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_login_log_id_seq', 1, false);


--
-- Name: sys_menu_menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_menu_menu_id_seq', 549, true);


--
-- Name: sys_opera_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_opera_log_id_seq', 36, true);


--
-- Name: sys_role_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_role_role_id_seq', 5, true);


--
-- Name: sys_user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_user_user_id_seq', 6, true);


--
-- Name: sys_config sys_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_config
    ADD CONSTRAINT sys_config_pkey PRIMARY KEY (id);


--
-- Name: sys_dept sys_dept_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dept
    ADD CONSTRAINT sys_dept_pkey PRIMARY KEY (dept_id);


--
-- Name: sys_dict_data sys_dict_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dict_data
    ADD CONSTRAINT sys_dict_data_pkey PRIMARY KEY (dict_code);


--
-- Name: sys_dict_type sys_dict_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dict_type
    ADD CONSTRAINT sys_dict_type_pkey PRIMARY KEY (dict_id);


--
-- Name: sys_job sys_job_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_job
    ADD CONSTRAINT sys_job_pkey PRIMARY KEY (job_id);


--
-- Name: sys_login_log sys_login_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_login_log
    ADD CONSTRAINT sys_login_log_pkey PRIMARY KEY (id);


--
-- Name: sys_menu sys_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_menu
    ADD CONSTRAINT sys_menu_pkey PRIMARY KEY (menu_id);


--
-- Name: sys_opera_log sys_opera_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_opera_log
    ADD CONSTRAINT sys_opera_log_pkey PRIMARY KEY (id);


--
-- Name: sys_role_dept sys_role_dept_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role_dept
    ADD CONSTRAINT sys_role_dept_pkey PRIMARY KEY (id);


--
-- Name: sys_role_menu sys_role_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role_menu
    ADD CONSTRAINT sys_role_menu_pkey PRIMARY KEY (id);


--
-- Name: sys_role sys_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role
    ADD CONSTRAINT sys_role_pkey PRIMARY KEY (role_id);


--
-- Name: sys_user sys_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_user
    ADD CONSTRAINT sys_user_pkey PRIMARY KEY (user_id);


--
-- Name: idx_sys_config_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_create_by ON public.sys_config USING btree (create_by);


--
-- Name: idx_sys_config_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_deleted_at ON public.sys_config USING btree (deleted_at);


--
-- Name: idx_sys_config_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_update_by ON public.sys_config USING btree (update_by);


--
-- Name: idx_sys_dept_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dept_create_by ON public.sys_dept USING btree (create_by);


--
-- Name: idx_sys_dept_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dept_deleted_at ON public.sys_dept USING btree (deleted_at);


--
-- Name: idx_sys_dept_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dept_update_by ON public.sys_dept USING btree (update_by);


--
-- Name: idx_sys_dict_data_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_data_create_by ON public.sys_dict_data USING btree (create_by);


--
-- Name: idx_sys_dict_data_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_data_deleted_at ON public.sys_dict_data USING btree (deleted_at);


--
-- Name: idx_sys_dict_data_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_data_update_by ON public.sys_dict_data USING btree (update_by);


--
-- Name: idx_sys_dict_type_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_type_create_by ON public.sys_dict_type USING btree (create_by);


--
-- Name: idx_sys_dict_type_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_type_deleted_at ON public.sys_dict_type USING btree (deleted_at);


--
-- Name: idx_sys_dict_type_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_dict_type_update_by ON public.sys_dict_type USING btree (update_by);


--
-- Name: idx_sys_job_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_job_create_by ON public.sys_job USING btree (create_by);


--
-- Name: idx_sys_job_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_job_deleted_at ON public.sys_job USING btree (deleted_at);


--
-- Name: idx_sys_job_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_job_update_by ON public.sys_job USING btree (update_by);


--
-- Name: idx_sys_login_log_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_login_log_create_by ON public.sys_login_log USING btree (create_by);


--
-- Name: idx_sys_login_log_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_login_log_update_by ON public.sys_login_log USING btree (update_by);


--
-- Name: idx_sys_menu_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_create_by ON public.sys_menu USING btree (create_by);


--
-- Name: idx_sys_menu_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_deleted_at ON public.sys_menu USING btree (deleted_at);


--
-- Name: idx_sys_menu_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_update_by ON public.sys_menu USING btree (update_by);


--
-- Name: idx_sys_opera_log_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_opera_log_create_by ON public.sys_opera_log USING btree (create_by);


--
-- Name: idx_sys_opera_log_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_opera_log_update_by ON public.sys_opera_log USING btree (update_by);


--
-- Name: idx_sys_role_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_role_create_by ON public.sys_role USING btree (create_by);


--
-- Name: idx_sys_role_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_role_deleted_at ON public.sys_role USING btree (deleted_at);


--
-- Name: idx_sys_role_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_role_update_by ON public.sys_role USING btree (update_by);


--
-- Name: idx_sys_user_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_create_by ON public.sys_user USING btree (create_by);


--
-- Name: idx_sys_user_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_deleted_at ON public.sys_user USING btree (deleted_at);


--
-- Name: idx_sys_user_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_update_by ON public.sys_user USING btree (update_by);


--
-- PostgreSQL database dump complete
--

\unrestrict r1pm3as1o0cTULLHDJzuAmnLlSQUrPElUQ1kRUvdr4ZCtWqUtlaK8I2TuqftqjB

