// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package svc

import (
	"civet/apps/kbrelease/api/internal/config"
	"civet/apps/kbrelease/model"
	_ "github.com/lib/pq"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

type ServiceContext struct {
	Config config.Config
	// Code generated model fields. DO NOT EDIT.
	AdvertiserTokensModel           model.AdvertiserTokensModel
	OceanengineDailyBaseModel       model.OceanengineDailyBaseModel
	OceanengineDailyConversionModel model.OceanengineDailyConversionModel
	OceanengineDailyLtvModel        model.OceanengineDailyLtvModel
	OceanengineDailyOtherModel      model.OceanengineDailyOtherModel
	OceanengineDailySummaryModel    model.OceanengineDailySummaryModel
	SummaryDataModel                model.SummaryDataModel
	WechatDailyDataModel            model.WechatDailyDataModel
	WechatRawDataModel              model.WechatRawDataModel
	// End generated model fields.
	// Code generated middleware fields. DO NOT EDIT.
	// End generated middleware fields.
}

func NewServiceContext(c config.Config) *ServiceContext {
	conn := sqlx.NewSqlConn(c.Pg.DriverName, c.Pg.DataSource)

	return &ServiceContext{
		Config: c,
		// Code generated model init. DO NOT EDIT.
		AdvertiserTokensModel:           model.NewAdvertiserTokensModel(conn),
		OceanengineDailyBaseModel:       model.NewOceanengineDailyBaseModel(conn),
		OceanengineDailyConversionModel: model.NewOceanengineDailyConversionModel(conn),
		OceanengineDailyLtvModel:        model.NewOceanengineDailyLtvModel(conn),
		OceanengineDailyOtherModel:      model.NewOceanengineDailyOtherModel(conn),
		OceanengineDailySummaryModel:    model.NewOceanengineDailySummaryModel(conn),
		SummaryDataModel:                model.NewSummaryDataModel(conn),
		WechatDailyDataModel:            model.NewWechatDailyDataModel(conn),
		WechatRawDataModel:              model.NewWechatRawDataModel(conn),
		// End generated model init.
		// Code generated middleware init. DO NOT EDIT.
		// End generated middleware init.
	}
}
