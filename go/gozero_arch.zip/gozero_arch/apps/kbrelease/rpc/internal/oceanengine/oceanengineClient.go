package oceanengine

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

const (
	defaultAccessTokenEndpoint         = "https://api.oceanengine.com/open_api/oauth2/access_token/"
	defaultRefreshTokenEndpoint        = "https://api.oceanengine.com/open_api/oauth2/refresh_token/"
	defaultAdvertiserGetEndpoint       = "https://api.oceanengine.com/open_api/oauth2/advertiser/get/"
	defaultCCAdvertiserListEndpoint    = "https://ad.oceanengine.com/open_api/2/customer_center/advertiser/list/"
	defaultMajordomoAdvertiserEndpoint = "https://api.oceanengine.com/open_api/2/majordomo/advertiser/select/"
	defaultReportConfigEndpoint        = "https://api.oceanengine.com/open_api/v3.0/report/custom/config/get/"
)

func NewClient() *Client {
	return &Client{
		httpClient:                  &http.Client{Timeout: 10 * time.Second},
		accessTokenEndpoint:         defaultAccessTokenEndpoint,
		refreshTokenEndpoint:        defaultRefreshTokenEndpoint,
		advertiserGetEndpoint:       defaultAdvertiserGetEndpoint,
		ccAdvertiserListEndpoint:    defaultCCAdvertiserListEndpoint,
		majordomoAdvertiserEndpoint: defaultMajordomoAdvertiserEndpoint,
		reportConfigEndpoint:        defaultReportConfigEndpoint,
	}
}

func (c *Client) GetAccessToken(ctx context.Context, req AccessTokenReq) (*TokenData, error) {
	if req.Secret == "" {
		return nil, fmt.Errorf("oceanengine secret is required")
	}
	if req.AuthCode == "" {
		return nil, fmt.Errorf("oceanengine auth_code is required")
	}
	if req.AppID <= 0 {
		return nil, fmt.Errorf("oceanengine app_id is required")
	}

	body, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}

	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, c.accessTokenEndpoint, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("request oceanengine access token failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode < http.StatusOK || resp.StatusCode >= http.StatusMultipleChoices {
		return nil, fmt.Errorf("request oceanengine access token failed: status=%d", resp.StatusCode)
	}

	var result TokenResp
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("decode oceanengine access token response failed: %w", err)
	}
	if result.Code != 0 {
		return nil, fmt.Errorf("oceanengine access token error: code=%d message=%s request_id=%s", result.Code, result.Message, result.RequestID)
	}

	return &result.Data, nil
}

func (c *Client) RefreshToken(ctx context.Context, req RefreshTokenReq) (*TokenData, error) {
	if req.Secret == "" {
		return nil, fmt.Errorf("oceanengine secret is required")
	}
	if req.RefreshToken == "" {
		return nil, fmt.Errorf("oceanengine refresh_token is required")
	}
	if req.AppID <= 0 {
		return nil, fmt.Errorf("oceanengine app_id is required")
	}

	body, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}

	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, c.refreshTokenEndpoint, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("request oceanengine refresh token failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode < http.StatusOK || resp.StatusCode >= http.StatusMultipleChoices {
		return nil, fmt.Errorf("request oceanengine refresh token failed: status=%d", resp.StatusCode)
	}

	var result TokenResp
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("decode oceanengine refresh token response failed: %w", err)
	}
	if result.Code != 0 {
		return nil, fmt.Errorf("oceanengine refresh token error: code=%d message=%s request_id=%s", result.Code, result.Message, result.RequestID)
	}

	return &result.Data, nil
}

func (c *Client) doGet(ctx context.Context, url, accessToken string) ([]byte, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Access-Token", accessToken)

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("oceanengine api request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode < http.StatusOK || resp.StatusCode >= http.StatusMultipleChoices {
		return nil, fmt.Errorf("oceanengine api request failed: status=%d url=%s", resp.StatusCode, url)
	}

	return io.ReadAll(resp.Body)
}

func (c *Client) GetAdvertiser(ctx context.Context, accessToken string) (*AuthorizedAccountData, error) {
	if accessToken == "" {
		return nil, fmt.Errorf("oceanengine access_token is required")
	}

	raw, err := c.doGet(ctx, c.advertiserGetEndpoint, accessToken)
	if err != nil {
		return nil, err
	}

	var result AuthorizedAccountResp
	if err := json.Unmarshal(raw, &result); err != nil {
		return nil, fmt.Errorf("decode oceanengine advertiser response failed: %w", err)
	}
	if result.Code != 0 {
		return nil, fmt.Errorf("oceanengine advertiser error: code=%d message=%s request_id=%s", result.Code, result.Message, result.RequestID)
	}

	return &result.Data, nil
}

func (c *Client) GetAdvertiserListByCCAccount(ctx context.Context, accessToken string, ccAccountID int64) (*CCAdvertiserListData, error) {
	if accessToken == "" {
		return nil, fmt.Errorf("oceanengine access_token is required")
	}
	if ccAccountID <= 0 {
		return nil, fmt.Errorf("oceanengine cc_account_id is required")
	}

	url := fmt.Sprintf("%s?cc_account_id=%d", c.ccAdvertiserListEndpoint, ccAccountID)
	raw, err := c.doGet(ctx, url, accessToken)
	if err != nil {
		return nil, err
	}

	var result CCAdvertiserListResp
	if err := json.Unmarshal(raw, &result); err != nil {
		return nil, fmt.Errorf("decode oceanengine cc advertiser list response failed: %w", err)
	}
	if result.Code != 0 {
		return nil, fmt.Errorf("oceanengine cc advertiser list error: code=%d message=%s request_id=%s", result.Code, result.Message, result.RequestID)
	}

	return &result.Data, nil
}

func (c *Client) GetAdvertiserByAdvertiserID(ctx context.Context, accessToken string, advertiserID int64) (*MajordomoAdvertiserData, error) {
	if accessToken == "" {
		return nil, fmt.Errorf("oceanengine access_token is required")
	}
	if advertiserID <= 0 {
		return nil, fmt.Errorf("oceanengine advertiser_id is required")
	}

	url := fmt.Sprintf("%s?advertiser_id=%d", c.majordomoAdvertiserEndpoint, advertiserID)
	raw, err := c.doGet(ctx, url, accessToken)
	if err != nil {
		return nil, err
	}

	var result MajordomoAdvertiserResp
	if err := json.Unmarshal(raw, &result); err != nil {
		return nil, fmt.Errorf("decode oceanengine majordomo advertiser response failed: %w", err)
	}
	if result.Code != 0 {
		return nil, fmt.Errorf("oceanengine majordomo advertiser error: code=%d message=%s request_id=%s", result.Code, result.Message, result.RequestID)
	}

	return &result.Data, nil
}

func (c *Client) GetReportConfig(ctx context.Context, accessToken string, advertiserID int64, dataTopics []string) (*ReportConfigData, error) {
	if accessToken == "" {
		return nil, fmt.Errorf("oceanengine access_token is required")
	}
	if advertiserID <= 0 {
		return nil, fmt.Errorf("oceanengine advertiser_id is required")
	}

	topics, err := json.Marshal(dataTopics)
	if err != nil {
		return nil, fmt.Errorf("marshal data_topics failed: %w", err)
	}

	url := fmt.Sprintf("%s?advertiser_id=%d&data_topics=%s", c.reportConfigEndpoint, advertiserID, string(topics))
	raw, err := c.doGet(ctx, url, accessToken)
	if err != nil {
		return nil, err
	}

	var result ReportConfigResp
	if err := json.Unmarshal(raw, &result); err != nil {
		return nil, fmt.Errorf("decode oceanengine report config response failed: %w", err)
	}
	if result.Code != 0 {
		return nil, fmt.Errorf("oceanengine report config error: code=%d message=%s request_id=%s", result.Code, result.Message, result.RequestID)
	}

	return &result.Data, nil
}
