package oceanengine

import "net/http"

type Client struct {
	httpClient                  *http.Client
	accessTokenEndpoint         string
	refreshTokenEndpoint        string
	advertiserGetEndpoint       string
	ccAdvertiserListEndpoint    string
	majordomoAdvertiserEndpoint string
	reportConfigEndpoint        string
	customReportEndpoint        string
}

type AccessTokenReq struct {
	Secret   string `json:"secret"`
	AuthCode string `json:"auth_code"`
	AppID    int64  `json:"app_id"`
}

type RefreshTokenReq struct {
	Secret       string `json:"secret"`
	RefreshToken string `json:"refresh_token"`
	AppID        int64  `json:"app_id"`
}

type TokenResp struct {
	Code      int       `json:"code"`
	Message   string    `json:"message"`
	RequestID string    `json:"request_id"`
	Data      TokenData `json:"data"`
}

type TokenData struct {
	AccessToken           string  `json:"access_token"`
	AdvertiserIDs         []int64 `json:"advertiser_ids,omitempty"`
	ExpiresIn             int64   `json:"expires_in"`
	RefreshToken          string  `json:"refresh_token"`
	RefreshTokenExpiresIn int64   `json:"refresh_token_expires_in"`
}

// GetAdvertiser response

type AuthorizedAccountResp struct {
	Code      int                   `json:"code"`
	Message   string                `json:"message"`
	RequestID string                `json:"request_id"`
	Data      AuthorizedAccountData `json:"data"`
}

type AuthorizedAccountData struct {
	List []AuthorizedAccount `json:"list"`
}

type AuthorizedAccount struct {
	AccountID      int64  `json:"account_id"`
	AccountName    string `json:"account_name"`
	AccountRole    string `json:"account_role"`
	AccountType    string `json:"account_type"`
	AdvertiserID   int64  `json:"advertiser_id"`
	AdvertiserName string `json:"advertiser_name"`
	AdvertiserRole int64  `json:"advertiser_role"`
	IsValid        bool   `json:"is_valid"`
}

// GetAdvertiserListByCCAccount response

type CCAdvertiserListResp struct {
	Code      int                  `json:"code"`
	Message   string               `json:"message"`
	RequestID string               `json:"request_id"`
	Data      CCAdvertiserListData `json:"data"`
}

type CCAdvertiserListData struct {
	PageInfo PageInfo       `json:"page_info"`
	List     []CCAdvertiser `json:"list"`
}

type PageInfo struct {
	TotalPage   int64 `json:"total_page"`
	PageSize    int64 `json:"page_size"`
	TotalNumber int64 `json:"total_number"`
	Page        int64 `json:"page"`
}

type CCAdvertiser struct {
	AdvertiserType string `json:"advertiser_type"`
	AdvertiserName string `json:"advertiser_name"`
	AdvertiserID   int64  `json:"advertiser_id"`
}

// GetAdvertiserByAdvertiserID response

type MajordomoAdvertiserResp struct {
	Code      int                     `json:"code"`
	Message   string                  `json:"message"`
	RequestID string                  `json:"request_id"`
	Data      MajordomoAdvertiserData `json:"data"`
}

type MajordomoAdvertiserData struct {
	List []MajordomoAdvertiser `json:"list"`
}

type MajordomoAdvertiser struct {
	AdvertiserID   int64  `json:"advertiser_id"`
	AdvertiserName string `json:"advertiser_name"`
}

// GetReportConfig response

type ReportConfigResp struct {
	Code      int              `json:"code"`
	Message   string           `json:"message"`
	RequestID string           `json:"request_id"`
	Data      ReportConfigData `json:"data"`
}

type ReportConfigData struct {
	List []ReportConfigItem `json:"list"`
}

type ReportConfigItem struct {
	DataTopic  string            `json:"data_topic"`
	Dimensions []ReportDimension `json:"dimensions"`
	Metrics    []ReportMetric    `json:"metrics"`
}

type ReportDimension struct {
	Description  string           `json:"description"`
	Field        string           `json:"field"`
	FilterAble   bool             `json:"filter_able"`
	FilterConfig *DimensionFilter `json:"filter_config,omitempty"`
	Name         string           `json:"name"`
	SortAble     bool             `json:"sort_able"`
}

type DimensionFilter struct {
	Operator   int            `json:"operator"`
	RangeValue []FilterOption `json:"range_value,omitempty"`
	Type       int            `json:"type"`
	ValueLimit int            `json:"value_limit"`
}

type FilterOption struct {
	Label string `json:"label"`
	Value string `json:"value"`
}

type ReportMetric struct {
	Description   string   `json:"description"`
	ExclusionDims []string `json:"exclusion_dims,omitempty"`
	Field         string   `json:"field"`
	Name          string   `json:"name"`
}

type PullOceanengineDataPayload struct {
	StartTime      string `json:"start_time"`
	EndTime        string `json:"end_time"`
	StartTimeCamel string `json:"startTime"`
	EndTimeCamel   string `json:"endTime"`
}

type PullOceanengineDataParams struct {
	AccessToken  string
	AdvertiserID int64
	StartTime    string
	EndTime      string
	PageSize     int64
}

type CustomReportReq struct {
	AdvertiserID int64    `json:"advertiser_id"`
	Dimensions   []string `json:"dimensions"`
	Metrics      []string `json:"metrics"`
	Filters      []any    `json:"filters"`
	StartTime    string   `json:"start_time"`
	EndTime      string   `json:"end_time"`
	OrderBy      []any    `json:"order_by"`
	Page         int64    `json:"page"`
	PageSize     int64    `json:"page_size"`
}

type CustomReportResp struct {
	Code      int              `json:"code"`
	Message   string           `json:"message"`
	RequestID string           `json:"request_id"`
	Data      CustomReportData `json:"data"`
}

type CustomReportData struct {
	PageInfo     PageInfo          `json:"page_info"`
	Rows         []CustomReportRow `json:"rows"`
	TotalMetrics map[string]string `json:"total_metrics"`
}

type CustomReportRow struct {
	Dimensions map[string]string `json:"dimensions"`
	Metrics    map[string]string `json:"metrics"`
}

var OceanengineDailySummaryMetrics = []string{
	"show_cnt",
	"stat_cost",
	"cpm_platform",
	"click_cnt",
	"ctr",
	"active",
	"active_cost",
	"active_register",
	"active_pay_cost",
	"active_pay",
	"active_pay_rate",
	"attribution_convert_cost",
	"attribution_conversion_rate",
	"attribution_billing_game_in_app_roi_1day",
	"attribution_billing_game_in_app_roi_2days",
	"attribution_billing_game_in_app_roi_3days",
	"attribution_billing_game_in_app_roi_4days",
	"attribution_billing_game_in_app_roi_5days",
	"attribution_billing_game_in_app_roi_6days",
	"attribution_billing_game_in_app_roi_7days",
	"attribution_next_day_open_cnt",
	"attribution_next_day_open_rate",
	"attribution_retention_2d_cnt",
	"attribution_retention_2d_rate",
	"attribution_retention_3d_cnt",
	"attribution_retention_3d_rate",
	"attribution_retention_4d_cnt",
	"attribution_retention_4d_rate",
	"attribution_retention_5d_cnt",
	"attribution_retention_5d_rate",
	"attribution_retention_6d_cnt",
	"attribution_retention_6d_rate",
	"attribution_retention_7d_cnt",
	"attribution_retention_7d_rate",
	"attribution_game_pay_7d_cost",
	"attribution_micro_game_0d_ltv",
	"attribution_micro_game_3d_ltv",
	"attribution_micro_game_7d_ltv",
	"attribution_micro_game_0d_roi",
	"attribution_micro_game_3d_roi",
	"attribution_micro_game_7d_roi",
	"attribution_micro_game_iaap_ltv_7d_roi",
	"attribution_micro_game_iaap_iap_roi_8days",
	"attribution_micro_game_iaap_iaa_7d_roi",
}

var OnlyDailyDimensions = []string{
	"stat_time_day",
}
