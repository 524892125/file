package oceanengine

import "net/http"

type Client struct {
	httpClient                  *http.Client
	accessTokenEndpoint         string
	refreshTokenEndpoint        string
	advertiserGetEndpoint       string
	ccAdvertiserListEndpoint    string
	majordomoAdvertiserEndpoint string
	reportConfigEndpoint        string
}

type AccessTokenReq struct {
	Secret   string `json:"secret"`
	AuthCode string `json:"auth_code"`
	AppID    int64  `json:"app_id"`
}

type RefreshTokenReq struct {
	Secret       string `json:"secret"`
	RefreshToken string `json:"refresh_token"`
	AppID        int64  `json:"app_id"`
}

type TokenResp struct {
	Code      int       `json:"code"`
	Message   string    `json:"message"`
	RequestID string    `json:"request_id"`
	Data      TokenData `json:"data"`
}

type TokenData struct {
	AccessToken           string  `json:"access_token"`
	AdvertiserIDs         []int64 `json:"advertiser_ids,omitempty"`
	ExpiresIn             int64   `json:"expires_in"`
	RefreshToken          string  `json:"refresh_token"`
	RefreshTokenExpiresIn int64   `json:"refresh_token_expires_in"`
}

// GetAdvertiser response

type AuthorizedAccountResp struct {
	Code      int                   `json:"code"`
	Message   string                `json:"message"`
	RequestID string                `json:"request_id"`
	Data      AuthorizedAccountData `json:"data"`
}

type AuthorizedAccountData struct {
	List []AuthorizedAccount `json:"list"`
}

type AuthorizedAccount struct {
	AccountID      int64  `json:"account_id"`
	AccountName    string `json:"account_name"`
	AccountRole    string `json:"account_role"`
	AccountType    string `json:"account_type"`
	AdvertiserID   int64  `json:"advertiser_id"`
	AdvertiserName string `json:"advertiser_name"`
	AdvertiserRole int64  `json:"advertiser_role"`
	IsValid        bool   `json:"is_valid"`
}

// GetAdvertiserListByCCAccount response

type CCAdvertiserListResp struct {
	Code      int                  `json:"code"`
	Message   string               `json:"message"`
	RequestID string               `json:"request_id"`
	Data      CCAdvertiserListData `json:"data"`
}

type CCAdvertiserListData struct {
	PageInfo PageInfo       `json:"page_info"`
	List     []CCAdvertiser `json:"list"`
}

type PageInfo struct {
	TotalPage   int64 `json:"total_page"`
	PageSize    int64 `json:"page_size"`
	TotalNumber int64 `json:"total_number"`
	Page        int64 `json:"page"`
}

type CCAdvertiser struct {
	AdvertiserType string `json:"advertiser_type"`
	AdvertiserName string `json:"advertiser_name"`
	AdvertiserID   int64  `json:"advertiser_id"`
}

// GetAdvertiserByAdvertiserID response

type MajordomoAdvertiserResp struct {
	Code      int                    `json:"code"`
	Message   string                 `json:"message"`
	RequestID string                 `json:"request_id"`
	Data      MajordomoAdvertiserData `json:"data"`
}

type MajordomoAdvertiserData struct {
	List []MajordomoAdvertiser `json:"list"`
}

type MajordomoAdvertiser struct {
	AdvertiserID   int64  `json:"advertiser_id"`
	AdvertiserName string `json:"advertiser_name"`
}

// GetReportConfig response

type ReportConfigResp struct {
	Code      int              `json:"code"`
	Message   string           `json:"message"`
	RequestID string           `json:"request_id"`
	Data      ReportConfigData `json:"data"`
}

type ReportConfigData struct {
	List []ReportConfigItem `json:"list"`
}

type ReportConfigItem struct {
	DataTopic  string              `json:"data_topic"`
	Dimensions []ReportDimension   `json:"dimensions"`
	Metrics    []ReportMetric      `json:"metrics"`
}

type ReportDimension struct {
	Description  string           `json:"description"`
	Field        string           `json:"field"`
	FilterAble   bool             `json:"filter_able"`
	FilterConfig *DimensionFilter `json:"filter_config,omitempty"`
	Name         string           `json:"name"`
	SortAble     bool             `json:"sort_able"`
}

type DimensionFilter struct {
	Operator   int                `json:"operator"`
	RangeValue []FilterOption     `json:"range_value,omitempty"`
	Type       int                `json:"type"`
	ValueLimit int                `json:"value_limit"`
}

type FilterOption struct {
	Label string `json:"label"`
	Value string `json:"value"`
}

type ReportMetric struct {
	Description   string   `json:"description"`
	ExclusionDims []string `json:"exclusion_dims,omitempty"`
	Field         string   `json:"field"`
	Name          string   `json:"name"`
}
