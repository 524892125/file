package svc

import (
	"civet/apps/kbrelease/model"
	"civet/apps/kbrelease/rpc/internal/config"
	"civet/apps/kbrelease/rpc/internal/oceanengine"
	"civet/apps/kbrelease/rpc/internal/wechat"

	_ "github.com/lib/pq"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

type ServiceContext struct {
	Config            config.Config
	WechatClient      *wechat.Client
	OceanengineClient *oceanengine.Client
	// Code generated rpc model fields. DO NOT EDIT.
	AdvertiserTokensModel           model.AdvertiserTokensModel
	OceanengineDailyBaseModel       model.OceanengineDailyBaseModel
	OceanengineDailyConversionModel model.OceanengineDailyConversionModel
	OceanengineDailyLtvModel        model.OceanengineDailyLtvModel
	OceanengineDailyOtherModel      model.OceanengineDailyOtherModel
	OceanengineDailySummaryModel    model.OceanengineDailySummaryModel
	SummaryDataModel                model.SummaryDataModel
	WechatDailyDataModel            model.WechatDailyDataModel
	WechatRawDataModel              model.WechatRawDataModel
	// End generated rpc model fields.
}

func NewServiceContext(c config.Config) *ServiceContext {
	conn := sqlx.NewSqlConn(c.Pg.DriverName, c.Pg.DataSource)

	return &ServiceContext{
		Config:            c,
		WechatClient:      wechat.NewClient(),
		OceanengineClient: oceanengine.NewClient(),
		// Code generated rpc model init. DO NOT EDIT.
		AdvertiserTokensModel:           model.NewAdvertiserTokensModel(conn),
		OceanengineDailyBaseModel:       model.NewOceanengineDailyBaseModel(conn),
		OceanengineDailyConversionModel: model.NewOceanengineDailyConversionModel(conn),
		OceanengineDailyLtvModel:        model.NewOceanengineDailyLtvModel(conn),
		OceanengineDailyOtherModel:      model.NewOceanengineDailyOtherModel(conn),
		OceanengineDailySummaryModel:    model.NewOceanengineDailySummaryModel(conn),
		SummaryDataModel:                model.NewSummaryDataModel(conn),
		WechatDailyDataModel:            model.NewWechatDailyDataModel(conn),
		WechatRawDataModel:              model.NewWechatRawDataModel(conn),
		// End generated rpc model init.
	}
}
