package svc

import (
	"civet/apps/kbrelease/model"
	"civet/apps/kbrelease/rpc/internal/config"
	"civet/apps/kbrelease/rpc/internal/wechat"

	_ "github.com/lib/pq"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

type ServiceContext struct {
	Config       config.Config
	WechatClient *wechat.Client
	// Code generated rpc model fields. DO NOT EDIT.
	SummaryDataModel     model.SummaryDataModel
	WechatDailyDataModel model.WechatDailyDataModel
	// End generated rpc model fields.
}

func NewServiceContext(c config.Config) *ServiceContext {
	conn := sqlx.NewSqlConn(c.Pg.DriverName, c.Pg.DataSource)

	return &ServiceContext{
		Config:       c,
		WechatClient: wechat.NewClient(),
		// Code generated rpc model init. DO NOT EDIT.
		SummaryDataModel:     model.NewSummaryDataModel(conn),
		WechatDailyDataModel: model.NewWechatDailyDataModel(conn),
		// End generated rpc model init.
	}
}
