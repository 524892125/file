package logic

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"civet/apps/kbrelease/model"
	"civet/apps/kbrelease/rpc/internal/oceanengine"
	"civet/apps/kbrelease/rpc/internal/svc"
	"civet/apps/kbrelease/rpc/kbrelease"

	"github.com/zeromicro/go-zero/core/logx"
)

const (
	oceanengineDateLayout              = "2006-01-02"
	defaultOceanenginePullAdvertiserID = int64(1845471174234451)
	defaultOceanenginePullPageSize     = int64(100)
)

func NewRpcPullOceanengineDataLogic(ctx context.Context, svcCtx *svc.ServiceContext) *RpcPullOceanengineDataLogic {
	return &RpcPullOceanengineDataLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *RpcPullOceanengineDataLogic) RpcPullOceanengineData(in *kbrelease.PullOceanengineDataReq) (*kbrelease.PullOceanengineDataResp, error) {
	params, err := l.parseOceanenginePullParams(in.GetPayload())
	if err != nil {
		return nil, err
	}

	go l.runOceanengineDailySummaryPull(context.Background(), params)

	return &kbrelease.PullOceanengineDataResp{
		Message: "oceanengine daily summary pull started",
	}, nil
}

func (l *RpcPullOceanengineDataLogic) parseOceanenginePullParams(raw string) (oceanengine.PullOceanengineDataParams, error) {
	payload, err := parseOceanenginePullPayload(raw)
	if err != nil {
		return oceanengine.PullOceanengineDataParams{}, err
	}

	accessToken, err := l.findOceanengineAccessToken()
	if err != nil {
		return oceanengine.PullOceanengineDataParams{}, err
	}
	startTime := normalizedOceanenginePayloadTime(payload.StartTime, payload.StartTimeCamel)
	endTime := normalizedOceanenginePayloadTime(payload.EndTime, payload.EndTimeCamel)

	params := oceanengine.PullOceanengineDataParams{
		AccessToken:  accessToken,
		AdvertiserID: defaultOceanenginePullAdvertiserID,
		StartTime:    startTime,
		EndTime:      endTime,
		PageSize:     defaultOceanenginePullPageSize,
	}
	if params.StartTime == "" || params.EndTime == "" {
		return oceanengine.PullOceanengineDataParams{}, fmt.Errorf("oceanengine start_time and end_time are required")
	}
	return params, nil
}

func (l *RpcPullOceanengineDataLogic) findOceanengineAccessToken() (string, error) {
	tokens, _, err := l.svcCtx.AdvertiserTokensModel.FindPageByFields(l.ctx, 1, 1, nil)
	if err != nil {
		return "", fmt.Errorf("query advertiser tokens failed: %w", err)
	}
	if len(tokens) == 0 || strings.TrimSpace(tokens[0].AccessToken) == "" {
		return "", fmt.Errorf("oceanengine access_token is required")
	}
	return strings.TrimSpace(tokens[0].AccessToken), nil
}

func normalizedOceanenginePayloadTime(snakeCase, camelCase string) string {
	if strings.TrimSpace(snakeCase) != "" {
		return strings.TrimSpace(snakeCase)
	}
	return strings.TrimSpace(camelCase)
}

func parseOceanenginePullPayload(raw string) (oceanengine.PullOceanengineDataPayload, error) {
	defaultDate := defaultOceanenginePullDate()
	if raw == "" {
		return oceanengine.PullOceanengineDataPayload{
			StartTime: defaultDate,
			EndTime:   defaultDate,
		}, nil
	}
	var payload oceanengine.PullOceanengineDataPayload
	if err := json.Unmarshal([]byte(raw), &payload); err != nil {
		return oceanengine.PullOceanengineDataPayload{}, fmt.Errorf("decode oceanengine pull payload failed: %w", err)
	}
	if normalizedOceanenginePayloadTime(payload.StartTime, payload.StartTimeCamel) == "" {
		payload.StartTime = defaultDate
	}
	if normalizedOceanenginePayloadTime(payload.EndTime, payload.EndTimeCamel) == "" {
		payload.EndTime = defaultDate
	}
	return payload, nil
}

func defaultOceanenginePullDate() string {
	return time.Now().AddDate(0, 0, -1).Format(oceanengineDateLayout)
}

func (l *RpcPullOceanengineDataLogic) runOceanengineDailySummaryPull(ctx context.Context, params oceanengine.PullOceanengineDataParams) {
	defer func() {
		if recovered := recover(); recovered != nil {
			l.Errorf("oceanengine daily summary pull panic: %v", recovered)
		}
	}()

	accounts, err := l.svcCtx.OceanengineClient.GetAdvertiserByAdvertiserID(ctx, params.AccessToken, params.AdvertiserID)
	if err != nil {
		l.Errorf("get oceanengine majordomo advertisers failed: advertiser_id=%d err=%v", params.AdvertiserID, err)
		return
	}
	l.Infof("get oceanengine majordomo advertisers done: advertiser_id=%d count=%d", params.AdvertiserID, len(accounts.List))

	var advertiserCount int64
	var savedRows int64
	for _, advertiser := range accounts.List {
		if advertiser.AdvertiserID <= 0 {
			continue
		}

		rows, err := l.pullAndSaveDailySummary(ctx, params, advertiser.AdvertiserID)
		if err != nil {
			l.Errorf("pull oceanengine daily summary failed: advertiser_id=%d advertiser_name=%s err=%v", advertiser.AdvertiserID, advertiser.AdvertiserName, err)
			continue
		}

		l.Infof("pull oceanengine daily summary done: advertiser_id=%d advertiser_name=%s rows=%d", advertiser.AdvertiserID, advertiser.AdvertiserName, rows)
		advertiserCount++
		savedRows += rows
	}

	l.Infof("oceanengine daily summary pull finished: advertisers=%d summary_rows=%d start_time=%s end_time=%s", advertiserCount, savedRows, params.StartTime, params.EndTime)
}

func (l *RpcPullOceanengineDataLogic) pullAndSaveDailySummary(ctx context.Context, params oceanengine.PullOceanengineDataParams, advertiserID int64) (int64, error) {
	var savedRows int64
	for page := int64(1); ; page++ {
		data, err := l.svcCtx.OceanengineClient.GetCustomReport(ctx, params.AccessToken, oceanengine.CustomReportReq{
			AdvertiserID: advertiserID,
			Dimensions:   oceanengine.OnlyDailyDimensions,
			Metrics:      oceanengine.OceanengineDailySummaryMetrics,
			Filters:      []any{},
			StartTime:    params.StartTime,
			EndTime:      params.EndTime,
			OrderBy:      []any{},
			Page:         page,
			PageSize:     params.PageSize,
		})
		if err != nil {
			return savedRows, err
		}

		for _, row := range data.Rows {
			record, err := reportRowToDailySummary(advertiserID, row)
			if err != nil {
				return savedRows, err
			}
			if err := l.svcCtx.OceanengineDailySummaryModel.UpsertByAdvertiserDate(ctx, record); err != nil {
				return savedRows, err
			}
			savedRows++
		}

		totalPage := data.PageInfo.TotalPage
		if totalPage <= 0 || page >= totalPage {
			break
		}
	}
	return savedRows, nil
}

func reportRowToDailySummary(advertiserID int64, row oceanengine.CustomReportRow) (*model.OceanengineDailySummary, error) {
	refDate, err := parseOceanengineDate(row.Dimensions["stat_time_day"])
	if err != nil {
		return nil, err
	}
	now := time.Now()
	metrics := row.Metrics
	return &model.OceanengineDailySummary{
		AdvertiserId:                        advertiserID,
		RefDate:                             refDate,
		StatCost:                            parseFloat(metrics["stat_cost"]),
		ShowCnt:                             parseInt64(metrics["show_cnt"]),
		CpmPlatform:                         parseFloat(metrics["cpm_platform"]),
		ClickCnt:                            parseInt64(metrics["click_cnt"]),
		Ctr:                                 parseFloat(metrics["ctr"]),
		Active:                              parseInt64(metrics["active"]),
		ActiveCost:                          parseFloat(metrics["active_cost"]),
		ActiveRegister:                      parseInt64(metrics["active_register"]),
		ActivePay:                           parseInt64(metrics["active_pay"]),
		ActivePayCost:                       parseFloat(metrics["active_pay_cost"]),
		ActivePayRate:                       parseFloat(metrics["active_pay_rate"]),
		AttributionConvertCost:              parseFloat(metrics["attribution_convert_cost"]),
		AttributionConversionRate:           parseFloat(metrics["attribution_conversion_rate"]),
		AttributionBillingGameInAppRoi1Day:  parseFloat(metrics["attribution_billing_game_in_app_roi_1day"]),
		AttributionBillingGameInAppRoi2Days: parseFloat(metrics["attribution_billing_game_in_app_roi_2days"]),
		AttributionBillingGameInAppRoi3Days: parseFloat(metrics["attribution_billing_game_in_app_roi_3days"]),
		AttributionBillingGameInAppRoi4Days: parseFloat(metrics["attribution_billing_game_in_app_roi_4days"]),
		AttributionBillingGameInAppRoi5Days: parseFloat(metrics["attribution_billing_game_in_app_roi_5days"]),
		AttributionBillingGameInAppRoi6Days: parseFloat(metrics["attribution_billing_game_in_app_roi_6days"]),
		AttributionBillingGameInAppRoi7Days: parseFloat(metrics["attribution_billing_game_in_app_roi_7days"]),
		AttributionNextDayOpenCnt:           parseInt64(metrics["attribution_next_day_open_cnt"]),
		AttributionNextDayOpenRate:          parseFloat(metrics["attribution_next_day_open_rate"]),
		AttributionRetention2DCnt:           parseInt64(metrics["attribution_retention_2d_cnt"]),
		AttributionRetention2DRate:          parseFloat(metrics["attribution_retention_2d_rate"]),
		AttributionRetention3DCnt:           parseInt64(metrics["attribution_retention_3d_cnt"]),
		AttributionRetention3DRate:          parseFloat(metrics["attribution_retention_3d_rate"]),
		AttributionRetention4DCnt:           parseInt64(metrics["attribution_retention_4d_cnt"]),
		AttributionRetention4DRate:          parseFloat(metrics["attribution_retention_4d_rate"]),
		AttributionRetention5DCnt:           parseInt64(metrics["attribution_retention_5d_cnt"]),
		AttributionRetention5DRate:          parseFloat(metrics["attribution_retention_5d_rate"]),
		AttributionRetention6DCnt:           parseInt64(metrics["attribution_retention_6d_cnt"]),
		AttributionRetention6DRate:          parseFloat(metrics["attribution_retention_6d_rate"]),
		AttributionRetention7DCnt:           parseInt64(metrics["attribution_retention_7d_cnt"]),
		AttributionRetention7DRate:          parseFloat(metrics["attribution_retention_7d_rate"]),
		AttributionGamePay7DCost:            parseFloat(metrics["attribution_game_pay_7d_cost"]),
		AttributionMicroGame0DLtv:           parseFloat(metrics["attribution_micro_game_0d_ltv"]),
		AttributionMicroGame3DLtv:           parseFloat(metrics["attribution_micro_game_3d_ltv"]),
		AttributionMicroGame7DLtv:           parseFloat(metrics["attribution_micro_game_7d_ltv"]),
		AttributionMicroGame0DRoi:           parseFloat(metrics["attribution_micro_game_0d_roi"]),
		AttributionMicroGame3DRoi:           parseFloat(metrics["attribution_micro_game_3d_roi"]),
		AttributionMicroGame7DRoi:           parseFloat(metrics["attribution_micro_game_7d_roi"]),
		AttributionMicroGameIaapLtv7DRoi:    parseFloat(metrics["attribution_micro_game_iaap_ltv_7d_roi"]),
		AttributionMicroGameIaapIapRoi8Days: parseFloat(metrics["attribution_micro_game_iaap_iap_roi_8days"]),
		AttributionMicroGameIaapIaa7DRoi:    parseFloat(metrics["attribution_micro_game_iaap_iaa_7d_roi"]),
		CreatedAt:                           now,
		UpdatedAt:                           now,
	}, nil
}

func parseOceanengineDate(value string) (time.Time, error) {
	if value == "" {
		return time.Time{}, fmt.Errorf("stat_time_day is required")
	}
	if t, err := time.Parse(oceanengineDateLayout, value); err == nil {
		return t, nil
	}
	if t, err := time.Parse(time.DateTime, value); err == nil {
		return t, nil
	}
	return time.Time{}, fmt.Errorf("invalid oceanengine date: %s", value)
}

func parseFloat(value string) float64 {
	if value == "" {
		return 0
	}
	parsed, err := strconv.ParseFloat(value, 64)
	if err != nil {
		return 0
	}
	return parsed
}

func parseInt64(value string) int64 {
	if value == "" {
		return 0
	}
	parsed, err := strconv.ParseFloat(value, 64)
	if err != nil {
		return 0
	}
	return int64(parsed)
}
