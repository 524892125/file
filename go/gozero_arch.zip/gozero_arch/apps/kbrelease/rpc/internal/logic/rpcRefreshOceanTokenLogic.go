package logic

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"civet/apps/kbrelease/rpc/internal/oceanengine"
	"civet/apps/kbrelease/rpc/internal/svc"
	"civet/apps/kbrelease/rpc/kbrelease"

	"github.com/zeromicro/go-zero/core/logx"
)

type RpcRefreshOceanTokenLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewRpcRefreshOceanTokenLogic(ctx context.Context, svcCtx *svc.ServiceContext) *RpcRefreshOceanTokenLogic {
	return &RpcRefreshOceanTokenLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

type refreshOceanTokenPayload struct {
	AppID  int64  `json:"app_id"`
	Secret string `json:"secret"`
}

func (l *RpcRefreshOceanTokenLogic) RpcRefreshOceanToken(in *kbrelease.RefreshOceanTokenReq) (*kbrelease.RefreshOceanTokenResp, error) {
	var payload refreshOceanTokenPayload
	payload.AppID = 1863139790999562
	payload.Secret = "9c58ee638a7a3d61117a78958557978faa2e2e90"

	// logx.Infof("ininin %#v", in)
	// if err := json.Unmarshal([]byte(in.Payload), &payload); err != nil {
	// 	return nil, fmt.Errorf("invalid payload: %w", err)
	// }
	// if payload.AppID <= 0 {
	// 	return nil, fmt.Errorf("app_id is required")
	// }
	// if payload.Secret == "" {
	// 	return nil, fmt.Errorf("secret is required")
	// }

	tokens, _, err := l.svcCtx.AdvertiserTokensModel.FindPageByFields(l.ctx, 1, 100, nil)
	if err != nil {
		return nil, fmt.Errorf("query advertiser tokens failed: %w", err)
	}
	if len(tokens) == 0 {
		return &kbrelease.RefreshOceanTokenResp{Message: "no tokens to refresh"}, nil
	}

	refreshed := 0
	for _, token := range tokens {
		data, err := l.svcCtx.OceanengineClient.RefreshToken(l.ctx, oceanengine.RefreshTokenReq{
			AppID:        payload.AppID,
			Secret:       payload.Secret,
			RefreshToken: token.RefreshToken,
		})
		if err != nil {
			l.Errorf("refresh ocean token id=%d failed: %v", token.Id, err)
			continue
		}

		now := time.Now()
		token.AccessToken = data.AccessToken
		token.RefreshToken = data.RefreshToken
		token.ExpiresIn = data.ExpiresIn
		token.RefreshTokenExpiresIn = data.RefreshTokenExpiresIn
		token.AccessTokenExpiresAt = sql.NullTime{
			Time:  now.Add(time.Duration(data.ExpiresIn) * time.Second),
			Valid: true,
		}
		token.RefreshTokenExpiresAt = sql.NullTime{
			Time:  now.Add(time.Duration(data.RefreshTokenExpiresIn) * time.Second),
			Valid: true,
		}
		token.UpdatedAt = now

		if err := l.svcCtx.AdvertiserTokensModel.Update(l.ctx, token); err != nil {
			l.Errorf("update ocean token id=%d failed: %v", token.Id, err)
			continue
		}
		refreshed++
	}

	return &kbrelease.RefreshOceanTokenResp{
		Message: fmt.Sprintf("refreshed %d/%d tokens", refreshed, len(tokens)),
	}, nil
}
