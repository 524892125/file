package logic

import (
	"context"

	"civet/apps/kbrelease/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type RpcPullOceanengineDataLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}
