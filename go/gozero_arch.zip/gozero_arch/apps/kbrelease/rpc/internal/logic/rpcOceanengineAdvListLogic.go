package logic

import (
	"context"
	"fmt"

	"civet/apps/kbrelease/rpc/internal/svc"
	"civet/apps/kbrelease/rpc/kbrelease"

	"github.com/zeromicro/go-zero/core/logx"
)

type RpcOceanengineAdvListLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

const defaultOceanengineMajordomoAdvertiserID int64 = 1845471174234451

func NewRpcOceanengineAdvListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *RpcOceanengineAdvListLogic {
	return &RpcOceanengineAdvListLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *RpcOceanengineAdvListLogic) RpcOceanengineAdvList(in *kbrelease.OceanengineAdvertiserListReq) (*kbrelease.OceanengineAdvertiserListResp, error) {
	advertiserID := in.GetAdvertiserId()
	if advertiserID <= 0 {
		advertiserID = defaultOceanengineMajordomoAdvertiserID
	}

	accessToken, err := l.findOceanengineAccessToken()
	if err != nil {
		return nil, err
	}

	data, err := l.svcCtx.OceanengineClient.GetAdvertiserByAdvertiserID(l.ctx, accessToken, advertiserID)
	if err != nil {
		return nil, fmt.Errorf("get oceanengine majordomo advertisers failed: advertiser_id=%d: %w", advertiserID, err)
	}

	list := make([]*kbrelease.OceanengineAdvertiser, 0, len(data.List))
	for _, advertiser := range data.List {
		if advertiser.AdvertiserID <= 0 {
			continue
		}
		list = append(list, &kbrelease.OceanengineAdvertiser{
			AdvertiserId:   advertiser.AdvertiserID,
			AdvertiserName: advertiser.AdvertiserName,
		})
	}

	return &kbrelease.OceanengineAdvertiserListResp{
		List: list,
	}, nil
}

func (l *RpcOceanengineAdvListLogic) findOceanengineAccessToken() (string, error) {
	tokens, _, err := l.svcCtx.AdvertiserTokensModel.FindPageByFields(l.ctx, 1, 1, nil)
	if err != nil {
		return "", fmt.Errorf("query advertiser tokens failed: %w", err)
	}
	if len(tokens) == 0 || tokens[0].AccessToken == "" {
		return "", fmt.Errorf("oceanengine access_token is required")
	}
	return tokens[0].AccessToken, nil
}
