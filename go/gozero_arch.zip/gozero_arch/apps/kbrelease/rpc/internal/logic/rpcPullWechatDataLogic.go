package logic

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"civet/apps/kbrelease/model"
	"civet/apps/kbrelease/rpc/internal/svc"
	"civet/apps/kbrelease/rpc/internal/wechat"
	"civet/apps/kbrelease/rpc/kbrelease"

	"github.com/zeromicro/go-zero/core/logx"
)

type RpcPullWechatDataLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewRpcPullWechatDataLogic(ctx context.Context, svcCtx *svc.ServiceContext) *RpcPullWechatDataLogic {
	return &RpcPullWechatDataLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *RpcPullWechatDataLogic) RpcPullWechatData(in *kbrelease.PullWechatDataReq) (*kbrelease.PullWechatDataResp, error) {
	appId := "wxcb9e812f3773d4fb"
	secret := "6ac41274713e2e7effcfa374c928e7ae"
	if in != nil && strings.TrimSpace(in.Payload) != "" {
		payload, err := parseWechatPayload(in.Payload)
		if err != nil {
			return nil, err
		}
		if payload.AppID != "" {
			appId = payload.AppID
		}
		if payload.Secret != "" {
			secret = payload.Secret
		}
	}

	accessToken, err := l.svcCtx.WechatClient.GetAccessToken(l.ctx, appId, secret)
	if err != nil {
		return nil, err
	}
	l.Infof("wechat access token fetched: appid=%s expires_in=%d token_len=%d", appId, accessToken.ExpiresIn, len(accessToken.Token))

	saved, err := l.pullAndSaveWechatDailyMetrics(appId, accessToken.Token)
	if err != nil {
		return nil, err
	}

	return &kbrelease.PullWechatDataResp{
		Message: fmt.Sprintf("wechat metrics saved: count=%d", saved),
	}, nil
}

type wechatMetricSpec struct {
	Metric    string
	ColumnKey string
}

var wechatDailyMetricSpecs = []wechatMetricSpec{
	{Metric: "1000001:5", ColumnKey: "dau"},
	{Metric: "1000011:3", ColumnKey: "new_users"},
	{Metric: "1000001:6", ColumnKey: "total_users_sum"},
	{Metric: "1000170:5", ColumnKey: "rev_traffic_owner"},
	{Metric: "1000022:3", ColumnKey: "rev_internal_purchase"},
	{Metric: "1000023:4", ColumnKey: "rev_commission"},
}

const (
	wechatDailyMetricsGranularity = int64(24)
	wechatDailyMetricsStartTime   = int64(1774972800)
	wechatDailyMetricsEndTime     = int64(1775059200)
)

func parseWechatPayload(payload string) (wechat.WechatPayload, error) {
	var data wechat.WechatPayload
	if err := json.Unmarshal([]byte(payload), &data); err != nil {
		return wechat.WechatPayload{}, fmt.Errorf("invalid wechat payload: %w", err)
	}
	data.AppID = strings.TrimSpace(data.AppID)
	data.Secret = strings.TrimSpace(data.Secret)
	return data, nil
}

func (l *RpcPullWechatDataLogic) pullAndSaveWechatDailyMetrics(appID, accessToken string) (int, error) {
	beijing := time.FixedZone("CST", 8*60*60)
	startAt := time.Unix(wechatDailyMetricsStartTime, 0).In(beijing)
	refDate := time.Date(startAt.Year(), startAt.Month(), startAt.Day(), 0, 0, 0, 0, beijing)
	saved := 0
	for index, spec := range wechatDailyMetricSpecs {
		if index > 0 {
			if err := sleepWithContext(l.ctx, 5*time.Second); err != nil {
				return saved, err
			}
		}

		resp, err := l.svcCtx.WechatClient.GetGameAnalysisData(l.ctx, accessToken, wechat.GameAnalysisDataReq{
			Metric:      spec.Metric,
			Granularity: wechatDailyMetricsGranularity,
			StartTime:   wechatDailyMetricsStartTime,
			EndTime:     wechatDailyMetricsEndTime,
			// FilterList:  []wechat.GameAnalysisFilter{
			// 	// {Dimension: "3", Value: "1"},
			// },
		})
		if err != nil {
			return saved, fmt.Errorf("pull wechat metric %s failed: %w", spec.Metric, err)
		}

		baseData, err := json.Marshal(resp.Raw)
		if err != nil {
			return saved, fmt.Errorf("marshal wechat metric %s raw data failed: %w", spec.Metric, err)
		}
		metricValue := extractWechatMetricValue(resp)
		now := time.Now()
		if err := l.svcCtx.WechatDailyDataModel.UpsertByAppIDRefDateColumnKey(l.ctx, &model.WechatDailyData{
			Appid:     appID,
			Metric:    sql.NullString{String: spec.Metric, Valid: true},
			ColumnKey: spec.ColumnKey,
			RefDate:   refDate,
			Num:       sql.NullInt64{Int64: metricValue, Valid: true},
			BaseData:  sql.NullString{String: string(baseData), Valid: true},
			CreatedAt: now,
			UpdatedAt: now,
		}); err != nil {
			return saved, fmt.Errorf("save wechat metric %s failed: %w", spec.Metric, err)
		}
		err = insertSummaryData(spec, appID, refDate, now, metricValue, l)
		if err != nil {
			return saved, fmt.Errorf("save summary data %s raw data failed: %w", spec.Metric, err)
		}
		saved++
	}
	return saved, nil
}

func insertSummaryData(spec wechatMetricSpec, appID string, refDate time.Time, now time.Time, metricValue int64, l *RpcPullWechatDataLogic) error {
	summaryData := &model.SummaryData{
		Appid:     appID,
		RefDate:   refDate,
		CreatedAt: now,
		UpdatedAt: now,
	}
	switch spec.ColumnKey {
	case "dau":
		summaryData.Dau = metricValue
	case "new_users":
		summaryData.NewUsers = metricValue
	case "total_users_sum":
		summaryData.TotalUsersSum = sql.NullInt64{Int64: metricValue, Valid: true}
	case "rev_traffic_owner":
		summaryData.RevTrafficOwner = float64(metricValue)
	case "rev_internal_purchase":
		summaryData.RevInternalPurchase = float64(metricValue)
	case "rev_commission":
		summaryData.RevCommission = float64(metricValue)
	default:
		return fmt.Errorf("unsupported summary metric column_key: %s", spec.ColumnKey)
	}

	if err := l.svcCtx.SummaryDataModel.UpsertMetricByAppIDRefDate(l.ctx, summaryData, spec.ColumnKey); err != nil {
		return fmt.Errorf("save summary data %s failed: %w", spec.Metric, err)
	}
	return nil
}

func sleepWithContext(ctx context.Context, duration time.Duration) error {
	timer := time.NewTimer(duration)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-timer.C:
		return nil
	}
}

func metricToInt64(metric string) int64 {
	parts := strings.SplitN(metric, ":", 2)
	var value int64
	_, _ = fmt.Sscanf(parts[0], "%d", &value)
	return value
}

func extractWechatMetricValue(resp wechat.GameAnalysisDataResp) int64 {
	for _, item := range append(resp.List, resp.Data...) {
		if value, ok := numericField(item, "metric_value"); ok {
			return value
		}
		if value, ok := numericField(item, "value"); ok {
			return value
		}
		if value, ok := numericField(item, "num"); ok {
			return value
		}
	}
	return 0
}

func numericField(item map[string]any, key string) (int64, bool) {
	value, ok := item[key]
	if !ok {
		return 0, false
	}
	switch typed := value.(type) {
	case float64:
		return int64(typed), true
	case int64:
		return typed, true
	case json.Number:
		parsed, err := typed.Int64()
		return parsed, err == nil
	case string:
		var parsed int64
		_, err := fmt.Sscanf(typed, "%d", &parsed)
		return parsed, err == nil
	default:
		return 0, false
	}
}
