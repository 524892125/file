package logic

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"civet/apps/kbrelease/model"
	"civet/apps/kbrelease/rpc/internal/svc"
	"civet/apps/kbrelease/rpc/internal/wechat"
	"civet/apps/kbrelease/rpc/kbrelease"

	"github.com/zeromicro/go-zero/core/logx"
)

type RpcPullWechatDataLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

type wechatPullPayload struct {
	StartTime      string `json:"start_time"`
	EndTime        string `json:"end_time"`
	StartTimeCamel string `json:"startTime"`
	EndTimeCamel   string `json:"endTime"`
}

type wechatPullWindow struct {
	RefDate   time.Time
	StartTime int64
	EndTime   int64
}

var wechatPullLocation = time.FixedZone("CST", 8*60*60)

func NewRpcPullWechatDataLogic(ctx context.Context, svcCtx *svc.ServiceContext) *RpcPullWechatDataLogic {
	return &RpcPullWechatDataLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *RpcPullWechatDataLogic) RpcPullWechatData(in *kbrelease.PullWechatDataReq) (*kbrelease.PullWechatDataResp, error) {
	windows, err := parseWechatPullWindows(in.GetPayload())
	if err != nil {
		return nil, err
	}

	var tasks []wechat.WechatPayload
	// if in != nil && strings.TrimSpace(in.Payload) != "" {
	// 	if err := json.Unmarshal([]byte(in.Payload), &tasks); err != nil {
	// 		return nil, fmt.Errorf("invalid wechat payload: %w", err)
	// 	}
	// }

	if len(tasks) == 0 {
		tasks = []wechat.WechatPayload{
			{AppID: "wxcb9e812f3773d4fb", Secret: "6ac41274713e2e7effcfa374c928e7ae"}, // 动物守卫
			// {AppID: "wx7c301031804f4142", Secret: "f5b97a4107ad416ac08f487bd483629c"}, // 机制特工
		}
	}

	for _, t := range tasks {
		t.AppID = strings.TrimSpace(t.AppID)
		t.Secret = strings.TrimSpace(t.Secret)
		if t.AppID != "" && t.Secret != "" {
			go l.runWechatDataPullTask(t.AppID, t.Secret, windows)
		}
	}

	return &kbrelease.PullWechatDataResp{
		Message: fmt.Sprintf("wechat metrics pull task started: count=%d windows=%d", len(tasks), len(windows)),
	}, nil
}

func parseWechatPullWindows(raw string) ([]wechatPullWindow, error) {
	payload, err := parseWechatPullPayload(raw)
	if err != nil {
		return nil, err
	}

	startDate := normalizedWechatPayloadTime(payload.StartTime, payload.StartTimeCamel)
	endDate := normalizedWechatPayloadTime(payload.EndTime, payload.EndTimeCamel)
	if startDate == "" && endDate == "" {
		yesterday := beginningOfWechatDay(time.Now().In(wechatPullLocation)).AddDate(0, 0, -1)
		return []wechatPullWindow{newWechatPullWindow(yesterday)}, nil
	}
	if startDate == "" || endDate == "" {
		return nil, fmt.Errorf("wechat startTime and endTime must be provided together")
	}

	startDay, err := parseWechatPullDate(startDate)
	if err != nil {
		return nil, fmt.Errorf("invalid wechat startTime: %w", err)
	}
	endDay, err := parseWechatPullDate(endDate)
	if err != nil {
		return nil, fmt.Errorf("invalid wechat endTime: %w", err)
	}
	if endDay.Before(startDay) {
		return nil, fmt.Errorf("wechat endTime must be greater than or equal to startTime")
	}

	var windows []wechatPullWindow
	for day := startDay; !day.After(endDay); day = day.AddDate(0, 0, 1) {
		windows = append(windows, newWechatPullWindow(day))
	}
	return windows, nil
}

func parseWechatPullPayload(raw string) (wechatPullPayload, error) {
	if strings.TrimSpace(raw) == "" {
		return wechatPullPayload{}, nil
	}
	var payload wechatPullPayload
	if err := json.Unmarshal([]byte(raw), &payload); err != nil {
		return wechatPullPayload{}, fmt.Errorf("invalid wechat payload: %w", err)
	}
	return payload, nil
}

func normalizedWechatPayloadTime(snakeCase, camelCase string) string {
	if strings.TrimSpace(snakeCase) != "" {
		return strings.TrimSpace(snakeCase)
	}
	return strings.TrimSpace(camelCase)
}

func parseWechatPullDate(value string) (time.Time, error) {
	t, err := time.ParseInLocation(time.DateOnly, strings.TrimSpace(value), wechatPullLocation)
	if err != nil {
		return time.Time{}, err
	}
	return beginningOfWechatDay(t), nil
}

func beginningOfWechatDay(value time.Time) time.Time {
	value = value.In(wechatPullLocation)
	return time.Date(value.Year(), value.Month(), value.Day(), 0, 0, 0, 0, wechatPullLocation)
}

func newWechatPullWindow(refDate time.Time) wechatPullWindow {
	refDate = beginningOfWechatDay(refDate)
	return wechatPullWindow{
		RefDate:   refDate,
		StartTime: refDate.Unix(),
		EndTime:   refDate.AddDate(0, 0, 1).Unix(),
	}
}

const (
	wechatDailyMetricsGranularity = int64(24)
)

func (l *RpcPullWechatDataLogic) runWechatDataPullTask(appID, secret string, windows []wechatPullWindow) {
	ctx := context.Background()

	taskLogic := &RpcPullWechatDataLogic{
		ctx:    ctx,
		svcCtx: l.svcCtx,
		Logger: logx.WithContext(ctx),
	}

	taskLogic.Infof("wechat metrics pull task started: appid=%s windows=%d", appID, len(windows))
	accessToken, err := taskLogic.svcCtx.WechatClient.GetAccessToken(ctx, appID, secret)
	if err != nil {
		taskLogic.Errorf("wechat access token fetch failed: appid=%s err=%v", appID, err)
		return
	}
	taskLogic.Infof("wechat access token fetched: appid=%s expires_in=%d token_len=%d", appID, accessToken.ExpiresIn, len(accessToken.Token))

	totalSaved := 0
	for _, window := range windows {
		saved, err := taskLogic.pullAndSaveWechatDailyMetrics(appID, accessToken.Token, window)
		if err != nil && isWechatInvalidAccessTokenError(err) {
			taskLogic.Errorf("wechat access token invalid, refetching: appid=%s ref_date=%s saved=%d err=%v", appID, window.RefDate.Format(time.DateOnly), saved, err)
			accessToken, err = taskLogic.svcCtx.WechatClient.GetAccessToken(ctx, appID, secret)
			if err != nil {
				taskLogic.Errorf("wechat access token refetch failed: appid=%s ref_date=%s err=%v", appID, window.RefDate.Format(time.DateOnly), err)
				return
			}
			taskLogic.Infof("wechat access token refetched: appid=%s expires_in=%d token_len=%d", appID, accessToken.ExpiresIn, len(accessToken.Token))

			saved, err = taskLogic.pullAndSaveWechatDailyMetrics(appID, accessToken.Token, window)
		}
		if err != nil {
			taskLogic.Errorf("wechat metrics pull window failed: appid=%s ref_date=%s saved=%d err=%v", appID, window.RefDate.Format(time.DateOnly), saved, err)
			return
		}
		taskLogic.Infof("wechat metrics pull window completed: appid=%s ref_date=%s saved=%d", appID, window.RefDate.Format(time.DateOnly), saved)
		totalSaved += saved
	}
	taskLogic.Infof("wechat metrics pull task completed: appid=%s saved=%d windows=%d", appID, totalSaved, len(windows))
}

func isWechatInvalidAccessTokenError(err error) bool {
	return err != nil && strings.Contains(err.Error(), "40001")
}

func (l *RpcPullWechatDataLogic) pullAndSaveWechatDailyMetrics(appID, accessToken string, window wechatPullWindow) (int, error) {
	now := time.Now()

	dailyData := &model.WechatDailyData{
		Appid:     appID,
		RefDate:   window.RefDate,
		CreatedAt: now,
		UpdatedAt: now,
	}

	saved := 0
	seen := make(map[string]bool)
	for _, spec := range wechat.DailyMetricSpecs {
		if spec.Granularity != wechatDailyMetricsGranularity {
			continue
		}
		if seen[spec.ColumnKey] {
			continue
		}
		seen[spec.ColumnKey] = true

		if saved > 0 {
			if err := sleepWithContext(l.ctx, 3*time.Second); err != nil {
				return saved, err
			}
		}

		resp, err := l.svcCtx.WechatClient.GetGameAnalysisData(l.ctx, accessToken, wechat.GameAnalysisDataReq{
			Metric:      spec.Metric,
			Granularity: spec.Granularity,
			StartTime:   window.StartTime,
			EndTime:     window.EndTime,
		})
		logx.Infof("resp %#v", resp)
		if err != nil {
			return saved, fmt.Errorf("pull wechat metric %s failed: %w", spec.Metric, err)
		}

		value := extractWechatMetricValue(resp)
		if value > 0 {
			if err := applyWechatDailyMetric(dailyData, spec.ColumnKey, value, resp.Raw); err != nil {
				return saved, fmt.Errorf("apply wechat metric %s failed: %w", spec.ColumnKey, err)
			}
		}
		saved++
	}

	if saved == 0 {
		return 0, nil
	}
	if err := l.svcCtx.WechatDailyDataModel.UpsertByAppIDRefDate(l.ctx, dailyData); err != nil {
		return saved, fmt.Errorf("save wechat daily data failed: %w", err)
	}
	return saved, nil
}

func extractWechatMetricValue(resp wechat.GameAnalysisDataResp) float64 {
	for _, item := range append(resp.List, resp.Data...) {
		if value, ok := numericField(item, "metric_value"); ok {
			return value
		}
		if value, ok := numericField(item, "value"); ok {
			return value
		}
		if value, ok := numericField(item, "num"); ok {
			return value
		}
	}
	return 0
}

func applyWechatDailyMetric(data *model.WechatDailyData, columnKey string, value float64, raw any) error {
	switch columnKey {
	case "active_users":
		data.ActiveUsers += int64(value)
	case "avg_active_user_stay_seconds":
		data.AvgActiveUserStaySeconds = addNullFloat64(data.AvgActiveUserStaySeconds, value)
	case "active_user_retention_1d":
		data.ActiveUserRetention1D = addNullFloat64(data.ActiveUserRetention1D, value)
	case "active_user_retention_7d":
		data.ActiveUserRetention7D = addNullFloat64(data.ActiveUserRetention7D, value)
	case "registered_users":
		data.RegisteredUsers += int64(value)
	case "registered_user_retention_1d":
		data.RegisteredUserRetention1D = addNullFloat64(data.RegisteredUserRetention1D, value)
	case "registered_user_retention_7d":
		data.RegisteredUserRetention7D = addNullFloat64(data.RegisteredUserRetention7D, value)
	case "paid_users":
		data.PaidUsers += int64(value)
	case "pay_penetration_rate":
		data.PayPenetrationRate = addNullFloat64(data.PayPenetrationRate, value)
	case "new_paid_users":
		data.NewPaidUsers += int64(value)
	case "paid_user_retention_1d":
		data.PaidUserRetention1D = addNullFloat64(data.PaidUserRetention1D, value)
	case "paid_user_retention_7d":
		data.PaidUserRetention7D = addNullFloat64(data.PaidUserRetention7D, value)
	case "new_paid_user_retention_1d":
		data.NewPaidUserRetention1D = addNullFloat64(data.NewPaidUserRetention1D, value)
	case "new_paid_user_retention_7d":
		data.NewPaidUserRetention7D = addNullFloat64(data.NewPaidUserRetention7D, value)
	case "payment_amount":
		data.PaymentAmount += value
	case "paid_user_arppu":
		data.PaidUserArppu = addNullFloat64(data.PaidUserArppu, value)
	case "new_payment_amount":
		data.NewPaymentAmount += value
	case "new_paid_user_arppu":
		data.NewPaidUserArppu = addNullFloat64(data.NewPaidUserArppu, value)
	case "ad_revenue_after_share":
		data.AdRevenueAfterShare += value
	case "ad_ltv_1d":
		data.AdLtv1D = addNullFloat64(data.AdLtv1D, value)
	case "ad_ltv_3d":
		data.AdLtv3D = addNullFloat64(data.AdLtv3D, value)
	case "ad_ltv_7d":
		data.AdLtv7D = addNullFloat64(data.AdLtv7D, value)
	case "ad_ltv_30d":
		data.AdLtv30D = addNullFloat64(data.AdLtv30D, value)
	case "item_ltv_1d":
		data.ItemLtv1D = addNullFloat64(data.ItemLtv1D, value)
	case "item_ltv_3d":
		data.ItemLtv3D = addNullFloat64(data.ItemLtv3D, value)
	case "item_ltv_7d":
		data.ItemLtv7D = addNullFloat64(data.ItemLtv7D, value)
	case "item_ltv_30d":
		data.ItemLtv30D = addNullFloat64(data.ItemLtv30D, value)
	case "registered_user_age_profile":
		return appendJSONProfile(&data.RegisteredUserAgeProfile, raw)
	case "registered_user_gender_profile":
		return appendJSONProfile(&data.RegisteredUserGenderProfile, raw)
	case "registered_user_province_profile":
		return appendJSONProfile(&data.RegisteredUserProvinceProfile, raw)
	case "registered_user_city_profile":
		return appendJSONProfile(&data.RegisteredUserCityProfile, raw)
	case "registered_user_device_profile":
		return appendJSONProfile(&data.RegisteredUserDeviceProfile, raw)
	default:
		return fmt.Errorf("unsupported daily column_key: %s", columnKey)
	}
	return nil
}

func addNullFloat64(current sql.NullFloat64, value float64) sql.NullFloat64 {
	if !current.Valid {
		return sql.NullFloat64{Float64: value, Valid: true}
	}
	current.Float64 += value
	return current
}

func sleepWithContext(ctx context.Context, duration time.Duration) error {
	timer := time.NewTimer(duration)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-timer.C:
		return nil
	}
}

func numericField(item map[string]any, key string) (float64, bool) {
	value, ok := item[key]
	if !ok {
		return 0, false
	}
	switch typed := value.(type) {
	case float64:
		return typed, true
	case int64:
		return float64(typed), true
	case int:
		return float64(typed), true
	case json.Number:
		parsed, err := typed.Float64()
		return parsed, err == nil
	case string:
		parsed, err := strconv.ParseFloat(typed, 64)
		return parsed, err == nil
	default:
		return 0, false
	}
}

func appendJSONProfile(target *sql.NullString, raw any) error {
	payload, err := json.Marshal(raw)
	if err != nil {
		return err
	}
	target.String = string(payload)
	target.Valid = true
	return nil
}
