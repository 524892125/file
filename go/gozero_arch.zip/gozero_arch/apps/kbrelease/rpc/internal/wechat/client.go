package wechat

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"
)

const (
	defaultAccessTokenEndpoint      = "https://api.weixin.qq.com/cgi-bin/token"
	defaultGameAnalysisDataEndpoint = "https://api.weixin.qq.com/datacube/getgameanalysisdata"
)

func NewClient() *Client {
	return &Client{
		httpClient: &http.Client{
			Timeout: 10 * time.Second,
		},
		accessTokenEndpoint:      defaultAccessTokenEndpoint,
		gameAnalysisDataEndpoint: defaultGameAnalysisDataEndpoint,
	}
}

func (c *Client) GetAccessToken(ctx context.Context, appID, secret string) (AccessToken, error) {
	appID = strings.TrimSpace(appID)
	secret = strings.TrimSpace(secret)
	if appID == "" {
		return AccessToken{}, fmt.Errorf("wechat appId is required")
	}
	if secret == "" {
		return AccessToken{}, fmt.Errorf("wechat secret is required")
	}

	values := url.Values{}
	values.Set("grant_type", "client_credential")
	values.Set("appid", appID)
	values.Set("secret", secret)

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.accessTokenEndpoint+"?"+values.Encode(), nil)
	if err != nil {
		return AccessToken{}, err
	}

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return AccessToken{}, fmt.Errorf("request wechat access token failed: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode < http.StatusOK || resp.StatusCode >= http.StatusMultipleChoices {
		return AccessToken{}, fmt.Errorf("request wechat access token failed: status=%d", resp.StatusCode)
	}

	var data accessTokenResp
	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
		return AccessToken{}, fmt.Errorf("decode wechat access token response failed: %w", err)
	}
	if data.ErrCode != 0 {
		return AccessToken{}, fmt.Errorf("wechat access token error: errcode=%d errmsg=%s", data.ErrCode, data.ErrMsg)
	}
	if data.AccessToken == "" {
		return AccessToken{}, fmt.Errorf("wechat access token response missing access_token")
	}
	return AccessToken{
		Token:     data.AccessToken,
		ExpiresIn: data.ExpiresIn,
	}, nil
}

func (c *Client) GetGameAnalysisData(ctx context.Context, accessToken string, data GameAnalysisDataReq) (GameAnalysisDataResp, error) {
	accessToken = strings.TrimSpace(accessToken)
	if accessToken == "" {
		return GameAnalysisDataResp{}, fmt.Errorf("wechat accessToken is required")
	}
	if strings.TrimSpace(data.Metric) == "" {
		return GameAnalysisDataResp{}, fmt.Errorf("wechat metric is required")
	}
	if data.Granularity <= 0 {
		return GameAnalysisDataResp{}, fmt.Errorf("wechat granularity is required")
	}
	if data.StartTime <= 0 || data.EndTime <= 0 {
		return GameAnalysisDataResp{}, fmt.Errorf("wechat start_time and end_time are required")
	}
	if data.EndTime < data.StartTime {
		return GameAnalysisDataResp{}, fmt.Errorf("wechat end_time must be greater than or equal to start_time")
	}

	body, err := json.Marshal(data)
	if err != nil {
		return GameAnalysisDataResp{}, err
	}

	values := url.Values{}
	values.Set("access_token", accessToken)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.gameAnalysisDataEndpoint+"?"+values.Encode(), bytes.NewReader(body))
	if err != nil {
		return GameAnalysisDataResp{}, err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return GameAnalysisDataResp{}, fmt.Errorf("request wechat game analysis data failed: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode < http.StatusOK || resp.StatusCode >= http.StatusMultipleChoices {
		return GameAnalysisDataResp{}, fmt.Errorf("request wechat game analysis data failed: status=%d", resp.StatusCode)
	}

	var raw jsonObject
	if err := json.NewDecoder(resp.Body).Decode(&raw); err != nil {
		return GameAnalysisDataResp{}, fmt.Errorf("decode wechat game analysis data response failed: %w", err)
	}

	result := GameAnalysisDataResp{Raw: raw}
	if value, ok := raw["errcode"].(float64); ok {
		result.ErrCode = int64(value)
	}
	if value, ok := raw["errmsg"].(string); ok {
		result.ErrMsg = value
	}
	result.List = jsonObjects(raw["list"])
	result.Data = jsonObjects(raw["data"])
	if len(result.List) == 0 && len(result.Data) == 0 {
		result.List = jsonObjects(raw["data_list"])
	}
	if result.ErrCode != 0 {
		return GameAnalysisDataResp{}, fmt.Errorf("wechat game analysis data error: errcode=%d errmsg=%s", result.ErrCode, result.ErrMsg)
	}
	return result, nil
}

func jsonObjects(value any) []jsonObject {
	items, ok := value.([]any)
	if !ok {
		return nil
	}
	result := make([]jsonObject, 0, len(items))
	for _, item := range items {
		object, ok := item.(map[string]any)
		if ok {
			result = append(result, object)
		}
	}
	return result
}
