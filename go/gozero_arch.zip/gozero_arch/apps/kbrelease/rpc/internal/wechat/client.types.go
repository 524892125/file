package wechat

import "net/http"

type Client struct {
	httpClient               *http.Client
	accessTokenEndpoint      string
	gameAnalysisDataEndpoint string
}

type AccessToken struct {
	Token     string
	ExpiresIn int64
}

type GameAnalysisDataReq struct {
	Metric      string               `json:"metric"`
	Granularity int64                `json:"granularity"`
	StartTime   int64                `json:"start_time"`
	EndTime     int64                `json:"end_time"`
	FilterList  []GameAnalysisFilter `json:"filter_list,omitempty"`
	GroupList   []string             `json:"group_list,omitempty"`
}

type GameAnalysisFilter struct {
	Dimension string `json:"dimension"`
	Value     string `json:"value"`
}

type GameAnalysisDataResp struct {
	ErrCode int64        `json:"errcode"`
	ErrMsg  string       `json:"errmsg"`
	List    []jsonObject `json:"list"`
	Data    []jsonObject `json:"data"`
	Raw     jsonObject   `json:"-"`
}

type jsonObject map[string]any

type accessTokenResp struct {
	AccessToken string `json:"access_token"`
	ExpiresIn   int64  `json:"expires_in"`
	ErrCode     int64  `json:"errcode"`
	ErrMsg      string `json:"errmsg"`
}

type WechatPayload struct {
	AppID  string `json:"appId"`
	Secret string `json:"secret"`
}

type DailyMetricSpec struct {
	Name        string
	Metric      string
	ColumnKey   string
	Granularity int64
	Dimensions  []MetricDimension
}

type MetricDimension struct {
	ID   int64
	Name string
}

var DailyMetricSpecs = []DailyMetricSpec{
	{Name: "活跃用户数", Metric: "1000001:5", ColumnKey: "active_users", Granularity: 24, Dimensions: []MetricDimension{{ID: 9, Name: "平台"}}},
	{Name: "活跃用户人均停留市时长", Metric: "1000001:7", ColumnKey: "avg_active_user_stay_seconds", Granularity: 24, Dimensions: []MetricDimension{{ID: 9, Name: "平台"}}},
	{Name: "注册用户数", Metric: "1000011:3", ColumnKey: "registered_users", Granularity: 24, Dimensions: []MetricDimension{{ID: 4, Name: "平台"}}},
	{Name: "活跃用户次日留存", Metric: "1000010:3", ColumnKey: "active_user_retention_1d", Granularity: 24, Dimensions: []MetricDimension{{ID: 8, Name: "平台"}}},
	{Name: "活跃用户七日留存", Metric: "1000010:5", ColumnKey: "active_user_retention_7d", Granularity: 24, Dimensions: []MetricDimension{{ID: 8, Name: "平台"}}},
	{Name: "注册用户次日留存", Metric: "1000021:3", ColumnKey: "registered_user_retention_1d", Granularity: 24, Dimensions: []MetricDimension{{ID: 8, Name: "平台"}}},
	{Name: "注册用户七日留存", Metric: "1000021:5", ColumnKey: "registered_user_retention_7d", Granularity: 24, Dimensions: []MetricDimension{{ID: 8, Name: "平台"}}},
	{Name: "注册用户年龄画像", Metric: "1000013:5", ColumnKey: "registered_user_age_profile", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "年龄段"}}},
	{Name: "注册用户性别画像", Metric: "1000015:4", ColumnKey: "registered_user_gender_profile", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "性别"}}},
	{Name: "注册用户省份画像", Metric: "1000017:4", ColumnKey: "registered_user_province_profile", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "省份"}}},
	{Name: "注册用户城市画像", Metric: "1000018:4", ColumnKey: "registered_user_city_profile", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "城市"}}},
	{Name: "注册用户设备画像", Metric: "1000019:4", ColumnKey: "registered_user_device_profile", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "设备"}}},
	{Name: "付费用户数", Metric: "1000022:6", ColumnKey: "paid_users", Granularity: 24, Dimensions: []MetricDimension{{ID: 4, Name: "平台"}}},
	{Name: "付费渗透率", Metric: "1000024:5", ColumnKey: "pay_penetration_rate", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}}},
	{Name: "新增付费用户数", Metric: "1000023:5", ColumnKey: "new_paid_users", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}}},
	{Name: "付费用户次日留存", Metric: "1000026:3", ColumnKey: "paid_user_retention_1d", Granularity: 24, Dimensions: []MetricDimension{{ID: 6, Name: "平台"}}},
	{Name: "付费用户七日留存", Metric: "1000026:5", ColumnKey: "paid_user_retention_7d", Granularity: 24, Dimensions: []MetricDimension{{ID: 6, Name: "平台"}}},
	{Name: "新增付费次日留存", Metric: "1000025:3", ColumnKey: "new_paid_user_retention_1d", Granularity: 24, Dimensions: []MetricDimension{{ID: 6, Name: "平台"}}},
	{Name: "新增付费七日留存", Metric: "1000025:5", ColumnKey: "new_paid_user_retention_7d", Granularity: 24, Dimensions: []MetricDimension{{ID: 6, Name: "平台"}}},
	{Name: "付费金额", Metric: "1000022:3", ColumnKey: "payment_amount", Granularity: 24, Dimensions: []MetricDimension{{ID: 4, Name: "平台"}}},
	{Name: "付费用户ARPPU", Metric: "1000022:5", ColumnKey: "paid_user_arppu", Granularity: 24, Dimensions: []MetricDimension{{ID: 4, Name: "平台"}}},
	{Name: "新增付费金额", Metric: "1000023:4", ColumnKey: "new_payment_amount", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}}},
	{Name: "新增付费用户ARPPU", Metric: "1000023:6", ColumnKey: "new_paid_user_arppu", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}}},
	{Name: "广告分成后收入", Metric: "1000170:5", ColumnKey: "ad_revenue_after_share", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "场景渠道"}}},
	{Name: "首日广告LTV", Metric: "1000170:9", ColumnKey: "ad_ltv_1d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "场景渠道"}}},
	{Name: "3日广告LTV", Metric: "1000170:6", ColumnKey: "ad_ltv_3d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "场景渠道"}}},
	{Name: "7日广告LTV", Metric: "1000170:7", ColumnKey: "ad_ltv_7d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "场景渠道"}}},
	{Name: "30日广告LTV", Metric: "1000170:8", ColumnKey: "ad_ltv_30d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "场景渠道"}}},
	{Name: "3日道具LTV", Metric: "1000169:7", ColumnKey: "item_ltv_3d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "场景渠道"}}},
	{Name: "7日道具LTV", Metric: "1000169:8", ColumnKey: "item_ltv_7d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "场景渠道"}}},
	{Name: "30日道具LTV", Metric: "1000169:9", ColumnKey: "item_ltv_30d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "场景渠道"}}},
	{Name: "3日广告LTV", Metric: "1000169:13", ColumnKey: "ad_ltv_3d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "场景渠道"}}},
	{Name: "7日广告LTV", Metric: "1000169:14", ColumnKey: "ad_ltv_7d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "场景渠道"}}},
	{Name: "30日广告LTV", Metric: "1000169:15", ColumnKey: "ad_ltv_30d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "场景渠道"}}},
	{Name: "首日道具LTV", Metric: "1000171:9", ColumnKey: "item_ltv_1d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "产品渠道"}, {ID: 5, Name: "微信公众平台账号"}}},
	{Name: "3日道具LTV", Metric: "1000171:6", ColumnKey: "item_ltv_3d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "产品渠道"}, {ID: 5, Name: "微信公众平台账号"}}},
	{Name: "7日道具LTV", Metric: "1000171:7", ColumnKey: "item_ltv_7d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "产品渠道"}, {ID: 5, Name: "微信公众平台账号"}}},
	{Name: "30日道具LTV", Metric: "1000171:8", ColumnKey: "item_ltv_30d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "产品渠道"}, {ID: 5, Name: "微信公众平台账号"}}},
	{Name: "广告分成后收入", Metric: "1000171:10", ColumnKey: "ad_revenue_after_share", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "产品渠道"}, {ID: 5, Name: "微信公众平台账号"}}},
	{Name: "首日广告LTV", Metric: "1000171:11", ColumnKey: "ad_ltv_1d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "产品渠道"}, {ID: 5, Name: "微信公众平台账号"}}},
	{Name: "3日广告LTV", Metric: "1000171:12", ColumnKey: "ad_ltv_3d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "产品渠道"}, {ID: 5, Name: "微信公众平台账号"}}},
	{Name: "7日广告LTV", Metric: "1000171:13", ColumnKey: "ad_ltv_7d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "产品渠道"}, {ID: 5, Name: "微信公众平台账号"}}},
	{Name: "30日广告LTV", Metric: "1000171:14", ColumnKey: "ad_ltv_30d", Granularity: 24, Dimensions: []MetricDimension{{ID: 3, Name: "平台"}, {ID: 4, Name: "产品渠道"}, {ID: 5, Name: "微信公众平台账号"}}},
}
