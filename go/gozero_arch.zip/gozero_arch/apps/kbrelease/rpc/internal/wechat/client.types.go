package wechat

import "net/http"

type Client struct {
	httpClient               *http.Client
	accessTokenEndpoint      string
	gameAnalysisDataEndpoint string
}

type AccessToken struct {
	Token     string
	ExpiresIn int64
}

type GameAnalysisDataReq struct {
	Metric      string               `json:"metric"`
	Granularity int64                `json:"granularity"`
	StartTime   int64                `json:"start_time"`
	EndTime     int64                `json:"end_time"`
	FilterList  []GameAnalysisFilter `json:"filter_list,omitempty"`
}

type GameAnalysisFilter struct {
	Dimension string `json:"dimension"`
	Value     string `json:"value"`
}

type GameAnalysisDataResp struct {
	ErrCode int64        `json:"errcode"`
	ErrMsg  string       `json:"errmsg"`
	List    []jsonObject `json:"list"`
	Data    []jsonObject `json:"data"`
	Raw     jsonObject   `json:"-"`
}

type jsonObject map[string]any

type accessTokenResp struct {
	AccessToken string `json:"access_token"`
	ExpiresIn   int64  `json:"expires_in"`
	ErrCode     int64  `json:"errcode"`
	ErrMsg      string `json:"errmsg"`
}

type WechatPayload struct {
	AppID  string `json:"appId"`
	Secret string `json:"secret"`
}
