package config

import (
	"github.com/zeromicro/go-zero/zrpc"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

type Config struct {
	zrpc.RpcServerConf
	Pg sqlx.SqlConf
}
