package test

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"slices"
	"strconv"
	"strings"
	"testing"
	"time"
)

// 游戏名：机制特工
// appid：wx7c301031804f4142
// app secret：f5b97a4107ad416ac08f487bd483629c

const (
	weChatAppIDEnv               = "wx7c301031804f4142"
	weChatAppSecretEnv           = "f5b97a4107ad416ac08f487bd483629c"
	weChatAnalysisMetricEnv      = "WECHAT_ANALYSIS_METRIC"
	weChatAnalysisGranularityEnv = "WECHAT_ANALYSIS_GRANULARITY"
	weChatAnalysisStartTimeEnv   = "WECHAT_ANALYSIS_START_TIME"
	weChatAnalysisEndTimeEnv     = "WECHAT_ANALYSIS_END_TIME"
	weChatAnalysisFilterListEnv  = "WECHAT_ANALYSIS_FILTER_LIST"
	weChatAnalysisGroupListEnv   = "WECHAT_ANALYSIS_GROUP_LIST"
	weChatAPITimezone            = "Asia/Shanghai"
	weChatAccessTokenURL         = "https://api.weixin.qq.com/cgi-bin/token"
	weChatGameAnalysisDataAPIURL = "https://api.weixin.qq.com/datacube/getgameanalysisdata"
	weChatDefaultRequestTimeout  = 20 * time.Second
	weChatDefaultGranularity     = 24
	weChatDateLayout             = "2006-01-02"
	weChatDateTimeLayout         = "2006-01-02 15:04:05"
	weChatDateTimeMinuteLayout   = "2006-01-02 15:04"
)

var weChatAllMetrics = []weChatMetricDefinition{
	{ID: "1000001:5", Name: "活跃用户数", Granularities: []int{24, 30}},
	{ID: "1000001:6", Name: "活跃用户访问次数", Granularities: []int{24, 30}},
	{ID: "1000001:8", Name: "活跃用户人均访问次数", Granularities: []int{24, 30}},
	{ID: "1000001:7", Name: "活跃用户人均停留时长", Granularities: []int{24, 30}},
	{ID: "1000010:3", Name: "活跃用户次日留存", Granularities: []int{24}, RecommendedDaysAgo: 2},
	{ID: "1000010:5", Name: "活跃用户七日留存", Granularities: []int{24}, RecommendedDaysAgo: 8},
	{ID: "1000005:4", Name: "活跃用户年龄画像", Granularities: []int{24, 30}},
	{ID: "1000006:4", Name: "活跃用户性别画像", Granularities: []int{24, 30}},
	{ID: "1000007:4", Name: "活跃用户省份画像", Granularities: []int{24, 30}},
	{ID: "1000014:4", Name: "活跃用户城市画像", Granularities: []int{24, 30}},
	{ID: "1000009:4", Name: "活跃用户设备画像", Granularities: []int{24, 30}},

	{ID: "1000011:3", Name: "注册用户数", Granularities: []int{24, 30}},
	{ID: "1000021:3", Name: "注册用户次日留存", Granularities: []int{24}, RecommendedDaysAgo: 2},
	{ID: "1000021:5", Name: "注册用户七日留存", Granularities: []int{24}, RecommendedDaysAgo: 8},
	{ID: "1000013:5", Name: "注册用户年龄画像", Granularities: []int{24, 30}},
	{ID: "1000015:4", Name: "注册用户性别画像", Granularities: []int{24, 30}},
	{ID: "1000017:4", Name: "注册用户省份画像", Granularities: []int{24, 30}},
	{ID: "1000018:4", Name: "注册用户城市画像", Granularities: []int{24, 30}},
	{ID: "1000019:4", Name: "注册用户设备画像", Granularities: []int{24, 30}},

	{ID: "1000022:6", Name: "付费用户数", Granularities: []int{24}},
	{ID: "1000024:5", Name: "付费渗透率", Granularities: []int{24}},
	{ID: "1000023:5", Name: "新增付费用户数", Granularities: []int{24}},
	{ID: "1000026:3", Name: "付费用户次日留存", Granularities: []int{24}, RecommendedDaysAgo: 2},
	{ID: "1000026:5", Name: "付费用户七日留存", Granularities: []int{24}, RecommendedDaysAgo: 8},
	{ID: "1000025:3", Name: "新增付费次日留存", Granularities: []int{24}, RecommendedDaysAgo: 2},
	{ID: "1000025:5", Name: "新增付费七日留存", Granularities: []int{24}, RecommendedDaysAgo: 8},
	{ID: "1000022:3", Name: "付费金额", Granularities: []int{24}},
	{ID: "1000022:5", Name: "付费用户ARPPU", Granularities: []int{24}},
	{ID: "1000023:4", Name: "新增付费金额", Granularities: []int{24}},
	{ID: "1000023:6", Name: "新增付费用户ARPPU", Granularities: []int{24}},
	{ID: "1000186:6", Name: "付费用户年龄画像", Granularities: []int{24}},
	{ID: "1000187:6", Name: "付费用户性别画像", Granularities: []int{24}},

	{ID: "1000028:4", Name: "分享用户数", Granularities: []int{24}},
	{ID: "1000028:3", Name: "分享次数", Granularities: []int{24}},
	{ID: "1000028:7", Name: "人均分享次数", Granularities: []int{24}},
	{ID: "1000028:5", Name: "分享率", Granularities: []int{24}},
	{ID: "1000188:6", Name: "分享用户年龄画像", Granularities: []int{24}},
	{ID: "1000189:6", Name: "分享用户性别画像", Granularities: []int{24}},

	{ID: "1000004:4", Name: "场景渠道分析-活跃用户数", Granularities: []int{24, 30}},
	{ID: "1000162:5", Name: "场景渠道分析-次日留存率", Granularities: []int{24}, RecommendedDaysAgo: 2},
	{ID: "1000145:7", Name: "场景渠道分析-访问次数", Granularities: []int{24}},
	{ID: "1000145:6", Name: "场景渠道分析-人均停留时长", Granularities: []int{24}},
	{ID: "1000166:6", Name: "场景渠道分析-分享率", Granularities: []int{24}},
	{ID: "1000170:5", Name: "场景渠道分析-广告分成后收入", Granularities: []int{24}},
	{ID: "1000170:9", Name: "场景渠道分析-首日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 1},
	{ID: "1000170:6", Name: "场景渠道分析-3日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 3},
	{ID: "1000170:7", Name: "场景渠道分析-7日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 7},
	{ID: "1000170:8", Name: "场景渠道分析-30日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 30},

	{ID: "1000084:4", Name: "场景渠道分析-注册用户数", Granularities: []int{24, 30}},
	{ID: "1000163:5", Name: "场景渠道分析-次日留存率", Granularities: []int{24}, RecommendedDaysAgo: 2},
	{ID: "1000169:5", Name: "场景渠道分析-新增付费用户数", Granularities: []int{24}},
	{ID: "1000169:6", Name: "场景渠道分析-新增付费收入", Granularities: []int{24}},
	{ID: "1000165:6", Name: "场景渠道分析-分享率", Granularities: []int{24}},
	{ID: "1000169:10", Name: "场景渠道分析-首日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 1},
	{ID: "1000169:7", Name: "场景渠道分析-3日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 3},
	{ID: "1000169:8", Name: "场景渠道分析-7日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 7},
	{ID: "1000169:9", Name: "场景渠道分析-30日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 30},
	{ID: "1000169:11", Name: "场景渠道分析-广告分成后收入", Granularities: []int{24}},
	{ID: "1000169:12", Name: "场景渠道分析-首日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 1},
	{ID: "1000169:13", Name: "场景渠道分析-3日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 3},
	{ID: "1000169:14", Name: "场景渠道分析-7日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 7},
	{ID: "1000169:15", Name: "场景渠道分析-30日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 30},

	{ID: "1000035:6", Name: "产品渠道分析-活跃用户数", Granularities: []int{24, 7, 30}},
	{ID: "1000164:6", Name: "产品渠道分析-次日留存率", Granularities: []int{24}, RecommendedDaysAgo: 2},
	{ID: "1000035:7", Name: "产品渠道分析-访问次数", Granularities: []int{24, 7, 30}},
	{ID: "1000035:8", Name: "产品渠道分析-人均停留时长", Granularities: []int{24, 7, 30}},
	{ID: "1000168:7", Name: "产品渠道分析-分享率", Granularities: []int{24}},
	{ID: "1000172:6", Name: "产品渠道分析-广告分成后收入", Granularities: []int{24}},
	{ID: "1000172:10", Name: "产品渠道分析-首日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 1},
	{ID: "1000172:7", Name: "产品渠道分析-3日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 3},
	{ID: "1000172:8", Name: "产品渠道分析-7日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 7},
	{ID: "1000172:9", Name: "产品渠道分析-30日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 30},

	{ID: "1000036:6", Name: "产品渠道分析-注册用户数", Granularities: []int{24, 7, 30}},
	{ID: "1000036:9", Name: "产品渠道分析-次日留存率", Granularities: []int{24, 7, 30}, RecommendedDaysAgo: 2},
	{ID: "1000036:7", Name: "产品渠道分析-新增付费用户数", Granularities: []int{24, 7, 30}},
	{ID: "1000036:8", Name: "产品渠道分析-新增付费收入", Granularities: []int{24, 7, 30}},
	{ID: "1000167:7", Name: "产品渠道分析-分享率", Granularities: []int{24}},
	{ID: "1000171:9", Name: "产品渠道分析-首日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 1},
	{ID: "1000171:6", Name: "产品渠道分析-3日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 3},
	{ID: "1000171:7", Name: "产品渠道分析-7日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 7},
	{ID: "1000171:8", Name: "产品渠道分析-30日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 30},
	{ID: "1000171:10", Name: "产品渠道分析-广告分成后收入", Granularities: []int{24}},
	{ID: "1000171:11", Name: "产品渠道分析-首日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 1},
	{ID: "1000171:12", Name: "产品渠道分析-3日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 3},
	{ID: "1000171:13", Name: "产品渠道分析-7日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 7},
	{ID: "1000171:14", Name: "产品渠道分析-30日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 30},

	{ID: "1000088:6", Name: "自定义渠道分析-活跃用户数", Granularities: []int{24}},
	{ID: "1000089:6", Name: "自定义渠道分析-次日留存率", Granularities: []int{24}, RecommendedDaysAgo: 2},
	{ID: "1000088:7", Name: "自定义渠道分析-访问次数", Granularities: []int{24}},
	{ID: "1000088:9", Name: "自定义渠道分析-人均停留时长", Granularities: []int{24}},
	{ID: "1000173:7", Name: "自定义渠道分析-分享率", Granularities: []int{24}},
	{ID: "1000176:6", Name: "自定义渠道分析-广告分成后收入", Granularities: []int{24}},
	{ID: "1000176:10", Name: "自定义渠道分析-首日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 1},
	{ID: "1000176:7", Name: "自定义渠道分析-3日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 3},
	{ID: "1000176:8", Name: "自定义渠道分析-7日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 7},
	{ID: "1000176:9", Name: "自定义渠道分析-30日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 30},

	{ID: "1000091:6", Name: "自定义渠道分析-注册用户数", Granularities: []int{24}},
	{ID: "1000093:6", Name: "自定义渠道分析-次日留存率", Granularities: []int{24}, RecommendedDaysAgo: 2},
	{ID: "1000092:6", Name: "自定义渠道分析-新增付费用户数", Granularities: []int{24}},
	{ID: "1000092:7", Name: "自定义渠道分析-新增付费收入", Granularities: []int{24}},
	{ID: "1000175:9", Name: "自定义渠道分析-首日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 1},
	{ID: "1000175:6", Name: "自定义渠道分析-3日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 3},
	{ID: "1000175:7", Name: "自定义渠道分析-7日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 7},
	{ID: "1000175:8", Name: "自定义渠道分析-30日道具LTV", Granularities: []int{24}, RecommendedDaysAgo: 30},
	{ID: "1000175:10", Name: "自定义渠道分析-广告分成后收入", Granularities: []int{24}},
	{ID: "1000175:11", Name: "自定义渠道分析-首日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 1},
	{ID: "1000175:12", Name: "自定义渠道分析-3日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 3},
	{ID: "1000175:13", Name: "自定义渠道分析-7日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 7},
	{ID: "1000175:14", Name: "自定义渠道分析-30日广告LTV", Granularities: []int{24}, RecommendedDaysAgo: 30},
}

type weChatFilter struct {
	Dimension string `json:"dimension"`
	Value     string `json:"value"`
}

type weChatGameAnalysisRequest struct {
	Metric      string         `json:"metric"`
	Granularity int            `json:"granularity"`
	StartTime   int64          `json:"start_time"`
	EndTime     int64          `json:"end_time"`
	FilterList  []weChatFilter `json:"filter_list,omitempty"`
	GroupList   []string       `json:"group_list,omitempty"`
}

type weChatGameAnalysisResponse struct {
	ErrCode  int                       `json:"errcode"`
	ErrMsg   string                    `json:"errmsg"`
	DataList []weChatGameAnalysisDatum `json:"data_list"`
}

type weChatGameAnalysisDatum struct {
	Timestamp          int64                  `json:"timestamp"`
	TimeLabel          string                 `json:"time_label"`
	GroupDimensionList []weChatGroupDimension `json:"group_dimension_list"`
	MetricValue        *float64               `json:"metric_value,omitempty"`
}

type weChatGroupDimension struct {
	Value string `json:"value"`
	Label string `json:"label"`
}

type weChatAccessTokenResponse struct {
	AccessToken string `json:"access_token"`
	ExpiresIn   int    `json:"expires_in"`
	ErrCode     int    `json:"errcode"`
	ErrMsg      string `json:"errmsg"`
}

type weChatMetricDefinition struct {
	ID                 string
	Name               string
	Granularities      []int
	RecommendedDaysAgo int
}

type weChatMetricResult struct {
	Metric            weChatMetricDefinition    `json:"metric"`
	Request           weChatGameAnalysisRequest `json:"request"`
	RequestStartLabel string                    `json:"request_start_label"`
	RequestEndLabel   string                    `json:"request_end_label"`
	Response          any                       `json:"response,omitempty"`
	Error             string                    `json:"error,omitempty"`
}

type weChatIntegrationConfig struct {
	AppID       string
	AppSecret   string
	Granularity int
	StartTime   time.Time
	EndTime     time.Time
	FilterList  []weChatFilter
	GroupList   []string
	Metrics     []weChatMetricDefinition
	Location    *time.Location
	MissingEnv  []string
}

func TestWeChatGameAnalysisIntegration(t *testing.T) {
	cfg, err := loadWeChatIntegrationConfig()
	if err != nil {
		t.Fatalf("load wechat integration config: %v", err)
	}
	if len(cfg.MissingEnv) > 0 {
		fmt.Printf("wechat integration test skipped: missing env %s\n", strings.Join(cfg.MissingEnv, ", "))
		t.Skipf("set %s to run this integration test", strings.Join(cfg.MissingEnv, ", "))
	}

	client := &http.Client{Timeout: weChatDefaultRequestTimeout}

	tokenResp, err := fetchWeChatAccessToken(client, cfg.AppID, cfg.AppSecret)
	if err != nil {
		t.Fatalf("fetch access_token: %v", err)
	}
	if tokenResp.AccessToken == "" {
		t.Fatalf("wechat access_token response missing access_token: %+v", tokenResp)
	}

	fmt.Printf("wechat access_token acquired, expires_in=%d, metrics=%d\n", tokenResp.ExpiresIn, len(cfg.Metrics))
	t.Logf("wechat access_token acquired, expires_in=%d, metrics=%d", tokenResp.ExpiresIn, len(cfg.Metrics))

	successResults := make([]weChatMetricResult, 0, len(cfg.Metrics))
	failedResults := make([]weChatMetricResult, 0)

	for _, metric := range cfg.Metrics {
		req := buildMetricRequest(cfg, metric)
		analysisResp, err := fetchWeChatGameAnalysisData(client, tokenResp.AccessToken, req)
		if err != nil {
			failedResults = append(failedResults, newMetricErrorResult(metric, req, cfg.Location, err))
			continue
		}
		if analysisResp.ErrCode != 0 {
			failedResults = append(failedResults, newMetricErrorResult(metric, req, cfg.Location, fmt.Errorf("errcode=%d errmsg=%s", analysisResp.ErrCode, analysisResp.ErrMsg)))
			continue
		}

		successResults = append(successResults, weChatMetricResult{
			Metric:            metric,
			Request:           req,
			RequestStartLabel: time.Unix(req.StartTime, 0).In(cfg.Location).Format(time.RFC3339),
			RequestEndLabel:   time.Unix(req.EndTime, 0).In(cfg.Location).Format(time.RFC3339),
			Response:          analysisResp,
		})
	}

	if len(successResults) > 0 {
		formatted, marshalErr := json.MarshalIndent(successResults, "", "  ")
		if marshalErr != nil {
			t.Fatalf("marshal successful metric responses: %v", marshalErr)
		}
		fmt.Printf("wechat game analysis success results:\n%s\n", formatted)
		t.Logf("wechat game analysis success results:\n%s", formatted)
	}

	if len(failedResults) > 0 {
		formatted, marshalErr := json.MarshalIndent(failedResults, "", "  ")
		if marshalErr != nil {
			t.Fatalf("marshal failed metric responses: %v", marshalErr)
		}
		fmt.Printf("wechat game analysis failed results:\n%s\n", formatted)
		t.Logf("wechat game analysis failed results:\n%s", formatted)
	}

	if len(successResults) == 0 {
		t.Fatalf("wechat game analysis returned no successful metric queries; failed=%d", len(failedResults))
	}
}

func loadWeChatIntegrationConfig() (*weChatIntegrationConfig, error) {
	location := mustLoadWeChatLocation()

	cfg := &weChatIntegrationConfig{
		AppID:     strings.TrimSpace("wx7c301031804f4142"),
		AppSecret: strings.TrimSpace("f5b97a4107ad416ac08f487bd483629c"),
		Location:  location,
	}
	if cfg.AppID == "" {
		cfg.MissingEnv = append(cfg.MissingEnv, weChatAppIDEnv)
	}
	if cfg.AppSecret == "" {
		cfg.MissingEnv = append(cfg.MissingEnv, weChatAppSecretEnv)
	}

	granularity, err := loadGranularity()
	if err != nil {
		return nil, err
	}
	cfg.Granularity = granularity

	startTime, endTime, err := loadTimeRange(granularity, location)
	if err != nil {
		return nil, err
	}
	cfg.StartTime = startTime
	cfg.EndTime = endTime

	filterList, err := loadFilterList()
	if err != nil {
		return nil, err
	}
	groupList, err := loadGroupList()
	if err != nil {
		return nil, err
	}
	cfg.FilterList = filterList
	cfg.GroupList = groupList

	metrics, err := loadMetrics(granularity)
	if err != nil {
		return nil, err
	}
	cfg.Metrics = metrics

	return cfg, nil
}

func loadMetrics(granularity int) ([]weChatMetricDefinition, error) {
	raw := strings.TrimSpace(os.Getenv(weChatAnalysisMetricEnv))
	if raw == "" || strings.EqualFold(raw, "all") {
		return filterMetricsByGranularity(weChatAllMetrics, granularity), nil
	}

	parts := strings.Split(raw, ",")
	metrics := make([]weChatMetricDefinition, 0, len(parts))
	for _, part := range parts {
		metricID := strings.TrimSpace(part)
		if metricID == "" {
			continue
		}

		metric, ok := findMetric(metricID)
		if !ok {
			metric = weChatMetricDefinition{
				ID:            metricID,
				Name:          metricID,
				Granularities: []int{granularity},
			}
		}
		if !slices.Contains(metric.Granularities, granularity) {
			return nil, fmt.Errorf("metric %s does not support granularity %d", metric.ID, granularity)
		}
		metrics = append(metrics, metric)
	}

	if len(metrics) == 0 {
		return nil, fmt.Errorf("%s is empty after parsing", weChatAnalysisMetricEnv)
	}

	return metrics, nil
}

func filterMetricsByGranularity(metrics []weChatMetricDefinition, granularity int) []weChatMetricDefinition {
	filtered := make([]weChatMetricDefinition, 0, len(metrics))
	for _, metric := range metrics {
		if slices.Contains(metric.Granularities, granularity) {
			filtered = append(filtered, metric)
		}
	}
	return filtered
}

func findMetric(metricID string) (weChatMetricDefinition, bool) {
	for _, metric := range weChatAllMetrics {
		if metric.ID == metricID {
			return metric, true
		}
	}
	return weChatMetricDefinition{}, false
}

func loadGranularity() (int, error) {
	raw := strings.TrimSpace(os.Getenv(weChatAnalysisGranularityEnv))
	if raw == "" {
		return weChatDefaultGranularity, nil
	}

	granularity, err := strconv.Atoi(raw)
	if err != nil {
		return 0, fmt.Errorf("parse %s: %w", weChatAnalysisGranularityEnv, err)
	}

	switch granularity {
	case 1, 5, 60, 24, 7, 30:
		return granularity, nil
	default:
		return 0, fmt.Errorf("%s=%d is unsupported", weChatAnalysisGranularityEnv, granularity)
	}
}

func loadTimeRange(granularity int, location *time.Location) (time.Time, time.Time, error) {
	defaultStart, err := alignTimeForGranularity(time.Now().In(location).AddDate(0, 0, -31), granularity)
	if err != nil {
		return time.Time{}, time.Time{}, err
	}

	startRaw := strings.TrimSpace(os.Getenv(weChatAnalysisStartTimeEnv))
	endRaw := strings.TrimSpace(os.Getenv(weChatAnalysisEndTimeEnv))

	startTime, err := parseAlignedEnvTime(weChatAnalysisStartTimeEnv, defaultStart, granularity, location)
	if err != nil {
		return time.Time{}, time.Time{}, err
	}

	defaultEnd, err := advanceAlignedTime(startTime, granularity)
	if err != nil {
		return time.Time{}, time.Time{}, err
	}

	endFallback := defaultEnd
	if startRaw == "" && endRaw != "" {
		endFallback = startTime
	}

	endTime, err := parseAlignedEnvTime(weChatAnalysisEndTimeEnv, endFallback, granularity, location)
	if err != nil {
		return time.Time{}, time.Time{}, err
	}
	if err := validateTimeRange(startTime, endTime, granularity); err != nil {
		return time.Time{}, time.Time{}, err
	}

	return startTime, endTime, nil
}

func parseAlignedEnvTime(envName string, fallback time.Time, granularity int, location *time.Location) (time.Time, error) {
	raw := strings.TrimSpace(os.Getenv(envName))
	if raw == "" {
		return alignTimeForGranularity(fallback, granularity)
	}

	if unixSeconds, err := strconv.ParseInt(raw, 10, 64); err == nil {
		return alignTimeForGranularity(time.Unix(unixSeconds, 0).In(location), granularity)
	}

	for _, layout := range []string{time.RFC3339, weChatDateTimeLayout, weChatDateTimeMinuteLayout, weChatDateLayout} {
		if ts, err := time.ParseInLocation(layout, raw, location); err == nil {
			return alignTimeForGranularity(ts, granularity)
		}
	}

	return time.Time{}, fmt.Errorf("parse %s=%q failed, supported formats are unix seconds, RFC3339, %s, %s or %s", envName, raw, weChatDateTimeLayout, weChatDateTimeMinuteLayout, weChatDateLayout)
}

func alignTimeForGranularity(ts time.Time, granularity int) (time.Time, error) {
	switch granularity {
	case 1:
		return ts.Truncate(time.Minute), nil
	case 5:
		return ts.Truncate(5 * time.Minute), nil
	case 60:
		return ts.Truncate(time.Hour), nil
	case 24:
		return time.Date(ts.Year(), ts.Month(), ts.Day(), 0, 0, 0, 0, ts.Location()), nil
	case 7:
		dayStart := time.Date(ts.Year(), ts.Month(), ts.Day(), 0, 0, 0, 0, ts.Location())
		offset := (int(dayStart.Weekday()) + 6) % 7
		return dayStart.AddDate(0, 0, -offset), nil
	case 30:
		return time.Date(ts.Year(), ts.Month(), 1, 0, 0, 0, 0, ts.Location()), nil
	default:
		return time.Time{}, fmt.Errorf("unsupported granularity %d", granularity)
	}
}

func advanceAlignedTime(ts time.Time, granularity int) (time.Time, error) {
	switch granularity {
	case 1:
		return ts.Add(time.Minute), nil
	case 5:
		return ts.Add(5 * time.Minute), nil
	case 60:
		return ts.Add(time.Hour), nil
	case 24:
		return ts.AddDate(0, 0, 1), nil
	case 7:
		return ts.AddDate(0, 0, 7), nil
	case 30:
		return ts.AddDate(0, 1, 0), nil
	default:
		return time.Time{}, fmt.Errorf("unsupported granularity %d", granularity)
	}
}

func validateTimeRange(startTime, endTime time.Time, granularity int) error {
	if !endTime.After(startTime) {
		return fmt.Errorf("%s must be greater than %s", weChatAnalysisEndTimeEnv, weChatAnalysisStartTimeEnv)
	}

	switch granularity {
	case 24, 7, 30:
		expectedEnd, err := advanceAlignedTime(startTime, granularity)
		if err != nil {
			return err
		}
		if !endTime.Equal(expectedEnd) {
			return fmt.Errorf("granularity=%d requires a single aligned period, expected end_time=%s", granularity, expectedEnd.Format(time.RFC3339))
		}
	case 1, 5, 60:
		if endTime.Sub(startTime) > 24*time.Hour {
			return fmt.Errorf("granularity=%d only allows a maximum 24 hour range", granularity)
		}
	}

	return nil
}

func loadFilterList() ([]weChatFilter, error) {
	raw := strings.TrimSpace(os.Getenv(weChatAnalysisFilterListEnv))
	if raw == "" {
		return nil, nil
	}

	var filters []weChatFilter
	if err := json.Unmarshal([]byte(raw), &filters); err != nil {
		return nil, fmt.Errorf("parse %s: %w", weChatAnalysisFilterListEnv, err)
	}

	return filters, nil
}

func loadGroupList() ([]string, error) {
	raw := strings.TrimSpace(os.Getenv(weChatAnalysisGroupListEnv))
	if raw == "" {
		return nil, nil
	}

	var groups []string
	if err := json.Unmarshal([]byte(raw), &groups); err != nil {
		return nil, fmt.Errorf("parse %s: %w", weChatAnalysisGroupListEnv, err)
	}

	return groups, nil
}

func buildMetricRequest(cfg *weChatIntegrationConfig, metric weChatMetricDefinition) weChatGameAnalysisRequest {
	startTime := cfg.StartTime
	endTime := cfg.EndTime

	if os.Getenv(weChatAnalysisStartTimeEnv) == "" && os.Getenv(weChatAnalysisEndTimeEnv) == "" && metric.RecommendedDaysAgo > 0 {
		recommendedStart, err := alignTimeForGranularity(time.Now().In(cfg.Location).AddDate(0, 0, -metric.RecommendedDaysAgo), cfg.Granularity)
		if err == nil {
			recommendedEnd, endErr := advanceAlignedTime(recommendedStart, cfg.Granularity)
			if endErr == nil {
				endTime = recommendedEnd
			}
			startTime = recommendedStart
		}
	}

	return weChatGameAnalysisRequest{
		Metric:      metric.ID,
		Granularity: cfg.Granularity,
		StartTime:   startTime.Unix(),
		EndTime:     endTime.Unix(),
		FilterList:  cfg.FilterList,
		GroupList:   cfg.GroupList,
	}
}

func newMetricErrorResult(metric weChatMetricDefinition, req weChatGameAnalysisRequest, location *time.Location, err error) weChatMetricResult {
	return weChatMetricResult{
		Metric:            metric,
		Request:           req,
		RequestStartLabel: time.Unix(req.StartTime, 0).In(location).Format(time.RFC3339),
		RequestEndLabel:   time.Unix(req.EndTime, 0).In(location).Format(time.RFC3339),
		Error:             err.Error(),
	}
}

func fetchWeChatAccessToken(client *http.Client, appID, appSecret string) (*weChatAccessTokenResponse, error) {
	query := url.Values{}
	query.Set("grant_type", "client_credential")
	query.Set("appid", appID)
	query.Set("secret", appSecret)

	endpoint := weChatAccessTokenURL + "?" + query.Encode()
	request, err := http.NewRequest(http.MethodGet, endpoint, nil)
	if err != nil {
		return nil, fmt.Errorf("build access token request: %w", err)
	}

	response := &weChatAccessTokenResponse{}
	if err := doJSONRequest(client, request, response); err != nil {
		return nil, err
	}
	if response.ErrCode != 0 {
		return nil, fmt.Errorf("wechat access token errcode=%d errmsg=%s", response.ErrCode, response.ErrMsg)
	}

	return response, nil
}

func fetchWeChatGameAnalysisData(client *http.Client, accessToken string, payload weChatGameAnalysisRequest) (*weChatGameAnalysisResponse, error) {
	body, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("marshal game analysis request: %w", err)
	}

	query := url.Values{}
	query.Set("access_token", accessToken)

	request, err := http.NewRequest(http.MethodPost, weChatGameAnalysisDataAPIURL+"?"+query.Encode(), bytes.NewReader(body))
	if err != nil {
		return nil, fmt.Errorf("build game analysis request: %w", err)
	}
	request.Header.Set("Content-Type", "application/json")

	response := &weChatGameAnalysisResponse{}
	if err := doJSONRequest(client, request, response); err != nil {
		return nil, err
	}

	return response, nil
}

func doJSONRequest(client *http.Client, request *http.Request, target interface{}) error {
	response, err := client.Do(request)
	if err != nil {
		return fmt.Errorf("do %s %s: %w", request.Method, request.URL.String(), err)
	}
	defer response.Body.Close()

	body, err := io.ReadAll(response.Body)
	if err != nil {
		return fmt.Errorf("read %s %s response body: %w", request.Method, request.URL.String(), err)
	}
	if response.StatusCode < http.StatusOK || response.StatusCode >= http.StatusMultipleChoices {
		return fmt.Errorf("%s %s returned status %d: %s", request.Method, request.URL.String(), response.StatusCode, strings.TrimSpace(string(body)))
	}
	if err := json.Unmarshal(body, target); err != nil {
		return fmt.Errorf("decode %s %s response: %w; body=%s", request.Method, request.URL.String(), err, strings.TrimSpace(string(body)))
	}

	return nil
}

func mustLoadWeChatLocation() *time.Location {
	location, err := time.LoadLocation(weChatAPITimezone)
	if err == nil {
		return location
	}
	return time.FixedZone("CST", 8*60*60)
}
