package main

import (
	"flag"
	"fmt"

	"civet/apps/kbrelease/rpc/internal/config"
	"civet/apps/kbrelease/rpc/internal/server"
	"civet/apps/kbrelease/rpc/internal/svc"
	"civet/apps/kbrelease/rpc/kbrelease"

	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/core/service"
	"github.com/zeromicro/go-zero/zrpc"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

var configFile = flag.String("f", "etc/kbrelease.yaml", "the config file")

func main() {
	flag.Parse()

	var c config.Config
	conf.MustLoad(*configFile, &c)
	ctx := svc.NewServiceContext(c)

	s := zrpc.MustNewServer(c.RpcServerConf, func(grpcServer *grpc.Server) {
		kbrelease.RegisterKbreleaseServer(grpcServer, server.NewKbreleaseServer(ctx))

		if c.Mode == service.DevMode || c.Mode == service.TestMode {
			reflection.Register(grpcServer)
		}
	})
	defer s.Stop()

	fmt.Printf("Starting rpc server at %s...\n", c.ListenOn)
	s.Start()
}
