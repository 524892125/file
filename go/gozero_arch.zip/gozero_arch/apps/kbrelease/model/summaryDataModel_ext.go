package model

import (
	"context"
	"fmt"
)

func (m *customSummaryDataModel) UpsertMetricByAppIDRefDate(ctx context.Context, data *SummaryData, columnKey string) error {
	column, value, err := summaryMetricColumnValue(data, columnKey)
	if err != nil {
		return err
	}
	query := fmt.Sprintf(`
insert into %s (appid, ref_date, %s, created_at, updated_at)
values ($1, $2, $3, $4, $5)
on conflict (appid, ref_date)
do update set
    %s = excluded.%s,
    updated_at = excluded.updated_at`, m.table, column, column, column)
	_, err = m.conn.ExecCtx(ctx, query, data.Appid, data.RefDate, value, data.CreatedAt, data.UpdatedAt)
	return err
}

func summaryMetricColumnValue(data *SummaryData, columnKey string) (string, any, error) {
	switch columnKey {
	case "dau":
		return "dau", data.Dau, nil
	case "new_users":
		return "new_users", data.NewUsers, nil
	case "total_users_sum":
		return "total_users_sum", data.TotalUsersSum, nil
	case "rev_traffic_owner":
		return "rev_traffic_owner", data.RevTrafficOwner, nil
	case "rev_internal_purchase":
		return "rev_internal_purchase", data.RevInternalPurchase, nil
	case "rev_commission":
		return "rev_commission", data.RevCommission, nil
	default:
		return "", nil, fmt.Errorf("unsupported summary metric column_key: %s", columnKey)
	}
}
