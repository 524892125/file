package model

import (
	"context"

	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ WechatDailyDataModel = (*customWechatDailyDataModel)(nil)

type (
	// WechatDailyDataModel is an interface to be customized, add more methods here,
	// and implement the added methods in customWechatDailyDataModel.
	WechatDailyDataModel interface {
		wechatDailyDataModel
		withSession(session sqlx.Session) WechatDailyDataModel
		UpsertByAppIDRefDateColumnKey(ctx context.Context, data *WechatDailyData) error
	}

	customWechatDailyDataModel struct {
		*defaultWechatDailyDataModel
	}
)

// NewWechatDailyDataModel returns a model for the database table.
func NewWechatDailyDataModel(conn sqlx.SqlConn) WechatDailyDataModel {
	return &customWechatDailyDataModel{
		defaultWechatDailyDataModel: newWechatDailyDataModel(conn),
	}
}

func (m *customWechatDailyDataModel) withSession(session sqlx.Session) WechatDailyDataModel {
	return NewWechatDailyDataModel(sqlx.NewSqlConnFromSession(session))
}
