package model

import (
	"context"
	"fmt"
)

func (m *customWechatDailyDataModel) UpsertByAppIDRefDateColumnKey(ctx context.Context, data *WechatDailyData) error {
	query := fmt.Sprintf(`
insert into %s (appid, metric, column_key, ref_date, num, base_data, created_at, updated_at)
values ($1, $2, $3, $4, $5, $6, $7, $8)
on conflict (appid, ref_date, column_key)
do update set
    metric = excluded.metric,
    num = excluded.num,
    base_data = excluded.base_data,
    updated_at = excluded.updated_at`, m.table)
	_, err := m.conn.ExecCtx(ctx, query,
		data.Appid,
		data.Metric,
		data.ColumnKey,
		data.RefDate,
		data.Num,
		data.BaseData,
		data.CreatedAt,
		data.UpdatedAt,
	)
	return err
}
