package model

import (
	"context"
	"fmt"
)

func (m *customWechatDailyDataModel) UpsertByAppIDRefDate(ctx context.Context, data *WechatDailyData) error {
	query := fmt.Sprintf(`
insert into %s (
    appid, ref_date, active_users, avg_active_user_stay_seconds,
    active_user_retention_1d, active_user_retention_7d, registered_users,
    registered_user_retention_1d, registered_user_retention_7d,
    registered_user_age_profile, registered_user_gender_profile,
    registered_user_province_profile, registered_user_city_profile,
    registered_user_device_profile, paid_users, pay_penetration_rate,
    new_paid_users, paid_user_retention_1d, paid_user_retention_7d,
    new_paid_user_retention_1d, new_paid_user_retention_7d,
    payment_amount, paid_user_arppu, new_payment_amount, new_paid_user_arppu,
    ad_revenue_after_share, ad_ltv_1d, ad_ltv_3d, ad_ltv_7d, ad_ltv_30d,
    item_ltv_1d, item_ltv_3d, item_ltv_7d, item_ltv_30d, created_at, updated_at
)
values (
    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
    $11, $12, $13, $14, $15, $16, $17, $18, $19, $20,
    $21, $22, $23, $24, $25, $26, $27, $28, $29, $30,
    $31, $32, $33, $34, $35, $36
)
on conflict (appid, ref_date)
do update set
    active_users = excluded.active_users,
    avg_active_user_stay_seconds = excluded.avg_active_user_stay_seconds,
    active_user_retention_1d = excluded.active_user_retention_1d,
    active_user_retention_7d = excluded.active_user_retention_7d,
    registered_users = excluded.registered_users,
    registered_user_retention_1d = excluded.registered_user_retention_1d,
    registered_user_retention_7d = excluded.registered_user_retention_7d,
    registered_user_age_profile = excluded.registered_user_age_profile,
    registered_user_gender_profile = excluded.registered_user_gender_profile,
    registered_user_province_profile = excluded.registered_user_province_profile,
    registered_user_city_profile = excluded.registered_user_city_profile,
    registered_user_device_profile = excluded.registered_user_device_profile,
    paid_users = excluded.paid_users,
    pay_penetration_rate = excluded.pay_penetration_rate,
    new_paid_users = excluded.new_paid_users,
    paid_user_retention_1d = excluded.paid_user_retention_1d,
    paid_user_retention_7d = excluded.paid_user_retention_7d,
    new_paid_user_retention_1d = excluded.new_paid_user_retention_1d,
    new_paid_user_retention_7d = excluded.new_paid_user_retention_7d,
    payment_amount = excluded.payment_amount,
    paid_user_arppu = excluded.paid_user_arppu,
    new_payment_amount = excluded.new_payment_amount,
    new_paid_user_arppu = excluded.new_paid_user_arppu,
    ad_revenue_after_share = excluded.ad_revenue_after_share,
    ad_ltv_1d = excluded.ad_ltv_1d,
    ad_ltv_3d = excluded.ad_ltv_3d,
    ad_ltv_7d = excluded.ad_ltv_7d,
    ad_ltv_30d = excluded.ad_ltv_30d,
    item_ltv_1d = excluded.item_ltv_1d,
    item_ltv_3d = excluded.item_ltv_3d,
    item_ltv_7d = excluded.item_ltv_7d,
    item_ltv_30d = excluded.item_ltv_30d,
    updated_at = excluded.updated_at`, m.table)
	_, err := m.conn.ExecCtx(ctx, query,
		data.Appid,
		data.RefDate,
		data.ActiveUsers,
		data.AvgActiveUserStaySeconds,
		data.ActiveUserRetention1D,
		data.ActiveUserRetention7D,
		data.RegisteredUsers,
		data.RegisteredUserRetention1D,
		data.RegisteredUserRetention7D,
		data.RegisteredUserAgeProfile,
		data.RegisteredUserGenderProfile,
		data.RegisteredUserProvinceProfile,
		data.RegisteredUserCityProfile,
		data.RegisteredUserDeviceProfile,
		data.PaidUsers,
		data.PayPenetrationRate,
		data.NewPaidUsers,
		data.PaidUserRetention1D,
		data.PaidUserRetention7D,
		data.NewPaidUserRetention1D,
		data.NewPaidUserRetention7D,
		data.PaymentAmount,
		data.PaidUserArppu,
		data.NewPaymentAmount,
		data.NewPaidUserArppu,
		data.AdRevenueAfterShare,
		data.AdLtv1D,
		data.AdLtv3D,
		data.AdLtv7D,
		data.AdLtv30D,
		data.ItemLtv1D,
		data.ItemLtv3D,
		data.ItemLtv7D,
		data.ItemLtv30D,
		data.CreatedAt,
		data.UpdatedAt,
	)
	return err
}
