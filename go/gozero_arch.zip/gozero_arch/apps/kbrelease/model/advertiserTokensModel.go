package model

import "github.com/zeromicro/go-zero/core/stores/sqlx"

var _ AdvertiserTokensModel = (*customAdvertiserTokensModel)(nil)

type (
	// AdvertiserTokensModel is an interface to be customized, add more methods here,
	// and implement the added methods in customAdvertiserTokensModel.
	AdvertiserTokensModel interface {
		advertiserTokensModel
		withSession(session sqlx.Session) AdvertiserTokensModel
	}

	customAdvertiserTokensModel struct {
		*defaultAdvertiserTokensModel
	}
)

// NewAdvertiserTokensModel returns a model for the database table.
func NewAdvertiserTokensModel(conn sqlx.SqlConn) AdvertiserTokensModel {
	return &customAdvertiserTokensModel{
		defaultAdvertiserTokensModel: newAdvertiserTokensModel(conn),
	}
}

func (m *customAdvertiserTokensModel) withSession(session sqlx.Session) AdvertiserTokensModel {
	return NewAdvertiserTokensModel(sqlx.NewSqlConnFromSession(session))
}
