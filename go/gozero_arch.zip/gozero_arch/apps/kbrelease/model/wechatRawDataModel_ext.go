package model

import (
	"context"
	"fmt"
)

func (m *customWechatRawDataModel) UpsertByAppIDMetricGranularityDimensionDateValue(ctx context.Context, data *WechatRawData) error {
	query := fmt.Sprintf(`
insert into %s (app_id, metric, granularity, dimesion, ref_date, ts, dimension_label, dimension_value, metric_value, raw_data)
values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
on conflict (app_id, metric, granularity, dimesion, ref_date, dimension_value)
do update set
    ts = excluded.ts,
    dimension_label = excluded.dimension_label,
    metric_value = excluded.metric_value,
    raw_data = excluded.raw_data`, m.table)
	_, err := m.conn.ExecCtx(ctx, query,
		data.AppId,
		data.Metric,
		data.Granularity,
		data.Dimesion,
		data.RefDate,
		data.Ts,
		data.DimensionLabel,
		data.DimensionValue,
		data.MetricValue,
		data.RawData,
	)
	return err
}
