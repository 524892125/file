package model

import "github.com/zeromicro/go-zero/core/stores/sqlx"

var _ OceanengineDailyConversionModel = (*customOceanengineDailyConversionModel)(nil)

type (
	// OceanengineDailyConversionModel is an interface to be customized, add more methods here,
	// and implement the added methods in customOceanengineDailyConversionModel.
	OceanengineDailyConversionModel interface {
		oceanengineDailyConversionModel
		withSession(session sqlx.Session) OceanengineDailyConversionModel
	}

	customOceanengineDailyConversionModel struct {
		*defaultOceanengineDailyConversionModel
	}
)

// NewOceanengineDailyConversionModel returns a model for the database table.
func NewOceanengineDailyConversionModel(conn sqlx.SqlConn) OceanengineDailyConversionModel {
	return &customOceanengineDailyConversionModel{
		defaultOceanengineDailyConversionModel: newOceanengineDailyConversionModel(conn),
	}
}

func (m *customOceanengineDailyConversionModel) withSession(session sqlx.Session) OceanengineDailyConversionModel {
	return NewOceanengineDailyConversionModel(sqlx.NewSqlConnFromSession(session))
}
