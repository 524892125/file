package model

import (
	"context"

	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ WechatRawDataModel = (*customWechatRawDataModel)(nil)

type (
	// WechatRawDataModel is an interface to be customized, add more methods here,
	// and implement the added methods in customWechatRawDataModel.
	WechatRawDataModel interface {
		wechatRawDataModel
		withSession(session sqlx.Session) WechatRawDataModel
		UpsertByAppIDMetricGranularityDimensionDateValue(ctx context.Context, data *WechatRawData) error
	}

	customWechatRawDataModel struct {
		*defaultWechatRawDataModel
	}
)

// NewWechatRawDataModel returns a model for the database table.
func NewWechatRawDataModel(conn sqlx.SqlConn) WechatRawDataModel {
	return &customWechatRawDataModel{
		defaultWechatRawDataModel: newWechatRawDataModel(conn),
	}
}

func (m *customWechatRawDataModel) withSession(session sqlx.Session) WechatRawDataModel {
	return NewWechatRawDataModel(sqlx.NewSqlConnFromSession(session))
}
