package model

import "github.com/zeromicro/go-zero/core/stores/sqlx"

var _ OceanengineDailyOtherModel = (*customOceanengineDailyOtherModel)(nil)

type (
	// OceanengineDailyOtherModel is an interface to be customized, add more methods here,
	// and implement the added methods in customOceanengineDailyOtherModel.
	OceanengineDailyOtherModel interface {
		oceanengineDailyOtherModel
		withSession(session sqlx.Session) OceanengineDailyOtherModel
	}

	customOceanengineDailyOtherModel struct {
		*defaultOceanengineDailyOtherModel
	}
)

// NewOceanengineDailyOtherModel returns a model for the database table.
func NewOceanengineDailyOtherModel(conn sqlx.SqlConn) OceanengineDailyOtherModel {
	return &customOceanengineDailyOtherModel{
		defaultOceanengineDailyOtherModel: newOceanengineDailyOtherModel(conn),
	}
}

func (m *customOceanengineDailyOtherModel) withSession(session sqlx.Session) OceanengineDailyOtherModel {
	return NewOceanengineDailyOtherModel(sqlx.NewSqlConnFromSession(session))
}
