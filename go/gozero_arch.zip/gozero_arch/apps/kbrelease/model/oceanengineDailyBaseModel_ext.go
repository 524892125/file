package model

import (
	"context"
	"fmt"
)

func (m *customOceanengineDailyBaseModel) ReplaceByDimensions(ctx context.Context, data *OceanengineDailyBase) error {
	query := fmt.Sprintf(`delete from %s
where advertiser_id = $1
  and ref_date = $2
  and type is not distinct from $3
  and cdp_project_id is not distinct from $4
  and gender is not distinct from $5
  and age is not distinct from $6
  and platform is not distinct from $7
  and city_name is not distinct from $8
  and image_mode is not distinct from $9`, m.table)
	_, err := m.conn.ExecCtx(ctx, query,
		data.AdvertiserId,
		data.RefDate,
		data.Type,
		data.CdpProjectId,
		data.Gender,
		data.Age,
		data.Platform,
		data.CityName,
		data.ImageMode,
	)
	if err != nil {
		return err
	}
	_, err = m.Insert(ctx, data)
	return err
}
