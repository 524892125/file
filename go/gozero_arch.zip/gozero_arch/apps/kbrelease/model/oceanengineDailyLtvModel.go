package model

import "github.com/zeromicro/go-zero/core/stores/sqlx"

var _ OceanengineDailyLtvModel = (*customOceanengineDailyLtvModel)(nil)

type (
	// OceanengineDailyLtvModel is an interface to be customized, add more methods here,
	// and implement the added methods in customOceanengineDailyLtvModel.
	OceanengineDailyLtvModel interface {
		oceanengineDailyLtvModel
		withSession(session sqlx.Session) OceanengineDailyLtvModel
	}

	customOceanengineDailyLtvModel struct {
		*defaultOceanengineDailyLtvModel
	}
)

// NewOceanengineDailyLtvModel returns a model for the database table.
func NewOceanengineDailyLtvModel(conn sqlx.SqlConn) OceanengineDailyLtvModel {
	return &customOceanengineDailyLtvModel{
		defaultOceanengineDailyLtvModel: newOceanengineDailyLtvModel(conn),
	}
}

func (m *customOceanengineDailyLtvModel) withSession(session sqlx.Session) OceanengineDailyLtvModel {
	return NewOceanengineDailyLtvModel(sqlx.NewSqlConnFromSession(session))
}
