package model

import (
	"context"

	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ OceanengineDailySummaryModel = (*customOceanengineDailySummaryModel)(nil)

type (
	// OceanengineDailySummaryModel is an interface to be customized, add more methods here,
	// and implement the added methods in customOceanengineDailySummaryModel.
	OceanengineDailySummaryModel interface {
		oceanengineDailySummaryModel
		UpsertByAdvertiserDate(ctx context.Context, data *OceanengineDailySummary) error
		withSession(session sqlx.Session) OceanengineDailySummaryModel
	}

	customOceanengineDailySummaryModel struct {
		*defaultOceanengineDailySummaryModel
	}
)

// NewOceanengineDailySummaryModel returns a model for the database table.
func NewOceanengineDailySummaryModel(conn sqlx.SqlConn) OceanengineDailySummaryModel {
	return &customOceanengineDailySummaryModel{
		defaultOceanengineDailySummaryModel: newOceanengineDailySummaryModel(conn),
	}
}

func (m *customOceanengineDailySummaryModel) UpsertByAdvertiserDate(ctx context.Context, data *OceanengineDailySummary) error {
	existing, err := m.FindOneByAdvertiserIdRefDate(ctx, data.AdvertiserId, data.RefDate)
	if err == nil {
		data.Id = existing.Id
		data.CreatedAt = existing.CreatedAt
		return m.Update(ctx, data)
	}
	if err != ErrNotFound {
		return err
	}
	_, err = m.Insert(ctx, data)
	return err
}

func (m *customOceanengineDailySummaryModel) withSession(session sqlx.Session) OceanengineDailySummaryModel {
	return NewOceanengineDailySummaryModel(sqlx.NewSqlConnFromSession(session))
}
