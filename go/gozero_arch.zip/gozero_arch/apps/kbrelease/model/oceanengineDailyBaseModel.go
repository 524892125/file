package model

import (
	"context"

	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ OceanengineDailyBaseModel = (*customOceanengineDailyBaseModel)(nil)

type (
	// OceanengineDailyBaseModel is an interface to be customized, add more methods here,
	// and implement the added methods in customOceanengineDailyBaseModel.
	OceanengineDailyBaseModel interface {
		oceanengineDailyBaseModel
		ReplaceByDimensions(ctx context.Context, data *OceanengineDailyBase) error
		withSession(session sqlx.Session) OceanengineDailyBaseModel
	}

	customOceanengineDailyBaseModel struct {
		*defaultOceanengineDailyBaseModel
	}
)

// NewOceanengineDailyBaseModel returns a model for the database table.
func NewOceanengineDailyBaseModel(conn sqlx.SqlConn) OceanengineDailyBaseModel {
	return &customOceanengineDailyBaseModel{
		defaultOceanengineDailyBaseModel: newOceanengineDailyBaseModel(conn),
	}
}

func (m *customOceanengineDailyBaseModel) withSession(session sqlx.Session) OceanengineDailyBaseModel {
	return NewOceanengineDailyBaseModel(sqlx.NewSqlConnFromSession(session))
}
