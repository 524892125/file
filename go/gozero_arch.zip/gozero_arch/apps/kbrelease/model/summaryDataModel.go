package model

import (
	"context"

	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ SummaryDataModel = (*customSummaryDataModel)(nil)

type (
	// SummaryDataModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSummaryDataModel.
	SummaryDataModel interface {
		summaryDataModel
		withSession(session sqlx.Session) SummaryDataModel
		UpsertMetricByAppIDRefDate(ctx context.Context, data *SummaryData, columnKey string) error
	}

	customSummaryDataModel struct {
		*defaultSummaryDataModel
	}
)

// NewSummaryDataModel returns a model for the database table.
func NewSummaryDataModel(conn sqlx.SqlConn) SummaryDataModel {
	return &customSummaryDataModel{
		defaultSummaryDataModel: newSummaryDataModel(conn),
	}
}

func (m *customSummaryDataModel) withSession(session sqlx.Session) SummaryDataModel {
	return NewSummaryDataModel(sqlx.NewSqlConnFromSession(session))
}
