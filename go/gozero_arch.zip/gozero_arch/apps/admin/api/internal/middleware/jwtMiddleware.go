// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package middleware

import (
	"context"
	"net/http"
	"strings"
	"sync"

	"civet/apps/admin/api/internal/config"
	"civet/apps/admin/api/internal/types"

	"github.com/golang-jwt/jwt/v4"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/rest/httpx"
)

type authClaimsContextKey string

const claimsContextKey authClaimsContextKey = "adminAuthClaims"

type JwtMiddleware struct {
}

var (
	jwtCfgMu sync.RWMutex
	jwtCfg   config.JWTConfig
)

func ConfigureJwt(cfg config.JWTConfig) {
	jwtCfgMu.Lock()
	jwtCfg = cfg
	jwtCfgMu.Unlock()
}

func currentJwtCfg() config.JWTConfig {
	jwtCfgMu.RLock()
	defer jwtCfgMu.RUnlock()
	return jwtCfg
}

func NewJwtMiddleware() *JwtMiddleware {
	return &JwtMiddleware{}
}

func WithAuthClaims(ctx context.Context, claims *types.AuthClaims) context.Context {
	return context.WithValue(ctx, claimsContextKey, claims)
}

func AuthClaimsFromContext(ctx context.Context) (*types.AuthClaims, bool) {
	claims, ok := ctx.Value(claimsContextKey).(*types.AuthClaims)
	return claims, ok && claims != nil
}

func (m *JwtMiddleware) Handle(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		claims, err := m.parseAuthClaims(r)
		if err != nil {
			writeUnauthorized(r, w, err.Error())
			return
		}

		next(w, r.WithContext(WithAuthClaims(r.Context(), claims)))
	}
}

func (m *JwtMiddleware) parseAuthClaims(r *http.Request) (*types.AuthClaims, error) {
	tokenString, err := bearerToken(r.Header.Get("Authorization"))
	if err != nil {
		return nil, err
	}
	cfg := currentJwtCfg()
	if strings.TrimSpace(cfg.Secret) == "" {
		return nil, errUnauthorized("jwt secret is not configured")
	}

	claims := new(types.AuthClaims)
	token, err := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, errUnauthorized("token invalid")
		}
		return []byte(cfg.Secret), nil
	})
	if err != nil || !token.Valid {
		return nil, errUnauthorized("token invalid")
	}

	requestTenant := resolveTenantCode(r, claims.TenantCode)
	if requestTenant != "" && claims.TenantCode != "" && requestTenant != claims.TenantCode {
		return nil, errUnauthorized("tenant not match token")
	}
	logx.Infof("jwtjwt %#v", claims)
	return claims, nil
}

func bearerToken(authHeader string) (string, error) {
	tokenString := strings.TrimSpace(authHeader)
	if tokenString == "" {
		return "", errUnauthorized("missing authorization token")
	}
	if strings.HasPrefix(strings.ToLower(tokenString), "bearer ") {
		tokenString = strings.TrimSpace(tokenString[7:])
	}
	if tokenString == "" {
		return "", errUnauthorized("missing authorization token")
	}
	return tokenString, nil
}

func resolveTenantCode(r *http.Request, fallback string) string {
	for _, candidate := range []string{
		r.Header.Get("X-Tenant-Code"),
		r.URL.Query().Get("tenantCode"),
		r.URL.Query().Get("projectCode"),
		fallback,
	} {
		if value := strings.TrimSpace(candidate); value != "" {
			return value
		}
	}
	return ""
}

func writeUnauthorized(r *http.Request, w http.ResponseWriter, msg string) {
	httpx.WriteJsonCtx(r.Context(), w, http.StatusUnauthorized, map[string]any{
		"code": http.StatusUnauthorized,
		"msg":  msg,
	})
}

type unauthorizedError string

func errUnauthorized(msg string) error {
	return unauthorizedError(msg)
}

func (e unauthorizedError) Error() string {
	return string(e)
}
