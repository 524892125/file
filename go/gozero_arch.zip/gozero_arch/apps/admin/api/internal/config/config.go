// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package config

import (
	"github.com/zeromicro/go-zero/core/stores/sqlx"
	"github.com/zeromicro/go-zero/rest"
)

type Config struct {
	rest.RestConf
	Pg  sqlx.SqlConf
	Jwt JWTConfig `json:"jwt,optional"`
}

type JWTConfig struct {
	Secret  string `json:"secret,optional"`
	Timeout int64  `json:"timeout,optional"`
}
