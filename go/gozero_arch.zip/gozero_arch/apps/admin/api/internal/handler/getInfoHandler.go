// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package handler

import (
	"net/http"

	"civet/apps/admin/api/internal/logic"
	"civet/apps/admin/api/internal/svc"
	"civet/apps/admin/api/internal/types"
	"civet/com/common"
	"github.com/zeromicro/go-zero/rest/httpx"
)

func GetInfoHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req types.GetInfoReq
		if err := httpx.Parse(r, &req); err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
			return
		}

		l := logic.NewGetInfoLogic(r.Context(), svcCtx)
		resp, err := l.GetInfo(&req, r)
		common.Response(w, resp, err)
	}
}
