// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package logic

import (
	"context"
	"errors"
	"strings"
	"time"

	"civet/apps/admin/api/internal/svc"
	"civet/apps/admin/api/internal/types"
	"civet/apps/admin/model"

	"github.com/golang-jwt/jwt/v4"
	"github.com/zeromicro/go-zero/core/logx"
	"golang.org/x/crypto/bcrypt"
)

type LoginLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewLoginLogic(ctx context.Context, svcCtx *svc.ServiceContext) *LoginLogic {
	return &LoginLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *LoginLogic) Login(req *types.LoginReq) (resp *types.LoginResp, err error) {
	username := strings.TrimSpace(req.UserName)
	password := strings.TrimSpace(req.Password)
	if username == "" || password == "" {
		return nil, errors.New("username or password is empty")
	}

	users, _, err := l.svcCtx.SysUserModel.FindPageByFields(l.ctx, 1, 1, []model.SysUserPageField{
		{
			Field: "username",
			Value: username,
			Op:    "=",
		},
	})
	if err != nil {
		return nil, err
	}
	if len(users) == 0 {
		return nil, errors.New("username or password is incorrect")
	}

	user := users[0]
	logx.Infof("usersusers %#v", user)
	if user.DeletedAt.Valid || strings.TrimSpace(user.Status.String) != "2" {
		return nil, errors.New("user is disabled")
	}
	if !passwordLoginAllowed(user.AllowPasswordLogin) {
		return nil, errors.New("password login not allowed")
	}
	if bcrypt.CompareHashAndPassword([]byte(user.Password.String), []byte(password)) != nil {
		return nil, errors.New("username or password is incorrect")
	}

	role, err := l.svcCtx.SysRoleModel.FindOne(l.ctx, user.RoleId.Int64)
	if err != nil {
		return nil, err
	}
	if role.DeletedAt.Valid || strings.TrimSpace(role.Status.String) != "2" {
		return nil, errors.New("role is disabled")
	}

	token, err := l.generateToken(user, role)
	if err != nil {
		return nil, err
	}

	return &types.LoginResp{Token: token}, nil
}

func passwordLoginAllowed(flag string) bool {
	flag = strings.TrimSpace(flag)
	return flag == "" || flag == "2"
}

func (l *LoginLogic) generateToken(user *model.SysUser, role *model.SysRole) (string, error) {
	secret := strings.TrimSpace(l.svcCtx.Config.Jwt.Secret)
	if secret == "" {
		return "", errors.New("jwt secret is not configured")
	}

	timeout := l.svcCtx.Config.Jwt.Timeout
	if timeout <= 0 {
		timeout = 3600
	}

	now := time.Now()
	claims := types.AuthClaims{
		UserId:     user.UserId,
		Username:   strings.TrimSpace(user.Username.String),
		RoleId:     role.RoleId,
		RoleKey:    strings.TrimSpace(role.RoleKey.String),
		RoleName:   strings.TrimSpace(role.RoleName.String),
		DataScope:  strings.TrimSpace(role.DataScope.String),
		TenantCode: "",
		RegisteredClaims: jwt.RegisteredClaims{
			IssuedAt:  jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(time.Duration(timeout) * time.Second)),
		},
	}

	return jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString([]byte(secret))
}
