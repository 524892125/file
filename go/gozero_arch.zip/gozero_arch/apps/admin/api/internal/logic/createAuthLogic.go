// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package logic

import (
	"context"

	"civet/apps/admin/api/internal/svc"
	"civet/apps/admin/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateAuthLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewCreateAuthLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateAuthLogic {
	return &CreateAuthLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *CreateAuthLogic) CreateAuth(req *types.Request) error {
	// todo: add your logic here and delete this line

	return nil
}
