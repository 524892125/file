// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package logic

import (
	"context"
	"encoding/json"
	"errors"

	"civet/apps/admin/api/internal/svc"
	"civet/apps/admin/api/internal/types"
	"civet/apps/admin/model"

	"github.com/zeromicro/go-zero/core/logx"
)

type ExtFeishuConfigLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewExtFeishuConfigLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ExtFeishuConfigLogic {
	return &ExtFeishuConfigLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ExtFeishuConfigLogic) ExtFeishuConfig(req *types.ExtFeishuConfigReq) (resp *types.ExtFeishuConfigResp, err error) {

	dbFieldValue := "feishu_login_qh"
	if req.Type == "kb" {
		dbFieldValue = "feishu_login_kb"
	}
	rows, _, err := l.svcCtx.SysConfigModel.FindPageByFields(l.ctx, 1, 1, []model.SysConfigPageField{
		{Field: "config_key", Value: dbFieldValue, Op: "="},
	})
	if err != nil {
		return nil, err
	}
	if len(rows) == 0 || !rows[0].ConfigValue.Valid {
		return nil, errors.New("feishu config not found")
	}

	var cfg struct {
		AppID       string `json:"appId"`
		AppSecret   string `json:"appSecret"`
		RedirectUrl string `json:"redirectUrl"`
		BaseUrl     string `json:"baseUrl"`
	}
	if err := json.Unmarshal([]byte(rows[0].ConfigValue.String), &cfg); err != nil {
		return nil, err
	}

	return &types.ExtFeishuConfigResp{
		AppID:       cfg.AppID,
		AppSecret:   cfg.AppSecret,
		RedirectURI: cfg.RedirectUrl,
		BaseURL:     cfg.BaseUrl,
	}, nil
}
