// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package logic

import (
	"context"

	"civet/apps/admin/api/internal/svc"
	"civet/apps/admin/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type ExtSaveRoleMenuLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewExtSaveRoleMenuLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ExtSaveRoleMenuLogic {
	return &ExtSaveRoleMenuLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ExtSaveRoleMenuLogic) ExtSaveRoleMenu(req *types.ExtSaveRoleMenuReq) (resp *types.ExtSaveRoleMenuResp, err error) {
	if _, err := l.svcCtx.SysRoleModel.FindOne(l.ctx, req.RoleId); err != nil {
		return nil, err
	}
	if err := l.svcCtx.SysRoleMenuModel.ReplaceByRoleID(l.ctx, req.RoleId, req.MenuIds); err != nil {
		return nil, err
	}

	return &types.ExtSaveRoleMenuResp{}, nil
}
