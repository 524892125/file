// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package logic

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"civet/apps/admin/api/internal/svc"
	"civet/apps/admin/api/internal/types"
	"civet/apps/admin/model"

	"github.com/zeromicro/go-zero/core/logx"
)

type ExtFeishuLoginLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewExtFeishuLoginLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ExtFeishuLoginLogic {
	return &ExtFeishuLoginLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ExtFeishuLoginLogic) ExtFeishuLogin(req *types.ExtFeishuLoginReq) (resp *types.LoginResp, err error) {
	code := strings.TrimSpace(req.Code)
	if code == "" {
		return nil, errors.New("code is required")
	}

	cfg, err := l.loadFeishuConfig(req.Type)
	if err != nil {
		return nil, err
	}

	accessToken, err := l.exchangeToken(cfg, code)
	if err != nil {
		return nil, fmt.Errorf("exchange feishu token: %w", err)
	}

	userInfo, err := requestFeishuUserInfo(*cfg, accessToken)
	if err != nil {
		return nil, fmt.Errorf("get feishu user info: %w", err)
	}

	user, err := l.matchLocalUser(userInfo)
	if err != nil {
		return nil, err
	}

	if user.DeletedAt.Valid || strings.TrimSpace(user.Status.String) != "2" {
		return nil, errors.New("user is disabled")
	}

	role, err := l.svcCtx.SysRoleModel.FindOne(l.ctx, user.RoleId.Int64)
	if err != nil {
		return nil, err
	}
	if role.DeletedAt.Valid || strings.TrimSpace(role.Status.String) != "2" {
		return nil, errors.New("role is disabled")
	}

	token, err := generateToken(l.svcCtx, user, role)
	if err != nil {
		return nil, err
	}

	return &types.LoginResp{Token: token}, nil
}

func (l *ExtFeishuLoginLogic) loadFeishuConfig(qrType string) (*types.ExtFeishuConfigResp, error) {
	dbFieldValue := "feishu_login_qh"
	if qrType == "kb" {
		dbFieldValue = "feishu_login_kb"
	}
	rows, _, err := l.svcCtx.SysConfigModel.FindPageByFields(l.ctx, 1, 1, []model.SysConfigPageField{
		{Field: "config_key", Value: dbFieldValue, Op: "="},
	})
	if err != nil {
		return nil, err
	}
	if len(rows) == 0 || !rows[0].ConfigValue.Valid {
		return nil, errors.New("feishu config not found")
	}

	var cfg types.ExtFeishuConfigResp
	if err := json.Unmarshal([]byte(rows[0].ConfigValue.String), &cfg); err != nil {
		return nil, err
	}
	return &cfg, nil
}

func (l *ExtFeishuLoginLogic) exchangeToken(cfg *types.ExtFeishuConfigResp, code string) (string, error) {
	baseURL := strings.TrimRight(strings.TrimSpace(cfg.BaseURL), "/")
	if baseURL == "" {
		return "", errors.New("empty feishu base_url from sys_config")
	}

	body, err := doFeishuRequest(http.MethodPost, baseURL+"/suite/passport/oauth/token", map[string]string{
		"Content-Type": "application/json",
	}, map[string]string{
		"grant_type":    "authorization_code",
		"client_id":     cfg.AppID,
		"app_id":        cfg.AppID,
		"client_secret": cfg.AppSecret,
		"app_secret":    cfg.AppSecret,
		"code":          code,
	})
	if err != nil {
		return "", err
	}

	var resp types.FeishuTokenResp
	if err := json.Unmarshal(body, &resp); err != nil {
		return "", err
	}
	if resp.AccessToken == "" {
		return "", errors.New("empty access_token from feishu")
	}
	return resp.AccessToken, nil
}

func (l *ExtFeishuLoginLogic) matchLocalUser(info types.FeishuUserInfo) (*model.SysUser, error) {
	email := strings.TrimSpace(info.Email)
	mobile := strings.TrimSpace(info.Mobile)
	mobile = strings.TrimPrefix(mobile, "+86")

	if email == "" && mobile == "" {
		return nil, errors.New("feishu user has no email or mobile")
	}

	if email != "" {
		users, _, err := l.svcCtx.SysUserModel.FindPageByFields(l.ctx, 1, 1, []model.SysUserPageField{
			{Field: "email", Value: email, Op: "="},
		})
		if err != nil {
			return nil, err
		}
		if len(users) > 0 {
			return users[0], nil
		}
	}

	if mobile != "" {
		users, _, err := l.svcCtx.SysUserModel.FindPageByFields(l.ctx, 1, 1, []model.SysUserPageField{
			{Field: "phone", Value: mobile, Op: "="},
		})
		if err != nil {
			return nil, err
		}
		if len(users) > 0 {
			return users[0], nil
		}
	}

	return nil, errors.New("账号在后台不存在")
}

func requestFeishuUserInfo(cfg types.ExtFeishuConfigResp, accessToken string) (types.FeishuUserInfo, error) {
	baseURL := strings.TrimRight(strings.TrimSpace(cfg.BaseURL), "/")
	if baseURL == "" {
		return types.FeishuUserInfo{}, errors.New("empty feishu base_url from sys_config")
	}

	body, err := doFeishuRequest(http.MethodGet, baseURL+"/suite/passport/oauth/userinfo", map[string]string{
		"Authorization": "Bearer " + accessToken,
	}, nil)
	if err != nil {
		return types.FeishuUserInfo{}, err
	}

	var resp types.FeishuUserInfoResp
	if err = json.Unmarshal(body, &resp); err != nil {
		return types.FeishuUserInfo{}, err
	}

	profile := resp.Data
	if profile.Name == "" {
		profile.Name = resp.Name
	}
	if profile.EnName == "" {
		profile.EnName = resp.EnName
	}
	if profile.AvatarURL == "" {
		profile.AvatarURL = resp.AvatarURL
	}
	if profile.Email == "" {
		profile.Email = resp.Email
	}
	if profile.EnterpriseMail == "" {
		profile.EnterpriseMail = resp.EnterpriseMail
	}
	if profile.Mobile == "" {
		profile.Mobile = resp.Mobile
	}
	if profile.OpenID == "" {
		profile.OpenID = resp.OpenID
	}
	if profile.UnionID == "" {
		profile.UnionID = resp.UnionID
	}
	if profile.UserID == "" {
		profile.UserID = resp.UserID
	}
	if profile.Name == "" && profile.Email == "" && profile.Mobile == "" {
		return types.FeishuUserInfo{}, errors.New("empty userinfo in feishu response")
	}
	return profile, nil
}

func doFeishuRequest(method string, endpoint string, headers map[string]string, payload any) ([]byte, error) {
	var bodyReader io.Reader
	if payload != nil {
		body, err := json.Marshal(payload)
		if err != nil {
			return nil, err
		}
		bodyReader = bytes.NewReader(body)
	}

	req, err := http.NewRequest(method, endpoint, bodyReader)
	if err != nil {
		return nil, err
	}
	for key, value := range headers {
		req.Header.Set(key, value)
	}
	if payload != nil {
		req.Header.Set("Content-Type", "application/json")
	}

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode < http.StatusOK || resp.StatusCode >= http.StatusMultipleChoices {
		return nil, fmt.Errorf("feishu request failed: status=%d body=%s", resp.StatusCode, strings.TrimSpace(string(body)))
	}
	return body, nil
}
