// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package svc

import (
	"civet/apps/admin/api/internal/config"

	"civet/apps/admin/model"

	"civet/apps/admin/api/internal/middleware"
	_ "github.com/lib/pq"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
	"github.com/zeromicro/go-zero/rest"
)

type ServiceContext struct {
	Config config.Config
	// Code generated model fields. DO NOT EDIT.
	AppRuntimeLogModel model.AppRuntimeLogModel
	SysConfigModel     model.SysConfigModel
	SysMenuModel       model.SysMenuModel
	SysUserModel       model.SysUserModel
	// End generated model fields.
	// Code generated middleware fields. DO NOT EDIT.
	JwtMiddleware        rest.Middleware
	PermissionMiddleware rest.Middleware
	// End generated middleware fields.
}

func NewServiceContext(c config.Config) *ServiceContext {
	conn := sqlx.NewSqlConn(c.Pg.DriverName, c.Pg.DataSource)

	middleware.ConfigureJwt(c.Jwt)

	return &ServiceContext{
		Config: c,
		// Code generated model init. DO NOT EDIT.
		AppRuntimeLogModel: model.NewAppRuntimeLogModel(conn),
		SysConfigModel:     model.NewSysConfigModel(conn),
		SysMenuModel:       model.NewSysMenuModel(conn),
		SysUserModel:       model.NewSysUserModel(conn),
		// End generated model init.
		// Code generated middleware init. DO NOT EDIT.
		JwtMiddleware:        middleware.NewJwtMiddleware().Handle,
		PermissionMiddleware: middleware.NewPermissionMiddleware().Handle,
		// End generated middleware init.
	}
}
