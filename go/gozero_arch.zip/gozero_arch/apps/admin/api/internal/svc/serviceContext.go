// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package svc

import (
	"civet/apps/admin/api/internal/config"

	"civet/apps/admin/model"

	"civet/apps/admin/api/internal/middleware"
	"civet/apps/kbrelease/rpc/kbreleaseClient"

	"civet/apps/cron/rpc/cronClient"
	_ "github.com/lib/pq"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
	"github.com/zeromicro/go-zero/rest"
	"github.com/zeromicro/go-zero/zrpc"
)

type ServiceContext struct {
	Config config.Config
	// Code generated rpc client fields. DO NOT EDIT.
	CronRpc      cronClient.Cron
	KbreleaseRpc kbreleaseClient.Kbrelease
	// End generated rpc client fields.
	// Code generated model fields. DO NOT EDIT.
	AppRuntimeLogModel model.AppRuntimeLogModel
	SysConfigModel     model.SysConfigModel
	SysDeptModel       model.SysDeptModel
	SysDictDataModel   model.SysDictDataModel
	SysDictTypeModel   model.SysDictTypeModel
	SysMenuModel       model.SysMenuModel
	SysRoleDeptModel   model.SysRoleDeptModel
	SysRoleMenuModel   model.SysRoleMenuModel
	SysRoleModel       model.SysRoleModel
	SysUserModel       model.SysUserModel
	// End generated model fields.
	// Code generated middleware fields. DO NOT EDIT.
	JwtMiddleware        rest.Middleware
	PermissionMiddleware rest.Middleware
	// End generated middleware fields.
}

func NewServiceContext(c config.Config) *ServiceContext {
	conn := sqlx.NewSqlConn(c.Pg.DriverName, c.Pg.DataSource)

	middleware.ConfigureJwt(c.Jwt)

	return &ServiceContext{
		Config: c,
		// Code generated rpc client init. DO NOT EDIT.
		CronRpc:      cronClient.NewCron(zrpc.MustNewClient(c.CronRpc)),
		KbreleaseRpc: kbreleaseClient.NewKbrelease(zrpc.MustNewClient(c.KbreleaseRpc)),
		// End generated rpc client init.
		// Code generated model init. DO NOT EDIT.
		AppRuntimeLogModel: model.NewAppRuntimeLogModel(conn),
		SysConfigModel:     model.NewSysConfigModel(conn),
		SysDeptModel:       model.NewSysDeptModel(conn),
		SysDictDataModel:   model.NewSysDictDataModel(conn),
		SysDictTypeModel:   model.NewSysDictTypeModel(conn),
		SysMenuModel:       model.NewSysMenuModel(conn),
		SysRoleDeptModel:   model.NewSysRoleDeptModel(conn),
		SysRoleMenuModel:   model.NewSysRoleMenuModel(conn),
		SysRoleModel:       model.NewSysRoleModel(conn),
		SysUserModel:       model.NewSysUserModel(conn),
		// End generated model init.
		// Code generated middleware init. DO NOT EDIT.
		JwtMiddleware:        middleware.NewJwtMiddleware().Handle,
		PermissionMiddleware: middleware.NewPermissionMiddleware().Handle,
		// End generated middleware init.
	}
}
