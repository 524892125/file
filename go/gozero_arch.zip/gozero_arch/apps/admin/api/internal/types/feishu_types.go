package types

type FeishuUserInfo struct {
	Name           string `json:"name"`
	EnName         string `json:"en_name"`
	AvatarURL      string `json:"avatar_url"`
	Email          string `json:"email"`
	EnterpriseMail string `json:"enterprise_email"`
	Mobile         string `json:"mobile"`
	OpenID         string `json:"open_id"`
	UnionID        string `json:"union_id"`
	UserID         string `json:"user_id"`
}

type FeishuUserInfoResp struct {
	Name           string         `json:"name"`
	EnName         string         `json:"en_name"`
	AvatarURL      string         `json:"avatar_url"`
	Email          string         `json:"email"`
	EnterpriseMail string         `json:"enterprise_email"`
	Mobile         string         `json:"mobile"`
	OpenID         string         `json:"open_id"`
	UnionID        string         `json:"union_id"`
	UserID         string         `json:"user_id"`
	Data           FeishuUserInfo `json:"data"`
}

type FeishuTokenResp struct {
	AccessToken string `json:"access_token"`
	OpenID      string `json:"open_id"`
}
