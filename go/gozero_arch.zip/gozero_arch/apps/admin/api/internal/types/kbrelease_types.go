package types

type RpcOceanengineAdvertiser struct {
	AdvertiserId   int64  `json:"advertiserId"`
	AdvertiserName string `json:"advertiserName"`
}

type RpcOceanengineAdvertiserListReq struct {
	AdvertiserId int64 `json:"advertiserId"`
}

type RpcOceanengineAdvertiserListResp struct {
	List []RpcOceanengineAdvertiser `json:"list"`
}
