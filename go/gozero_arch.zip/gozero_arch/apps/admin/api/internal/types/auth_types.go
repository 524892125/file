package types

import "github.com/golang-jwt/jwt/v4"

type AuthClaims struct {
	UserId     int64  `json:"userId"`
	Username   string `json:"username"`
	RoleId     int64  `json:"roleId"`
	RoleKey    string `json:"roleKey"`
	RoleName   string `json:"roleName"`
	DataScope  string `json:"dataScope"`
	TenantCode string `json:"tenantCode"`
	jwt.RegisteredClaims
}
