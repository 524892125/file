# admin RPC API 契约目录

`rpcapi/` 用于放置 admin API 调用后端 RPC 服务的手写 HTTP API spec。

## 目录边界

- `dbapi/`：只放 SQL/DDL 自动生成的 CRUD API spec。
- `rpcapi/`：只放 admin API 作为网关调用 RPC 的手写 API spec。
- `rpcapi/*.api` 只定义 HTTP 请求、响应和路由契约，不放 RPC proto 或 RPC client 代码。

## 命名规则

- 文件名必须使用 lowerCamel 业务名，例如 `krPublish.api`、`kbRelease.api`。
- 不使用表名、页面名或随意缩写命名。
- 新增 `rpcapi/*.api` 后，必须手工在 `../admin.api` 的 import block 中引入。

## 鉴权约束

- `rpcapi/*.api` 中的业务路由必须走 admin API 的 JWT/权限中间件。
- 外部请求不得绕过 admin API 直连后端 RPC。
- JWT 解析、账号状态校验、权限判断和 operator 上下文装配由 admin API logic 完成。
