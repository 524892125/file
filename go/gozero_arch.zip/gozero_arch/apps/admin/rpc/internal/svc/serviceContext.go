package svc

import (
	"civet/apps/admin/model"
	"civet/apps/admin/rpc/internal/config"

	_ "github.com/lib/pq"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

type ServiceContext struct {
	Config config.Config
	// Code generated rpc model fields. DO NOT EDIT.
	AppRuntimeLogModel model.AppRuntimeLogModel
	SysConfigModel     model.SysConfigModel
	SysDeptModel       model.SysDeptModel
	SysDictDataModel   model.SysDictDataModel
	SysDictTypeModel   model.SysDictTypeModel
	SysMenuModel       model.SysMenuModel
	SysRoleModel       model.SysRoleModel
	SysRoleDeptModel   model.SysRoleDeptModel
	SysRoleMenuModel   model.SysRoleMenuModel
	SysUserModel       model.SysUserModel
	// End generated rpc model fields.
}

func NewServiceContext(c config.Config) *ServiceContext {
	conn := sqlx.NewSqlConn(c.Pg.DriverName, c.Pg.DataSource)

	return &ServiceContext{
		Config: c,
		// Code generated rpc model init. DO NOT EDIT.
		AppRuntimeLogModel: model.NewAppRuntimeLogModel(conn),
		SysConfigModel:     model.NewSysConfigModel(conn),
		SysDeptModel:       model.NewSysDeptModel(conn),
		SysDictDataModel:   model.NewSysDictDataModel(conn),
		SysDictTypeModel:   model.NewSysDictTypeModel(conn),
		SysMenuModel:       model.NewSysMenuModel(conn),
		SysRoleModel:       model.NewSysRoleModel(conn),
		SysRoleDeptModel:   model.NewSysRoleDeptModel(conn),
		SysRoleMenuModel:   model.NewSysRoleMenuModel(conn),
		SysUserModel:       model.NewSysUserModel(conn),
		// End generated rpc model init.
	}
}
