package model

import (
	"context"
	"fmt"
)

func (m *customSysMenuModel) DeleteWithChildren(ctx context.Context, menuId int64) error {
	query := fmt.Sprintf(`
with recursive menu_tree as (
	select menu_id
	from %s
	where menu_id = $1
	union all
	select child.menu_id
	from %s child
	inner join menu_tree parent on child.parent_id = parent.menu_id
)
delete from %s
where menu_id in (select menu_id from menu_tree)
`, m.table, m.table, m.table)
	_, err := m.conn.ExecCtx(ctx, query, menuId)
	return err
}
