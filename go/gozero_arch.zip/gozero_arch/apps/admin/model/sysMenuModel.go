package model

import "github.com/zeromicro/go-zero/core/stores/sqlx"

var _ SysMenuModel = (*customSysMenuModel)(nil)

type (
	// SysMenuModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSysMenuModel.
	SysMenuModel interface {
		sysMenuModel
		withSession(session sqlx.Session) SysMenuModel
	}

	customSysMenuModel struct {
		*defaultSysMenuModel
	}
)

// NewSysMenuModel returns a model for the database table.
func NewSysMenuModel(conn sqlx.SqlConn) SysMenuModel {
	return &customSysMenuModel{
		defaultSysMenuModel: newSysMenuModel(conn),
	}
}

func (m *customSysMenuModel) withSession(session sqlx.Session) SysMenuModel {
	return NewSysMenuModel(sqlx.NewSqlConnFromSession(session))
}
