package model

import "github.com/zeromicro/go-zero/core/stores/sqlx"

var _ CoupleWeekRankModel = (*customCoupleWeekRankModel)(nil)

type (
	// CoupleWeekRankModel is an interface to be customized, add more methods here,
	// and implement the added methods in customCoupleWeekRankModel.
	CoupleWeekRankModel interface {
		coupleWeekRankModel
		withSession(session sqlx.Session) CoupleWeekRankModel
	}

	customCoupleWeekRankModel struct {
		*defaultCoupleWeekRankModel
	}
)

// NewCoupleWeekRankModel returns a model for the database table.
func NewCoupleWeekRankModel(conn sqlx.SqlConn) CoupleWeekRankModel {
	return &customCoupleWeekRankModel{
		defaultCoupleWeekRankModel: newCoupleWeekRankModel(conn),
	}
}

func (m *customCoupleWeekRankModel) withSession(session sqlx.Session) CoupleWeekRankModel {
	return NewCoupleWeekRankModel(sqlx.NewSqlConnFromSession(session))
}
