package model

import (
	"context"

	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ SysRoleMenuModel = (*customSysRoleMenuModel)(nil)

type (
	// SysRoleMenuModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSysRoleMenuModel.
	SysRoleMenuModel interface {
		sysRoleMenuModel
		withSession(session sqlx.Session) SysRoleMenuModel
		InsertWithGeneratedID(ctx context.Context, roleId, menuId int64) (int64, error)
		DeleteByRoleID(ctx context.Context, roleId int64) error
		ReplaceByRoleID(ctx context.Context, roleId int64, menuIds []int64) error
	}

	customSysRoleMenuModel struct {
		*defaultSysRoleMenuModel
	}
)

// NewSysRoleMenuModel returns a model for the database table.
func NewSysRoleMenuModel(conn sqlx.SqlConn) SysRoleMenuModel {
	return &customSysRoleMenuModel{
		defaultSysRoleMenuModel: newSysRoleMenuModel(conn),
	}
}

func (m *customSysRoleMenuModel) withSession(session sqlx.Session) SysRoleMenuModel {
	return NewSysRoleMenuModel(sqlx.NewSqlConnFromSession(session))
}
