package model

import (
	"context"
	"fmt"
	"sort"

	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

func (m *customSysRoleMenuModel) InsertWithGeneratedID(ctx context.Context, roleId, menuId int64) (int64, error) {
	query := fmt.Sprintf("insert into %s (role_id, menu_id) values ($1, $2) returning id", m.table)
	var resp int64
	if err := m.conn.QueryRowCtx(ctx, &resp, query, roleId, menuId); err != nil {
		return 0, err
	}
	return resp, nil
}

func (m *customSysRoleMenuModel) DeleteByRoleID(ctx context.Context, roleId int64) error {
	query := fmt.Sprintf("delete from %s where role_id = $1", m.table)
	_, err := m.conn.ExecCtx(ctx, query, roleId)
	return err
}

func (m *customSysRoleMenuModel) ReplaceByRoleID(ctx context.Context, roleId int64, menuIds []int64) error {
	cleaned := uniqueSysRoleMenuIDs(menuIds)
	return m.conn.TransactCtx(ctx, func(txCtx context.Context, session sqlx.Session) error {
		txModel := NewSysRoleMenuModel(sqlx.NewSqlConnFromSession(session))
		if err := txModel.DeleteByRoleID(txCtx, roleId); err != nil {
			return err
		}
		for _, menuId := range cleaned {
			if _, err := txModel.InsertWithGeneratedID(txCtx, roleId, menuId); err != nil {
				return err
			}
		}
		return nil
	})
}

func uniqueSysRoleMenuIDs(menuIds []int64) []int64 {
	seen := make(map[int64]struct{}, len(menuIds))
	result := make([]int64, 0, len(menuIds))
	for _, menuId := range menuIds {
		if menuId <= 0 {
			continue
		}
		if _, ok := seen[menuId]; ok {
			continue
		}
		seen[menuId] = struct{}{}
		result = append(result, menuId)
	}
	sort.Slice(result, func(i, j int) bool {
		return result[i] < result[j]
	})
	return result
}
