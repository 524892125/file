package model

import "github.com/zeromicro/go-zero/core/stores/sqlx"

var _ AppRuntimeLogModel = (*customAppRuntimeLogModel)(nil)

type (
	// AppRuntimeLogModel is an interface to be customized, add more methods here,
	// and implement the added methods in customAppRuntimeLogModel.
	AppRuntimeLogModel interface {
		appRuntimeLogModel
		withSession(session sqlx.Session) AppRuntimeLogModel
	}

	customAppRuntimeLogModel struct {
		*defaultAppRuntimeLogModel
	}
)

// NewAppRuntimeLogModel returns a model for the database table.
func NewAppRuntimeLogModel(conn sqlx.SqlConn) AppRuntimeLogModel {
	return &customAppRuntimeLogModel{
		defaultAppRuntimeLogModel: newAppRuntimeLogModel(conn),
	}
}

func (m *customAppRuntimeLogModel) withSession(session sqlx.Session) AppRuntimeLogModel {
	return NewAppRuntimeLogModel(sqlx.NewSqlConnFromSession(session))
}
