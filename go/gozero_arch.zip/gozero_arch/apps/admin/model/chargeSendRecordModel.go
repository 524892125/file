package model

import "github.com/zeromicro/go-zero/core/stores/sqlx"

var _ ChargeSendRecordModel = (*customChargeSendRecordModel)(nil)

type (
	// ChargeSendRecordModel is an interface to be customized, add more methods here,
	// and implement the added methods in customChargeSendRecordModel.
	ChargeSendRecordModel interface {
		chargeSendRecordModel
		withSession(session sqlx.Session) ChargeSendRecordModel
	}

	customChargeSendRecordModel struct {
		*defaultChargeSendRecordModel
	}
)

// NewChargeSendRecordModel returns a model for the database table.
func NewChargeSendRecordModel(conn sqlx.SqlConn) ChargeSendRecordModel {
	return &customChargeSendRecordModel{
		defaultChargeSendRecordModel: newChargeSendRecordModel(conn),
	}
}

func (m *customChargeSendRecordModel) withSession(session sqlx.Session) ChargeSendRecordModel {
	return NewChargeSendRecordModel(sqlx.NewSqlConnFromSession(session))
}
