package model

import "github.com/zeromicro/go-zero/core/stores/sqlx"

var _ ActivityGroupJoinModel = (*customActivityGroupJoinModel)(nil)

type (
	// ActivityGroupJoinModel is an interface to be customized, add more methods here,
	// and implement the added methods in customActivityGroupJoinModel.
	ActivityGroupJoinModel interface {
		activityGroupJoinModel
		withSession(session sqlx.Session) ActivityGroupJoinModel
	}

	customActivityGroupJoinModel struct {
		*defaultActivityGroupJoinModel
	}
)

// NewActivityGroupJoinModel returns a model for the database table.
func NewActivityGroupJoinModel(conn sqlx.SqlConn) ActivityGroupJoinModel {
	return &customActivityGroupJoinModel{
		defaultActivityGroupJoinModel: newActivityGroupJoinModel(conn),
	}
}

func (m *customActivityGroupJoinModel) withSession(session sqlx.Session) ActivityGroupJoinModel {
	return NewActivityGroupJoinModel(sqlx.NewSqlConnFromSession(session))
}
