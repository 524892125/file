package model

import (
	"context"
	"fmt"

	"github.com/zeromicro/go-zero/core/stores/sqlc"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ ActivityRewardConfModel = (*customActivityRewardConfModel)(nil)

type (
	// ActivityRewardConfModel is an interface to be customized, add more methods here,
	// and implement the added methods in customActivityRewardConfModel.
	ActivityRewardConfModel interface {
		activityRewardConfModel
		withSession(session sqlx.Session) ActivityRewardConfModel
	}

	customActivityRewardConfModel struct {
		*defaultActivityRewardConfModel
	}
)

// NewActivityRewardConfModel returns a model for the database table.
func NewActivityRewardConfModel(conn sqlx.SqlConn) ActivityRewardConfModel {
	return &customActivityRewardConfModel{
		defaultActivityRewardConfModel: newActivityRewardConfModel(conn),
	}
}

func (m *customActivityRewardConfModel) withSession(session sqlx.Session) ActivityRewardConfModel {
	return NewActivityRewardConfModel(sqlx.NewSqlConnFromSession(session))
}

func (m *defaultActivityRewardConfModel) FindByActType(ctx context.Context, actType int64) ([]*ActivityRewardConf, error) {
	query := fmt.Sprintf("select %s from %s where `actType` = ?", activityRewardConfRows, m.table)
	var resp []*ActivityRewardConf
	err := m.conn.QueryRowsCtx(ctx, &resp, query, actType)
	switch err {
	case nil:
		return resp, nil
	case sqlc.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
