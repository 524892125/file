package svc

import (
	"civet/apps/user/rpc/internal/config"
	"civet/com/redistore"
	"civet/core/redisx"

	gzredis "github.com/zeromicro/go-zero/core/stores/redis"
)

type ServiceContext struct {
	Config     config.Config
	Redis      *gzredis.Redis
	RedisStore *redistore.Store
}

func NewServiceContext(c config.Config) *ServiceContext {
	rds := gzredis.MustNewRedis(c.Redis)

	return &ServiceContext{
		Config:     c,
		Redis:      rds,
		RedisStore: redistore.New(redisx.NewGoZeroStore(rds)),
	}
}
