import webapi from "./gocliRequest"
import * as components from "./userComponents"
export * from "./userComponents"

/**
 * @description 
 */
export function createAuth() {
	return webapi.post<null>(`/users/auth/create`)
}

/**
 * @description 
 */
export function getUser() {
	return webapi.get<components.Response>(`/users/id/${userId}`)
}
