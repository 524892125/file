package svc

import (
	"civet/apps/cron/model"
	"civet/apps/cron/rpc/internal/config"
	"civet/apps/cron/rpc/internal/invoker"
	"civet/apps/cron/rpc/internal/scheduler"
	"civet/apps/kbrelease/rpc/kbreleaseClient"

	_ "github.com/lib/pq"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
	"github.com/zeromicro/go-zero/zrpc"
)

type ServiceContext struct {
	Config       config.Config
	Scheduler    *scheduler.Scheduler
	Invokers     *scheduler.Registry
	KbreleaseRpc kbreleaseClient.Kbrelease
	// Code generated rpc model fields. DO NOT EDIT.
	CronTaskModel       model.CronTaskModel
	CronTaskRunLogModel model.CronTaskRunLogModel
	// End generated rpc model fields.
}

func NewServiceContext(c config.Config) *ServiceContext {
	conn := sqlx.NewSqlConn(c.Pg.DriverName, c.Pg.DataSource)

	cronTaskModel := model.NewCronTaskModel(conn)
	cronTaskRunLogModel := model.NewCronTaskRunLogModel(conn)
	invokers := scheduler.NewRegistry()
	kbreleaseRpc := kbreleaseClient.NewKbrelease(zrpc.MustNewClient(c.KbreleaseRpc))
	invoker.RegisterKbrelease(invokers, kbreleaseRpc)
	s := scheduler.New(c.Scheduler, cronTaskModel, cronTaskRunLogModel, invokers)
	s.Start()

	return &ServiceContext{
		Config:       c,
		Scheduler:    s,
		Invokers:     invokers,
		KbreleaseRpc: kbreleaseRpc,
		// Code generated rpc model init. DO NOT EDIT.
		CronTaskModel:       cronTaskModel,
		CronTaskRunLogModel: cronTaskRunLogModel,
		// End generated rpc model init.
	}
}

func (s *ServiceContext) Stop() {
	if s.Scheduler != nil {
		s.Scheduler.Stop()
	}
}
