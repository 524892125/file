package scheduler

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"sync"

	"civet/apps/cron/model"
)

type InvokeRequest struct {
	Task         *model.CronTask
	Service      string
	Method       string
	InvokeTarget string
	Payload      map[string]any
}

type Invoker func(ctx context.Context, req InvokeRequest) error

type Registry struct {
	mu       sync.RWMutex
	invokers map[string]Invoker
}

func NewRegistry() *Registry {
	return &Registry{invokers: make(map[string]Invoker)}
}

func (r *Registry) Register(target string, invoker Invoker) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.invokers[normalizeTarget(target)] = invoker
}

func (r *Registry) Invoke(ctx context.Context, task *model.CronTask) error {
	target, payload, err := resolveTarget(task)
	if err != nil {
		return err
	}

	r.mu.RLock()
	invoker := r.invokers[normalizeTarget(target)]
	r.mu.RUnlock()
	if invoker == nil {
		return fmt.Errorf("cron target not registered: %s", target)
	}

	service, method, _ := strings.Cut(target, ".")
	return invoker(ctx, InvokeRequest{
		Task:         task,
		Service:      service,
		Method:       method,
		InvokeTarget: target,
		Payload:      payload,
	})
}

func resolveTarget(task *model.CronTask) (string, map[string]any, error) {
	payload := map[string]any{}
	if strings.TrimSpace(task.Payload) != "" {
		if err := json.Unmarshal([]byte(task.Payload), &payload); err != nil {
			return "", nil, fmt.Errorf("invalid cron task payload: %w", err)
		}
	}

	target := strings.TrimSpace(task.TaskKey)
	if raw, ok := payload["invokeTarget"].(string); ok && strings.TrimSpace(raw) != "" {
		target = strings.TrimSpace(raw)
	}
	target = normalizeTarget(target)
	if target == "" || !strings.Contains(target, ".") {
		return "", nil, fmt.Errorf("invalid cron invoke target: %s", target)
	}
	return target, payload, nil
}

func normalizeTarget(target string) string {
	target = strings.TrimSpace(target)
	target = strings.TrimPrefix(target, "rpc://")
	target = strings.TrimPrefix(target, "/")
	return target
}
