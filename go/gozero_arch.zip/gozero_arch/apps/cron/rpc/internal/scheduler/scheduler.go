package scheduler

import (
	"context"
	"errors"
	"fmt"
	"os"
	"sync"
	"time"

	"civet/apps/cron/model"
	"civet/apps/cron/rpc/internal/config"

	"github.com/zeromicro/go-zero/core/logx"
)

type Scheduler struct {
	conf      config.SchedulerConf
	taskModel model.CronTaskModel
	logModel  model.CronTaskRunLogModel
	registry  *Registry
	workerID  string

	ctx    context.Context
	cancel context.CancelFunc
	wg     sync.WaitGroup
}

func New(conf config.SchedulerConf, taskModel model.CronTaskModel, logModel model.CronTaskRunLogModel, registry *Registry) *Scheduler {
	if conf.PollInterval <= 0 {
		conf.PollInterval = time.Second
	}
	if conf.LeaseDuration <= 0 {
		conf.LeaseDuration = 30 * time.Second
	}
	if conf.ExecutionTimeout <= 0 {
		conf.ExecutionTimeout = 5 * time.Minute
	}
	if conf.MaxBatchSize <= 0 {
		conf.MaxBatchSize = 10
	}

	workerID := conf.WorkerID
	if workerID == "" {
		host, _ := os.Hostname()
		workerID = fmt.Sprintf("%s-%d", host, os.Getpid())
	}

	ctx, cancel := context.WithCancel(context.Background())
	return &Scheduler{
		conf:      conf,
		taskModel: taskModel,
		logModel:  logModel,
		registry:  registry,
		workerID:  workerID,
		ctx:       ctx,
		cancel:    cancel,
	}
}

func (s *Scheduler) Start() {
	if !s.conf.Enabled {
		logx.Infof("cron scheduler disabled")
		return
	}
	logx.Infof("cron scheduler started: worker_id=%s poll_interval=%s lease_duration=%s max_batch_size=%d execution_timeout=%s",
		s.workerID, s.conf.PollInterval, s.conf.LeaseDuration, s.conf.MaxBatchSize, s.conf.ExecutionTimeout)
	s.wg.Add(1)
	go s.loop()
}

func (s *Scheduler) Stop() {
	s.cancel()
	s.wg.Wait()
}

func (s *Scheduler) loop() {
	defer s.wg.Done()
	ticker := time.NewTicker(s.conf.PollInterval)
	defer ticker.Stop()

	for {
		s.tick()
		select {
		case <-s.ctx.Done():
			return
		case <-ticker.C:
		}
	}
}

func (s *Scheduler) tick() {
	tasks, err := s.taskModel.ClaimDue(s.ctx, s.workerID, s.conf.LeaseDuration, s.conf.MaxBatchSize)
	if err != nil {
		logx.Errorf("claim cron tasks failed: %v", err)
		return
	}
	for _, task := range tasks {
		task := task
		s.wg.Add(1)
		go func() {
			defer s.wg.Done()
			s.run(task)
		}()
	}
}

func (s *Scheduler) run(task *model.CronTask) {
	startedAt := time.Now()
	ctx, cancel := context.WithTimeout(s.ctx, s.conf.ExecutionTimeout)
	err := s.registry.Invoke(ctx, task)
	cancel()

	finishedAt := time.Now()
	status := model.CronTaskRunStatusSuccess
	message := "ok"
	if err != nil {
		status = model.CronTaskRunStatusFailed
		message = err.Error()
	}
	if errors.Is(ctx.Err(), context.DeadlineExceeded) {
		status = model.CronTaskRunStatusFailed
		message = "task execution timeout"
	}

	bg := context.Background()
	if err := s.logModel.Record(bg, task.Id, s.workerID, status, message, startedAt, finishedAt); err != nil {
		logx.Errorf("record cron task log failed: task_id=%d err=%v", task.Id, err)
	}
	if err := s.taskModel.CompleteRun(bg, task, s.workerID, finishedAt); err != nil {
		logx.Errorf("complete cron task failed: task_id=%d err=%v", task.Id, err)
	}
}
