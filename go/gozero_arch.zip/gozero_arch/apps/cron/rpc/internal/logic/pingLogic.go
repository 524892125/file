package logic

import (
	"context"

	"civet/apps/cron/rpc/cron"
	"civet/apps/cron/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type PingLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewPingLogic(ctx context.Context, svcCtx *svc.ServiceContext) *PingLogic {
	return &PingLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *PingLogic) Ping(in *cron.Request) (*cron.Response, error) {
	// todo: add your logic here and delete this line

	return &cron.Response{}, nil
}
