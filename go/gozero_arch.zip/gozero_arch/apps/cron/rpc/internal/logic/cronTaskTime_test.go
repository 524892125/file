package logic

import (
	"database/sql"
	"testing"
	"time"
)

func TestCronTaskTimeUsesShanghaiLocation(t *testing.T) {
	const input = "2026-05-14 14:48:31"

	parsed := parseUpdateCronTaskTime(input)
	if got := parsed.In(time.UTC).Format(time.DateTime); got != "2026-05-14 06:48:31" {
		t.Fatalf("parseUpdateCronTaskTime() UTC = %s, want 2026-05-14 06:48:31", got)
	}
	if got := formatGetCronTaskTime(parsed); got != input {
		t.Fatalf("formatGetCronTaskTime() = %s, want %s", got, input)
	}
	if got := formatListCronTaskTime(parsed); got != input {
		t.Fatalf("formatListCronTaskTime() = %s, want %s", got, input)
	}
	if got := formatFindPageCronTaskTime(parsed); got != input {
		t.Fatalf("formatFindPageCronTaskTime() = %s, want %s", got, input)
	}
}

func TestCronTaskNullTimeUsesShanghaiLocation(t *testing.T) {
	const input = "2026-05-14 14:48:31"

	parsed := parseCreateCronTaskNullTime(input)
	if !parsed.Valid {
		t.Fatal("parseCreateCronTaskNullTime() should be valid")
	}
	if got := formatGetCronTaskNullTime(sql.NullTime{Time: parsed.Time, Valid: true}); got != input {
		t.Fatalf("formatGetCronTaskNullTime() = %s, want %s", got, input)
	}
}

func TestCronTaskNextRunAtDefaultsToRunAt(t *testing.T) {
	const input = "2026-05-14 14:59:19"

	runAt := parseCreateCronTaskTime(input)
	createNextRunAt := defaultCreateCronTaskNextRunAt("", runAt)
	if !createNextRunAt.Valid {
		t.Fatal("defaultCreateCronTaskNextRunAt() should be valid")
	}
	if got := formatGetCronTaskNullTime(createNextRunAt); got != input {
		t.Fatalf("defaultCreateCronTaskNextRunAt() = %s, want %s", got, input)
	}

	updateNextRunAt := defaultUpdateCronTaskNextRunAt("", runAt)
	if !updateNextRunAt.Valid {
		t.Fatal("defaultUpdateCronTaskNextRunAt() should be valid")
	}
	if got := formatGetCronTaskNullTime(updateNextRunAt); got != input {
		t.Fatalf("defaultUpdateCronTaskNextRunAt() = %s, want %s", got, input)
	}
}
