package invoker

import (
	"context"

	"civet/apps/cron/rpc/internal/scheduler"
	"civet/apps/kbrelease/rpc/kbreleaseClient"
)

func RegisterKbrelease(registry *scheduler.Registry, client kbreleaseClient.Kbrelease) {
	registry.Register("kbrelease.ping", func(ctx context.Context, req scheduler.InvokeRequest) error {
		_, err := client.Ping(ctx, &kbreleaseClient.Request{Ping: req.Task.Payload})
		return err
	})

	registry.Register("kbrelease.rpcPullWechatData", func(ctx context.Context, req scheduler.InvokeRequest) error {
		_, err := client.RpcPullWechatData(ctx, &kbreleaseClient.PullWechatDataReq{Payload: req.Task.Payload})
		return err
	})

	registry.Register("kbrelease.rpcPullOceanengineData", func(ctx context.Context, req scheduler.InvokeRequest) error {
		_, err := client.RpcPullOceanengineData(ctx, &kbreleaseClient.PullOceanengineDataReq{Payload: req.Task.Payload})
		return err
	})
	registry.Register("kbrelease.RrcRefreshOceanToken", func(ctx context.Context, req scheduler.InvokeRequest) error {
		_, err := client.RpcRefreshOceanToken(ctx, &kbreleaseClient.RefreshOceanTokenReq{Payload: req.Task.Payload})
		return err
	})
}
