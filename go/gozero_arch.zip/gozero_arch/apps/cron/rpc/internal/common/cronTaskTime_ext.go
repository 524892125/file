package common

import (
	"database/sql"
	"time"
)

var cronTaskLocation = loadCronTaskLocation()

func loadCronTaskLocation() *time.Location {
	loc, err := time.LoadLocation("Asia/Shanghai")
	if err != nil {
		return time.FixedZone("Asia/Shanghai", 8*60*60)
	}
	return loc
}

func ParseCronTaskTimeValue(value string) time.Time {
	if value == "" {
		return time.Time{}
	}
	if t, err := time.ParseInLocation(time.DateTime, value, cronTaskLocation); err == nil {
		return t
	}
	if t, err := time.ParseInLocation(time.DateOnly, value, cronTaskLocation); err == nil {
		return t
	}
	if t, err := time.Parse(time.RFC3339, value); err == nil {
		return t.In(cronTaskLocation)
	}
	return time.Time{}
}

func ParseCronTaskNullTime(value string) sql.NullTime {
	if value == "" {
		return sql.NullTime{}
	}
	t := ParseCronTaskTimeValue(value)
	if t.IsZero() {
		return sql.NullTime{}
	}
	return sql.NullTime{Time: t, Valid: true}
}

func DefaultCronTaskNextRunAt(nextRunAt string, runAt time.Time) sql.NullTime {
	if parsed := ParseCronTaskNullTime(nextRunAt); parsed.Valid {
		return parsed
	}
	if runAt.IsZero() {
		return sql.NullTime{}
	}
	return sql.NullTime{Time: runAt, Valid: true}
}

func FormatCronTaskTime(value time.Time) string {
	if value.IsZero() {
		return ""
	}
	return value.In(cronTaskLocation).Format(time.DateTime)
}

func FormatCronTaskNullTime(value sql.NullTime) string {
	if !value.Valid {
		return ""
	}
	return FormatCronTaskTime(value.Time)
}
