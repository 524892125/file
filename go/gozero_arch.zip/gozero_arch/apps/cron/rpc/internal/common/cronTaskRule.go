package common

import (
	"database/sql"
	"fmt"
	"strings"
	"time"

	"civet/apps/cron/model"
	"civet/core/util"
)

func NormalizeScheduleType(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case model.CronTaskSchedulePeriodic, "interval":
		return model.CronTaskSchedulePeriodic
	default:
		return model.CronTaskScheduleOnce
	}
}

func NormalizeTaskStatus(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case model.CronTaskStatusDisabled:
		return model.CronTaskStatusDisabled
	default:
		return model.CronTaskStatusEnabled
	}
}

func ValidateCronTask(scheduleType string, runAt time.Time, intervalSeconds int64) error {
	if runAt.IsZero() {
		return fmt.Errorf("runAt is required")
	}
	if scheduleType == model.CronTaskSchedulePeriodic && intervalSeconds <= 0 {
		return fmt.Errorf("intervalSeconds is required for periodic task")
	}
	if scheduleType == model.CronTaskScheduleOnce && intervalSeconds < 0 {
		return fmt.Errorf("intervalSeconds must be greater than or equal to 0")
	}
	return nil
}

func ParseCronTaskTime(value string) (time.Time, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return time.Time{}, nil
	}
	if t := util.ParseShanghaiTimeValue(value); !t.IsZero() {
		return t, nil
	}
	return time.Time{}, fmt.Errorf("invalid time %q, expected yyyy-mm-dd hh:mm:ss", value)
}

func NextRunAtForStatus(status string, runAt time.Time) sql.NullTime {
	if status != model.CronTaskStatusEnabled {
		return sql.NullTime{}
	}
	return sql.NullTime{Time: runAt, Valid: true}
}
