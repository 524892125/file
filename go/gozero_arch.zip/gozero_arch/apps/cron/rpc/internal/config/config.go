package config

import (
	"time"

	"github.com/zeromicro/go-zero/core/stores/sqlx"
	"github.com/zeromicro/go-zero/zrpc"
)

type Config struct {
	zrpc.RpcServerConf
	LogSql       bool `json:",default=true"`
	Pg           sqlx.SqlConf
	KbreleaseRpc zrpc.RpcClientConf `json:"kbreleaseRpc,optional"`
	Scheduler    SchedulerConf      `json:"scheduler,optional"`
}

type SchedulerConf struct {
	Enabled          bool          `json:",default=true"`
	WorkerID         string        `json:",optional"`
	PollInterval     time.Duration `json:",default=1s"`
	LeaseDuration    time.Duration `json:",default=30s"`
	MaxBatchSize     int           `json:",default=10"`
	ExecutionTimeout time.Duration `json:",default=5m"`
}
