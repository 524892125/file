// Code scaffolded by goctl. Safe to edit.
// goctl 1.10.1

package svc

import (
	"civet/apps/cron/api/internal/config"
	"civet/apps/cron/model"
	_ "github.com/lib/pq"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

type ServiceContext struct {
	Config config.Config
	// Code generated model fields. DO NOT EDIT.
	CronTaskModel       model.CronTaskModel
	CronTaskRunLogModel model.CronTaskRunLogModel
	// End generated model fields.
	// Code generated middleware fields. DO NOT EDIT.
	// End generated middleware fields.
}

func NewServiceContext(c config.Config) *ServiceContext {
	conn := sqlx.NewSqlConn(c.Pg.DriverName, c.Pg.DataSource)

	return &ServiceContext{
		Config: c,
		// Code generated model init. DO NOT EDIT.
		CronTaskModel:       model.NewCronTaskModel(conn),
		CronTaskRunLogModel: model.NewCronTaskRunLogModel(conn),
		// End generated model init.
		// Code generated middleware init. DO NOT EDIT.
		// End generated middleware init.
	}
}
