package model

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

const (
	CronTaskScheduleOnce     = "once"
	CronTaskSchedulePeriodic = "periodic"

	CronTaskStatusEnabled  = "enabled"
	CronTaskStatusDisabled = "disabled"
)

var _ CronTaskModel = (*customCronTaskModel)(nil)

type (
	// CronTaskModel is an interface to be customized, add more methods here,
	// and implement the added methods in customCronTaskModel.
	CronTaskModel interface {
		cronTaskModel
		withSession(session sqlx.Session) CronTaskModel
		ClaimDue(ctx context.Context, workerID string, leaseDuration time.Duration, limit int) ([]*CronTask, error)
		CompleteRun(ctx context.Context, task *CronTask, workerID string, finishedAt time.Time) error
		ReconcileOverdueOnStartup(ctx context.Context, now time.Time) (CronTaskStartupReconcileResult, error)
	}

	customCronTaskModel struct {
		*defaultCronTaskModel
	}

	CronTaskStartupReconcileResult struct {
		DisabledOnceTasks     int64
		AdvancedPeriodicTasks int64
		DisabledInvalidTasks  int64
	}
)

// NewCronTaskModel returns a model for the database table.
func NewCronTaskModel(conn sqlx.SqlConn) CronTaskModel {
	return &customCronTaskModel{
		defaultCronTaskModel: newCronTaskModel(conn),
	}
}

func (m *customCronTaskModel) withSession(session sqlx.Session) CronTaskModel {
	return NewCronTaskModel(sqlx.NewSqlConnFromSession(session))
}

func (m *customCronTaskModel) ClaimDue(ctx context.Context, workerID string, leaseDuration time.Duration, limit int) ([]*CronTask, error) {
	if limit <= 0 {
		limit = 10
	}
	query := fmt.Sprintf(`
update %s
set locked_by = $1,
    locked_until = now() + ($2::text)::interval,
    updated_at = now()
where id in (
  select id
  from %s
  where status = $3
    and next_run_at is not null
    and next_run_at <= now()
    and (locked_until is null or locked_until < now())
  order by next_run_at asc, id asc
  for update skip locked
  limit $4
)
returning %s`, m.table, m.table, cronTaskRows)

	var tasks []*CronTask
	err := m.conn.QueryRowsCtx(ctx, &tasks, query, workerID, pgInterval(leaseDuration), CronTaskStatusEnabled, limit)
	if err == sqlx.ErrNotFound {
		return []*CronTask{}, nil
	}
	return tasks, err
}

func (m *customCronTaskModel) CompleteRun(ctx context.Context, task *CronTask, workerID string, finishedAt time.Time) error {
	nextRunAt, nextStatus := nextTaskState(task, finishedAt)
	query := fmt.Sprintf(`
update %s
set next_run_at = $1,
    last_run_at = $2,
    status = $3,
    locked_by = '',
    locked_until = null,
    updated_at = now()
where id = $4 and locked_by = $5`, m.table)
	_, err := m.conn.ExecCtx(ctx, query, nextRunAt, finishedAt, nextStatus, task.Id, workerID)
	return err
}

func (m *customCronTaskModel) ReconcileOverdueOnStartup(ctx context.Context, now time.Time) (CronTaskStartupReconcileResult, error) {
	var result CronTaskStartupReconcileResult

	disabledOnce, err := m.disableOverdueOnceTasks(ctx, now)
	if err != nil {
		return result, err
	}
	result.DisabledOnceTasks = disabledOnce

	disabledInvalid, err := m.disableInvalidOverduePeriodicTasks(ctx, now)
	if err != nil {
		return result, err
	}
	result.DisabledInvalidTasks = disabledInvalid

	advancedPeriodic, err := m.advanceOverduePeriodicTasks(ctx, now)
	if err != nil {
		return result, err
	}
	result.AdvancedPeriodicTasks = advancedPeriodic

	return result, nil
}

func (m *customCronTaskModel) disableOverdueOnceTasks(ctx context.Context, now time.Time) (int64, error) {
	query := fmt.Sprintf(`
update %s
set status = $1,
    next_run_at = null,
    locked_by = '',
    locked_until = null,
    updated_at = now()
where status = $2
  and schedule_type = $3
  and next_run_at is not null
  and next_run_at < $4`, m.table)
	res, err := m.conn.ExecCtx(ctx, query, CronTaskStatusDisabled, CronTaskStatusEnabled, CronTaskScheduleOnce, now)
	return rowsAffected(res), err
}

func (m *customCronTaskModel) disableInvalidOverduePeriodicTasks(ctx context.Context, now time.Time) (int64, error) {
	query := fmt.Sprintf(`
update %s
set status = $1,
    next_run_at = null,
    locked_by = '',
    locked_until = null,
    updated_at = now()
where status = $2
  and schedule_type = $3
  and interval_seconds <= 0
  and next_run_at is not null
  and next_run_at < $4`, m.table)
	res, err := m.conn.ExecCtx(ctx, query, CronTaskStatusDisabled, CronTaskStatusEnabled, CronTaskSchedulePeriodic, now)
	return rowsAffected(res), err
}

func (m *customCronTaskModel) advanceOverduePeriodicTasks(ctx context.Context, now time.Time) (int64, error) {
	query := fmt.Sprintf(`
update %s
set next_run_at = case
      when run_at > $1 then run_at
      else run_at + ((floor(extract(epoch from ($1 - run_at)) / interval_seconds)::bigint + 1) * interval_seconds) * interval '1 second'
    end,
    locked_by = '',
    locked_until = null,
    updated_at = now()
where status = $2
  and schedule_type = $3
  and interval_seconds > 0
  and next_run_at is not null
  and next_run_at < $1`, m.table)
	res, err := m.conn.ExecCtx(ctx, query, now, CronTaskStatusEnabled, CronTaskSchedulePeriodic)
	return rowsAffected(res), err
}

func nextTaskState(task *CronTask, finishedAt time.Time) (sql.NullTime, string) {
	if task.ScheduleType != CronTaskSchedulePeriodic || task.IntervalSeconds <= 0 {
		return sql.NullTime{}, CronTaskStatusDisabled
	}
	next := nextPeriodicRunAt(task.RunAt, task.IntervalSeconds, finishedAt)
	return sql.NullTime{Time: next, Valid: true}, CronTaskStatusEnabled
}

func nextPeriodicRunAt(runAt time.Time, intervalSeconds int64, after time.Time) time.Time {
	interval := time.Duration(intervalSeconds) * time.Second
	if interval <= 0 || runAt.After(after) {
		return runAt
	}
	elapsed := after.Sub(runAt)
	steps := elapsed/interval + 1
	return runAt.Add(steps * interval)
}

func pgInterval(duration time.Duration) string {
	seconds := int64(duration.Seconds())
	if seconds < 1 {
		seconds = 1
	}
	return fmt.Sprintf("%d seconds", seconds)
}

func rowsAffected(res sql.Result) int64 {
	if res == nil {
		return 0
	}
	rows, err := res.RowsAffected()
	if err != nil {
		return 0
	}
	return rows
}
