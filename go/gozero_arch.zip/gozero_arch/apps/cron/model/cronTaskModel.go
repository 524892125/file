package model

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

const (
	CronTaskScheduleOnce     = "once"
	CronTaskSchedulePeriodic = "periodic"

	CronTaskStatusEnabled  = "enabled"
	CronTaskStatusDisabled = "disabled"
)

var _ CronTaskModel = (*customCronTaskModel)(nil)

type (
	// CronTaskModel is an interface to be customized, add more methods here,
	// and implement the added methods in customCronTaskModel.
	CronTaskModel interface {
		cronTaskModel
		withSession(session sqlx.Session) CronTaskModel
		ClaimDue(ctx context.Context, workerID string, leaseDuration time.Duration, limit int) ([]*CronTask, error)
		CompleteRun(ctx context.Context, task *CronTask, workerID string, finishedAt time.Time) error
	}

	customCronTaskModel struct {
		*defaultCronTaskModel
	}
)

// NewCronTaskModel returns a model for the database table.
func NewCronTaskModel(conn sqlx.SqlConn) CronTaskModel {
	return &customCronTaskModel{
		defaultCronTaskModel: newCronTaskModel(conn),
	}
}

func (m *customCronTaskModel) withSession(session sqlx.Session) CronTaskModel {
	return NewCronTaskModel(sqlx.NewSqlConnFromSession(session))
}

func (m *customCronTaskModel) ClaimDue(ctx context.Context, workerID string, leaseDuration time.Duration, limit int) ([]*CronTask, error) {
	if limit <= 0 {
		limit = 10
	}
	query := fmt.Sprintf(`
update %s
set locked_by = $1,
    locked_until = now() + ($2::text)::interval,
    updated_at = now()
where id in (
  select id
  from %s
  where status = $3
    and next_run_at is not null
    and next_run_at <= now()
    and (locked_until is null or locked_until < now())
  order by next_run_at asc, id asc
  for update skip locked
  limit $4
)
returning %s`, m.table, m.table, cronTaskRows)

	var tasks []*CronTask
	err := m.conn.QueryRowsCtx(ctx, &tasks, query, workerID, pgInterval(leaseDuration), CronTaskStatusEnabled, limit)
	if err == sqlx.ErrNotFound {
		return []*CronTask{}, nil
	}
	return tasks, err
}

func (m *customCronTaskModel) CompleteRun(ctx context.Context, task *CronTask, workerID string, finishedAt time.Time) error {
	nextRunAt, nextStatus := nextTaskState(task, finishedAt)
	query := fmt.Sprintf(`
update %s
set next_run_at = $1,
    last_run_at = $2,
    status = $3,
    locked_by = '',
    locked_until = null,
    updated_at = now()
where id = $4 and locked_by = $5`, m.table)
	_, err := m.conn.ExecCtx(ctx, query, nextRunAt, finishedAt, nextStatus, task.Id, workerID)
	return err
}

func nextTaskState(task *CronTask, finishedAt time.Time) (sql.NullTime, string) {
	if task.ScheduleType != CronTaskSchedulePeriodic || task.IntervalSeconds <= 0 {
		return sql.NullTime{}, CronTaskStatusDisabled
	}
	next := finishedAt.Add(time.Duration(task.IntervalSeconds) * time.Second)
	return sql.NullTime{Time: next, Valid: true}, CronTaskStatusEnabled
}

func pgInterval(duration time.Duration) string {
	seconds := int64(duration.Seconds())
	if seconds < 1 {
		seconds = 1
	}
	return fmt.Sprintf("%d seconds", seconds)
}
