package model

import (
	"context"
	"time"

	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

const (
	CronTaskRunStatusSuccess = "success"
	CronTaskRunStatusFailed  = "failed"
)

var _ CronTaskRunLogModel = (*customCronTaskRunLogModel)(nil)

type (
	// CronTaskRunLogModel is an interface to be customized, add more methods here,
	// and implement the added methods in customCronTaskRunLogModel.
	CronTaskRunLogModel interface {
		cronTaskRunLogModel
		withSession(session sqlx.Session) CronTaskRunLogModel
		Record(ctx context.Context, taskID int64, workerID, status, message string, startedAt, finishedAt time.Time) error
	}

	customCronTaskRunLogModel struct {
		*defaultCronTaskRunLogModel
	}
)

// NewCronTaskRunLogModel returns a model for the database table.
func NewCronTaskRunLogModel(conn sqlx.SqlConn) CronTaskRunLogModel {
	return &customCronTaskRunLogModel{
		defaultCronTaskRunLogModel: newCronTaskRunLogModel(conn),
	}
}

func (m *customCronTaskRunLogModel) withSession(session sqlx.Session) CronTaskRunLogModel {
	return NewCronTaskRunLogModel(sqlx.NewSqlConnFromSession(session))
}

func (m *customCronTaskRunLogModel) Record(ctx context.Context, taskID int64, workerID, status, message string, startedAt, finishedAt time.Time) error {
	if len(message) > 4000 {
		message = message[:4000]
	}
	_, err := m.Insert(ctx, &CronTaskRunLog{
		TaskId:     taskID,
		WorkerId:   workerID,
		Status:     status,
		Message:    message,
		StartedAt:  startedAt,
		FinishedAt: finishedAt,
		DurationMs: finishedAt.Sub(startedAt).Milliseconds(),
		CreatedAt:  finishedAt,
	})
	return err
}
