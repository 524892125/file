package util

import (
	"bytes"
	"container/list"
	"crypto/md5"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"io/ioutil"
	"math"
	"math/rand"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"strconv"
	"strings"
	"syscall"
	"time"

	"github.com/golang/protobuf/jsonpb"
	"github.com/golang/protobuf/proto"
	"golang.org/x/exp/constraints"
)

// 游戏基础时间,仅仅只是测试用
var WorldBaseTs int64 = 0

func SetWroldBaseTs(ts int64) {
	//不允许时间回溯
	if WorldBaseTs < ts {
		WorldBaseTs = ts
	}
}

func AddWroldBaseTs(ts int64) {
	WorldBaseTs += ts
}

func GetWroldBaseTs() int64 {
	return WorldBaseTs
}

// 返回绝对值
func Abs[T constraints.Signed | constraints.Float](t T) T {
	if t < 0 {
		return -t
	}
	return t
}

// 返回最小值
func Min[T constraints.Integer | constraints.Float](v1, v2 T) T {
	if v1 < v2 {
		return v1
	}
	return v2
}

// 返回最大值
func Max[T constraints.Integer | constraints.Float](v1, v2 T) T {
	if v1 > v2 {
		return v1
	}
	return v2
}

// 比较（关系符字符串）
func Compare[T constraints.Integer | constraints.Float | string](v1, v2 T, rela string) bool {
	switch rela {
	case ">":
		return v1 > v2
	case ">=":
		return v1 >= v2
	case "<":
		return v1 < v2
	case "<=":
		return v1 <= v2
	case "==":
		return v1 == v2
	case "!=":
		return v1 != v2
	}
	return false
}

// 比较（关系符数字）
func Compare1[T constraints.Integer | constraints.Float | string](v1, v2 T, rela uint32) bool {
	switch rela {
	case 1:
		return v1 > v2
	case 2:
		return v1 >= v2
	case 3:
		return v1 < v2
	case 4:
		return v1 <= v2
	case 5:
		return v1 == v2
	case 6:
		return v1 != v2
	}
	return false
}

// 比较值
func Compare2[T constraints.Integer | constraints.Float | string](v1, v2 T, desc bool) bool {
	if desc {
		return v1 > v2
	}
	return v1 < v2
}

// flag标记位
func AddFlag[T constraints.Unsigned](flag T, v T) T {
	return flag | (1 << v)
}

func RemoveFlag[T constraints.Unsigned](flag T, v T) T {
	return flag &^ (1 << v)
}

func HaveFlag[T constraints.Unsigned](flag T, v T) bool {
	return flag&(1<<v) != 0
}

// 判断slice是否相等
func SliceEqual[T comparable](v1, v2 []T) bool {
	if len(v1) != len(v2) {
		return false
	}
	for i := 0; i < len(v1); i++ {
		if v1[i] != v2[i] {
			return false
		}
	}
	return true
}

// 获取slice中最小
func SliceMin[T constraints.Integer | constraints.Float](s []T) T {
	var ret T
	var min int = -1
	for i, v := range s {
		if min == -1 || v < s[min] {
			min = i
		}
	}
	if min != -1 {
		return s[min]
	}
	return ret
}

// 获取slice中最大
func SliceMax[T constraints.Integer | constraints.Float](s []T) T {
	var ret T
	var max int = -1
	for i, v := range s {
		if max == -1 || v > s[max] {
			max = i
		}
	}
	if max != -1 {
		return s[max]
	}
	return ret
}

// 获取最值
func SliceTop[T any](s []T, compare func(int, int) bool) T {
	var ret T
	if compare == nil {
		return ret
	}
	var top int = -1
	for i, _ := range s {
		if top == -1 || compare(i, top) {
			top = i
		}
	}
	if top != -1 {
		return s[top]
	}
	return ret
}

// 判断slice中是否存在某个元素
func InSlice[T comparable](slice []T, elem T) bool {
	for _, v := range slice {
		if v == elem {
			return true
		}
	}
	return false
}

// 移除某个元素
func RemoveSliceElem[T comparable](slice []T, elem T, all bool) []T {
	for i := 0; i < len(slice); i++ {
		if slice[i] == elem {
			slice = append(slice[:i], slice[i+1:]...)
			if all {
				i--
			} else {
				break
			}
		}
	}
	return slice
}

// 移除满足某个条件的元素
func RemoveSliceElem2[T any](slice []T, equal func(i int) bool, all bool) []T {
	for i := 0; i < len(slice); i++ {
		if equal(i) {
			slice = append(slice[:i], slice[i+1:]...)
			if all {
				i--
			} else {
				break
			}
		}
	}
	return slice
}

// 获得满足某个条件的所有元素
func GetSliceElem[T any](slice []T, equal func(i int) bool) []T {
	list := make([]T, 0)
	for i := 0; i < len(slice); i++ {
		if equal(i) {
			list = append(list, slice[i])
		}
	}
	return list
}

// 获得满足某个条件的元素
func GetSliceElem2[T any](slice []T, equal func(i int) bool) T {
	var ret T
	for i := 0; i < len(slice); i++ {
		if equal(i) {
			ret = slice[i]
			break
		}
	}
	return ret
}

// slice唯一化, 如果slice预先排序过，则bSort设置true
func UniqueSlice[T comparable](slice []T, bSort bool) []T {
	if len(slice) < 2 {
		return slice
	}
	for i := 0; i < len(slice); i++ {
		bDel := false
		if bSort {
			if i > 0 && slice[i-1] == slice[i] {
				bDel = true
			}
		} else {
			for j := 0; j < i; j++ {
				if slice[j] == slice[i] {
					bDel = true
					break
				}
			}
		}
		if bDel {
			slice = append(slice[:i], slice[i+1:]...)
			i--
		}
	}
	return slice
}

// slice唯一化, 可设定唯一条件，如果slice预先排序过，则bSort设置true
func UniqueSlice2[T any](slice []T, equal func(i, j int) bool, bSort bool) []T {
	if len(slice) < 2 {
		return slice
	}
	for i := 0; i < len(slice); i++ {
		bDel := false
		if bSort {
			if i > 0 && equal(i-1, i) {
				bDel = true
			}
		} else {
			for j := 0; j < i; j++ {
				if equal(i, j) {
					bDel = true
					break
				}
			}
		}
		if bDel {
			slice = append(slice[:i], slice[i+1:]...)
			i--
		}
	}
	return slice
}

// slice唯一化, 借助map快速实现
func UniqueSlice3[T comparable](slice []T) []T {
	ret := make(map[T]struct{})
	for _, v := range slice {
		ret[v] = struct{}{}
	}
	slice = slice[:0]
	for k, _ := range ret {
		slice = append(slice, k)
	}
	return slice
}

// slice中是否有重复元素
func IsSliceRepeat[T comparable](slice []T) bool {
	ret := make(map[T]struct{})
	for _, v := range slice {
		if _, ok := ret[v]; ok {
			return true
		}
		ret[v] = struct{}{}
	}
	return false
}

// slice中是否有不同的元素
func IsSliceDiff[T comparable](slice []T) bool {
	if len(slice) < 2 {
		return false
	}
	for i := 1; i < len(slice); i++ {
		if slice[i] != slice[i-1] {
			return true
		}
	}
	return false
}

// map深拷贝
func CopyMap[K comparable, V any](m map[K]V) map[K]V {
	ret := make(map[K]V)
	for k, v := range m {
		ret[k] = v
	}
	return ret
}

// map是否相等
func MapEqual[K comparable, V comparable](m1, m2 map[K]V) bool {
	if len(m1) != len(m2) {
		return false
	}
	for k, v := range m1 {
		v2, ok := m2[k]
		if !ok || v2 != v {
			return false
		}
	}
	return true
}

// 随机打乱slice
func RandShuffle[T any](arr []T, num int) {
	RandShuffle2(nil, arr, num)
}

func RandShuffle2[T any](r *rand.Rand, arr []T, num int) {
	if len(arr) < 2 {
		return
	}
	if num <= 0 || num >= len(arr) {
		num = len(arr) - 1
	}
	if r == nil {
		r = rand.New(rand.NewSource(CurNanoSecond()))
	}
	for i := 1; i <= num; i++ {
		index := r.Intn(len(arr)-i+1) + i - 1
		arr[i-1], arr[index] = arr[index], arr[i-1]
	}
}

// 从slice中随机一个元素
func RandSlice[T any](arr []T) T {
	return RandSlice2(nil, arr)
}

func RandSlice2[T any](r *rand.Rand, arr []T) T {
	if len(arr) == 0 {
		var a T
		return a
	} else if len(arr) == 1 {
		return arr[0]
	} else {
		if r != nil {
			return arr[r.Intn(len(arr))]
		} else {
			return arr[rand.Intn(len(arr))]
		}
	}
}

// 权重随机，最优方案应该是区间树
func RandWeight[T comparable](mWeight map[T]uint32) T {
	return RandWeight2(nil, mWeight)
}

func RandWeight2[T comparable](r *rand.Rand, mWeight map[T]uint32) T {
	var t T
	if len(mWeight) == 0 {
		return t
	}
	var sum uint32
	for _, v := range mWeight {
		sum += v
	}
	var rv int
	if sum == 0 {
		if r != nil {
			rv = r.Intn(len(mWeight))
		} else {
			rv = rand.Intn(len(mWeight))
		}
		for k, _ := range mWeight {
			if rv == 0 {
				t = k
				break
			}
			rv--
		}
	} else {
		if r != nil {
			rv = r.Intn(int(sum))
		} else {
			rv = rand.Intn(int(sum))
		}
		for k, v := range mWeight {
			if rv < int(v) {
				t = k
				break
			}
			rv -= int(v)
		}
	}
	return t
}

// 快速排序
func QuickSort[T constraints.Ordered](values []T) {
	if len(values) <= 1 {
		return
	}
	mid, i := values[0], 1
	head, tail := 0, len(values)-1
	for head < tail {
		//      fmt.Println(values)
		if values[i] > mid {
			values[i], values[tail] = values[tail], values[i]
			tail--
		} else {
			values[i], values[head] = values[head], values[i]
			head++
			i++
		}
	}
	values[head] = mid
	QuickSort(values[:head])
	QuickSort(values[head+1:])
}

// 遍历slice集
func traverseSliceSet[T any](ss [][]T, cb func([]T) bool) [][]T {
	var ret [][]T
	if cb == nil {
		var sum int = 1
		for _, s := range ss {
			if len(s) == 0 {
				return ret
			}
			sum *= len(s)
		}
		ret = make([][]T, 0, sum)
	}
	ps := make([]int, len(ss))
	updatePs := func() bool {
		for i := 0; i < len(ps); i++ {
			ps[i]++
			if ps[i] < len(ss[i]) {
				break
			} else {
				if i == len(ps)-1 {
					return false
				}
				ps[i] = 0
			}
		}
		return true
	}
	for {
		elem := make([]T, len(ps))
		for i, p := range ps {
			elem[i] = ss[i][p]
		}
		if cb == nil {
			ret = append(ret, elem)
		} else {
			if !cb(elem) {
				return ret
			}
		}
		if !updatePs() {
			break
		}
	}
	return ret
}

func TraverseSliceSet[T any](ss [][]T) [][]T {
	return traverseSliceSet(ss, nil)
}

func TraverseSliceSet2[T any](ss [][]T, cb func([]T) bool) {
	traverseSliceSet(ss, cb)
}

// 遍历slice集（按照深度递增的方式）
func combineSliceSet[T any](arr [][]T, depth int, cb func([]T) bool) [][]T {
	var result [][]T
	var maxDepth int
	for _, v := range arr {
		if len(v) == 0 {
			return result
		}
		maxDepth += len(v) - 1
	}
	if depth < 0 || depth > maxDepth {
		depth = maxDepth
	}
	for idxSum := 0; idxSum <= depth; idxSum++ {
		var current []T
		if !buildCombination(arr, 0, idxSum, &current, cb, &result) {
			break
		}
	}
	return result
}

// 构造特定深度的组合
func buildCombination[T any](arr [][]T, start int, idxSum int, current *[]T, cb func([]T) bool, result *[][]T) bool {
	if idxSum < 0 {
		return true
	}
	if start == len(arr) {
		if idxSum == 0 {
			if cb == nil {
				tmp := make([]T, len(*current))
				copy(tmp, *current)
				*result = append(*result, tmp)
			} else {
				if !cb(*current) {
					return false
				}
			}
		}
		return true
	}
	for i := 0; i < len(arr[start]); i++ {
		*current = append(*current, arr[start][i])
		if !buildCombination(arr, start+1, idxSum-i, current, cb, result) {
			return false
		}
		*current = (*current)[:len(*current)-1]
	}
	return true
}

func CombineSliceSet[T any](arr [][]T, depth int) [][]T {
	return combineSliceSet(arr, depth, nil)
}

func CombineSliceSet2[T any](arr [][]T, depth int, cb func([]T) bool) {
	combineSliceSet(arr, depth, cb)
}

// 计算组合数
func CNM(n, m int) int {
	if n <= 0 || m > n || m < 0 {
		return 0
	}
	if m == 0 || m == n {
		return 1
	}
	var k int
	if n-m > m {
		k = n - m
	} else {
		k = m
		m = n - m
	}
	ret := 1
	for i := k + 1; i <= n; i++ {
		ret *= i
	}
	var jm int = 1
	for i := 2; i <= m; i++ {
		jm *= i
	}
	return ret / jm
}

// 返回所有的组合（不考虑重复元素），深度优先
func combineNMDepth[T any](s []T, m int, cb func([]T) bool) ([][]T, bool) {
	if m == 0 || m > len(s) {
		return nil, false
	}
	var ret [][]T
	if cb == nil {
		ret = make([][]T, 0, CNM(len(s), m))
	}
	indexs := make([]int, m)
	for i := 0; i < m; i++ {
		indexs[i] = i
	}
	for {
		elem := make([]T, m)
		for i, index := range indexs {
			elem[i] = s[index]
		}
		if cb == nil {
			ret = append(ret, elem)
		} else {
			if !cb(elem) {
				return ret, false
			}
		}
		i := m - 1
		for i >= 0 && indexs[i] == len(s)-m+i {
			i--
		}
		if i < 0 {
			break
		}
		indexs[i]++
		for j := i + 1; j < m; j++ {
			indexs[j] = indexs[j-1] + 1
		}
	}
	return ret, true
}

// 返回所有的组合（不考虑重复元素），广度优先
func combineNMBreadth[T any](s []T, m int, cb func([]T) bool) ([][]T, bool) {
	if m == 0 || m > len(s) {
		return nil, false
	}
	var ret [][]T
	if cb == nil {
		ret = make([][]T, 0, CNM(len(s), m))
	}
	indexs := make([]int, m)
	for i := 0; i < m; i++ {
		indexs[i] = i
	}
	for {
		elem := make([]T, m)
		for i, index := range indexs {
			elem[i] = s[index]
		}
		if cb == nil {
			ret = append(ret, elem)
		} else {
			if !cb(elem) {
				return ret, false
			}
		}
		p := m - 1
		for i := 0; i < m-1; i++ {
			if indexs[i]+1 < indexs[i+1] {
				p = i
				break
			}
		}
		if indexs[p]+1 < len(s) {
			indexs[p]++
			if indexs[0] > 0 {
				for i := 0; i < p; i++ {
					indexs[i] = i
				}
			}
		} else {
			break
		}
	}
	return ret, true
}

func CombineNM[T any](s []T, m int) [][]T {
	ret, _ := combineNMBreadth(s, m, nil)
	return ret
}

func CombineNM2[T any](s []T, m int, cb func([]T) bool) bool {
	_, ok := combineNMBreadth(s, m, cb)
	return ok
}

// 计算排列数
func ANM(n, m int) int {
	if n <= 0 || m > n || m < 0 {
		return 0
	}
	if m == 0 {
		return 1
	}
	ret := n - m + 1
	for i := n - m + 2; i <= n; i++ {
		ret *= i
	}
	return ret
}

func arrange[T any](s []T, m int, elem []T, visit []bool, res *[][]T, cb func([]T) bool) bool {
	if len(elem) == m {
		s := make([]T, len(elem))
		copy(s, elem)
		if cb == nil {
			*res = append(*res, s)
		} else {
			if !cb(s) {
				return false
			}
		}
		return true
	}
	for i := 0; i < len(s); i++ {
		if visit[i] {
			continue
		}
		visit[i] = true
		elem = append(elem, s[i])
		if !arrange(s, m, elem, visit, res, cb) {
			return false
		}
		elem = elem[:len(elem)-1]
		visit[i] = false
	}
	return true
}

// 返回所有的排列（不考虑重复元素）
func arrangeNM[T any](s []T, m int, cb func([]T) bool) ([][]T, bool) {
	var res [][]T
	if cb == nil {
		res = make([][]T, 0, ANM(len(s), m))
	}
	elem := make([]T, 0, m)
	visit := make([]bool, len(s))
	if !arrange(s, m, elem, visit, &res, cb) {
		return res, false
	}
	return res, true
}

func ArrangeNM[T any](s []T, m int) [][]T {
	ret, _ := arrangeNM(s, m, nil)
	return ret
}

func ArrangeNM2[T any](s []T, m int, cb func([]T) bool) bool {
	_, ok := arrangeNM(s, m, cb)
	return ok
}

func partition[T constraints.Integer | constraints.Float](s []T, l, r int) int {
	x := s[l]
	for l < r {
		for l < r && s[r] >= x {
			r--
		}
		if l < r {
			s[l] = s[r]
			l++
		}
		for l < r && s[l] < x {
			l++
		}
		if l < r {
			s[r] = s[l]
			r--
		}
	}
	s[l] = x
	return l
}

// 获取第k个数
func GetKthNum[T constraints.Integer | constraints.Float](s []T, pos int) T {
	var ret T
	if len(s) == 0 {
		return ret
	}
	l, r := 0, len(s)-1
	for {
		index := partition(s, l, r)
		if index == pos {
			return s[index]
		} else if index > pos {
			r = index - 1
		} else {
			l = index + 1
		}
	}
	return ret
}

// 获取中位数
func GetMidNum[T constraints.Integer | constraints.Float](s []T) T {
	if len(s)%2 == 1 {
		return GetKthNum(s, len(s)/2)
	}
	return (GetKthNum(s, len(s)/2-1) + GetKthNum(s, len(s)/2)) / 2
}

// 获取平均数
func GetAverNum[T constraints.Integer | constraints.Float](s []T) T {
	if len(s) == 0 {
		return 0
	}
	var sum T
	for _, v := range s {
		sum += v
	}
	return sum / T(len(s))
}

// ProtoMsgToBytes protobuf message to bytes
func ProtoMsgToBytes(id int32, msg proto.Message) []byte {
	data, _ := proto.Marshal(msg)
	buff := make([]byte, 4, len(data)+4)
	buff[0] = byte(id & 0xff)
	buff[1] = byte(id >> 8 & 0xff)
	buff[2] = byte(id >> 16 & 0xff)
	buff[3] = byte(id >> 24 & 0xff)
	return append(buff, data...)
}

// CurSecond : get current second
func CurSecond() int64 {
	return time.Now().Unix() + GetWroldBaseTs()
}

// CurMilliSecond : get current milli second
func CurMilliSecond() int64 {
	return time.Now().UnixNano()/1000000 + GetWroldBaseTs()*1000
}

// CurNanoSecond : get current nano second
func CurNanoSecond() int64 {
	return time.Now().UnixNano() + GetWroldBaseTs()*1000*1000*1000
}

// CurMicroSecond : get current micro second
func CurMicroSecond() int64 {
	return time.Now().UnixNano()/1000 + GetWroldBaseTs()*1000*1000
}

// GetNextDayTime : get next day 00:00:00 timestamp
func GetNextDayTime() int64 {
	now := time.Unix(CurSecond(), 0)
	nextDay := now.AddDate(0, 0, 1)
	return time.Date(nextDay.Year(), nextDay.Month(), nextDay.Day(), 0, 0, 0, 0, nextDay.Location()).Unix()
}

// GetDayStartTime : get current day 00:00:00 timestamp
func GetDayStartTime() int64 {
	now := time.Unix(CurSecond(), 0)
	return time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location()).Unix()
}

func WeekDay() int {
	t := time.Unix(CurSecond(), 0)
	return int(t.Weekday())
	//return int(time.Now().Weekday())
}

func GetDayDate(sec int64) string {
	day := time.Unix(sec, 0)
	return day.Format("2006-01-02")
}

func GetDayHour(sec int64) uint32 {
	day := time.Unix(sec, 0)
	return uint32(day.Hour())
}

func GetDayMin(sec int64) uint32 {
	day := time.Unix(sec, 0)
	return uint32(day.Minute())
}

func GetDaySec(date string) int64 {
	rdata := date + " 00:00:00"
	return GetDateSecond(rdata)
}

// GetDateSecond : date to ts
func GetDateSecond(formTime string) int64 {
	//格式: 2006-01-02 15:04:05
	loc, _ := time.LoadLocation("Local") //重要：获取时区
	t, _ := time.ParseInLocation("2006-01-02 15:04:05", formTime, loc)
	return t.Unix()
}

// GetSecondFormData : ts to date
func GetSecondFormData(ts int64, isAll bool) string {
	tm := time.Unix(ts, 0)
	if isAll {
		return tm.Format("2006-01-02 15:04:05")
	}
	return tm.Format("2006-01-02")
}

// GetTimeSecond : special time to ts
func GetTimeSecond(ts int64, hour int32, minute int32, second int32, deltaDay int32) int64 {
	t := time.Unix(ts, 0)
	t = t.AddDate(0, 0, int(deltaDay))
	year, month, day := t.Date()
	nt := time.Date(year, month, day, int(hour), int(minute), int(second), 0, t.Location())
	return nt.Unix()
}

func GetNextWeekTs(ts int64) int64 {
	t := time.Unix(ts, 0)
	weekday := int(t.Weekday())

	//weekday 周日为0
	if weekday == 0 {
		weekday = 7
	}

	// 计算距离下周一的天数
	daysUntilMonday := 7 - weekday + 1
	nextWeek := t.AddDate(0, 0, daysUntilMonday)
	nextWeekBegin := time.Date(nextWeek.Year(), nextWeek.Month(), nextWeek.Day(), 0, 0, 0, 0, nextWeek.Location())
	return nextWeekBegin.Unix()
}

func GetNextMonthTs(ts int64) int64 {
	t := time.Unix(ts, 0)
	nextMonth := t.AddDate(0, 1, 0)
	nextMonthBeginning := time.Date(nextMonth.Year(), nextMonth.Month(), 1, 0, 0, 0, 0, nextMonth.Location())
	return nextMonthBeginning.Unix()
}

func GetNextDayTs(ts int64) int64 {
	t := time.Unix(ts, 0)
	tomorrow := t.AddDate(0, 0, 1)
	tomorrowBeginning := time.Date(tomorrow.Year(), tomorrow.Month(), tomorrow.Day(), 0, 0, 0, 0, tomorrow.Location())
	return tomorrowBeginning.Unix()
}

func GetMonthAndDay(curTs int64) (uint32, uint32) {
	t := time.Unix(curTs, 0)
	_, month, day := t.Date()
	return uint32(month), uint32(day)
}

func GetYear(curTs int64) uint32 {
	t := time.Unix(curTs, 0)
	year, _, _ := t.Date()
	return uint32(year)
}

func GetClock(curTs int64) (int, int, int) {
	t := time.Unix(curTs, 0)
	return t.Hour(), t.Minute(), t.Second()
}

// 1~6: 周一~周六，0: 周日
func GetWeekDay(curTs int64) uint32 {
	t := time.Unix(curTs, 0)
	return uint32(t.Weekday())
}

// GetTimeSecondForPointMin : special time to ts
func GetTimeSecondForPointMin(ts int64, deltaMin int32) int64 {
	t := time.Unix(ts, 0)
	year, month, day := t.Date()
	nt := time.Date(year, month, day, t.Hour(), t.Minute()+int(deltaMin), 0, 0, t.Location())
	return nt.Unix()
}

// GetTimeSecondForPointHour : special time to ts
func GetTimeSecondForPointHour(ts int64, deltaHour int32) int64 {
	t := time.Unix(ts, 0)
	year, month, day := t.Date()
	nt := time.Date(year, month, day, t.Hour()+int(deltaHour), 0, 0, 0, t.Location())
	return nt.Unix()
}

// GetTimeSecondForMonth : special time to ts
func GetTimeSecondForWeek(ts int64, hour int32, minute int32, second int32, deltaWeek int32) int64 {
	t := time.Unix(ts, 0)
	deltaWeekDay := 7 - int(t.Weekday()) + 1
	if deltaWeekDay > 7 {
		deltaWeekDay = 1
	}
	t = t.AddDate(0, 0, deltaWeekDay)
	year, month, day := t.Date()
	nt := time.Date(year, month, day, int(hour), int(minute), int(second), 0, t.Location())
	return nt.Unix()
}

// GetTimeSecondForMonth : special time to ts
func GetTimeSecondForMonth(ts int64, hour int32, minute int32, second int32, deltaMon int32) int64 {
	t := time.Unix(ts, 0)
	t = t.AddDate(0, int(deltaMon), 0)
	year, month, day := t.Date()
	nt := time.Date(year, month, day, int(hour), int(minute), int(second), 0, t.Location())
	return nt.Unix()
}

// GetTimeSecondForYear : special time to ts
func GetTimeSecondForYear(ts int64, hour int32, minute int32, second int32, deltaYear int32) int64 {
	t := time.Unix(ts, 0)
	t = t.AddDate(int(deltaYear), 0, 0)
	year, month, day := t.Date()
	nt := time.Date(year, month, day, int(hour), int(minute), int(second), 0, t.Location())
	return nt.Unix()
}

func GetSecondWithClock(timepoint string) int64 {
	//t := time.Now()
	t := time.Unix(CurSecond(), 0)
	dateTime := fmt.Sprintf("%d-%02d-%02d %s", t.Year(), t.Month(), t.Day(), timepoint)
	return GetDateSecond(dateTime)
}

// GetDeltaDay : two ts delta time
func GetDeltaDay(startTs int64, endTs int64) int64 {
	startZeroSec := GetTimeSecond(startTs, 0, 0, 0, 0)
	endZeroSec := GetTimeSecond(endTs, 0, 0, 0, 0)
	return (endZeroSec - startZeroSec) / (3600 * 24)
}

func GetDeltaWeek(startTs int64, endTs int64) int64 {
	weekTs1, weekTs2 := GetNextWeekTs(startTs), GetNextWeekTs(endTs)
	return GetDeltaDay(weekTs1, weekTs2) / 7
}

func GetZeroSec(ts int64) int64 {
	return GetTimeSecond(ts, 0, 0, 0, 0)
}

func GetStrTime() string {
	t := time.Unix(CurSecond(), 0)
	return t.Format("2006-01-02 15:04:05")
	//return time.Now().Format("2006-01-02 15:04:05")
}

func GetStrData() string {
	t := time.Unix(CurSecond(), 0)
	return t.Format("2006-01-02")
	//return time.Now().Format("2006-01-02")
}

func GetStrClock() string {
	t := time.Unix(CurSecond(), 0)
	return t.Format("15:04:05")
	//return time.Now().Format("15:04:05")
}

func GetBuryStrTime(curTs int64) string {
	t := time.Unix(curTs, 0)
	return fmt.Sprintf("%d-%d-%d", t.Year(), t.Month(), t.Day())
}

// RandomInt32 : get a random val
func RandomInt32(start, end int32) int32 {
	if start > end {
		return 0
	} else if start == end {
		return start
	}
	return start + rand.Int31n(end-start+1)
}

// NormRandomInt32 : get a norm random val (高斯分布)
func NormRandomInt32(start int32, end int32) int32 {
	if start > end {
		return 0
	} else if start == end {
		return start
	}
	//t := time.Unix(CurSecond(), 0)
	//r := rand.New(rand.NewSource(time.Now().UnixNano()))
	r := rand.New(rand.NewSource(CurNanoSecond()))
	for {
		ret := int32(r.NormFloat64()*float64(end-start)/6 + float64(start+end)/2)
		if ret >= start && ret <= end {
			return ret
		}
	}
}

func InSameDay(t1, t2 int64) bool {
	y1, m1, d1 := time.Unix(t1, 0).Date()
	y2, m2, d2 := time.Unix(t2, 0).Date()

	return y1 == y2 && m1 == m2 && d1 == d2
}
func InSameWeek(t1, t2 int64) bool {
	y1, week1 := time.Unix(t1, 0).ISOWeek()
	y2, week2 := time.Unix(t2, 0).ISOWeek()
	return y1 == y2 && week1 == week2
}

// RandomRate : get random rate
func RandomRate() float64 {
	return float64(RandomInt32(1, 100)) / 100
}

// RandomFloat : get random rate in zone
func RandomFloat(min, max float64) float64 {
	return min + rand.Float64()*(max-min)
}

// RandMultiIndex : get multi index
func RandMultiIndex(indexLen int32, randNums int32) []int32 {
	if indexLen < randNums {
		return nil
	}
	resultIndexes := []int32{}
	indexes := []int{}
	for i := 0; i < int(indexLen); i++ {
		indexes = append(indexes, i)
	}
	for i := 0; i < int(randNums); i++ {
		index := RandomInt32(0, indexLen-1)
		resultIndexes = append(resultIndexes, int32(indexes[index]))
		indexes[index] = indexes[indexLen-1]
		indexLen--
	}
	return resultIndexes
}

// ToMd5 : string md5
func ToMd5(sig string) string {
	bData := []byte(sig)
	sMd5 := md5.Sum(bData)
	var bMd5Sum []byte
	bMd5Sum = sMd5[0:16]
	strMd5 := hex.EncodeToString(bMd5Sum)
	return strMd5
}

// ToMd5Base64 : string md5 Base64
func ToMd5Base64(sig string) string {
	bData := []byte(sig)
	sMd5 := md5.Sum(bData)
	var bMd5Sum []byte
	bMd5Sum = sMd5[0:16]
	strMd5 := hex.EncodeToString(bMd5Sum)
	bMd5 := []byte(strMd5)
	baseVal := base64.StdEncoding.EncodeToString(bMd5)
	return baseVal
}

// SerialToJSON : serial to json
func SerialToJSON(v interface{}) []byte {
	output, err := json.MarshalIndent(v, "", "")
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}
	return output
}

// SerialToJSON2 : serial to json
func SerialToJSON2(v interface{}) []byte {
	output, err := json.Marshal(v)
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}
	return output
}

// SerialToXML : serial to xml
func SerialToXML(v interface{}) []byte {
	output, err := xml.MarshalIndent(v, "", "")
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}
	return output
}

// ReadXML : read xml content
func ReadXML(dirName string, xmlFileName string) []byte {
	filePath := dirName + xmlFileName + ".xml"
	file, err := os.Open(filePath)
	if err != nil {
		fmt.Printf("error: %v", err)
		return nil
	}
	defer file.Close()
	data, err := ioutil.ReadAll(file)
	if err != nil {
		fmt.Printf("error: %v", err)
		return nil
	}
	return data
}

// Base64Encode : Base64 Encode
func Base64Encode(val string) string {
	return base64.StdEncoding.EncodeToString([]byte(val))
}

// Base64Decode : Base64 Decode
func Base64Decode(val string) string {
	v, err := base64.StdEncoding.DecodeString(val)
	if err != nil {
		return ""
	}
	return string(v)
}

// StringToUint32WithPanic : string to uint32 with panic
func StringToUint32WithPanic(strVal string) uint32 {
	val, err := strconv.Atoi(strVal)
	if err != nil {
		panic(err)
	}
	return uint32(val)
}

// StringToUint32 : string to uint32
func StringToUint32(strVal string) uint32 {
	val, err := strconv.Atoi(strVal)
	if err != nil {
		return 0
	}
	return uint32(val)
}

// StringToUint64 : string to uint64
func StringToUint64(strVal string) uint64 {
	val, err := strconv.Atoi(strVal)
	if err != nil {
		return 0
	}
	return uint64(val)
}

// StringToUint64WithPanic : string to uint64 with panic
func StringToUint64WithPanic(strVal string) uint64 {
	val, err := strconv.Atoi(strVal)
	if err != nil {
		panic(err)
	}
	return uint64(val)
}

// StringToInt32 : string to int32
func StringToInt32(strVal string) int32 {
	val, err := strconv.Atoi(strVal)
	if err != nil {
		return 0
	}
	return int32(val)
}

// StringToInt64 : string to int64
func StringToInt64(strVal string) int64 {
	val, err := strconv.Atoi(strVal)
	if err != nil {
		return 0
	}
	return int64(val)
}

// StringToInt32WithPanic : string to int32 with panic
func StringToInt32WithPanic(strVal string) int32 {
	val, err := strconv.Atoi(strVal)
	if err != nil {
		panic(err)
	}
	return int32(val)
}

// StringToFloat64 : string to float64
func StringToFloat64(strVal string) float64 {
	val, err := strconv.ParseFloat(strVal, 64)
	if err != nil {
		return 0.0
	}
	return float64(val)
}

// StringToFloat64WithPanic : string to float64 with panic
func StringToFloat64WithPanic(strVal string) float64 {
	val, err := strconv.ParseFloat(strVal, 64)
	if err != nil {
		panic(err)
	}
	return float64(val)
}

// StringArrToUint64Arr : string array to uint64 array
func StringArrToUint64Arr(strs []string) []uint64 {
	ret := make([]uint64, 0, len(strs))
	for i := 0; i < len(strs); i++ {
		val, err := strconv.Atoi(strs[i])
		if err != nil {
			continue
		}
		ret = append(ret, uint64(val))
	}
	return ret
}

func Int32ToBytes(val int32) []byte {
	b := make([]byte, 0, 4)
	b = append(b, byte(val&0xff))
	b = append(b, byte(val>>8&0xff))
	b = append(b, byte(val>>16&0xff))
	b = append(b, byte(val>>24&0xff))
	return b
}

func Uint32ToBytes(val uint32) []byte {
	b := make([]byte, 0, 4)
	b = append(b, byte(val&0xff))
	b = append(b, byte(val>>8&0xff))
	b = append(b, byte(val>>16&0xff))
	b = append(b, byte(val>>24&0xff))
	return b
}

func Int64ToBytes(val uint64) []byte {
	b := make([]byte, 0, 8)
	b = append(b, byte(val&0xff))
	b = append(b, byte(val>>8&0xff))
	b = append(b, byte(val>>16&0xff))
	b = append(b, byte(val>>24&0xff))
	b = append(b, byte(val>>32&0xff))
	b = append(b, byte(val>>40&0xff))
	b = append(b, byte(val>>48&0xff))
	b = append(b, byte(val>>56&0xff))
	return b
}

func Uint64ToBytes(val uint64) []byte {
	b := make([]byte, 0, 8)
	b = append(b, byte(val&0xff))
	b = append(b, byte(val>>8&0xff))
	b = append(b, byte(val>>16&0xff))
	b = append(b, byte(val>>24&0xff))
	b = append(b, byte(val>>32&0xff))
	b = append(b, byte(val>>40&0xff))
	b = append(b, byte(val>>48&0xff))
	b = append(b, byte(val>>56&0xff))
	return b
}

func IntToStr[T constraints.Integer](num T) string {
	return strconv.Itoa(int(num))
}

func SplitStringToInt32(strVal string, splitChar string) []int32 {
	if len(strVal) == 0 {
		return []int32{}
	}
	strAry := strings.Split(strVal, splitChar)
	ary := make([]int32, 0, len(strAry))
	for i := 0; i < len(strAry); i++ {
		ary = append(ary, StringToInt32(strAry[i]))
	}
	return ary
}

// SplitString : split string to []int32
func SplitString(strVal string, splitChar string) []uint32 {
	if len(strVal) == 0 {
		return []uint32{}
	}
	strAry := strings.Split(strVal, splitChar)
	ary := make([]uint32, 0, len(strAry))
	for i := 0; i < len(strAry); i++ {
		ary = append(ary, StringToUint32(strAry[i]))
	}
	return ary
}

// SplitStringWithPanic : split string to []uint32
func SplitStringWithPanic(strVal string, splitChar string) []uint32 {
	if len(strVal) == 0 {
		return []uint32{}
	}
	strAry := strings.Split(strVal, splitChar)
	ary := make([]uint32, 0, len(strAry))
	for i := 0; i < len(strAry); i++ {
		ary = append(ary, StringToUint32WithPanic(strAry[i]))
	}
	return ary
}

func ArrayToMap(arr []uint32) map[uint32]struct{} {
	m := make(map[uint32]struct{})
	for i := 0; i < len(arr); i++ {
		m[arr[i]] = struct{}{}
	}
	return m
}

func ArrayToString(arr []uint32, split string) string {
	var builder strings.Builder
	for i := 0; i < len(arr); i++ {
		if i != 0 {
			builder.WriteString(split)
		}
		builder.WriteString(strconv.FormatUint(uint64(arr[i]), 10))
	}
	return builder.String()
}

func Uint64ArrayToString(arr []uint64, split string) string {
	var builder strings.Builder
	for i := 0; i < len(arr); i++ {
		if i != 0 {
			builder.WriteString(split)
		}
		builder.WriteString(strconv.FormatUint(uint64(arr[i]), 10))
	}
	return builder.String()
}

// Round : 四舍五入取整, go1.10后可用rand.Round()
func Round(num float64) int64 {
	return int64(num + math.Copysign(0.5, num))
}

// ToFixed : 浮点数取精度
func ToFixed(num float64, precision int64) float64 {
	output := math.Pow(10, float64(precision))
	return float64(Round(num*output)) / output
}

// GetIP get ip
func GetIP() (net.IP, error) {
	ifaces, err := net.Interfaces()
	if err != nil {
		return nil, err
	}
	for _, iface := range ifaces {
		if iface.Flags&net.FlagUp == 0 {
			continue // interface down
		}
		if iface.Flags&net.FlagLoopback != 0 {
			continue // loopback interface
		}
		addrs, err := iface.Addrs()
		if err != nil {
			return nil, err
		}
		for _, addr := range addrs {
			ip := getIPFromAddr(addr)
			if ip == nil {
				continue
			}
			return ip, nil
		}
	}
	return nil, errors.New("connected to the network?")
}

func getIPFromAddr(addr net.Addr) net.IP {
	var ip net.IP
	switch v := addr.(type) {
	case *net.IPNet:
		ip = v.IP
	case *net.IPAddr:
		ip = v.IP
	}
	if ip == nil || ip.IsLoopback() {
		return nil
	}
	ip = ip.To4()
	if ip == nil {
		return nil // not an ipv4 address
	}
	return ip
}

// // GetLocationByIP : get location by ip
// func GetLocationByIP(ip string) (string, string, string) {
// 	region, err := ip2region.New("ip2region.db")
// 	defer func() {
// 		if region != nil {
// 			region.Close()
// 		}
// 	}()
// 	if err != nil {
// 		fmt.Printf("error: %v\n", err)
// 		return "", "", ""
// 	}
// 	ipInfo := ip2region.IpInfo{}
// 	ipInfo, err = region.BtreeSearch(ip)
// 	if err != nil {
// 		fmt.Printf("error: %s\n", err.Error())
// 		return "", "", ""
// 	}
// 	return ipInfo.Country, ipInfo.Province, ipInfo.City
// }

const letterBytes = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"

// RandStringBytes : rand string
func RandStringBytes(n int) string {
	b := make([]byte, n)
	for i := range b {
		b[i] = letterBytes[rand.Intn(len(letterBytes))]
	}
	return string(b)
}

// GetProcessMd5 : get process md5
func GetProcessMd5() string {
	exeName := os.Args[0] //获取程序名称
	cmd := exec.Command("md5sum", exeName)
	out, err := cmd.Output()
	if err != nil {
		return ""
	}
	return string(out)
}

// ShowFields show yaml/json fields
func ShowFields(obj interface{}, formType string) {
	t := reflect.TypeOf(obj)
	v := reflect.ValueOf(obj)
	for i := 0; i < t.Elem().NumField(); i++ {
		f := t.Elem().Field(i)
		tag := f.Tag.Get(formType)
		if tag == "" {
			continue
		}
		val := v.Elem().Field(i).Interface()
		switch f.Type.Kind() {
		case reflect.Struct:
		default:
		}
	}
}

func BytesString(b []byte) string {
	for i := 0; i < len(b); i++ {
		if b[i] == 0 {
			return string(b[0:i])
		}
	}
	return string(b)
}

// 删除并返回下一个
func ListRemove(l *list.List, e *list.Element) *list.Element {
	next := e.Next()
	l.Remove(e)
	return next
}

func GetIpByAddr(addr string) string {
	args := strings.Split(addr, ":")
	if len(args) > 1 {
		return args[0]
	}
	return ""
}

func IsPidExist(pid int) bool {
	if err := syscall.Kill(pid, 0); err == nil {
		return true
	}
	return false
}

func NewMessageByName(name string) proto.Message {
	msgType := proto.MessageType(name)
	if msgType == nil {
		return nil
	}
	return reflect.New(msgType.Elem()).Interface().(proto.Message)
}

func Message2Json(msg proto.Message, formate bool) string {
	strJson, _ := new(jsonpb.Marshaler).MarshalToString(msg)
	if !formate {
		return strJson
	}
	var buff bytes.Buffer
	json.Indent(&buff, []byte(strJson), "", "    ")
	return buff.String()
}

func WalkDir(dirPth, suffix string) (files []string, err error) {
	suffix = strings.ToUpper(suffix)
	err = filepath.Walk(dirPth, func(filename string, fi os.FileInfo, err error) error {
		if err != nil || fi.IsDir() {
			return err
		}
		if strings.HasSuffix(strings.ToUpper(fi.Name()), suffix) {
			files = append(files, filename)
		}
		return nil
	})
	return files, err
}
func ChageUint32ToBits(bitEndian bool, v uint32) []byte {
	bytes := make([]byte, 4)
	if bitEndian {
		bytes[0] = byte(v >> 24)
		bytes[1] = byte(v >> 16)
		bytes[2] = byte(v >> 8)
		bytes[3] = byte(v)
	} else {
		bytes[0] = byte(v)
		bytes[1] = byte(v >> 8)
		bytes[2] = byte(v >> 16)
		bytes[3] = byte(v >> 24)
	}
	bits := make([]byte, 0)
	for _, v := range bytes {
		oneByte := make([]byte, 8)
		for i := 0; i < 8; i++ {
			move := uint(7 - i)
			val := byte((v >> move) & 1)
			oneByte[7-i] = val
		}
		bits = append(bits, oneByte...)
	}
	return bits
}

func Pow(x, y uint32) uint32 {
	if y == 0 {
		return 1
	}
	if y == 1 {
		return x
	}
	return x * Pow(x, y-1)
}

func ChageBitsToUint32(bitEndian bool, bits []byte) uint32 {
	bytes := make([]byte, 0)
	var bt byte
	for i, v := range bits {
		j := uint32(i % 8)
		if uint32(v) == 1 {
			bt = bt | byte(Pow(2, j))
		}
		if (i+1)%8 == 0 {
			bytes = append(bytes, bt)
			bt = byte(0)
		}
	}
	ret := uint32(0)
	if bitEndian {
		ret = binary.BigEndian.Uint32(bytes)
	} else {
		ret = binary.LittleEndian.Uint32(bytes)
	}
	return ret
}

// 当前零时区的日期字符串
func GetCurUtcDate(isAll bool) string {
	t := time.Unix(CurSecond(), 0)
	tm := t.UTC()
	//	tm := time.Now().UTC()
	if isAll {
		return tm.Format("2006-01-02 15:04:05")
	}
	return tm.Format("2006-01-02")
}

// ts时间零时区的日期字符串
func GetTsUtcDate(ts int64, isAll bool) string {
	utc := CurSecond()
	t := time.Unix(CurSecond(), 0)
	tm := t.UTC()
	//	tm := time.Now().UTC()
	tm = tm.Add(time.Second * time.Duration(ts-utc))
	if isAll {
		return tm.Format("2006-01-02 15:04:05")
	}
	return tm.Format("2006-01-02")
}

// 移除多余的空格或tab
func RemoveRepeatBlank(s string) string {
	var buff []byte
	for i := 0; i < len(s); i++ {
		if len(buff) == 0 {
			buff = append(buff, s[i])
		} else {
			c := buff[len(buff)-1]
			if c != ' ' && c != '\t' || s[i] != ' ' && s[i] != '\t' {
				buff = append(buff, s[i])
			}
		}
	}
	return string(buff)
}

// 移除所有空格或tab
func RemoveAllBlank(s string) string {
	s = strings.Replace(s, "\t", "", -1)
	s = strings.Replace(s, " ", "", -1)
	return s
}

// 移除左边的空格或tab
func RemoveLeftBlank(s string) string {
	for i := 0; i < len(s); i++ {
		if s[i] != ' ' && s[i] != '\t' {
			return s[i:]
		}
	}
	return ""
}

// 移除右边的空格或tab
func RemoveRightBlank(s string) string {
	for i := len(s) - 1; i >= 0; i-- {
		if s[i] != ' ' && s[i] != '\t' {
			return s[:i+1]
		}
	}
	return ""
}

// 移除两端的空格或tab
func RemoveSideBlank(s string) string {
	return RemoveRightBlank(RemoveLeftBlank(s))
}

// 分离关键字
func SplitKeyStr(s, key string) []string {
	var c byte
	var last int
	var ret []string
	for i := 0; i < len(s); {
		if (i < 1 || s[i-1] != '\\') && (s[i] == '\'' || s[i] == '"') {
			if c == 0 {
				c = s[i]
			} else if s[i] == c {
				c = 0
			}
		} else if c == 0 && len(s) >= i+len(key) && s[i:i+len(key)] == key {
			ret = append(ret, s[last:i])
			i += len(key)
			last = i
			continue
		}
		i++
	}
	ret = append(ret, s[last:])
	return ret
}

func GetSliceString[T any](list []T) string {
	str := fmt.Sprintf("len:%v", len(list))
	for _, data := range list {
		str += fmt.Sprintf(" data:%v", data)
	}
	return str
}

func AnyToJsonString(s any) string {
	b, err := json.Marshal(s)
	if err != nil {
		return ""
	}
	return string(b)
}

func ParseStrToMap(str string, split1, split2 string, panicFlag bool) map[uint32]uint32 {
	m := make(map[uint32]uint32)
	strArr := strings.Split(str, split1)
	for _, v := range strArr {
		if len(v) == 0 {
			continue
		}
		if panicFlag {
			if ret := SplitStringWithPanic(v, split2); len(ret) == 2 {
				m[uint32(ret[0])] += uint32(ret[1])
			}
		} else {
			if ret := SplitString(v, split2); len(ret) == 2 {
				m[uint32(ret[0])] += uint32(ret[1])
			}
		}
	}
	return m
}

func ArrayToMap2(arr []uint32) map[uint32]uint32 {
	m := make(map[uint32]uint32)
	for i := 0; i < len(arr); i += 1 {
		m[arr[i]] = 1
	}
	return m
}

func ArrayToMap3(arr []uint32) map[uint32]uint32 {
	m := make(map[uint32]uint32)
	for i := 0; i < len(arr); i += 2 {
		m[arr[i]] = arr[i+1]
	}
	return m
}

type Addable interface {
	int64 | int32 | uint32
}

func MergeMap[Key comparable, Val Addable](map1, map2 map[Key]Val) (retMap map[Key]Val) {
	retMap = make(map[Key]Val)
	Merge := func(argMap map[Key]Val) {
		for key, val := range argMap {
			retMap[key] += val
		}
	}
	Merge(map1)
	Merge(map2)
	return retMap
}

func MergeMap2[Key comparable](map1, map2 map[Key]struct{}) (retMap map[Key]struct{}) {
	retMap = make(map[Key]struct{})
	Merge := func(argMap map[Key]struct{}) {
		for key, val := range argMap {
			retMap[key] = val
		}
	}
	Merge(map1)
	Merge(map2)
	return retMap
}

func DecentralizeExec[T any](s []T, f func(T), usMin, usMax, nLimit int) {
	time.Sleep(time.Duration(usMin) * time.Microsecond)
	for _, v := range s {
		f(v)
		if len(s) > nLimit {
			time.Sleep(time.Duration((usMax-usMin)/len(s)) * time.Microsecond)
		}
	}
}

func Change2Uint32(val interface{}) (uint32, bool) {
	switch v := val.(type) {
	case int:
		return uint32(val.(int)), true
	case int8:
		return uint32(val.(int8)), true
	case int16:
		return uint32(val.(int16)), true
	case int32:
		return uint32(val.(int32)), true
	case uint:
		return uint32(val.(uint)), true
	case uint8:
		return uint32(val.(uint8)), true
	case uint16:
		return uint32(val.(uint16)), true
	case uint32:
		return uint32(val.(uint32)), true
	default:
	}
	return 0, false
}

func Change2Uint64(val interface{}) (uint64, bool) {
	switch v := val.(type) {
	case int64:
		return uint64(val.(int64)), true
	case uint64:
		return uint64(val.(uint64)), true
	default:
		if tmp, ret := Change2Uint32(val); ret {
			return uint64(tmp), true
		}
	}
	return 0, false
}

func ConvertToString(values ...interface{}) string {
	strValues := make([]string, len(values))
	for i, v := range values {
		strValues[i] = fmt.Sprint(v)
	}
	return strings.Join(strValues, " ")
}

func IsNil(i interface{}) bool {
	if i == nil {
		return true
	}
	v := reflect.ValueOf(i)
	return !v.IsValid() || v.IsNil()
}
