package redisx

import (
	"fmt"
	"strconv"
)

func FormatInt32(v int32) string {
	return strconv.FormatInt(int64(v), 10)
}

func FormatInt64(v int64) string {
	return strconv.FormatInt(v, 10)
}

func ParseInt32(s string) (int32, error) {
	v, err := strconv.ParseInt(s, 10, 32)
	return int32(v), err
}

func ParseInt64(s string) (int64, error) {
	return strconv.ParseInt(s, 10, 64)
}

func MustFormat(v any) string {
	switch x := v.(type) {
	case string:
		return x
	case int32:
		return FormatInt32(x)
	case int64:
		return FormatInt64(x)
	default:
		return fmt.Sprint(v)
	}
}
