package redisx

import "errors"

var ErrNotFound = errors.New("redis: not found")

type ZItem struct {
	Member string
	Score  int64
}

type Store interface {
	String() StringStore
	Hash() HashStore
	List() ListStore
	Set() SetStore
	ZSet() ZSetStore
}

type StringStore interface {
	Get(ctx Context, key string) (string, error)
	Set(ctx Context, key, value string, expireSeconds int) error
	SetNX(ctx Context, key, value string, expireSeconds int) (bool, error)
	Del(ctx Context, key string) error
	Incr(ctx Context, key string) (int64, error)
	IncrBy(ctx Context, key string, increment int64) (int64, error)
}

type HashStore interface {
	Get(ctx Context, key, field string) (string, error)
	GetAll(ctx Context, key string) (map[string]string, error)
	Set(ctx Context, key, field, value string) error
	SetNX(ctx Context, key, field, value string) (bool, error)
	Del(ctx Context, key string, fields ...string) error
	Exists(ctx Context, key, field string) (bool, error)
}

type ListStore interface {
	Range(ctx Context, key string, start, stop int64) ([]string, error)
	LPush(ctx Context, key string, values ...string) (int64, error)
	LTrim(ctx Context, key string, start, stop int64) error
	Expire(ctx Context, key string, expireSeconds int) error
}

type SetStore interface {
	Members(ctx Context, key string) ([]string, error)
	Add(ctx Context, key string, members ...string) (int64, error)
}

type ZSetStore interface {
	Card(ctx Context, key string) (int64, error)
	Score(ctx Context, key, member string) (int64, error)
	Add(ctx Context, key string, item ZItem) (bool, error)
	AddNX(ctx Context, key string, item ZItem) (bool, error)
}
