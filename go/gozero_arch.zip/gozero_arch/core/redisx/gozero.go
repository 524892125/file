package redisx

import (
	"errors"

	gzredis "github.com/zeromicro/go-zero/core/stores/redis"
)

type GoZeroStore struct {
	client *gzredis.Redis
}

func NewGoZeroStore(client *gzredis.Redis) *GoZeroStore {
	return &GoZeroStore{client: client}
}

func (s *GoZeroStore) String() StringStore { return goZeroStringStore{client: s.client} }
func (s *GoZeroStore) Hash() HashStore     { return goZeroHashStore{client: s.client} }
func (s *GoZeroStore) List() ListStore     { return goZeroListStore{client: s.client} }
func (s *GoZeroStore) Set() SetStore       { return goZeroSetStore{client: s.client} }
func (s *GoZeroStore) ZSet() ZSetStore     { return goZeroZSetStore{client: s.client} }

type goZeroStringStore struct{ client *gzredis.Redis }

func (s goZeroStringStore) Get(ctx Context, key string) (string, error) {
	val, err := s.client.GetCtx(ctx, key)
	if err != nil {
		return "", err
	}
	if val == "" {
		exists, err := s.client.ExistsCtx(ctx, key)
		if err != nil {
			return "", err
		}
		if !exists {
			return "", ErrNotFound
		}
	}
	if val == "" {
		return "", nil
	}
	return val, nil
}

func (s goZeroStringStore) Set(ctx Context, key, value string, expireSeconds int) error {
	if expireSeconds > 0 {
		return s.client.SetexCtx(ctx, key, value, expireSeconds)
	}
	return s.client.SetCtx(ctx, key, value)
}

func (s goZeroStringStore) SetNX(ctx Context, key, value string, expireSeconds int) (bool, error) {
	if expireSeconds > 0 {
		return s.client.SetnxExCtx(ctx, key, value, expireSeconds)
	}
	return s.client.SetnxCtx(ctx, key, value)
}

func (s goZeroStringStore) Del(ctx Context, key string) error {
	_, err := s.client.DelCtx(ctx, key)
	return err
}

func (s goZeroStringStore) Incr(ctx Context, key string) (int64, error) {
	return s.client.IncrCtx(ctx, key)
}

func (s goZeroStringStore) IncrBy(ctx Context, key string, increment int64) (int64, error) {
	return s.client.IncrbyCtx(ctx, key, increment)
}

type goZeroHashStore struct{ client *gzredis.Redis }

func (s goZeroHashStore) Get(ctx Context, key, field string) (string, error) {
	val, err := s.client.HgetCtx(ctx, key, field)
	if errors.Is(err, gzredis.Nil) {
		return "", ErrNotFound
	}
	return val, err
}

func (s goZeroHashStore) GetAll(ctx Context, key string) (map[string]string, error) {
	return s.client.HgetallCtx(ctx, key)
}

func (s goZeroHashStore) Set(ctx Context, key, field, value string) error {
	return s.client.HsetCtx(ctx, key, field, value)
}

func (s goZeroHashStore) SetNX(ctx Context, key, field, value string) (bool, error) {
	return s.client.HsetnxCtx(ctx, key, field, value)
}

func (s goZeroHashStore) Del(ctx Context, key string, fields ...string) error {
	_, err := s.client.HdelCtx(ctx, key, fields...)
	return err
}

func (s goZeroHashStore) Exists(ctx Context, key, field string) (bool, error) {
	return s.client.HexistsCtx(ctx, key, field)
}

type goZeroListStore struct{ client *gzredis.Redis }

func (s goZeroListStore) Range(ctx Context, key string, start, stop int64) ([]string, error) {
	return s.client.LrangeCtx(ctx, key, int(start), int(stop))
}

func (s goZeroListStore) LPush(ctx Context, key string, values ...string) (int64, error) {
	args := make([]any, 0, len(values))
	for _, v := range values {
		args = append(args, v)
	}
	val, err := s.client.LpushCtx(ctx, key, args...)
	return int64(val), err
}

func (s goZeroListStore) LTrim(ctx Context, key string, start, stop int64) error {
	return s.client.LtrimCtx(ctx, key, start, stop)
}

func (s goZeroListStore) Expire(ctx Context, key string, expireSeconds int) error {
	return s.client.ExpireCtx(ctx, key, expireSeconds)
}

type goZeroSetStore struct{ client *gzredis.Redis }

func (s goZeroSetStore) Members(ctx Context, key string) ([]string, error) {
	return s.client.SmembersCtx(ctx, key)
}

func (s goZeroSetStore) Add(ctx Context, key string, members ...string) (int64, error) {
	args := make([]any, 0, len(members))
	for _, v := range members {
		args = append(args, v)
	}
	val, err := s.client.SaddCtx(ctx, key, args...)
	return int64(val), err
}

type goZeroZSetStore struct{ client *gzredis.Redis }

func (s goZeroZSetStore) Card(ctx Context, key string) (int64, error) {
	val, err := s.client.ZcardCtx(ctx, key)
	return int64(val), err
}

func (s goZeroZSetStore) Score(ctx Context, key, member string) (int64, error) {
	val, err := s.client.ZscoreCtx(ctx, key, member)
	if errors.Is(err, gzredis.Nil) {
		return 0, ErrNotFound
	}
	return val, err
}

func (s goZeroZSetStore) Add(ctx Context, key string, item ZItem) (bool, error) {
	return s.client.ZaddCtx(ctx, key, item.Score, item.Member)
}

func (s goZeroZSetStore) AddNX(ctx Context, key string, item ZItem) (bool, error) {
	return s.client.ZaddnxCtx(ctx, key, item.Score, item.Member)
}
