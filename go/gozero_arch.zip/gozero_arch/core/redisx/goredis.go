package redisx

import (
	"errors"
	"time"

	red "github.com/redis/go-redis/v9"
)

type GoRedisStore struct {
	client red.UniversalClient
}

func NewGoRedisStore(client red.UniversalClient) *GoRedisStore {
	return &GoRedisStore{client: client}
}

func (s *GoRedisStore) String() StringStore { return goRedisStringStore{client: s.client} }
func (s *GoRedisStore) Hash() HashStore     { return goRedisHashStore{client: s.client} }
func (s *GoRedisStore) List() ListStore     { return goRedisListStore{client: s.client} }
func (s *GoRedisStore) Set() SetStore       { return goRedisSetStore{client: s.client} }
func (s *GoRedisStore) ZSet() ZSetStore     { return goRedisZSetStore{client: s.client} }

type goRedisStringStore struct{ client red.UniversalClient }

func (s goRedisStringStore) Get(ctx Context, key string) (string, error) {
	val, err := s.client.Get(ctx, key).Result()
	if errors.Is(err, red.Nil) {
		return "", ErrNotFound
	}
	return val, err
}

func (s goRedisStringStore) Set(ctx Context, key, value string, expireSeconds int) error {
	ttl := time.Duration(expireSeconds) * time.Second
	return s.client.Set(ctx, key, value, ttl).Err()
}

func (s goRedisStringStore) SetNX(ctx Context, key, value string, expireSeconds int) (bool, error) {
	ttl := time.Duration(expireSeconds) * time.Second
	return s.client.SetNX(ctx, key, value, ttl).Result()
}

func (s goRedisStringStore) Del(ctx Context, key string) error {
	return s.client.Del(ctx, key).Err()
}

func (s goRedisStringStore) Incr(ctx Context, key string) (int64, error) {
	return s.client.Incr(ctx, key).Result()
}

func (s goRedisStringStore) IncrBy(ctx Context, key string, increment int64) (int64, error) {
	return s.client.IncrBy(ctx, key, increment).Result()
}

type goRedisHashStore struct{ client red.UniversalClient }

func (s goRedisHashStore) Get(ctx Context, key, field string) (string, error) {
	val, err := s.client.HGet(ctx, key, field).Result()
	if errors.Is(err, red.Nil) {
		return "", ErrNotFound
	}
	return val, err
}

func (s goRedisHashStore) GetAll(ctx Context, key string) (map[string]string, error) {
	return s.client.HGetAll(ctx, key).Result()
}

func (s goRedisHashStore) Set(ctx Context, key, field, value string) error {
	return s.client.HSet(ctx, key, field, value).Err()
}

func (s goRedisHashStore) SetNX(ctx Context, key, field, value string) (bool, error) {
	return s.client.HSetNX(ctx, key, field, value).Result()
}

func (s goRedisHashStore) Del(ctx Context, key string, fields ...string) error {
	return s.client.HDel(ctx, key, fields...).Err()
}

func (s goRedisHashStore) Exists(ctx Context, key, field string) (bool, error) {
	return s.client.HExists(ctx, key, field).Result()
}

type goRedisListStore struct{ client red.UniversalClient }

func (s goRedisListStore) Range(ctx Context, key string, start, stop int64) ([]string, error) {
	return s.client.LRange(ctx, key, start, stop).Result()
}

func (s goRedisListStore) LPush(ctx Context, key string, values ...string) (int64, error) {
	args := make([]any, 0, len(values))
	for _, v := range values {
		args = append(args, v)
	}
	return s.client.LPush(ctx, key, args...).Result()
}

func (s goRedisListStore) LTrim(ctx Context, key string, start, stop int64) error {
	return s.client.LTrim(ctx, key, start, stop).Err()
}

func (s goRedisListStore) Expire(ctx Context, key string, expireSeconds int) error {
	return s.client.Expire(ctx, key, time.Duration(expireSeconds)*time.Second).Err()
}

type goRedisSetStore struct{ client red.UniversalClient }

func (s goRedisSetStore) Members(ctx Context, key string) ([]string, error) {
	return s.client.SMembers(ctx, key).Result()
}

func (s goRedisSetStore) Add(ctx Context, key string, members ...string) (int64, error) {
	args := make([]any, 0, len(members))
	for _, v := range members {
		args = append(args, v)
	}
	return s.client.SAdd(ctx, key, args...).Result()
}

type goRedisZSetStore struct{ client red.UniversalClient }

func (s goRedisZSetStore) Card(ctx Context, key string) (int64, error) {
	return s.client.ZCard(ctx, key).Result()
}

func (s goRedisZSetStore) Score(ctx Context, key, member string) (int64, error) {
	val, err := s.client.ZScore(ctx, key, member).Result()
	if errors.Is(err, red.Nil) {
		return 0, ErrNotFound
	}
	return int64(val), err
}

func (s goRedisZSetStore) Add(ctx Context, key string, item ZItem) (bool, error) {
	val, err := s.client.ZAdd(ctx, key, red.Z{Score: float64(item.Score), Member: item.Member}).Result()
	return val > 0, err
}

func (s goRedisZSetStore) AddNX(ctx Context, key string, item ZItem) (bool, error) {
	val, err := s.client.ZAddArgs(ctx, key, red.ZAddArgs{
		NX:      true,
		Members: []red.Z{{Score: float64(item.Score), Member: item.Member}},
	}).Result()
	return val > 0, err
}
