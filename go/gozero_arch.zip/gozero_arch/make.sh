#!/usr/bin/env bash

server=(
  "user"
  "admin"
)

for s in "${server[@]}"; do
    GOOS=linux GOARCH=amd64 go build -o ./bin/${s}-api ./apps/${s}/api/${s}.go -ldflags="-s -w" -tags no_k8s
    cp ./apps/${s}/api/etc/* ./bin/etc/

    GOOS=linux GOARCH=amd64 go build -o ./bin/${s} ./apps/${s}/rpc/${s}.go -ldflags="-s -w" -tags no_k8s
    cp ./apps/${s}/rpc/etc/* ./bin/etc/
done