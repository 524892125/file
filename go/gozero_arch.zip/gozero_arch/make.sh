#!/usr/bin/env bash

server=(
  "user"
  "admin"
  "kbrelease"
  "cron"
)

for s in "${server[@]}"; do
    GOOS=linux GOARCH=amd64 go build -o ./bin/${s}-api -ldflags="-s -w" -tags no_k8s ./apps/${s}/api/${s}.go
    cp ./apps/${s}/api/etc/* ./bin/etc/

    GOOS=linux GOARCH=amd64 go build -o ./bin/${s} -ldflags="-s -w" -tags no_k8s ./apps/${s}/rpc/${s}.go
    cp ./apps/${s}/rpc/etc/* ./bin/etc/
done