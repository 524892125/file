--
-- PostgreSQL database dump
--

\restrict cEXweKFhiafLraYnVes1lNc5g0Mt6CMDr9iCMHdyOor28d499JGt7clszhHESSp

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_runtime_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_runtime_log (
    id bigint NOT NULL,
    message_id character varying(64) NOT NULL,
    trace_id character varying(128),
    tenant_code character varying(64),
    service_name character varying(64) NOT NULL,
    level character varying(32) NOT NULL,
    caller character varying(255),
    content text,
    fields_json text,
    source character varying(64),
    logged_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.app_runtime_log OWNER TO postgres;

--
-- Name: sys_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_config (
    id bigint NOT NULL,
    config_name character varying(128),
    config_key character varying(128),
    config_value character varying(255),
    config_type character varying(64),
    is_frontend character varying(64),
    remark character varying(128),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_config OWNER TO postgres;

--
-- Name: COLUMN sys_config.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.id IS '主键编码';


--
-- Name: COLUMN sys_config.config_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_name IS 'ConfigName';


--
-- Name: COLUMN sys_config.config_key; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_key IS 'ConfigKey';


--
-- Name: COLUMN sys_config.config_value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_value IS 'ConfigValue';


--
-- Name: COLUMN sys_config.config_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.config_type IS 'ConfigType';


--
-- Name: COLUMN sys_config.is_frontend; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.is_frontend IS '是否前台';


--
-- Name: COLUMN sys_config.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.remark IS 'Remark';


--
-- Name: COLUMN sys_config.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.create_by IS '创建者';


--
-- Name: COLUMN sys_config.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.update_by IS '更新者';


--
-- Name: COLUMN sys_config.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.created_at IS '创建时间';


--
-- Name: COLUMN sys_config.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_config.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_config.deleted_at IS '删除时间';


--
-- Name: sys_config_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_config_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_config_config_id_seq OWNER TO postgres;

--
-- Name: sys_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_config_id_seq OWNER TO postgres;

--
-- Name: sys_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_config_id_seq OWNED BY public.sys_config.id;


--
-- Name: sys_config_test; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_config_test (
    id bigint NOT NULL,
    config_name character varying(128),
    config_key character varying(128),
    config_value character varying(255),
    config_type character varying(64),
    is_frontend character varying(64),
    remark character varying(128),
    create_by integer DEFAULT 0 NOT NULL,
    update_by integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sys_config_test OWNER TO postgres;

--
-- Name: sys_config_test_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_config_test_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_config_test_id_seq OWNER TO postgres;

--
-- Name: sys_config_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_config_test_id_seq OWNED BY public.sys_config_test.id;


--
-- Name: sys_dept; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_dept (
    dept_id bigint NOT NULL,
    parent_id bigint,
    dept_path character varying(255),
    dept_name character varying(128),
    sort smallint,
    leader character varying(128),
    phone character varying(11),
    email character varying(64),
    status smallint,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_dept OWNER TO postgres;

--
-- Name: sys_dept_dept_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_dept_dept_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_dept_dept_id_seq OWNER TO postgres;

--
-- Name: sys_dept_dept_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_dept_dept_id_seq OWNED BY public.sys_dept.dept_id;


--
-- Name: sys_dict_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_dict_data (
    dict_code bigint NOT NULL,
    dict_sort bigint,
    dict_label character varying(128),
    dict_value character varying(255),
    dict_type character varying(64),
    css_class character varying(128),
    list_class character varying(128),
    is_default character varying(8),
    status smallint,
    "default" character varying(8),
    remark character varying(255),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_dict_data OWNER TO postgres;

--
-- Name: sys_dict_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_dict_type (
    dict_id bigint NOT NULL,
    dict_name character varying(128),
    dict_type character varying(128),
    status smallint,
    remark character varying(255),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_dict_type OWNER TO postgres;

--
-- Name: sys_job_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_job_id_seq OWNER TO postgres;

--
-- Name: sys_login_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_login_log (
    id bigint NOT NULL,
    username character varying(128),
    status character varying(4),
    ipaddr character varying(255),
    login_location character varying(255),
    browser character varying(255),
    os character varying(255),
    platform character varying(255),
    login_time timestamp without time zone,
    remark text,
    msg text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    create_by bigint,
    update_by bigint
);


ALTER TABLE public.sys_login_log OWNER TO postgres;

--
-- Name: COLUMN sys_login_log.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.id IS '主键编码';


--
-- Name: COLUMN sys_login_log.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.username IS 'username';


--
-- Name: COLUMN sys_login_log.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.status IS 'status';


--
-- Name: COLUMN sys_login_log.ipaddr; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.ipaddr IS 'ip address';


--
-- Name: COLUMN sys_login_log.login_location; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.login_location IS 'login location';


--
-- Name: COLUMN sys_login_log.browser; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.browser IS 'browser';


--
-- Name: COLUMN sys_login_log.os; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.os IS 'os';


--
-- Name: COLUMN sys_login_log.platform; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.platform IS 'platform';


--
-- Name: COLUMN sys_login_log.login_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.login_time IS 'login time';


--
-- Name: COLUMN sys_login_log.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.remark IS 'remark';


--
-- Name: COLUMN sys_login_log.msg; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.msg IS 'message';


--
-- Name: COLUMN sys_login_log.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.created_at IS 'created at';


--
-- Name: COLUMN sys_login_log.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.updated_at IS 'updated at';


--
-- Name: COLUMN sys_login_log.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.create_by IS '创建者';


--
-- Name: COLUMN sys_login_log.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_login_log.update_by IS '更新者';


--
-- Name: sys_login_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_login_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_login_log_id_seq OWNER TO postgres;

--
-- Name: sys_login_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_login_log_id_seq OWNED BY public.sys_login_log.id;


--
-- Name: sys_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_menu (
    menu_id bigint NOT NULL,
    menu_name character varying(128) NOT NULL,
    title character varying(128),
    icon character varying(128),
    path character varying(128) NOT NULL,
    paths character varying(128),
    menu_type character varying(1) NOT NULL,
    action character varying(16),
    permission character varying(255),
    parent_id smallint,
    no_cache boolean,
    breadcrumb character varying(255),
    component character varying(255),
    sort smallint,
    visible character varying(1),
    is_frame character varying(1) DEFAULT '0'::character varying,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_menu OWNER TO postgres;

--
-- Name: COLUMN sys_menu.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.create_by IS '创建者';


--
-- Name: COLUMN sys_menu.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.update_by IS '更新者';


--
-- Name: COLUMN sys_menu.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.created_at IS '创建时间';


--
-- Name: COLUMN sys_menu.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_menu.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_menu.deleted_at IS '删除时间';


--
-- Name: sys_menu_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_menu_menu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_menu_menu_id_seq OWNER TO postgres;

--
-- Name: sys_menu_menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_menu_menu_id_seq OWNED BY public.sys_menu.menu_id;


--
-- Name: sys_opera_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_opera_log (
    id bigint NOT NULL,
    title character varying(255),
    business_type character varying(128),
    business_types character varying(128),
    method character varying(128),
    request_method character varying(128),
    operator_type character varying(128),
    oper_name character varying(128),
    dept_name character varying(128),
    oper_url character varying(255),
    oper_ip character varying(128),
    oper_location character varying(128),
    oper_param text,
    status character varying(4),
    oper_time timestamp without time zone,
    json_result character varying(255),
    remark character varying(255),
    latency_time character varying(128),
    user_agent character varying(255),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    create_by bigint,
    update_by bigint,
    "IOMMU" character varying(255),
    message_id character varying(255),
    trace_id character varying(255),
    tenant_code character varying(255),
    service_name character varying(255),
    user_id integer
);


ALTER TABLE public.sys_opera_log OWNER TO postgres;

--
-- Name: COLUMN sys_opera_log.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.id IS '主键编码';


--
-- Name: COLUMN sys_opera_log.title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.title IS '操作模块';


--
-- Name: COLUMN sys_opera_log.business_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.business_type IS '操作类型';


--
-- Name: COLUMN sys_opera_log.business_types; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.business_types IS 'BusinessTypes';


--
-- Name: COLUMN sys_opera_log.method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.method IS '函数';


--
-- Name: COLUMN sys_opera_log.request_method; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.request_method IS '请求方式: GET POST PUT DELETE';


--
-- Name: COLUMN sys_opera_log.operator_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.operator_type IS '操作类型';


--
-- Name: COLUMN sys_opera_log.oper_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_name IS '操作者';


--
-- Name: COLUMN sys_opera_log.dept_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.dept_name IS '部门名称';


--
-- Name: COLUMN sys_opera_log.oper_url; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_url IS '访问地址';


--
-- Name: COLUMN sys_opera_log.oper_ip; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_ip IS '客户端ip';


--
-- Name: COLUMN sys_opera_log.oper_location; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_location IS '访问位置';


--
-- Name: COLUMN sys_opera_log.oper_param; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_param IS '请求参数';


--
-- Name: COLUMN sys_opera_log.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.status IS '操作状态 1:正常 2:关闭';


--
-- Name: COLUMN sys_opera_log.oper_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.oper_time IS '操作时间';


--
-- Name: COLUMN sys_opera_log.json_result; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.json_result IS '返回数据';


--
-- Name: COLUMN sys_opera_log.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.remark IS '备注';


--
-- Name: COLUMN sys_opera_log.latency_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.latency_time IS '耗时';


--
-- Name: COLUMN sys_opera_log.user_agent; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.user_agent IS 'ua';


--
-- Name: COLUMN sys_opera_log.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.created_at IS '创建时间';


--
-- Name: COLUMN sys_opera_log.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_opera_log.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.create_by IS '创建者';


--
-- Name: COLUMN sys_opera_log.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_opera_log.update_by IS '更新者';


--
-- Name: sys_opera_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_opera_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_opera_log_id_seq OWNER TO postgres;

--
-- Name: sys_opera_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_opera_log_id_seq OWNED BY public.sys_opera_log.id;


--
-- Name: sys_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_role (
    role_id bigint NOT NULL,
    role_name character varying(128),
    status character varying(4),
    role_key character varying(128),
    role_sort bigint,
    flag character varying(128),
    remark character varying(255),
    admin boolean,
    data_scope character varying(128),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sys_role OWNER TO postgres;

--
-- Name: sys_role_dept; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_role_dept (
    id bigint NOT NULL,
    role_id smallint NOT NULL,
    dept_id smallint NOT NULL
);


ALTER TABLE public.sys_role_dept OWNER TO postgres;

--
-- Name: sys_role_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_role_menu (
    id bigint NOT NULL,
    role_id bigint NOT NULL,
    menu_id bigint NOT NULL
);


ALTER TABLE public.sys_role_menu OWNER TO postgres;

--
-- Name: sys_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_user (
    user_id bigint NOT NULL,
    username character varying(64),
    password character varying(128),
    nick_name character varying(128),
    phone character varying(11),
    role_id bigint,
    salt character varying(255),
    avatar character varying(255),
    sex character varying(255),
    email character varying(128),
    dept_id bigint,
    post_id bigint,
    remark character varying(255),
    status character varying(4),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    allow_password_login character varying(4) DEFAULT '2'::character varying
);


ALTER TABLE public.sys_user OWNER TO postgres;

--
-- Name: COLUMN sys_user.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.user_id IS '编码';


--
-- Name: COLUMN sys_user.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.username IS '用户名';


--
-- Name: COLUMN sys_user.password; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.password IS '密码';


--
-- Name: COLUMN sys_user.nick_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.nick_name IS '昵称';


--
-- Name: COLUMN sys_user.phone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.phone IS '手机号';


--
-- Name: COLUMN sys_user.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.role_id IS '角色ID';


--
-- Name: COLUMN sys_user.salt; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.salt IS '盐';


--
-- Name: COLUMN sys_user.avatar; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.avatar IS '头像';


--
-- Name: COLUMN sys_user.sex; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.sex IS '性别';


--
-- Name: COLUMN sys_user.email; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.email IS '邮箱';


--
-- Name: COLUMN sys_user.dept_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.dept_id IS '部门';


--
-- Name: COLUMN sys_user.post_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.post_id IS '岗位';


--
-- Name: COLUMN sys_user.remark; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.remark IS '备注';


--
-- Name: COLUMN sys_user.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.status IS '状态';


--
-- Name: COLUMN sys_user.create_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.create_by IS '创建者';


--
-- Name: COLUMN sys_user.update_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.update_by IS '更新者';


--
-- Name: COLUMN sys_user.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.created_at IS '创建时间';


--
-- Name: COLUMN sys_user.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.updated_at IS '最后更新时间';


--
-- Name: COLUMN sys_user.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.deleted_at IS '删除时间';


--
-- Name: COLUMN sys_user.allow_password_login; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sys_user.allow_password_login IS '是否允许账号密码登录';


--
-- Name: sys_user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_user_user_id_seq OWNER TO postgres;

--
-- Name: sys_user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_user_user_id_seq OWNED BY public.sys_user.user_id;


--
-- Name: sys_config id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_config ALTER COLUMN id SET DEFAULT nextval('public.sys_config_id_seq'::regclass);


--
-- Name: sys_config_test id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_config_test ALTER COLUMN id SET DEFAULT nextval('public.sys_config_test_id_seq'::regclass);


--
-- Name: sys_dept dept_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dept ALTER COLUMN dept_id SET DEFAULT nextval('public.sys_dept_dept_id_seq'::regclass);


--
-- Name: sys_login_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_login_log ALTER COLUMN id SET DEFAULT nextval('public.sys_login_log_id_seq'::regclass);


--
-- Name: sys_menu menu_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_menu ALTER COLUMN menu_id SET DEFAULT nextval('public.sys_menu_menu_id_seq'::regclass);


--
-- Name: sys_opera_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_opera_log ALTER COLUMN id SET DEFAULT nextval('public.sys_opera_log_id_seq'::regclass);


--
-- Name: sys_user user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_user ALTER COLUMN user_id SET DEFAULT nextval('public.sys_user_user_id_seq'::regclass);


--
-- Data for Name: app_runtime_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_runtime_log (id, message_id, trace_id, tenant_code, service_name, level, caller, content, fields_json, source, logged_at, created_at) FROM stdin;
\.


--
-- Data for Name: sys_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_config (id, config_name, config_key, config_value, config_type, is_frontend, remark, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
1	皮肤样式	sys_index_skinName	skin-green	Y	0	主框架页-默认皮肤样式名称:蓝色 skin-blue、绿色 skin-green、紫色 skin-purple、红色 skin-red、黄色 skin-yellow	1	1	2021-05-13 19:56:37.913+08	2021-06-05 13:50:13.123+08	\N
2	初始密码	sys_user_initPassword	123456	Y	0	用户管理-账号初始密码:123456	1	1	2021-05-13 19:56:37.913+08	2021-05-13 19:56:37.913+08	\N
3	侧栏主题	sys_index_sideTheme	theme-dark	Y	0	主框架页-侧边栏主题:深色主题theme-dark，浅色主题theme-light	1	1	2021-05-13 19:56:37.913+08	2021-05-13 19:56:37.913+08	\N
4	系统名称	sys_app_name	公共后台	Y	1		1	0	2021-03-17 08:52:06.067+08	2021-05-28 10:08:25.248+08	\N
5	系统logo	sys_app_logo	https://kiif-ase-web.kiifstudio.com/gw/20260105/20260409-152645.jpg	Y	1		1	0	2021-03-17 08:53:19.462+08	2021-03-17 08:53:19.462+08	\N
7	飞书登录氪爆	feishu_login_kb	{"appId":"cli_a9242c209338dcc4","appSecret":"lbYah6PocTeTUiJhEDXm0fG0cgdwVpCX","redirectUrl":"192.168.32.128:1799/feishu-auth","baseUrl":"https://passport.feishu.cn"}	\N	\N	\N	\N	\N	\N	\N	\N
6	飞书登录千乎	feishu_login_qh	{"appId":"cli_a9242c209338dcc4","appSecret":"lbYah6PocTeTUiJhEDXm0fG0cgdwVpCX","redirectUrl":"http://192.168.32.128:1799/sign-in","baseUrl":"https://passport.feishu.cn"}	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sys_config_test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_config_test (id, config_name, config_key, config_value, config_type, is_frontend, remark, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
1	\N	123	312	312	312	321	0	0	0001-01-01 08:05:43+08:05:43	0001-01-01 08:05:43+08:05:43	2026-05-09 13:21:08.93751+08
\.


--
-- Data for Name: sys_dept; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_dept (dept_id, parent_id, dept_path, dept_name, sort, leader, phone, email, status, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
1	0	12	总部	0				0	1	1	2026-05-08 15:48:24.507396+08	2026-05-08 15:48:24.507396+08	\N
2	1	1	技术部	0				0	1	1	2026-05-08 15:54:27.709293+08	2026-05-08 15:54:27.709293+08	\N
\.


--
-- Data for Name: sys_dict_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_dict_data (dict_code, dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, "default", remark, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: sys_dict_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_dict_type (dict_id, dict_name, dict_type, status, remark, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: sys_login_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_login_log (id, username, status, ipaddr, login_location, browser, os, platform, login_time, remark, msg, created_at, updated_at, create_by, update_by) FROM stdin;
\.


--
-- Data for Name: sys_menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_menu (menu_id, menu_name, title, icon, path, paths, menu_type, action, permission, parent_id, no_cache, breadcrumb, component, sort, visible, is_frame, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
2	Admin	系统管理	api-server	/admin	/0/2	M	无		0	t		Layout	10	0	1	0	1	2021-05-20 21:58:45.679+08	2026-03-09 10:06:07.420935+08	\N
211	Log	日志管理	log	/log	/0/2/211	M			2	f		/log/index	80	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:06:07.43084+08	\N
459	Schedule	定时任务	time-range	/schedule	/0/459	M	无		0	f		Layout	21	0	1	1	1	2020-08-03 09:17:37+08	2026-03-09 10:06:07.422239+08	\N
45		修改管理员	app-group-fill		/0/2/3/45	B	PUT	admin:sysUser:edit	3	f			30	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:06:07.435151+08	\N
58	Dict	字典管理	education	/sys-dict	/0/2/58	M	无	admin:sysDictType:list	2	f		/admin/dict/index	60	0	1	0	1	2021-05-20 22:08:44.526+08	2026-05-11 14:13:12.41909+08	\N
59	SysDictDataManage	字典数据	education	/admin/dict/data/:dictId	/0/2/59	M	无	admin:sysDictData:list	2	f		/admin/dict/data	100	1	1	0	1	2021-05-20 22:08:44.526+08	2026-05-08 10:16:41.657775+08	\N
56	SysDeptManage	部门管理	tree	/sys-dept	/0/2/56	M	无	admin:sysDept:list	2	f		/admin/sysDept/index	40	0	1	0	1	2021-05-20 22:08:44.526+08	2026-05-11 14:13:20.938373+08	\N
43		新增管理员	app-group-fill		/0/2/3/43	B	POST	admin:sysUser:add	3	f			10	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:06:07.432913+08	\N
220		新增菜单	app-group-fill		/0/2/51/220	B		admin:sysMenu:add	51	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.436679+08	\N
221		修改菜单	app-group-fill		/0/2/51/221	B		admin:sysMenu:edit	51	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.437742+08	\N
46		删除管理员	app-group-fill		/0/2/3/46	B	DELETE	admin:sysUser:remove	3	f			20	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:06:07.436161+08	\N
44		查询管理员	app-group-fill		/0/2/3/44	B	GET	admin:sysUser:query	3	f			40	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:06:07.434037+08	\N
244		查询参数	app-group-fill		/0/2/62/244	B		admin:sysConfig:query	62	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.475888+08	\N
243		删除数据	app-group-fill		/0/2/59/243	B		admin:sysDictData:remove	59	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.472536+08	\N
242		修改数据	app-group-fill		/0/2/59/242	B		admin:sysDictData:edit	59	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.471715+08	\N
241		新增数据	app-group-fill		/0/2/59/241	B		admin:sysDictData:add	59	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.471186+08	\N
240		查询数据	app-group-fill		/0/2/59/240	B		admin:sysDictData:query	59	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.470155+08	\N
239		删除类型	app-group-fill		/0/2/58/239	B		system:sysdicttype:remove	58	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.469584+08	\N
238		修改类型	app-group-fill		/0/2/58/238	B		admin:sysDictType:edit	58	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.469081+08	\N
237		新增类型	app-group-fill		/0/2/58/237	B		admin:sysDictType:add	58	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.467973+08	\N
236		查询字典	app-group-fill		/0/2/58/236	B		admin:sysDictType:query	58	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.465296+08	\N
3	SysUserManage	用户管理	user	/admin/sys-user	/0/2/3	M	无	admin:sysUser:list	2	f		/admin/sysUser/index	10	0	1	0	1	2021-05-20 22:08:44.526+08	2026-05-11 14:41:50.410102+08	\N
52	SysRoleManage	角色管理	peoples	/sys-role	/0/2/52	M	无	admin:sysRole:list	2	t		/admin/sysRole/index	21	0	1	0	1	2021-05-20 22:08:44.526+08	2026-05-11 14:41:58.648611+08	\N
231		删除部门	app-group-fill		/0/2/56/231	B		admin:sysDept:remove	56	f			20	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:06:07.446598+08	\N
230		修改部门	app-group-fill		/0/2/56/230	B		admin:sysDept:edit	56	f			30	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:06:07.445589+08	\N
229		新增部门	app-group-fill		/0/2/56/229	B		admin:sysDept:add	56	f			10	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:06:07.444744+08	\N
228		查询部门	app-group-fill		/0/2/56/228	B		admin:sysDept:query	56	f			40	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:06:07.444241+08	\N
227		删除角色	app-group-fill		/0/2/52/227	B		admin:sysRole:remove	52	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.442957+08	\N
226		修改角色	app-group-fill		/0/2/52/226	B		admin:sysRole:update	52	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.44173+08	\N
225		查询角色	app-group-fill		/0/2/52/225	B		admin:sysRole:query	52	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.440878+08	\N
224		新增角色	app-group-fill		/0/2/52/224	B		admin:sysRole:add	52	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.440375+08	\N
223		删除菜单	app-group-fill		/0/2/51/223	B		admin:sysMenu:remove	51	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.439592+08	\N
222		查询菜单	app-group-fill		/0/2/51/222	B		admin:sysMenu:query	51	f			1	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.438246+08	\N
212	SysLoginLogManage	登录日志	logininfor	/admin/sys-login-log	/0/2/211/212	M		admin:sysLoginLog:list	211	f		/admin/sys-login-log/index	1	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:06:07.479282+08	\N
216	OperLog	操作日志	skill	/admin/sys-oper-log	/0/2/211/216	M		admin:sysOperLog:list	211	f		/admin/sys-oper-log/index	1	0	1	0	1	2021-05-20 22:08:44.526+08	2026-03-09 10:06:07.479792+08	\N
251		删除操作日志	app-group-fill		/0/2/211/216/251	B		admin:sysOperLog:remove	216	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.482847+08	\N
250		查询操作日志	app-group-fill		/0/2/211/216/250	B		admin:sysOperLog:query	216	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.482329+08	\N
249		删除登录日志	app-group-fill		/0/2/211/212/249	B		admin:sysLoginLog:remove	212	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.481321+08	\N
248		查询登录日志	app-group-fill		/0/2/211/212/248	B		admin:sysLoginLog:query	212	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.480308+08	\N
247		删除参数	app-group-fill		/0/2/62/247	B		admin:sysConfig:remove	62	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.477747+08	\N
246		修改参数	app-group-fill		/0/2/62/246	B		admin:sysConfig:edit	62	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.477225+08	\N
245		新增参数	app-group-fill		/0/2/62/245	B		admin:sysConfig:add	62	f			0	0	1	1	1	2020-04-11 15:52:48+08	2026-03-09 10:06:07.476431+08	\N
464	sys_job	删除定时任务	app-group-fill		/0/459/460/464	B	无	job:sysJob:remove	460	f			0	0	1	1	1	2020-08-03 09:17:37+08	2026-03-09 10:06:07.48695+08	\N
463	sys_job	修改定时任务	app-group-fill		/0/459/460/463	B	无	job:sysJob:edit	460	f			0	0	1	1	1	2020-08-03 09:17:37+08	2026-03-09 10:06:07.486356+08	\N
462	sys_job	创建定时任务	app-group-fill		/0/459/460/462	B	无	job:sysJob:add	460	f			0	0	1	1	1	2020-08-03 09:17:37+08	2026-03-09 10:06:07.485854+08	\N
461	sys_job	分页获取定时任务	app-group-fill		/0/459/460/461	B	无	job:sysJob:query	460	f			1	0	1	1	1	2020-08-03 09:17:37+08	2026-03-09 10:06:07.484693+08	\N
51	SysMenuManage	菜单管理	tree-table	/sys-menu	/0/2/51	M	无	admin:sysMenu:list	2	t		/sys-menu	30	0	1	0	1	2021-05-20 22:08:44.526+08	2026-05-08 10:16:21.859853+08	\N
550	kbrelease	氪爆发行		/kbrelease		M			0	f			70	0	0	1	1	2026-05-11 17:39:50.184783+08	2026-05-11 17:40:10.138495+08	\N
551	data	数据		/data		D			550	f			0	0	0	1	1	2026-05-11 18:32:31.604085+08	2026-05-11 18:34:45.843724+08	\N
552	SummaryData	汇总数据		/summary-data		M			551	f		/summary-data	0	0	0	1	1	2026-05-11 18:33:40.372285+08	2026-05-12 10:50:17.098699+08	\N
471	CronTask	定时任务	bug	/cron-task	/0/459/471	M			459	f		/cron-task	0	0	1	1	1	2020-08-05 21:24:46+08	2026-05-12 11:09:35.567702+08	\N
\.


--
-- Data for Name: sys_opera_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_opera_log (id, title, business_type, business_types, method, request_method, operator_type, oper_name, dept_name, oper_url, oper_ip, oper_location, oper_param, status, oper_time, json_result, remark, latency_time, user_agent, created_at, updated_at, create_by, update_by, "IOMMU", message_id, trace_id, tenant_code, service_name, user_id) FROM stdin;
1	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"menuType":"M","sort":0,"isFrame":"1","visible":"0","component":"Layout","title":"数据分析","path":"/analysis","icon":"RiAccountCircle2Line"}	1	2026-04-09 11:27:25.817	{"code":200,"data":546,"msg":"success"}	\N	36.915563ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-09 14:33:30.354659+08	\N	\N	\N	\N	159d3b67-04c5-4ee6-86df-66edd9064a97	\N	krboom-publish	admin-api	1
2	编辑菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Update-fm	PUT	BUS	admin	\N	/api/v1/menu/546	192.168.32.128	\N	{"menuType":"M","sort":60,"isFrame":"1","visible":"0","component":"Layout","title":"数据分析","path":"/analysis","icon":"RiAccountCircle2Line","parentId":0,"menuName":"","menuId":546,"paths":"/0/546","action":"","permission":"","noCache":false,"breadcrumb":"","apis":[],"sysApi":[]}	1	2026-04-09 11:27:35.105	{"code":200,"data":546,"msg":"success"}	\N	6.827476ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-09 14:33:30.354659+08	\N	\N	\N	\N	bacb14d6-4742-4c41-8fae-e8a582ddf3f2	\N	krboom-publish	admin-api	1
3	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"menuType":"C","sort":0,"isFrame":"1","visible":"0","component":"/krboom-publish/wechat-analysis/index","title":"微信数据","path":"/krboom-publish/wechat-analysis/index","parentId":546,"menuId":null,"paths":"/0/546","action":"","permission":"","noCache":false,"breadcrumb":"","apis":[],"sysApi":[]}	1	2026-04-09 11:30:01.485	{"code":200,"data":547,"msg":"success"}	\N	12.099146ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-09 14:33:30.354659+08	\N	\N	\N	\N	32c899ac-bdf9-458a-a068-c385fd517831	\N	krboom-publish	admin-api	1
4	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"menuType":"C","sort":0,"isFrame":"1","visible":"0","component":"/cron/index","parentId":459,"path":"/cron/index","title":"定时任务"}	1	2026-04-10 17:42:44.205	{"code":200,"data":548,"msg":"success"}	\N	22.608892ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-10 17:42:46.190022+08	\N	\N	\N	\N	a56f9397-3ac9-42fb-871e-dff1495133cf	\N	krboom-publish	admin-api	1
5	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"ids":[460]}	1	2026-04-10 17:42:52.621	{"code":200,"data":[460],"msg":"success"}	\N	5.777443ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-10 17:42:56.189189+08	\N	\N	\N	\N	38d730d3-fd26-41f1-b774-f5d796bfde21	\N	krboom-publish	admin-api	1
6	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"ids":[60]}	1	2026-04-10 17:43:04.028	{"code":200,"data":[60],"msg":"success"}	\N	4.311391ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-10 17:43:06.188989+08	\N	\N	\N	\N	f7360f95-831d-42a0-a2a0-e4a33e964171	\N	krboom-publish	admin-api	1
7	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"ids":[540]}	1	2026-04-10 17:44:01.189	{"code":200,"data":[540],"msg":"success"}	\N	6.020891ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-10 17:44:06.189435+08	\N	\N	\N	\N	2b6d2139-ff9b-469d-930d-c935e076e692	\N	krboom-publish	admin-api	1
8	/api/v1/cron/task/5/trigger	\N	\N	POST /api/v1/cron/task/5/trigger	POST	\N	admin	\N	/api/v1/cron/task/5/trigger	192.168.32.128	\N	\N	1	2026-04-10 17:57:01.734	{"code":200,"data":{"id":7894,"task_id":5,"tenant_code":"krboom-publish","task_key":"ocean_engine_da	\N	18.539358ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-10 17:57:02.788941+08	\N	\N	\N	\N	70feb36d-6c76-4083-bcef-4206a5af0687	\N	krboom-publish	admin-api	1
9	/api/v1/cron/task	\N	\N	POST /api/v1/cron/task	POST	\N	admin	\N	/api/v1/cron/task	192.168.32.128	\N	{"taskKey":"test","taskName":"尔特","scheduleType":"interval","intervalSeconds":5,"scheduledAt":"2026-04-13T02:58:10.000Z","payload":{"invokeTarget":"EchoArgs","args":"testt"}}	1	2026-04-13 10:57:31.448	{"code":200,"data":{"id":6,"tenant_code":"krboom-publish","task_key":"test","task_name":"尔特","ta	\N	10.650015ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-13 10:57:34.356445+08	\N	\N	\N	\N	ad56d304-d57b-4829-8146-5df154cb81f8	\N	krboom-publish	admin-api	1
10	/api/v1/cron/task/6/status	\N	\N	PUT /api/v1/cron/task/6/status	PUT	\N	admin	\N	/api/v1/cron/task/6/status	192.168.32.128	\N	{"status":"disabled"}	1	2026-04-13 10:58:27.278	{"code":200,"data":{"id":6,"tenant_code":"krboom-publish","task_key":"test","task_name":"尔特","ta	\N	4.701952ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-13 10:58:30.175647+08	\N	\N	\N	\N	ae4063b3-279b-4956-ac3f-7de7a48e32af	\N	krboom-publish	admin-api	1
11	编辑菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Update-fm	PUT	BUS	admin	\N	/api/v1/menu/2	192.168.32.128	\N	{"menuType":"M","sort":10,"isFrame":"1","visible":"0","component":"Layout","menuId":2,"menuName":"Admin","title":"系统管理","icon":"Ri4kLine","path":"/admin","paths":"/0/2","action":"无","permission":"","parentId":0,"noCache":true,"breadcrumb":"","apis":[],"sysApi":[]}	1	2026-04-13 14:30:25.225	{"code":200,"data":2,"msg":"success"}	\N	10.331827ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-13 14:30:29.734338+08	\N	\N	\N	\N	76b651b6-8551-45bc-bfa4-1857ba50951a	\N	krboom-publish	admin-api	1
12	/api/v1/cron/task/7/trigger	\N	\N	POST /api/v1/cron/task/7/trigger	POST	\N	admin	\N	/api/v1/cron/task/7/trigger	192.168.32.128	\N	\N	2	2026-04-14 16:19:45.317	{"code":500,"msg":"rpc error: code = Unavailable desc = last connection error: connection error: des	\N	1.373089ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-14 16:19:50.329453+08	\N	\N	\N	\N	e762fe5c-6a9f-4c61-83c5-0f8e791fedac	\N	krboom-publish	admin-api	1
13	/api/v1/cron/task/7/trigger	\N	\N	POST /api/v1/cron/task/7/trigger	POST	\N	admin	\N	/api/v1/cron/task/7/trigger	192.168.32.128	\N	\N	1	2026-04-14 16:19:50.364	{"code":200,"data":{"id":7921,"task_id":7,"tenant_code":"krboom-publish","task_key":"refresh_token",	\N	4.893855ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-14 16:19:55.327735+08	\N	\N	\N	\N	110d8caa-8158-43b4-bde1-557b43917aa6	\N	krboom-publish	admin-api	1
14	/api/v1/cron/task/7/trigger	\N	\N	POST /api/v1/cron/task/7/trigger	POST	\N	admin	\N	/api/v1/cron/task/7/trigger	192.168.32.128	\N	\N	1	2026-04-14 16:20:09.971	{"code":200,"data":{"id":7926,"task_id":7,"tenant_code":"krboom-publish","task_key":"refresh_token",	\N	8.499337ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-14 16:20:10.328973+08	\N	\N	\N	\N	59953f78-3035-4844-be79-80305c564c56	\N	krboom-publish	admin-api	1
15	/api/v1/cron/task/6/status	\N	\N	PUT /api/v1/cron/task/6/status	PUT	\N	admin	\N	/api/v1/cron/task/6/status	192.168.32.128	\N	{"status":"enabled"}	1	2026-04-15 13:51:00.872	{"code":200,"data":{"id":6,"tenant_code":"krboom-publish","task_key":"test","task_name":"尔特","ta	\N	10.9562ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-15 13:51:05.020458+08	\N	\N	\N	\N	6b4abb56-7448-4b7c-832f-6ef2a925535a	\N	krboom-publish	admin-api	1
16	/api/v1/cron/task/6	\N	\N	PUT /api/v1/cron/task/6	PUT	\N	admin	\N	/api/v1/cron/task/6	192.168.32.128	\N	{"taskName":"尔特","scheduleType":"interval","intervalSeconds":5,"scheduledAt":"2026-04-15T05:53:15.000Z","payload":{"invokeTarget":"EchoArgs","args":"testt"}}	1	2026-04-15 13:51:20.48	{"code":200,"data":{"id":6,"tenant_code":"krboom-publish","task_key":"test","task_name":"尔特","ta	\N	10.124795ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-15 13:51:25.0213+08	\N	\N	\N	\N	6cd888b2-d3f8-401f-bf8b-d585ad29f052	\N	krboom-publish	admin-api	1
17	/api/v1/cron/task/6/status	\N	\N	PUT /api/v1/cron/task/6/status	PUT	\N	admin	\N	/api/v1/cron/task/6/status	192.168.32.128	\N	{"status":"disabled"}	1	2026-04-15 13:53:29.872	{"code":200,"data":{"id":6,"tenant_code":"krboom-publish","task_key":"test","task_name":"尔特","ta	\N	8.121481ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-15 13:53:30.021573+08	\N	\N	\N	\N	f389eb27-66e4-4629-a9e4-70c3d884ff33	\N	krboom-publish	admin-api	1
18	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"ids":[60]}	1	2026-04-16 17:42:23.421	{"code":200,"data":[60],"msg":"success"}	\N	9.73737ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-16 17:42:26.422169+08	\N	\N	\N	\N	ad36f9f7-404a-48d3-80e9-cad0db55498c	\N	kiif-gm	admin-api	1
19	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"ids":[537]}	1	2026-04-16 17:42:33.572	{"code":200,"data":[537],"msg":"success"}	\N	4.3286ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-16 17:42:36.421164+08	\N	\N	\N	\N	5c9fb88e-2790-43c0-846b-c3a27ae67688	\N	kiif-gm	admin-api	1
20	/api/v1/cron/task/8/trigger	\N	\N	POST /api/v1/cron/task/8/trigger	POST	\N	admin	\N	/api/v1/cron/task/8/trigger	192.168.32.128	\N	\N	1	2026-04-17 14:11:37.302	{"code":200,"data":{"id":27941,"task_id":8,"tenant_code":"krboom-publish","task_key":"wechat_analysi	\N	56.347236ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-17 14:11:37.748911+08	\N	\N	\N	\N	08415271-52fa-46af-ab69-860003e44fcb	\N	krboom-publish	admin-api	1
21	接口编辑	BUS	BUS	go-admin/app/admin/apis.SysApi.Update-fm	PUT	BUS	admin	\N	/api/v1/sys-api/159	192.168.32.128	\N	{"id":159,"handle":"github.com/gin-gonic/gin.(*RouterGroup).createStaticHandler.func1","title":"让他","path":"/form-generator/*filepath","action":"HEAD","type":"","createdAt":"2021-06-13T19:25:02.808+08:00","updatedAt":"2021-06-13T20:53:52.838+08:00"}	2	2026-04-21 10:45:06.229	{"code":400,"msg":"invalid request"}	\N	1.275046ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 10:45:08.288083+08	\N	\N	\N	\N	4057b10f-967a-43f5-b0ab-2d952c08c013	\N	krboom-publish	admin-api	1
22	管理员编辑	BUS	BUS	go-admin/app/admin/apis.SysUser.Update-fm	PUT	BUS	admin	\N	/api/v1/sys-user	192.168.32.128	\N	{"userId":6,"username":"1234","password":"","nickName":"1234","phone":"1234","roleId":1,"avatar":"","sex":"","email":"1234@qq.com","deptId":7,"postId":0,"remark":"","status":"2","allowPasswordLogin":"1","deptIds":[7],"postIds":[0],"roleIds":[1],"createBy":1,"updateBy":0,"dept":{"deptId":7,"parentId":1,"deptPath":"/0/1/7/","deptName":"研发部","sort":1,"leader":"aituo","phone":"13782218188","email":"atuo@aituo.com","status":2,"createdAt":"0001-01-01T00:00:00Z","updatedAt":"0001-01-01T00:00:00Z","children":[]},"createdAt":"2026-03-13T18:42:15.087875+08:00","updatedAt":"2026-03-13T18:42:51.908351+08:00"}	1	2026-04-21 10:45:21.702	{"code":200,"data":6,"msg":"update success"}	\N	20.665268ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 10:45:23.297326+08	\N	\N	\N	\N	64a2cc4b-38ac-43a0-a43c-27b8e5aecc48	\N	krboom-publish	admin-api	1
23	管理员编辑	BUS	BUS	go-admin/app/admin/apis.SysUser.Update-fm	PUT	BUS	admin	\N	/api/v1/sys-user	192.168.32.128	\N	{"userId":6,"username":"1234","password":"","nickName":"12345","phone":"1234","roleId":1,"avatar":"","sex":"","email":"1234@qq.com","deptId":7,"postId":0,"remark":"","status":"2","allowPasswordLogin":"1","deptIds":[7],"postIds":[0],"roleIds":[1],"createBy":1,"updateBy":1,"dept":{"deptId":7,"parentId":1,"deptPath":"/0/1/7/","deptName":"研发部","sort":1,"leader":"aituo","phone":"13782218188","email":"atuo@aituo.com","status":2,"createdAt":"0001-01-01T00:00:00Z","updatedAt":"0001-01-01T00:00:00Z","children":[]},"createdAt":"2026-03-13T18:42:15.087875+08:00","updatedAt":"2026-04-21T10:45:21.718039+08:00"}	1	2026-04-21 10:45:26.98	{"code":200,"data":6,"msg":"update success"}	\N	8.804627ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 10:45:28.279151+08	\N	\N	\N	\N	837fd782-552b-4baf-b9bc-301f84def089	\N	krboom-publish	admin-api	1
24	角色编辑	BUS	BUS	go-admin/app/admin/apis.SysRole.Update-fm	PUT	BUS	admin	\N	/api/v1/role/1	192.168.32.128	\N	{"sort":0,"status":"2","roleId":1,"roleName":"系统管理员","roleKey":"admin","roleSort":1,"flag":"","remark":"","admin":true,"dataScope":"","menuIds":[],"deptIds":null,"sysMenu":null,"createdAt":"2021-05-13T19:56:37.913+08:00","updatedAt":"2021-05-13T19:56:37.913+08:00"}	1	2026-04-21 10:45:56.82	{"code":200,"data":1,"msg":"success"}	\N	11.565425ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 10:45:58.285513+08	\N	\N	\N	\N	791d194c-cf00-43b4-89f5-c28ddbcf40b3	\N	krboom-publish	admin-api	1
25	角色创建	BUS	BUS	go-admin/app/admin/apis.SysRole.Insert-fm	POST	BUS	admin	\N	/api/v1/role	192.168.32.128	\N	{"sort":0,"status":"2","roleId":null,"roleName":"34","roleKey":"423","roleSort":2,"flag":"","admin":true,"dataScope":"","menuIds":[459,471,548],"deptIds":null,"sysMenu":null,"createdAt":"2021-05-13T19:56:37.913+08:00","updatedAt":"2021-05-13T19:56:37.913+08:00"}	1	2026-04-21 10:46:03.588	{"code":200,"data":5,"msg":"success"}	\N	13.31411ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 10:46:08.284434+08	\N	\N	\N	\N	97e1159d-dbf5-4c09-8422-2597c062003a	\N	krboom-publish	admin-api	1
26	管理员编辑	BUS	BUS	go-admin/app/admin/apis.SysUser.Update-fm	PUT	BUS	admin	\N	/api/v1/sys-user	192.168.32.128	\N	{"userId":1,"username":"admin","password":"","nickName":"zhangwj","phone":"18612529003","roleId":1,"avatar":"","sex":"1","email":"1@qq.com","deptId":1,"postId":1,"remark":"","status":"2","allowPasswordLogin":"2","deptIds":[1],"postIds":[1],"roleIds":[1],"createBy":1,"updateBy":1,"dept":{"deptId":1,"parentId":0,"deptPath":"/0/1/","deptName":"爱拓科技","sort":0,"leader":"aituo","phone":"13782218188","email":"atuo@aituo.com","status":2,"createdAt":"0001-01-01T00:00:00Z","updatedAt":"0001-01-01T00:00:00Z","children":[]},"createdAt":"2021-05-13T19:56:37.914+08:00","updatedAt":"2021-05-13T19:56:40.205+08:00"}	1	2026-04-21 12:43:50.022	{"code":200,"data":1,"msg":"update success"}	\N	16.799441ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 12:43:52.652189+08	\N	\N	\N	\N	1bfeacf7-49d6-45d6-a7a4-dd031ee98ff3	\N	krboom-publish	admin-api	1
27	管理员编辑	BUS	BUS	go-admin/app/admin/apis.SysUser.Update-fm	PUT	BUS	admin	\N	/api/v1/sys-user	192.168.32.128	\N	{"userId":6,"username":"1234","password":"","nickName":"12345","phone":"1234","roleId":1,"avatar":"","sex":"","email":"1234@qq.com","deptId":7,"postId":0,"remark":"","status":"2","allowPasswordLogin":"1","deptIds":[7],"postIds":[0],"roleIds":[1],"createBy":1,"updateBy":1,"dept":{"deptId":7,"parentId":1,"deptPath":"/0/1/7/","deptName":"研发部","sort":1,"leader":"aituo","phone":"13782218188","email":"atuo@aituo.com","status":2,"createdAt":"0001-01-01T00:00:00Z","updatedAt":"0001-01-01T00:00:00Z","children":[]},"createdAt":"2026-03-13T18:42:15.087875+08:00","updatedAt":"2026-04-21T10:45:26.984838+08:00"}	1	2026-04-21 13:54:27.398	{"code":200,"data":6,"msg":"update success"}	\N	12.195039ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-21 13:54:29.603613+08	\N	\N	\N	\N	cac13907-8edd-484d-b127-c6d999ef8829	\N	krboom-publish	admin-api	1
28	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"menuType":"M","sort":0,"isFrame":"1","visible":"0","component":"Layout","title":"GM工具","path":"gmtools"}	1	2026-04-22 10:03:00.28	{"code":200,"data":551,"msg":"success"}	\N	48.400371ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:03:02.586531+08	\N	\N	\N	\N	ac5fda4e-4c49-441d-9a4e-1d9adac3c6d0	\N	kiif-gm	admin-api	1
29	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"menuType":"C","sort":0,"isFrame":"1","visible":"0","component":"/kiif-gm/announcement/index","title":"公告","path":"/kiif-gm/announcement/index","parentId":551,"menuId":null,"paths":"/0/551","action":"","permission":"","noCache":false,"breadcrumb":"","apis":[],"sysApi":[]}	1	2026-04-22 10:03:35.114	{"code":200,"data":552,"msg":"success"}	\N	14.91145ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:03:37.591443+08	\N	\N	\N	\N	7cc51665-3436-4337-9b38-aa3843890d98	\N	kiif-gm	admin-api	1
30	/api/v1/user/status	\N	\N	go-admin/app/admin/apis.SysUser.UpdateStatus-fm	PUT	\N	admin	\N	/api/v1/user/status	192.168.32.128	\N	{"userId":6,"status":"1"}	1	2026-04-22 10:32:14.338	{"code":200,"data":6,"msg":"update success"}	\N	25.130761ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:32:17.56786+08	\N	\N	\N	\N	8ce92b70-c820-4759-84a0-4ede77f02a0b	\N	krboom-publish	admin-api	1
31	/api/v1/user/status	\N	\N	go-admin/app/admin/apis.SysUser.UpdateStatus-fm	PUT	\N	admin	\N	/api/v1/user/status	192.168.32.128	\N	{"userId":6,"status":"2"}	1	2026-04-22 10:32:20.05	{"code":200,"data":6,"msg":"update success"}	\N	10.203911ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:32:22.581297+08	\N	\N	\N	\N	fedf87a4-03b1-4d6d-bae9-4eccdee110a5	\N	krboom-publish	admin-api	1
32	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"ids":[269]}	1	2026-04-22 10:33:07.248	{"code":200,"data":[269],"msg":"success"}	\N	13.640113ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:33:07.570063+08	\N	\N	\N	\N	56d496f2-128d-48b3-a0d8-be20630a00b0	\N	krboom-publish	admin-api	1
33	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"menuType":"C","sort":0,"isFrame":"1","visible":"0","component":"/kiif-gm/data-source/index","parentId":537,"menuName":"","path":"/kiif-gm/data-source/index","title":"数据源"}	1	2026-04-22 10:33:28.955	{"code":200,"data":549,"msg":"success"}	\N	51.256943ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:33:32.571502+08	\N	\N	\N	\N	6402590c-5686-41c5-a7ad-89105dd8f372	\N	krboom-publish	admin-api	1
34	删除菜单	BUS	BUS	go-admin/app/admin/apis.SysMenu.Delete-fm	DELETE	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"ids":[549]}	1	2026-04-22 10:34:14.373	{"code":200,"data":[549],"msg":"success"}	\N	5.683232ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:34:17.571711+08	\N	\N	\N	\N	7dfb0dd0-073e-4d46-96a9-91ebab195669	\N	krboom-publish	admin-api	1
35	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"menuType":"M","sort":0,"isFrame":"1","visible":"0","component":"Layout","title":"系统工具","path":"systemTools"}	1	2026-04-22 10:34:45.051	{"code":200,"data":553,"msg":"success"}	\N	15.362252ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:34:47.568119+08	\N	\N	\N	\N	a27c5546-7ef3-4999-98a3-d0ed7a5b4659	\N	kiif-gm	admin-api	1
36	菜单创建	BUS	BUS	go-admin/app/admin/apis.SysMenu.Insert-fm	POST	BUS	admin	\N	/api/v1/menu	192.168.32.128	\N	{"menuType":"C","sort":0,"isFrame":"1","visible":"0","component":"/kiif-gm/data-source/index","title":"数据源","path":"/kiif-gm/data-source/index","parentId":553,"menuId":null}	1	2026-04-22 10:41:07.779	{"code":200,"data":554,"msg":"success"}	\N	12.712358ms	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-04-22 10:41:12.567122+08	\N	\N	\N	\N	21f9c8ef-b688-4119-8e76-c22f5f3a0995	\N	kiif-gm	admin-api	1
\.


--
-- Data for Name: sys_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_role (role_id, role_name, status, role_key, role_sort, flag, remark, admin, data_scope, create_by, update_by, created_at, updated_at, deleted_at) FROM stdin;
1	系统管理员	2	admin	1			t		1	1	2021-05-13 19:56:37.913+08	2021-05-13 19:56:37.913+08	\N
\.


--
-- Data for Name: sys_role_dept; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_role_dept (id, role_id, dept_id) FROM stdin;
\.


--
-- Data for Name: sys_role_menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_role_menu (id, role_id, menu_id) FROM stdin;
\.


--
-- Data for Name: sys_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_user (user_id, username, password, nick_name, phone, role_id, salt, avatar, sex, email, dept_id, post_id, remark, status, create_by, update_by, created_at, updated_at, deleted_at, allow_password_login) FROM stdin;
1	admin	$2a$10$/Glr4g9Svr6O0kvjsRJCXu3f0W8/dsP3XZyVNi1019ratWpSPMyw.	zhangwj	18612529005	1			1	1@qq.com	1	1		2	1	1	2021-05-13 19:56:37.914+08	2026-04-21 12:43:50.035854+08	\N	2
18	lisheng	$2a$10$EUZi/pqcsNf/m4HoUZADMOC/afQbKAIQF00xvCD1/7TIfik9wpJD.	李晟	18612529003	1	ppngPwSwu7worQjBwdBm6w		2		1	0		2	1	1	2026-05-08 15:26:13.159496+08	2026-05-11 16:03:40.794586+08	\N	2
16	123456	$2a$10$qB06WEWdtZK0Yc0k0Qe6fu61barJYRi.tULe51Kj5UAlGRDnH0rdO	123456	123456	1			2	123456@qq.com	2	0		2	0	1	2026-03-13 15:52:44.010772+08	2026-05-11 16:31:13.508325+08	\N	0
\.


--
-- Name: sys_config_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_config_config_id_seq', 6, true);


--
-- Name: sys_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_config_id_seq', 1, true);


--
-- Name: sys_config_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_config_test_id_seq', 1, true);


--
-- Name: sys_dept_dept_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_dept_dept_id_seq', 2, true);


--
-- Name: sys_job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_job_id_seq', 3, true);


--
-- Name: sys_login_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_login_log_id_seq', 1, false);


--
-- Name: sys_menu_menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_menu_menu_id_seq', 552, true);


--
-- Name: sys_opera_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_opera_log_id_seq', 36, true);


--
-- Name: sys_user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_user_user_id_seq', 18, true);


--
-- Name: app_runtime_log app_runtime_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_runtime_log
    ADD CONSTRAINT app_runtime_log_pkey PRIMARY KEY (id);


--
-- Name: sys_config sys_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_config
    ADD CONSTRAINT sys_config_pkey PRIMARY KEY (id);


--
-- Name: sys_config_test sys_config_test_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_config_test
    ADD CONSTRAINT sys_config_test_pkey PRIMARY KEY (id);


--
-- Name: sys_dept sys_dept_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dept
    ADD CONSTRAINT sys_dept_pkey PRIMARY KEY (dept_id);


--
-- Name: sys_dict_data sys_dict_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dict_data
    ADD CONSTRAINT sys_dict_data_pkey PRIMARY KEY (dict_code);


--
-- Name: sys_dict_type sys_dict_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_dict_type
    ADD CONSTRAINT sys_dict_type_pkey PRIMARY KEY (dict_id);


--
-- Name: sys_login_log sys_login_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_login_log
    ADD CONSTRAINT sys_login_log_pkey PRIMARY KEY (id);


--
-- Name: sys_menu sys_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_menu
    ADD CONSTRAINT sys_menu_pkey PRIMARY KEY (menu_id);


--
-- Name: sys_opera_log sys_opera_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_opera_log
    ADD CONSTRAINT sys_opera_log_pkey PRIMARY KEY (id);


--
-- Name: sys_role_dept sys_role_dept_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role_dept
    ADD CONSTRAINT sys_role_dept_pkey PRIMARY KEY (id);


--
-- Name: sys_role_menu sys_role_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role_menu
    ADD CONSTRAINT sys_role_menu_pkey PRIMARY KEY (id);


--
-- Name: sys_role sys_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_role
    ADD CONSTRAINT sys_role_pkey PRIMARY KEY (role_id);


--
-- Name: sys_user sys_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_user
    ADD CONSTRAINT sys_user_pkey PRIMARY KEY (user_id);


--
-- Name: idx_sys_config_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_create_by ON public.sys_config USING btree (create_by);


--
-- Name: idx_sys_config_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_deleted_at ON public.sys_config USING btree (deleted_at);


--
-- Name: idx_sys_config_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_config_update_by ON public.sys_config USING btree (update_by);


--
-- Name: idx_sys_login_log_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_login_log_create_by ON public.sys_login_log USING btree (create_by);


--
-- Name: idx_sys_login_log_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_login_log_update_by ON public.sys_login_log USING btree (update_by);


--
-- Name: idx_sys_menu_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_create_by ON public.sys_menu USING btree (create_by);


--
-- Name: idx_sys_menu_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_deleted_at ON public.sys_menu USING btree (deleted_at);


--
-- Name: idx_sys_menu_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_menu_update_by ON public.sys_menu USING btree (update_by);


--
-- Name: idx_sys_opera_log_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_opera_log_create_by ON public.sys_opera_log USING btree (create_by);


--
-- Name: idx_sys_opera_log_message_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_sys_opera_log_message_id_unique ON public.sys_opera_log USING btree (message_id);


--
-- Name: idx_sys_opera_log_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_opera_log_update_by ON public.sys_opera_log USING btree (update_by);


--
-- Name: idx_sys_user_create_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_create_by ON public.sys_user USING btree (create_by);


--
-- Name: idx_sys_user_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_deleted_at ON public.sys_user USING btree (deleted_at);


--
-- Name: idx_sys_user_update_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sys_user_update_by ON public.sys_user USING btree (update_by);


--
-- PostgreSQL database dump complete
--

\unrestrict cEXweKFhiafLraYnVes1lNc5g0Mt6CMDr9iCMHdyOor28d499JGt7clszhHESSp

