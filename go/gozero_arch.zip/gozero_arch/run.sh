#!/bin/bash


bash stop.sh

mkdir -p ./bin/logs/console/
cd ./bin

servers=(
	"user"
	"admin"
	
	"user-api"
	"admin-api"
)

for server in ${servers[@]}; do
    echo "Starting ${server}"
    nohup ./${server} tag=gozero-${server} >> ./logs/console/${server}.log 2>&1 &
done

sleep 1

echo "检查服务进程"
for ((i=0; i < ${#servers[*]}; i++))
do
	server_name=${servers[$i]}
	pss=`ps -ef | grep gozero-${server_name} | grep -v grep`
    if [ "${pss}" == "" ]; then
        echo "启动失败" ${server_name}
	else
		echo "启动成功 ${pss}"
	fi
done