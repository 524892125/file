import webapi from "./gocliRequest"
import * as components from "./adminComponents"
export * from "./adminComponents"

/**
 * @description 
 * @param req
 */
export function login(req: components.LoginReq) {
	return webapi.post<components.LoginResp>(`/api/v1/login`, req)
}

/**
 * @description 
 */
export function createAuth() {
	return webapi.post<null>(`/users/auth/create`)
}

/**
 * @description 
 */
export function getUser() {
	return webapi.get<components.Response>(`/users/id/${userId}`)
}

/**
 * @description 
 */
export function getInfo() {
	return webapi.get<components.GetInfoResp>(`/api/v1/getinfo`)
}

/**
 * @description 
 * @param params
 */
export function getSysConfig(params: components.SysConfigIdReqParams, id: number) {
	return webapi.get<components.SysConfig>(`/db/sys-config/${id}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysConfig(params: components.SysConfigIdReqParams, id: number) {
	return webapi.delete<components.SysConfigEmptyResp>(`/db/sys-config/${id}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysConfig(req: components.SysConfigCreateReq) {
	return webapi.post<components.SysConfigCreateResp>(`/db/sys-config/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysConfig(params: components.SysConfigListReqParams) {
	return webapi.get<components.SysConfigFindPageResp>(`/db/sys-config/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysConfig(params: components.SysConfigListReqParams) {
	return webapi.get<components.SysConfigListResp>(`/db/sys-config/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysConfig(req: components.SysConfigUpdateReq) {
	return webapi.post<components.SysConfigEmptyResp>(`/db/sys-config/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getAppRuntimeLog(params: components.AppRuntimeLogIdReqParams, id: number) {
	return webapi.get<components.AppRuntimeLog>(`/db/app-runtime-log/${id}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteAppRuntimeLog(params: components.AppRuntimeLogIdReqParams, id: number) {
	return webapi.delete<components.AppRuntimeLogEmptyResp>(`/db/app-runtime-log/${id}`, params)
}

/**
 * @description 
 * @param req
 */
export function createAppRuntimeLog(req: components.AppRuntimeLogCreateReq) {
	return webapi.post<components.AppRuntimeLogCreateResp>(`/db/app-runtime-log/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageAppRuntimeLog(params: components.AppRuntimeLogListReqParams) {
	return webapi.get<components.AppRuntimeLogFindPageResp>(`/db/app-runtime-log/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listAppRuntimeLog(params: components.AppRuntimeLogListReqParams) {
	return webapi.get<components.AppRuntimeLogListResp>(`/db/app-runtime-log/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateAppRuntimeLog(req: components.AppRuntimeLogUpdateReq) {
	return webapi.post<components.AppRuntimeLogEmptyResp>(`/db/app-runtime-log/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysUser(params: components.SysUserIdReqParams, userId: number) {
	return webapi.get<components.SysUser>(`/db/sys-user/${userId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysUser(params: components.SysUserIdReqParams, userId: number) {
	return webapi.delete<components.SysUserEmptyResp>(`/db/sys-user/${userId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysUser(req: components.SysUserCreateReq) {
	return webapi.post<components.SysUserCreateResp>(`/db/sys-user/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysUser(params: components.SysUserListReqParams) {
	return webapi.get<components.SysUserFindPageResp>(`/db/sys-user/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysUser(params: components.SysUserListReqParams) {
	return webapi.get<components.SysUserListResp>(`/db/sys-user/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysUser(req: components.SysUserUpdateReq) {
	return webapi.post<components.SysUserEmptyResp>(`/db/sys-user/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysMenu(params: components.SysMenuIdReqParams, menuId: number) {
	return webapi.get<components.SysMenu>(`/db/sys-menu/${menuId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysMenu(params: components.SysMenuIdReqParams, menuId: number) {
	return webapi.delete<components.SysMenuEmptyResp>(`/db/sys-menu/${menuId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysMenu(req: components.SysMenuCreateReq) {
	return webapi.post<components.SysMenuCreateResp>(`/db/sys-menu/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysMenu(params: components.SysMenuListReqParams) {
	return webapi.get<components.SysMenuFindPageResp>(`/db/sys-menu/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysMenu(params: components.SysMenuListReqParams) {
	return webapi.get<components.SysMenuListResp>(`/db/sys-menu/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysMenu(req: components.SysMenuUpdateReq) {
	return webapi.post<components.SysMenuEmptyResp>(`/db/sys-menu/update`, req)
}
