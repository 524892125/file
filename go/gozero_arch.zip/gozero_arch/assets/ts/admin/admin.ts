import webapi from "./gocliRequest"
import * as components from "./adminComponents"
export * from "./adminComponents"

/**
 * @description 
 * @param req
 */
export function login(req: components.LoginReq) {
	return webapi.post<components.LoginResp>(`/api/v1/login`, req)
}

/**
 * @description 
 */
export function createAuth() {
	return webapi.post<null>(`/users/auth/create`)
}

/**
 * @description 
 */
export function getUser() {
	return webapi.get<components.Response>(`/users/id/${userId}`)
}

/**
 * @description 
 */
export function getInfo() {
	return webapi.get<components.GetInfoResp>(`/api/v1/getinfo`)
}

/**
 * @description 
 */
export function menuRole() {
	return webapi.get<components.MenuRoleResp>(`/api/v1/menurole`)
}

/**
 * @description 
 * @param params
 */
export function getSysDictData(params: components.SysDictDataIdReqParams, dictCode: number) {
	return webapi.get<components.SysDictData>(`/db/sys-dict-data/${dictCode}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysDictData(params: components.SysDictDataIdReqParams, dictCode: number) {
	return webapi.delete<components.SysDictDataEmptyResp>(`/db/sys-dict-data/${dictCode}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysDictData(req: components.SysDictDataCreateReq) {
	return webapi.post<components.SysDictDataCreateResp>(`/db/sys-dict-data/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysDictData(params: components.SysDictDataListReqParams) {
	return webapi.get<components.SysDictDataFindPageResp>(`/db/sys-dict-data/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysDictData(params: components.SysDictDataListReqParams) {
	return webapi.get<components.SysDictDataListResp>(`/db/sys-dict-data/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysDictData(req: components.SysDictDataUpdateReq) {
	return webapi.post<components.SysDictDataEmptyResp>(`/db/sys-dict-data/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysDictType(params: components.SysDictTypeIdReqParams, dictId: number) {
	return webapi.get<components.SysDictType>(`/db/sys-dict-type/${dictId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysDictType(params: components.SysDictTypeIdReqParams, dictId: number) {
	return webapi.delete<components.SysDictTypeEmptyResp>(`/db/sys-dict-type/${dictId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysDictType(req: components.SysDictTypeCreateReq) {
	return webapi.post<components.SysDictTypeCreateResp>(`/db/sys-dict-type/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysDictType(params: components.SysDictTypeListReqParams) {
	return webapi.get<components.SysDictTypeFindPageResp>(`/db/sys-dict-type/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysDictType(params: components.SysDictTypeListReqParams) {
	return webapi.get<components.SysDictTypeListResp>(`/db/sys-dict-type/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysDictType(req: components.SysDictTypeUpdateReq) {
	return webapi.post<components.SysDictTypeEmptyResp>(`/db/sys-dict-type/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysConfig(params: components.SysConfigIdReqParams, id: number) {
	return webapi.get<components.SysConfig>(`/db/sys-config/${id}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysConfig(params: components.SysConfigIdReqParams, id: number) {
	return webapi.delete<components.SysConfigEmptyResp>(`/db/sys-config/${id}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysConfig(req: components.SysConfigCreateReq) {
	return webapi.post<components.SysConfigCreateResp>(`/db/sys-config/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysConfig(params: components.SysConfigListReqParams) {
	return webapi.get<components.SysConfigFindPageResp>(`/db/sys-config/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysConfig(params: components.SysConfigListReqParams) {
	return webapi.get<components.SysConfigListResp>(`/db/sys-config/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysConfig(req: components.SysConfigUpdateReq) {
	return webapi.post<components.SysConfigEmptyResp>(`/db/sys-config/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getAppRuntimeLog(params: components.AppRuntimeLogIdReqParams, id: number) {
	return webapi.get<components.AppRuntimeLog>(`/db/app-runtime-log/${id}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteAppRuntimeLog(params: components.AppRuntimeLogIdReqParams, id: number) {
	return webapi.delete<components.AppRuntimeLogEmptyResp>(`/db/app-runtime-log/${id}`, params)
}

/**
 * @description 
 * @param req
 */
export function createAppRuntimeLog(req: components.AppRuntimeLogCreateReq) {
	return webapi.post<components.AppRuntimeLogCreateResp>(`/db/app-runtime-log/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageAppRuntimeLog(params: components.AppRuntimeLogListReqParams) {
	return webapi.get<components.AppRuntimeLogFindPageResp>(`/db/app-runtime-log/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listAppRuntimeLog(params: components.AppRuntimeLogListReqParams) {
	return webapi.get<components.AppRuntimeLogListResp>(`/db/app-runtime-log/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateAppRuntimeLog(req: components.AppRuntimeLogUpdateReq) {
	return webapi.post<components.AppRuntimeLogEmptyResp>(`/db/app-runtime-log/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysUser(params: components.SysUserIdReqParams, userId: number) {
	return webapi.get<components.SysUser>(`/db/sys-user/${userId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysUser(params: components.SysUserIdReqParams, userId: number) {
	return webapi.delete<components.SysUserEmptyResp>(`/db/sys-user/${userId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysUser(req: components.SysUserCreateReq) {
	return webapi.post<components.SysUserCreateResp>(`/db/sys-user/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysUser(params: components.SysUserListReqParams) {
	return webapi.get<components.SysUserFindPageResp>(`/db/sys-user/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysUser(params: components.SysUserListReqParams) {
	return webapi.get<components.SysUserListResp>(`/db/sys-user/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysUser(req: components.SysUserUpdateReq) {
	return webapi.post<components.SysUserEmptyResp>(`/db/sys-user/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysMenu(params: components.SysMenuIdReqParams, menuId: number) {
	return webapi.get<components.SysMenu>(`/db/sys-menu/${menuId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysMenu(params: components.SysMenuIdReqParams, menuId: number) {
	return webapi.delete<components.SysMenuEmptyResp>(`/db/sys-menu/${menuId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysMenu(req: components.SysMenuCreateReq) {
	return webapi.post<components.SysMenuCreateResp>(`/db/sys-menu/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysMenu(params: components.SysMenuListReqParams) {
	return webapi.get<components.SysMenuFindPageResp>(`/db/sys-menu/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysMenu(params: components.SysMenuListReqParams) {
	return webapi.get<components.SysMenuListResp>(`/db/sys-menu/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysMenu(req: components.SysMenuUpdateReq) {
	return webapi.post<components.SysMenuEmptyResp>(`/db/sys-menu/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysRole(params: components.SysRoleIdReqParams, roleId: number) {
	return webapi.get<components.SysRole>(`/db/sys-role/${roleId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysRole(params: components.SysRoleIdReqParams, roleId: number) {
	return webapi.delete<components.SysRoleEmptyResp>(`/db/sys-role/${roleId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysRole(req: components.SysRoleCreateReq) {
	return webapi.post<components.SysRoleCreateResp>(`/db/sys-role/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysRole(params: components.SysRoleListReqParams) {
	return webapi.get<components.SysRoleFindPageResp>(`/db/sys-role/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysRole(params: components.SysRoleListReqParams) {
	return webapi.get<components.SysRoleListResp>(`/db/sys-role/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysRole(req: components.SysRoleUpdateReq) {
	return webapi.post<components.SysRoleEmptyResp>(`/db/sys-role/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysDept(params: components.SysDeptIdReqParams, deptId: number) {
	return webapi.get<components.SysDept>(`/db/sys-dept/${deptId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysDept(params: components.SysDeptIdReqParams, deptId: number) {
	return webapi.delete<components.SysDeptEmptyResp>(`/db/sys-dept/${deptId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysDept(req: components.SysDeptCreateReq) {
	return webapi.post<components.SysDeptCreateResp>(`/db/sys-dept/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysDept(params: components.SysDeptListReqParams) {
	return webapi.get<components.SysDeptFindPageResp>(`/db/sys-dept/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysDept(params: components.SysDeptListReqParams) {
	return webapi.get<components.SysDeptListResp>(`/db/sys-dept/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysDept(req: components.SysDeptUpdateReq) {
	return webapi.post<components.SysDeptEmptyResp>(`/db/sys-dept/update`, req)
}
