import webapi from "./gocliRequest"
import * as components from "./adminComponents"
export * from "./adminComponents"

/**
 * @description 
 * @param params
 */
export function getAppRuntimeLog(params: components.AppRuntimeLogIdReqParams, id: number) {
	return webapi.get<components.AppRuntimeLog>(`/api/v1/db/app-runtime-log/${id}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteAppRuntimeLog(params: components.AppRuntimeLogIdReqParams, id: number) {
	return webapi.delete<components.AppRuntimeLogEmptyResp>(`/api/v1/db/app-runtime-log/${id}`, params)
}

/**
 * @description 
 * @param req
 */
export function createAppRuntimeLog(req: components.AppRuntimeLogCreateReq) {
	return webapi.post<components.AppRuntimeLogCreateResp>(`/api/v1/db/app-runtime-log/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageAppRuntimeLog(params: components.AppRuntimeLogListReqParams) {
	return webapi.get<components.AppRuntimeLogFindPageResp>(`/api/v1/db/app-runtime-log/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listAppRuntimeLog(params: components.AppRuntimeLogListReqParams) {
	return webapi.get<components.AppRuntimeLogListResp>(`/api/v1/db/app-runtime-log/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateAppRuntimeLog(req: components.AppRuntimeLogUpdateReq) {
	return webapi.post<components.AppRuntimeLogEmptyResp>(`/api/v1/db/app-runtime-log/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysConfig(params: components.SysConfigIdReqParams, id: number) {
	return webapi.get<components.SysConfig>(`/api/v1/db/sys-config/${id}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysConfig(params: components.SysConfigIdReqParams, id: number) {
	return webapi.delete<components.SysConfigEmptyResp>(`/api/v1/db/sys-config/${id}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysConfig(req: components.SysConfigCreateReq) {
	return webapi.post<components.SysConfigCreateResp>(`/api/v1/db/sys-config/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysConfig(params: components.SysConfigListReqParams) {
	return webapi.get<components.SysConfigFindPageResp>(`/api/v1/db/sys-config/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysConfig(params: components.SysConfigListReqParams) {
	return webapi.get<components.SysConfigListResp>(`/api/v1/db/sys-config/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysConfig(req: components.SysConfigUpdateReq) {
	return webapi.post<components.SysConfigEmptyResp>(`/api/v1/db/sys-config/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysDept(params: components.SysDeptIdReqParams, deptId: number) {
	return webapi.get<components.SysDept>(`/api/v1/db/sys-dept/${deptId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysDept(params: components.SysDeptIdReqParams, deptId: number) {
	return webapi.delete<components.SysDeptEmptyResp>(`/api/v1/db/sys-dept/${deptId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysDept(req: components.SysDeptCreateReq) {
	return webapi.post<components.SysDeptCreateResp>(`/api/v1/db/sys-dept/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysDept(params: components.SysDeptListReqParams) {
	return webapi.get<components.SysDeptFindPageResp>(`/api/v1/db/sys-dept/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysDept(params: components.SysDeptListReqParams) {
	return webapi.get<components.SysDeptListResp>(`/api/v1/db/sys-dept/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysDept(req: components.SysDeptUpdateReq) {
	return webapi.post<components.SysDeptEmptyResp>(`/api/v1/db/sys-dept/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysDictData(params: components.SysDictDataIdReqParams, dictCode: number) {
	return webapi.get<components.SysDictData>(`/api/v1/db/sys-dict-data/${dictCode}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysDictData(params: components.SysDictDataIdReqParams, dictCode: number) {
	return webapi.delete<components.SysDictDataEmptyResp>(`/api/v1/db/sys-dict-data/${dictCode}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysDictData(req: components.SysDictDataCreateReq) {
	return webapi.post<components.SysDictDataCreateResp>(`/api/v1/db/sys-dict-data/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysDictData(params: components.SysDictDataListReqParams) {
	return webapi.get<components.SysDictDataFindPageResp>(`/api/v1/db/sys-dict-data/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysDictData(params: components.SysDictDataListReqParams) {
	return webapi.get<components.SysDictDataListResp>(`/api/v1/db/sys-dict-data/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysDictData(req: components.SysDictDataUpdateReq) {
	return webapi.post<components.SysDictDataEmptyResp>(`/api/v1/db/sys-dict-data/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysDictType(params: components.SysDictTypeIdReqParams, dictId: number) {
	return webapi.get<components.SysDictType>(`/api/v1/db/sys-dict-type/${dictId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysDictType(params: components.SysDictTypeIdReqParams, dictId: number) {
	return webapi.delete<components.SysDictTypeEmptyResp>(`/api/v1/db/sys-dict-type/${dictId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysDictType(req: components.SysDictTypeCreateReq) {
	return webapi.post<components.SysDictTypeCreateResp>(`/api/v1/db/sys-dict-type/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysDictType(params: components.SysDictTypeListReqParams) {
	return webapi.get<components.SysDictTypeFindPageResp>(`/api/v1/db/sys-dict-type/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysDictType(params: components.SysDictTypeListReqParams) {
	return webapi.get<components.SysDictTypeListResp>(`/api/v1/db/sys-dict-type/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysDictType(req: components.SysDictTypeUpdateReq) {
	return webapi.post<components.SysDictTypeEmptyResp>(`/api/v1/db/sys-dict-type/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysMenu(params: components.SysMenuIdReqParams, menuId: number) {
	return webapi.get<components.SysMenu>(`/api/v1/db/sys-menu/${menuId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysMenu(params: components.SysMenuIdReqParams, menuId: number) {
	return webapi.delete<components.SysMenuEmptyResp>(`/api/v1/db/sys-menu/${menuId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysMenu(req: components.SysMenuCreateReq) {
	return webapi.post<components.SysMenuCreateResp>(`/api/v1/db/sys-menu/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysMenu(params: components.SysMenuListReqParams) {
	return webapi.get<components.SysMenuFindPageResp>(`/api/v1/db/sys-menu/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysMenu(params: components.SysMenuListReqParams) {
	return webapi.get<components.SysMenuListResp>(`/api/v1/db/sys-menu/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysMenu(req: components.SysMenuUpdateReq) {
	return webapi.post<components.SysMenuEmptyResp>(`/api/v1/db/sys-menu/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysRole(params: components.SysRoleIdReqParams, roleId: number) {
	return webapi.get<components.SysRole>(`/api/v1/db/sys-role/${roleId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysRole(params: components.SysRoleIdReqParams, roleId: number) {
	return webapi.delete<components.SysRoleEmptyResp>(`/api/v1/db/sys-role/${roleId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysRole(req: components.SysRoleCreateReq) {
	return webapi.post<components.SysRoleCreateResp>(`/api/v1/db/sys-role/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysRole(params: components.SysRoleListReqParams) {
	return webapi.get<components.SysRoleFindPageResp>(`/api/v1/db/sys-role/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysRole(params: components.SysRoleListReqParams) {
	return webapi.get<components.SysRoleListResp>(`/api/v1/db/sys-role/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysRole(req: components.SysRoleUpdateReq) {
	return webapi.post<components.SysRoleEmptyResp>(`/api/v1/db/sys-role/update`, req)
}

/**
 * @description 
 * @param params
 */
export function getSysUser(params: components.SysUserIdReqParams, userId: number) {
	return webapi.get<components.SysUser>(`/api/v1/db/sys-user/${userId}`, params)
}

/**
 * @description 
 * @param params
 */
export function deleteSysUser(params: components.SysUserIdReqParams, userId: number) {
	return webapi.delete<components.SysUserEmptyResp>(`/api/v1/db/sys-user/${userId}`, params)
}

/**
 * @description 
 * @param req
 */
export function createSysUser(req: components.SysUserCreateReq) {
	return webapi.post<components.SysUserCreateResp>(`/api/v1/db/sys-user/create`, req)
}

/**
 * @description 
 * @param params
 */
export function findPageSysUser(params: components.SysUserListReqParams) {
	return webapi.get<components.SysUserFindPageResp>(`/api/v1/db/sys-user/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function listSysUser(params: components.SysUserListReqParams) {
	return webapi.get<components.SysUserListResp>(`/api/v1/db/sys-user/list`, params)
}

/**
 * @description 
 * @param req
 */
export function updateSysUser(req: components.SysUserUpdateReq) {
	return webapi.post<components.SysUserEmptyResp>(`/api/v1/db/sys-user/update`, req)
}

/**
 * @description 
 */
export function extDeptTree() {
	return webapi.get<components.ExtDeptTreeResp>(`/api/v1/deptTree`)
}

/**
 * @description 
 */
export function extFeishuConfig() {
	return webapi.get<components.ExtFeishuConfigResp>(`/api/v1/extFeishuConfig`)
}

/**
 * @description 
 * @param req
 */
export function extFeishuLogin(req: components.ExtFeishuLoginReq) {
	return webapi.post<components.LoginResp>(`/api/v1/extFeishuLogin`, req)
}

/**
 * @description 
 */
export function extGetInfo() {
	return webapi.get<components.GetInfoResp>(`/api/v1/getinfo`)
}

/**
 * @description 
 * @param req
 */
export function extLogin(req: components.LoginReq) {
	return webapi.post<components.LoginResp>(`/api/v1/login`, req)
}

/**
 * @description 
 */
export function extMenuTree() {
	return webapi.get<components.MenuRoleResp>(`/api/v1/menuTree`)
}

/**
 * @description 
 */
export function extMenuRole() {
	return webapi.get<components.MenuRoleResp>(`/api/v1/menurole`)
}

/**
 * @description 
 * @param params
 */
export function rpcGetCronTaskRunLog(params: components.RpcCronTaskRunLogIdReqParams, id: number) {
	return webapi.get<components.RpcCronTaskRunLog>(`/api/v1/rpc/cron/cron-task-run-log/${id}`, params)
}

/**
 * @description 
 * @param params
 */
export function rpcDeleteCronTaskRunLog(params: components.RpcCronTaskRunLogIdReqParams, id: number) {
	return webapi.delete<components.RpcCronTaskRunLogEmptyResp>(`/api/v1/rpc/cron/cron-task-run-log/${id}`, params)
}

/**
 * @description 
 * @param req
 */
export function rpcCreateCronTaskRunLog(req: components.RpcCronTaskRunLogCreateReq) {
	return webapi.post<components.RpcCronTaskRunLogCreateResp>(`/api/v1/rpc/cron/cron-task-run-log/create`, req)
}

/**
 * @description 
 * @param params
 */
export function rpcFindPageCronTaskRunLog(params: components.RpcCronTaskRunLogListReqParams) {
	return webapi.get<components.RpcCronTaskRunLogFindPageResp>(`/api/v1/rpc/cron/cron-task-run-log/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function rpcListCronTaskRunLog(params: components.RpcCronTaskRunLogListReqParams) {
	return webapi.get<components.RpcCronTaskRunLogListResp>(`/api/v1/rpc/cron/cron-task-run-log/list`, params)
}

/**
 * @description 
 * @param req
 */
export function rpcUpdateCronTaskRunLog(req: components.RpcCronTaskRunLogUpdateReq) {
	return webapi.post<components.RpcCronTaskRunLogEmptyResp>(`/api/v1/rpc/cron/cron-task-run-log/update`, req)
}

/**
 * @description 
 * @param params
 */
export function rpcGetCronTask(params: components.RpcCronTaskIdReqParams, id: number) {
	return webapi.get<components.RpcCronTask>(`/api/v1/rpc/cron/cron-task/${id}`, params)
}

/**
 * @description 
 * @param params
 */
export function rpcDeleteCronTask(params: components.RpcCronTaskIdReqParams, id: number) {
	return webapi.delete<components.RpcCronTaskEmptyResp>(`/api/v1/rpc/cron/cron-task/${id}`, params)
}

/**
 * @description 
 * @param req
 */
export function rpcCreateCronTask(req: components.RpcCronTaskCreateReq) {
	return webapi.post<components.RpcCronTaskCreateResp>(`/api/v1/rpc/cron/cron-task/create`, req)
}

/**
 * @description 
 * @param params
 */
export function rpcFindPageCronTask(params: components.RpcCronTaskListReqParams) {
	return webapi.get<components.RpcCronTaskFindPageResp>(`/api/v1/rpc/cron/cron-task/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function rpcListCronTask(params: components.RpcCronTaskListReqParams) {
	return webapi.get<components.RpcCronTaskListResp>(`/api/v1/rpc/cron/cron-task/list`, params)
}

/**
 * @description 
 * @param req
 */
export function rpcUpdateCronTask(req: components.RpcCronTaskUpdateReq) {
	return webapi.post<components.RpcCronTaskEmptyResp>(`/api/v1/rpc/cron/cron-task/update`, req)
}

/**
 * @description 
 * @param params
 */
export function rpcGetSummaryData(params: components.RpcSummaryDataIdReqParams, id: number) {
	return webapi.get<components.RpcSummaryData>(`/api/v1/rpc/kbrelease/summary-data/${id}`, params)
}

/**
 * @description 
 * @param params
 */
export function rpcDeleteSummaryData(params: components.RpcSummaryDataIdReqParams, id: number) {
	return webapi.delete<components.RpcSummaryDataEmptyResp>(`/api/v1/rpc/kbrelease/summary-data/${id}`, params)
}

/**
 * @description 
 * @param req
 */
export function rpcCreateSummaryData(req: components.RpcSummaryDataCreateReq) {
	return webapi.post<components.RpcSummaryDataCreateResp>(`/api/v1/rpc/kbrelease/summary-data/create`, req)
}

/**
 * @description 
 * @param params
 */
export function rpcFindPageSummaryData(params: components.RpcSummaryDataListReqParams) {
	return webapi.get<components.RpcSummaryDataFindPageResp>(`/api/v1/rpc/kbrelease/summary-data/findPage`, params)
}

/**
 * @description 
 * @param params
 */
export function rpcListSummaryData(params: components.RpcSummaryDataListReqParams) {
	return webapi.get<components.RpcSummaryDataListResp>(`/api/v1/rpc/kbrelease/summary-data/list`, params)
}

/**
 * @description 
 * @param req
 */
export function rpcUpdateSummaryData(req: components.RpcSummaryDataUpdateReq) {
	return webapi.post<components.RpcSummaryDataEmptyResp>(`/api/v1/rpc/kbrelease/summary-data/update`, req)
}
