import webapi from "./gocliRequest"
import * as components from "./kbreleaseComponents"
export * from "./kbreleaseComponents"

/**
 * @description 
 */
export function createAuth() {
	return webapi.post<null>(`/users/auth/create`)
}

/**
 * @description 
 */
export function getUser() {
	return webapi.get<components.Response>(`/users/id/${userId}`)
}
