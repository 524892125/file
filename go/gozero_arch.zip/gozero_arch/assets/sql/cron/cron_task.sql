-- @gen: model,rpc,api2rpc,ui-react
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS cron_task (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(128) NOT NULL,
  task_key VARCHAR(128) NOT NULL,
  payload TEXT NOT NULL DEFAULT '',
  schedule_type VARCHAR(16) NOT NULL,
  run_at TIMESTAMPTZ NOT NULL,
  interval_seconds BIGINT NOT NULL DEFAULT 0,
  status VARCHAR(16) NOT NULL DEFAULT 'enabled',
  next_run_at TIMESTAMPTZ,
  last_run_at TIMESTAMPTZ,
  locked_by VARCHAR(128),
  locked_until TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_cron_task_due
  ON cron_task (status, next_run_at)
  WHERE next_run_at IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_cron_task_task_key
  ON cron_task (task_key);
