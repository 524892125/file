-- @gen: model,rpc,api2rpc,ui-react
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS cron_task_run_log (
  id BIGSERIAL PRIMARY KEY,
  task_id BIGINT NOT NULL,
  worker_id VARCHAR(128) NOT NULL,
  status VARCHAR(16) NOT NULL,
  message TEXT NOT NULL DEFAULT '',
  started_at TIMESTAMPTZ NOT NULL,
  finished_at TIMESTAMPTZ NOT NULL,
  duration_ms BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_cron_task_run_log_task_id
  ON cron_task_run_log (task_id, id DESC);
