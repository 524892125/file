-- @gen: model,api,ui-react
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS public.sys_dict_data (
    dict_code BIGSERIAL NOT NULL PRIMARY KEY,
    dict_sort bigint,
    dict_label character varying(128),
    dict_value character varying(255),
    dict_type character varying(64),
    css_class character varying(128),
    list_class character varying(128),
    is_default character varying(8),
    status smallint,
    "default" character varying(8),
    remark character varying(255),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);
