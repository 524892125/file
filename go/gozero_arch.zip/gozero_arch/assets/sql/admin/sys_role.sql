-- @gen: model,api,ui-react
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS public.sys_role (
    role_id BIGSERIAL NOT NULL PRIMARY KEY,
    role_name character varying(128),
    status character varying(4),
    role_key character varying(128),
    role_sort bigint,
    flag character varying(128),
    remark character varying(255),
    admin boolean,
    data_scope character varying(128),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);
