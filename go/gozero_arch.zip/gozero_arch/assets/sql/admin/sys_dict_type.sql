-- @gen: model,api,ui-react
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS public.sys_dict_type (
    dict_id bigint NOT NULL PRIMARY KEY,
    dict_name character varying(128),
    dict_type character varying(128),
    status smallint,
    remark character varying(255),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);
