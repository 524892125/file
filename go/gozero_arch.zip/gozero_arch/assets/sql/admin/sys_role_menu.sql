-- @gen: model,api
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS public.sys_role_menu (
    id BIGSERIAL NOT NULL PRIMARY KEY,
    role_id bigint NOT NULL,
    menu_id bigint NOT NULL
);