-- @gen: model
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS public.sys_role_menu (
    id bigint NOT NULL PRIMARY KEY,
    role_id bigint NOT NULL,
    menu_id bigint NOT NULL
);