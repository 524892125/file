-- @gen: model,api,rpc
-- @api.public: true
CREATE TABLE IF NOT EXISTS public.app_runtime_log (
    id bigint NOT NULL,
    message_id character varying(64) NOT NULL,
    trace_id character varying(128),
    tenant_code character varying(64),
    service_name character varying(64) NOT NULL,
    level character varying(32) NOT NULL,
    caller character varying(255),
    content text,
    fields_json text,
    source character varying(64),
    logged_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);
