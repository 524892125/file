CREATE TABLE `charge_send_record` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` bigint NOT NULL,
    `charge_send_desc` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '描述',
    `activity_id` int DEFAULT NULL COMMENT '活动id',
    `gears` int NOT NULL COMMENT '档位',
    `status` bigint NOT NULL COMMENT '1.充值赠送成功 3.充值赠送失败',
    `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;