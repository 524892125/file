-- @gen: model,api,ui-react
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS public.sys_user (
    user_id BIGSERIAL NOT NULL PRIMARY KEY,
    username character varying(64),
    password character varying(128),
    nick_name character varying(128),
    phone character varying(11),
    role_id bigint,
    salt character varying(255),
    avatar character varying(255),
    sex character varying(255),
    email character varying(128),
    dept_id bigint,
    post_id bigint,
    remark character varying(255),
    status character varying(4),
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    allow_password_login character varying(4) DEFAULT '2'::character varying
);
