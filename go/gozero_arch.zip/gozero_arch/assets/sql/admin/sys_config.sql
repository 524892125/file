-- @gen: model,api,rpc,ui-react
-- @api.public: true   
CREATE TABLE IF NOT EXISTS "public"."sys_config" (
        id BIGSERIAL PRIMARY KEY,
        config_name VARCHAR(128),
        config_key VARCHAR(128) ,
        config_value VARCHAR(255),
        config_type VARCHAR(64) ,
        is_frontend VARCHAR(64),
        remark VARCHAR(128),
        create_by INT NOT NULL DEFAULT 0,
        update_by INT NOT NULL DEFAULT 0,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        deleted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- INSERT INTO "public"."sys_config" ("id", "config_name", "config_key", "config_value", "config_type", "is_frontend", "remark", "create_by", "update_by", "created_at", "updated_at", "deleted_at") VALUES (1, 'feishu_login_qh', 'feishu_login_qh', '{"appId": "cli_a9242c209338dcc4", "appSecret":"lbYah6PocTeTUiJhEDXm0fG0cgdwVpCX", "redirectUrl": "http://localhost:1799/login", "baseUrl": "https://passport.feishu.cn"}', NULL, NULL, NULL, 0, 0, '2026-05-10 08:12:30.299277+08', '2026-05-10 08:12:30.299277+08', '2026-05-10 08:12:30.299277+08');

