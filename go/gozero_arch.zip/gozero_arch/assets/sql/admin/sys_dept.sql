-- @gen: model,api
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS public.sys_dept (
    dept_id bigint NOT NULL PRIMARY KEY,
    parent_id bigint,
    dept_path character varying(255),
    dept_name character varying(128),
    sort smallint,
    leader character varying(128),
    phone character varying(11),
    email character varying(64),
    status smallint,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);