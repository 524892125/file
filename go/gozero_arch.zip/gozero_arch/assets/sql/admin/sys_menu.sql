-- @gen: model,api,ui-react
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS public.sys_menu (
    menu_id BIGSERIAL NOT NULL PRIMARY KEY,
    menu_name character varying(128) NOT NULL,
    title character varying(128),
    icon character varying(128),
    path character varying(128) NOT NULL,
    paths character varying(128),
    menu_type character varying(1) NOT NULL,
    action character varying(16),
    permission character varying(255),
    parent_id smallint,
    no_cache boolean,
    breadcrumb character varying(255),
    component character varying(255),
    sort smallint,
    visible character varying(1),
    is_frame character varying(1) DEFAULT '0'::character varying,
    create_by bigint,
    update_by bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);
