CREATE TABLE `couple_week_rank` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键id',
    `cid` bigint NOT NULL COMMENT 'cp表主键id',
    `cp_experience` bigint NOT NULL COMMENT 'cp亲密值',
    `cp_rank` int NOT NULL COMMENT 'cp某一周排名，目前只记录1、2、3名',
    `settle_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '周排行结算时间',
    `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='cp周排行榜';