-- @gen: model
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS public.sys_role_dept (
    id bigint NOT NULL PRIMARY KEY,
    role_id smallint NOT NULL,
    dept_id smallint NOT NULL
);