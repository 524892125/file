-- @gen: model
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS "public"."oceanengine_daily_conversion" (
  "id" BIGSERIAL PRIMARY KEY,
  "advertiser_id" int8 NOT NULL,
  "ref_date" date NOT NULL,
  "type" varchar(32),
  "cdp_project_id" int8,
  "cdp_project_name" varchar(32),
  "cdp_promotion_name" varchar(32),
  "app_code" varchar(32),
  "gender" varchar(32),
  "age" varchar(32),
  "platform" varchar(32),
  "city_name" varchar(32),
  "image_mode" varchar(32),

  "attribution_convert_cost" numeric(15, 4) DEFAULT 0,
  "attribution_conversion_rate" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_1day" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_2days" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_3days" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_4days" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_5days" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_6days" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_7days" numeric(10, 6) DEFAULT 0,

  "created_at" timestamptz(6) DEFAULT CURRENT_TIMESTAMP,
  "updated_at" timestamptz(6) DEFAULT CURRENT_TIMESTAMP
);


COMMENT ON COLUMN "public"."oceanengine_daily_conversion"."attribution_convert_cost" IS '转化成本(计费时间)';
COMMENT ON COLUMN "public"."oceanengine_daily_conversion"."attribution_conversion_rate" IS '转化率(计费时间) ';
COMMENT ON COLUMN "public"."oceanengine_daily_conversion"."attribution_billing_game_in_app_roi_1day" IS '计费当日付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_conversion"."attribution_billing_game_in_app_roi_2days" IS '计费二日内付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_conversion"."attribution_billing_game_in_app_roi_3days" IS '计费三日内付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_conversion"."attribution_billing_game_in_app_roi_4days" IS '计费四日内付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_conversion"."attribution_billing_game_in_app_roi_5days" IS '计费五日内付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_conversion"."attribution_billing_game_in_app_roi_6days" IS '计费六日内付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_conversion"."attribution_billing_game_in_app_roi_7days" IS '计费七日内付费ROI';

CREATE UNIQUE INDEX IF NOT EXISTS "uni_oe_conv_dim" ON "public"."oceanengine_daily_conversion" (
  "advertiser_id", 
  "ref_date", 
  "cdp_project_id", 
  "gender", 
  "age", 
  "platform", 
  "city_name", 
  "image_mode"
);