-- @gen: model,rpc,api2rpc,ui-react
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS "public"."oceanengine_daily_summary" (
  "id" BIGSERIAL PRIMARY KEY,
  "advertiser_id" int8 NOT NULL,
  "ref_date" date NOT NULL,

  "stat_cost" numeric(15, 4) DEFAULT 0,
  "show_cnt" int8 DEFAULT 0,
  "cpm_platform" numeric(15, 4) DEFAULT 0,
  "click_cnt" int8 DEFAULT 0,
  "ctr" numeric(10, 6) DEFAULT 0,
  "active" int8 DEFAULT 0,
  "active_cost" numeric(15, 4) DEFAULT 0,
  "active_register" int8 DEFAULT 0,
  "active_pay" int8 DEFAULT 0,
  "active_pay_cost" numeric(15, 4) DEFAULT 0,
  "active_pay_rate" numeric(10, 6) DEFAULT 0,

  "attribution_convert_cost" numeric(15, 4) DEFAULT 0,
  "attribution_conversion_rate" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_1day" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_2days" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_3days" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_4days" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_5days" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_6days" numeric(10, 6) DEFAULT 0,
  "attribution_billing_game_in_app_roi_7days" numeric(10, 6) DEFAULT 0,

  "attribution_next_day_open_cnt" int8 DEFAULT 0,
  "attribution_next_day_open_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_2d_cnt" int8 DEFAULT 0,
  "attribution_retention_2d_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_3d_cnt" int8 DEFAULT 0,
  "attribution_retention_3d_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_4d_cnt" int8 DEFAULT 0,
  "attribution_retention_4d_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_5d_cnt" int8 DEFAULT 0,
  "attribution_retention_5d_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_6d_cnt" int8 DEFAULT 0,
  "attribution_retention_6d_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_7d_cnt" int8 DEFAULT 0,
  "attribution_retention_7d_rate" numeric(10, 6) DEFAULT 0,

  "attribution_game_pay_7d_cost" numeric(15, 4) DEFAULT 0,
  "attribution_micro_game_0d_ltv" numeric(15, 4) DEFAULT 0,
  "attribution_micro_game_3d_ltv" numeric(15, 4) DEFAULT 0,
  "attribution_micro_game_7d_ltv" numeric(15, 4) DEFAULT 0,
  "attribution_micro_game_0d_roi" numeric(10, 6) DEFAULT 0,
  "attribution_micro_game_3d_roi" numeric(10, 6) DEFAULT 0,
  "attribution_micro_game_7d_roi" numeric(10, 6) DEFAULT 0,
  "attribution_micro_game_iaap_ltv_7d_roi" numeric(10, 6) DEFAULT 0,

  "attribution_micro_game_iaap_iap_roi_8days" numeric(10, 6) DEFAULT 0,
  "attribution_micro_game_iaap_iaa_7d_roi" numeric(10, 6) DEFAULT 0,

  "created_at" timestamptz(6) DEFAULT CURRENT_TIMESTAMP,
  "updated_at" timestamptz(6) DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE "public"."oceanengine_daily_summary" IS '巨量引擎每日广告主维度汇总数据';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."advertiser_id" IS '广告主 ID';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."ref_date" IS '数据归属日期';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."stat_cost" IS '消耗（元）';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."show_cnt" IS '展示数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."cpm_platform" IS '平均千次展现费用';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."click_cnt" IS '点击数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."ctr" IS '点击数率';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."active" IS '激活数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."active_cost" IS '激活成本（元）';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."active_register" IS '注册数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."active_pay" IS '首次付费数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."active_pay_cost" IS '首次付费成本';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."active_pay_rate" IS '首次付费率';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_convert_cost" IS '转化成本(计费时间)';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_conversion_rate" IS '转化率(计费时间)';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_billing_game_in_app_roi_1day" IS '计费当日付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_billing_game_in_app_roi_2days" IS '计费二日内付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_billing_game_in_app_roi_3days" IS '计费三日内付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_billing_game_in_app_roi_4days" IS '计费四日内付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_billing_game_in_app_roi_5days" IS '计费五日内付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_billing_game_in_app_roi_6days" IS '计费六日内付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_billing_game_in_app_roi_7days" IS '计费七日内付费ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_next_day_open_cnt" IS '次留数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_next_day_open_rate" IS '次留率';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_2d_cnt" IS '2日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_2d_rate" IS '2日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_3d_cnt" IS '3日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_3d_rate" IS '3日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_4d_cnt" IS '4日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_4d_rate" IS '4日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_5d_cnt" IS '5日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_5d_rate" IS '5日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_6d_cnt" IS '6日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_6d_rate" IS '6日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_7d_cnt" IS '7日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_retention_7d_rate" IS '7日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_game_pay_7d_cost" IS '7日付费成本(激活时间)';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_micro_game_0d_ltv" IS '小程序/小游戏当日LTV';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_micro_game_3d_ltv" IS '小程序/小游戏激活后三日LTV';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_micro_game_7d_ltv" IS '小程序/小游戏激活后七日LTV';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_micro_game_0d_roi" IS '小程序/小游戏当日变现ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_micro_game_3d_roi" IS '小程序/小游戏激活后三日变现ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_micro_game_7d_roi" IS '小程序/小游戏激活后七日变现ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_micro_game_iaap_ltv_7d_roi" IS '7日综合ROI（激活时间）';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_micro_game_iaap_iap_roi_8days" IS '混变-7日付费roi（激活时间）';
COMMENT ON COLUMN "public"."oceanengine_daily_summary"."attribution_micro_game_iaap_iaa_7d_roi" IS '混变-7日变现roi（激活时间）';

CREATE UNIQUE INDEX IF NOT EXISTS "uni_oe_summary_adv_date" ON "public"."oceanengine_daily_summary" (
  "advertiser_id",
  "ref_date"
);
