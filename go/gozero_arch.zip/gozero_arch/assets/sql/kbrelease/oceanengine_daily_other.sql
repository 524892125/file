-- @gen: model
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS "public"."oceanengine_daily_other" (
  "id" BIGSERIAL PRIMARY KEY,
  "advertiser_id" int8 NOT NULL,
  "ref_date" date NOT NULL,
  "type" varchar(32),
  "cdp_project_id" int8,
  "cdp_project_name" varchar(32),
  "cdp_promotion_name" varchar(32),
  "app_code" varchar(32),
  "gender" varchar(32),
  "age" varchar(32),
  "platform" varchar(32),
  "city_name" varchar(32),
  "image_mode" varchar(32),
  "attribution_micro_game_iaap_iap_roi_8days" numeric(10, 6) DEFAULT 0,
  "attribution_micro_game_iaap_iaa_7d_roi" numeric(10, 6) DEFAULT 0,
  "created_at" timestamptz(6) DEFAULT CURRENT_TIMESTAMP,
  "updated_at" timestamptz(6) DEFAULT CURRENT_TIMESTAMP
);
COMMENT ON COLUMN "public"."oceanengine_daily_other"."attribution_micro_game_iaap_iap_roi_8days" IS '混变-7日付费roi（激活时间）';
COMMENT ON COLUMN "public"."oceanengine_daily_other"."attribution_micro_game_iaap_iaa_7d_roi" IS '混变-7日变现roi（激活时间）';
CREATE UNIQUE INDEX IF NOT EXISTS "uni_oe_other_dim" ON "public"."oceanengine_daily_other" (
  "advertiser_id", 
  "ref_date", 
  "cdp_project_id", 
  "gender", 
  "age", 
  "platform", 
  "city_name", 
  "image_mode"
);