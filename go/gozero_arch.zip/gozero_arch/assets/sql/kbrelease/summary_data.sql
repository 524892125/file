-- @gen: model,rpc,api2rpc,ui-react
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS summary_data (
    id BIGSERIAL PRIMARY KEY,
    appid VARCHAR(64) NOT NULL,
    ref_date DATE NOT NULL, 
    dau bigint DEFAULT 0,      
    new_users bigint DEFAULT 0,
    new_user_ratio NUMERIC(10, 4),
    avg_acquisition_cost NUMERIC(15, 4),
    avg_active_cost NUMERIC(15, 4),
    avg_total_cost NUMERIC(15, 4),
    lt_value NUMERIC(10, 2),
    total_users_sum bigint,
    total_revenue NUMERIC(15, 2) DEFAULT 0,
    total_expenditure NUMERIC(15, 2) DEFAULT 0,
    gross_profit NUMERIC(15, 2) DEFAULT 0,
    coop_profit_share NUMERIC(15, 2) DEFAULT 0,
    profit_margin NUMERIC(10, 4),
    rev_traffic_owner NUMERIC(15, 2) DEFAULT 0,
    rev_internal_purchase NUMERIC(15, 2) DEFAULT 0,
    rev_commission NUMERIC(15, 2) DEFAULT 0,
    rev_traffic_rental NUMERIC(15, 2) DEFAULT 0,
    rev_ad_settlement NUMERIC(15, 2) DEFAULT 0,
    rev_total_calc NUMERIC(15, 2) DEFAULT 0,
    exp_daily_base NUMERIC(15, 2) DEFAULT 0,
    exp_internal_buy NUMERIC(15, 2) DEFAULT 0,
    exp_external_buy NUMERIC(15, 2) DEFAULT 0,
    exp_total_ops NUMERIC(15, 2) DEFAULT 0,
    remark TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (appid, ref_date)
);

CREATE INDEX IF NOT EXISTS idx_date ON summary_data (ref_date);
CREATE INDEX IF NOT EXISTS idx_appid_date ON summary_data (appid, ref_date);