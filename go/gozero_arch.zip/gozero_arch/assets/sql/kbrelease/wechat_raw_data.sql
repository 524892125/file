-- @gen: model
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS wechat_raw_data (
    id BIGSERIAL PRIMARY KEY,
    app_id VARCHAR(64) NOT NULL,
    metric VARCHAR(64) NOT NULL,
    granularity BIGINT NOT NULL,
    dimesion BIGINT,
    ref_date DATE NOT NULL,
    ts bigint,
    dimension_label TEXT,
    dimension_value TEXT,
    metric_value NUMERIC,
    raw_data jsonb,
    UNIQUE (app_id, metric, granularity, dimesion, ref_date, dimension_value)
);

CREATE INDEX IF NOT EXISTS idx_wechat_date_dim ON wechat_raw_data (ref_date, dimension_label, granularity, metric);
