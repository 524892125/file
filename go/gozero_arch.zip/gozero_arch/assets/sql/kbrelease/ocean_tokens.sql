-- @gen: model
CREATE TABLE IF NOT EXISTS advertiser_tokens (
    id SERIAL PRIMARY KEY,
    access_token VARCHAR(255) NOT NULL,
    refresh_token VARCHAR(255) NOT NULL,

    advertiser_ids BIGINT[] NOT NULL,

    expires_in INTEGER NOT NULL, -- 原始秒数
    refresh_token_expires_in INTEGER NOT NULL, -- 刷新令牌原始秒数

    access_token_expires_at TIMESTAMP WITH TIME ZONE,
    refresh_token_expires_at TIMESTAMP WITH TIME ZONE,

    last_request_id VARCHAR(64),

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);