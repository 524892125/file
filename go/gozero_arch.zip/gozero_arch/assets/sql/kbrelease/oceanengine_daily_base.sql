-- @gen: model,rpc,api2rpc,ui-react
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS "public"."oceanengine_daily_base" (
  "id" BIGSERIAL PRIMARY KEY,

  "advertiser_id" int8 NOT NULL,
  "ref_date" date NOT NULL,
  "type" varchar(32),
  "cdp_project_id" int8,
  "cdp_project_name" varchar(32),
  "cdp_promotion_name" varchar(32),
  "app_code" varchar(32),
  "gender" varchar(32),
  "age" varchar(32),
  "platform" varchar(32),
  "city_name" varchar(32),
  "image_mode" varchar(32),

  "stat_cost" numeric(15, 4) DEFAULT 0,
  "show_cnt" int8 DEFAULT 0,
  "cpm_platform" numeric(15, 4) DEFAULT 0,
  "click_cnt" int8 DEFAULT 0,
  "ctr" numeric(10, 6) DEFAULT 0,
  "active" int8 DEFAULT 0,
  "active_cost" numeric(15, 4) DEFAULT 0,
  "active_register" int8 DEFAULT 0,
  "active_pay" int8 DEFAULT 0,
  "active_pay_cost" numeric(15, 4) DEFAULT 0,
  "active_pay_rate" numeric(10, 6) DEFAULT 0,


  "created_at" timestamptz(6) DEFAULT CURRENT_TIMESTAMP,
  "updated_at" timestamptz(6) DEFAULT CURRENT_TIMESTAMP
);


COMMENT ON COLUMN "public"."oceanengine_daily_base"."stat_cost" IS '消耗（元）';
COMMENT ON COLUMN "public"."oceanengine_daily_base"."show_cnt" IS '展示数';
COMMENT ON COLUMN "public"."oceanengine_daily_base"."cpm_platform" IS '平均千次展现费用';
COMMENT ON COLUMN "public"."oceanengine_daily_base"."click_cnt" IS '点击数';
COMMENT ON COLUMN "public"."oceanengine_daily_base"."ctr" IS '点击数率';
COMMENT ON COLUMN "public"."oceanengine_daily_base"."active" IS '激活数';
COMMENT ON COLUMN "public"."oceanengine_daily_base"."active_cost" IS '激活成本（元）';
COMMENT ON COLUMN "public"."oceanengine_daily_base"."active_register" IS '注册数';
COMMENT ON COLUMN "public"."oceanengine_daily_base"."active_pay" IS '首次付费数';
COMMENT ON COLUMN "public"."oceanengine_daily_base"."active_pay_cost" IS '首次付费成本';
COMMENT ON COLUMN "public"."oceanengine_daily_base"."active_pay_rate" IS '首次付费率';


CREATE UNIQUE INDEX IF NOT EXISTS "uni_oe_report_dim" ON "public"."oceanengine_daily_base" (
  "advertiser_id", 
  "ref_date", 
  "cdp_project_id", 
  "gender", 
  "age", 
  "platform", 
  "city_name", 
  "image_mode"
);