-- @gen: model
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS "public"."oceanengine_daily_ltv" (
  "id" BIGSERIAL PRIMARY KEY,
  "advertiser_id" int8 NOT NULL,
  "ref_date" date NOT NULL,
  "type" varchar(32),
  "cdp_project_id" int8,
  "cdp_project_name" varchar(32),
  "cdp_promotion_name" varchar(32),
  "app_code" varchar(32),
  "gender" varchar(32),
  "age" varchar(32),
  "platform" varchar(32),
  "city_name" varchar(32),
  "image_mode" varchar(32),

  "attribution_next_day_open_cnt" int8 DEFAULT 0,
  "attribution_next_day_open_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_2d_cnt" int8 DEFAULT 0,
  "attribution_retention_2d_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_3d_cnt" int8 DEFAULT 0,
  "attribution_retention_3d_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_4d_cnt" int8 DEFAULT 0,
  "attribution_retention_4d_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_5d_cnt" int8 DEFAULT 0,
  "attribution_retention_5d_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_6d_cnt" int8 DEFAULT 0,
  "attribution_retention_6d_rate" numeric(10, 6) DEFAULT 0,
  "attribution_retention_7d_cnt" int8 DEFAULT 0,
  "attribution_retention_7d_rate" numeric(10, 6) DEFAULT 0,

  "attribution_game_pay_7d_cost" numeric(15, 4) DEFAULT 0,
  "attribution_micro_game_0d_ltv" numeric(15, 4) DEFAULT 0,
  "attribution_micro_game_3d_ltv" numeric(15, 4) DEFAULT 0,
  "attribution_micro_game_7d_ltv" numeric(15, 4) DEFAULT 0,
  "attribution_micro_game_0d_roi" numeric(10, 6) DEFAULT 0,
  "attribution_micro_game_3d_roi" numeric(10, 6) DEFAULT 0,
  "attribution_micro_game_7d_roi" numeric(10, 6) DEFAULT 0,
  "attribution_micro_game_iaap_ltv_7d_roi" numeric(10, 6) DEFAULT 0,
  "created_at" timestamptz(6) DEFAULT CURRENT_TIMESTAMP,
  "updated_at" timestamptz(6) DEFAULT CURRENT_TIMESTAMP
);
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_next_day_open_cnt" IS '次留数';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_next_day_open_rate" IS '次留率';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_game_pay_7d_cost" IS '7日付费成本(激活时间)';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_2d_cnt" IS '2日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_2d_rate" IS '2日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_3d_cnt" IS '3日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_3d_rate" IS '3日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_4d_cnt" IS '4日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_4d_rate" IS '4日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_5d_cnt" IS '5日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_5d_rate" IS '5日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_6d_cnt" IS '6日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_6d_rate" IS '6日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_7d_cnt" IS '7日留存数';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_retention_7d_rate" IS '7日留存率';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_micro_game_0d_ltv" IS '小程序/小游戏当日LTV';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_micro_game_3d_ltv" IS '小程序/小游戏激活后三日LTV';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_micro_game_7d_ltv" IS '小程序/小游戏激活后七日LTV';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_micro_game_0d_roi" IS '小程序/小游戏当日变现ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_micro_game_3d_roi" IS '小程序/小游戏激活后三日变现ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_micro_game_7d_roi" IS '小程序/小游戏激活后七日变现ROI';
COMMENT ON COLUMN "public"."oceanengine_daily_ltv"."attribution_micro_game_iaap_ltv_7d_roi" IS '7日综合ROI（激活时间）';

-- 创建联合唯一索引，防止重复写入数据
CREATE UNIQUE INDEX IF NOT EXISTS "uni_oe_ltv_dim" ON "public"."oceanengine_daily_ltv" (
  "advertiser_id", 
  "ref_date", 
  "cdp_project_id", 
  "gender", 
  "age", 
  "platform", 
  "city_name", 
  "image_mode"
);