-- @gen: model,rpc
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS wechat_daily_data (
    id BIGSERIAL PRIMARY KEY,
    appid VARCHAR(64) NOT NULL,
    metric VARCHAR(64) NOT NULL,
    column_key VARCHAR(64) NOT NULL,
    ref_date DATE NOT NULL,
    num bigint,
    base_data JSON,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (appid, ref_date, column_key)
);
CREATE INDEX IF NOT EXISTS idx_date ON wechat_daily_data (ref_date);
CREATE INDEX IF NOT EXISTS idx_appid_date ON wechat_daily_data (appid, ref_date);
CREATE INDEX IF NOT EXISTS idx_appid_date_column_key ON wechat_daily_data (appid, ref_date, column_key);
