-- @gen: model,rpc,api2rpc,ui-react
-- @api.middleware: PermissionMiddleware,JwtMiddleware
CREATE TABLE IF NOT EXISTS wechat_daily_data (
    id BIGSERIAL PRIMARY KEY,
    appid VARCHAR(64) NOT NULL,
    ref_date DATE NOT NULL,
    active_users BIGINT DEFAULT 0,
    avg_active_user_stay_seconds NUMERIC(15, 4),
    active_user_retention_1d NUMERIC(10, 4),
    active_user_retention_7d NUMERIC(10, 4),
    registered_users BIGINT DEFAULT 0,
    registered_user_retention_1d NUMERIC(10, 4),
    registered_user_retention_7d NUMERIC(10, 4),
    registered_user_age_profile JSONB,
    registered_user_gender_profile JSONB,
    registered_user_province_profile JSONB,
    registered_user_city_profile JSONB,
    registered_user_device_profile JSONB,
    paid_users BIGINT DEFAULT 0,
    pay_penetration_rate NUMERIC(10, 4),
    new_paid_users BIGINT DEFAULT 0,
    paid_user_retention_1d NUMERIC(10, 4),
    paid_user_retention_7d NUMERIC(10, 4),
    new_paid_user_retention_1d NUMERIC(10, 4),
    new_paid_user_retention_7d NUMERIC(10, 4),
    payment_amount NUMERIC(15, 2) DEFAULT 0,
    paid_user_arppu NUMERIC(15, 4),
    new_payment_amount NUMERIC(15, 2) DEFAULT 0,
    new_paid_user_arppu NUMERIC(15, 4),
    ad_revenue_after_share NUMERIC(15, 2) DEFAULT 0,
    ad_ltv_1d NUMERIC(15, 4),
    ad_ltv_3d NUMERIC(15, 4),
    ad_ltv_7d NUMERIC(15, 4),
    ad_ltv_30d NUMERIC(15, 4),
    item_ltv_1d NUMERIC(15, 4),
    item_ltv_3d NUMERIC(15, 4),
    item_ltv_7d NUMERIC(15, 4),
    item_ltv_30d NUMERIC(15, 4),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (appid, ref_date)
);

COMMENT ON TABLE wechat_daily_data IS '微信每日数据';
COMMENT ON COLUMN wechat_daily_data.id IS '主键 ID';
COMMENT ON COLUMN wechat_daily_data.appid IS '微信小程序/小游戏 appid';
COMMENT ON COLUMN wechat_daily_data.ref_date IS '数据归属日期';
COMMENT ON COLUMN wechat_daily_data.active_users IS '活跃用户数';
COMMENT ON COLUMN wechat_daily_data.avg_active_user_stay_seconds IS '活跃用户人均停留时长';
COMMENT ON COLUMN wechat_daily_data.active_user_retention_1d IS '活跃用户次日留存';
COMMENT ON COLUMN wechat_daily_data.active_user_retention_7d IS '活跃用户七日留存';
COMMENT ON COLUMN wechat_daily_data.registered_users IS '注册用户数';
COMMENT ON COLUMN wechat_daily_data.registered_user_retention_1d IS '注册用户次日留存';
COMMENT ON COLUMN wechat_daily_data.registered_user_retention_7d IS '注册用户七日留存';
COMMENT ON COLUMN wechat_daily_data.registered_user_age_profile IS '注册用户年龄画像';
COMMENT ON COLUMN wechat_daily_data.registered_user_gender_profile IS '注册用户性别画像';
COMMENT ON COLUMN wechat_daily_data.registered_user_province_profile IS '注册用户省份画像';
COMMENT ON COLUMN wechat_daily_data.registered_user_city_profile IS '注册用户城市画像';
COMMENT ON COLUMN wechat_daily_data.registered_user_device_profile IS '注册用户设备画像';
COMMENT ON COLUMN wechat_daily_data.paid_users IS '付费用户数';
COMMENT ON COLUMN wechat_daily_data.pay_penetration_rate IS '付费渗透率';
COMMENT ON COLUMN wechat_daily_data.new_paid_users IS '新增付费用户数';
COMMENT ON COLUMN wechat_daily_data.paid_user_retention_1d IS '付费用户次日留存';
COMMENT ON COLUMN wechat_daily_data.paid_user_retention_7d IS '付费用户七日留存';
COMMENT ON COLUMN wechat_daily_data.new_paid_user_retention_1d IS '新增付费次日留存';
COMMENT ON COLUMN wechat_daily_data.new_paid_user_retention_7d IS '新增付费七日留存';
COMMENT ON COLUMN wechat_daily_data.payment_amount IS '付费金额';
COMMENT ON COLUMN wechat_daily_data.paid_user_arppu IS '付费用户 ARPPU';
COMMENT ON COLUMN wechat_daily_data.new_payment_amount IS '新增付费金额';
COMMENT ON COLUMN wechat_daily_data.new_paid_user_arppu IS '新增付费用户 ARPPU';
COMMENT ON COLUMN wechat_daily_data.ad_revenue_after_share IS '广告分成后收入';
COMMENT ON COLUMN wechat_daily_data.ad_ltv_1d IS '首日广告 LTV';
COMMENT ON COLUMN wechat_daily_data.ad_ltv_3d IS '3 日广告 LTV';
COMMENT ON COLUMN wechat_daily_data.ad_ltv_7d IS '7 日广告 LTV';
COMMENT ON COLUMN wechat_daily_data.ad_ltv_30d IS '30 日广告 LTV';
COMMENT ON COLUMN wechat_daily_data.item_ltv_1d IS '首日道具 LTV';
COMMENT ON COLUMN wechat_daily_data.item_ltv_3d IS '3 日道具 LTV';
COMMENT ON COLUMN wechat_daily_data.item_ltv_7d IS '7 日道具 LTV';
COMMENT ON COLUMN wechat_daily_data.item_ltv_30d IS '30 日道具 LTV';
COMMENT ON COLUMN wechat_daily_data.created_at IS '创建时间';
COMMENT ON COLUMN wechat_daily_data.updated_at IS '更新时间';

CREATE INDEX IF NOT EXISTS idx_date ON wechat_daily_data (ref_date);
CREATE INDEX IF NOT EXISTS idx_appid_date ON wechat_daily_data (appid, ref_date);
