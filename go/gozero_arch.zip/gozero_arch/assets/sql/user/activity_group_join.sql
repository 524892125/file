SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for act_group_join
-- ----------------------------
DROP TABLE IF EXISTS `activity_group_join`;
CREATE TABLE `activity_group_join`  (
    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
    `uid` int(11) NOT NULL,
    `act_id` int(11) NOT NULL,
    `group_id` int(11) NOT NULL,
    `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE INDEX `udx_uid_actid_groupid`(`uid`, `act_id`, `group_id`) USING BTREE,
    INDEX `idx_uid`(`uid`) USING BTREE,
    INDEX `idx_act_id`(`act_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;