### 1. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/:id
- Method: GET
- Request: `AppRuntimeLogIdReq`
- Response: `AppRuntimeLog`

2. request definition



```golang
type AppRuntimeLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type AppRuntimeLog struct {
	Id int64 `json:"id"`
	MessageId string `json:"messageId"`
	TraceId string `json:"traceId"`
	TenantCode string `json:"tenantCode"`
	ServiceName string `json:"serviceName"`
	Level string `json:"level"`
	Caller string `json:"caller"`
	Content string `json:"content"`
	FieldsJson string `json:"fieldsJson"`
	Source string `json:"source"`
	LoggedAt string `json:"loggedAt"`
	CreatedAt string `json:"createdAt"`
}
```

### 2. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/:id
- Method: DELETE
- Request: `AppRuntimeLogIdReq`
- Response: `AppRuntimeLogEmptyResp`

2. request definition



```golang
type AppRuntimeLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type AppRuntimeLogEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/create
- Method: POST
- Request: `AppRuntimeLogCreateReq`
- Response: `AppRuntimeLogCreateResp`

2. request definition



```golang
type AppRuntimeLogCreateReq struct {
	MessageId string `json:"messageId"`
	TraceId string `json:"traceId,optional"`
	TenantCode string `json:"tenantCode,optional"`
	ServiceName string `json:"serviceName"`
	Level string `json:"level"`
	Caller string `json:"caller,optional"`
	Content string `json:"content,optional"`
	FieldsJson string `json:"fieldsJson,optional"`
	Source string `json:"source,optional"`
	LoggedAt string `json:"loggedAt"`
}
```


3. response definition



```golang
type AppRuntimeLogCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/findPage
- Method: GET
- Request: `AppRuntimeLogListReq`
- Response: `AppRuntimeLogFindPageResp`

2. request definition



```golang
type AppRuntimeLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogFindPageResp struct {
	List []AppRuntimeLog `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/list
- Method: GET
- Request: `AppRuntimeLogListReq`
- Response: `AppRuntimeLogListResp`

2. request definition



```golang
type AppRuntimeLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogListResp struct {
	List []AppRuntimeLog `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/update
- Method: POST
- Request: `AppRuntimeLogUpdateReq`
- Response: `AppRuntimeLogEmptyResp`

2. request definition



```golang
type AppRuntimeLogUpdateReq struct {
	Id int64 `json:"id"`
	MessageId *string `json:"messageId,optional"`
	TraceId *string `json:"traceId,optional"`
	TenantCode *string `json:"tenantCode,optional"`
	ServiceName *string `json:"serviceName,optional"`
	Level *string `json:"level,optional"`
	Caller *string `json:"caller,optional"`
	Content *string `json:"content,optional"`
	FieldsJson *string `json:"fieldsJson,optional"`
	Source *string `json:"source,optional"`
	LoggedAt *string `json:"loggedAt,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogEmptyResp struct {
}
```

### 7. N/A

1. route definition

- Url: /api/v1/db/sys-config/:id
- Method: GET
- Request: `SysConfigIdReq`
- Response: `SysConfig`

2. request definition



```golang
type SysConfigIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type SysConfig struct {
	Id int64 `json:"id"`
	ConfigName string `json:"configName"`
	ConfigKey string `json:"configKey"`
	ConfigValue string `json:"configValue"`
	ConfigType string `json:"configType"`
	IsFrontend string `json:"isFrontend"`
	Remark string `json:"remark"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 8. N/A

1. route definition

- Url: /api/v1/db/sys-config/:id
- Method: DELETE
- Request: `SysConfigIdReq`
- Response: `SysConfigEmptyResp`

2. request definition



```golang
type SysConfigIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type SysConfigEmptyResp struct {
}
```

### 9. N/A

1. route definition

- Url: /api/v1/db/sys-config/create
- Method: POST
- Request: `SysConfigCreateReq`
- Response: `SysConfigCreateResp`

2. request definition



```golang
type SysConfigCreateReq struct {
	ConfigName string `json:"configName,optional"`
	ConfigKey string `json:"configKey,optional"`
	ConfigValue string `json:"configValue,optional"`
	ConfigType string `json:"configType,optional"`
	IsFrontend string `json:"isFrontend,optional"`
	Remark string `json:"remark,optional"`
}
```


3. response definition



```golang
type SysConfigCreateResp struct {
	Id int64 `json:"id"`
}
```

### 10. N/A

1. route definition

- Url: /api/v1/db/sys-config/findPage
- Method: GET
- Request: `SysConfigListReq`
- Response: `SysConfigFindPageResp`

2. request definition



```golang
type SysConfigListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysConfigFindPageResp struct {
	List []SysConfig `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 11. N/A

1. route definition

- Url: /api/v1/db/sys-config/list
- Method: GET
- Request: `SysConfigListReq`
- Response: `SysConfigListResp`

2. request definition



```golang
type SysConfigListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysConfigListResp struct {
	List []SysConfig `json:"list"`
	Total int64 `json:"total"`
}
```

### 12. N/A

1. route definition

- Url: /api/v1/db/sys-config/update
- Method: POST
- Request: `SysConfigUpdateReq`
- Response: `SysConfigEmptyResp`

2. request definition



```golang
type SysConfigUpdateReq struct {
	Id int64 `json:"id"`
	ConfigName *string `json:"configName,optional"`
	ConfigKey *string `json:"configKey,optional"`
	ConfigValue *string `json:"configValue,optional"`
	ConfigType *string `json:"configType,optional"`
	IsFrontend *string `json:"isFrontend,optional"`
	Remark *string `json:"remark,optional"`
}
```


3. response definition



```golang
type SysConfigEmptyResp struct {
}
```

### 13. N/A

1. route definition

- Url: /api/v1/db/sys-dept/:deptId
- Method: GET
- Request: `SysDeptIdReq`
- Response: `SysDept`

2. request definition



```golang
type SysDeptIdReq struct {
	DeptId int64 `path:"deptId"`
}
```


3. response definition



```golang
type SysDept struct {
	DeptId int64 `json:"deptId"`
	ParentId int64 `json:"parentId"`
	DeptPath string `json:"deptPath"`
	DeptName string `json:"deptName"`
	Sort int64 `json:"sort"`
	Leader string `json:"leader"`
	Phone string `json:"phone"`
	Email string `json:"email"`
	Status int64 `json:"status"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 14. N/A

1. route definition

- Url: /api/v1/db/sys-dept/:deptId
- Method: DELETE
- Request: `SysDeptIdReq`
- Response: `SysDeptEmptyResp`

2. request definition



```golang
type SysDeptIdReq struct {
	DeptId int64 `path:"deptId"`
}
```


3. response definition



```golang
type SysDeptEmptyResp struct {
}
```

### 15. N/A

1. route definition

- Url: /api/v1/db/sys-dept/create
- Method: POST
- Request: `SysDeptCreateReq`
- Response: `SysDeptCreateResp`

2. request definition



```golang
type SysDeptCreateReq struct {
	ParentId int64 `json:"parentId,optional"`
	DeptPath string `json:"deptPath,optional"`
	DeptName string `json:"deptName,optional"`
	Sort int64 `json:"sort,optional"`
	Leader string `json:"leader,optional"`
	Phone string `json:"phone,optional"`
	Email string `json:"email,optional"`
	Status int64 `json:"status,optional"`
}
```


3. response definition



```golang
type SysDeptCreateResp struct {
	Id int64 `json:"id"`
}
```

### 16. N/A

1. route definition

- Url: /api/v1/db/sys-dept/findPage
- Method: GET
- Request: `SysDeptListReq`
- Response: `SysDeptFindPageResp`

2. request definition



```golang
type SysDeptListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDeptFindPageResp struct {
	List []SysDept `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 17. N/A

1. route definition

- Url: /api/v1/db/sys-dept/list
- Method: GET
- Request: `SysDeptListReq`
- Response: `SysDeptListResp`

2. request definition



```golang
type SysDeptListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDeptListResp struct {
	List []SysDept `json:"list"`
	Total int64 `json:"total"`
}
```

### 18. N/A

1. route definition

- Url: /api/v1/db/sys-dept/update
- Method: POST
- Request: `SysDeptUpdateReq`
- Response: `SysDeptEmptyResp`

2. request definition



```golang
type SysDeptUpdateReq struct {
	DeptId int64 `json:"deptId"`
	ParentId *int64 `json:"parentId,optional"`
	DeptPath *string `json:"deptPath,optional"`
	DeptName *string `json:"deptName,optional"`
	Sort *int64 `json:"sort,optional"`
	Leader *string `json:"leader,optional"`
	Phone *string `json:"phone,optional"`
	Email *string `json:"email,optional"`
	Status *int64 `json:"status,optional"`
}
```


3. response definition



```golang
type SysDeptEmptyResp struct {
}
```

### 19. N/A

1. route definition

- Url: /api/v1/db/sys-dict-data/:dictCode
- Method: GET
- Request: `SysDictDataIdReq`
- Response: `SysDictData`

2. request definition



```golang
type SysDictDataIdReq struct {
	DictCode int64 `path:"dictCode"`
}
```


3. response definition



```golang
type SysDictData struct {
	DictCode int64 `json:"dictCode"`
	DictSort int64 `json:"dictSort"`
	DictLabel string `json:"dictLabel"`
	DictValue string `json:"dictValue"`
	DictType string `json:"dictType"`
	CssClass string `json:"cssClass"`
	ListClass string `json:"listClass"`
	IsDefault string `json:"isDefault"`
	Status int64 `json:"status"`
	Default string `json:"default"`
	Remark string `json:"remark"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 20. N/A

1. route definition

- Url: /api/v1/db/sys-dict-data/:dictCode
- Method: DELETE
- Request: `SysDictDataIdReq`
- Response: `SysDictDataEmptyResp`

2. request definition



```golang
type SysDictDataIdReq struct {
	DictCode int64 `path:"dictCode"`
}
```


3. response definition



```golang
type SysDictDataEmptyResp struct {
}
```

### 21. N/A

1. route definition

- Url: /api/v1/db/sys-dict-data/create
- Method: POST
- Request: `SysDictDataCreateReq`
- Response: `SysDictDataCreateResp`

2. request definition



```golang
type SysDictDataCreateReq struct {
	DictSort int64 `json:"dictSort,optional"`
	DictLabel string `json:"dictLabel,optional"`
	DictValue string `json:"dictValue,optional"`
	DictType string `json:"dictType,optional"`
	CssClass string `json:"cssClass,optional"`
	ListClass string `json:"listClass,optional"`
	IsDefault string `json:"isDefault,optional"`
	Status int64 `json:"status,optional"`
	Default string `json:"default,optional"`
	Remark string `json:"remark,optional"`
}
```


3. response definition



```golang
type SysDictDataCreateResp struct {
	Id int64 `json:"id"`
}
```

### 22. N/A

1. route definition

- Url: /api/v1/db/sys-dict-data/findPage
- Method: GET
- Request: `SysDictDataListReq`
- Response: `SysDictDataFindPageResp`

2. request definition



```golang
type SysDictDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDictDataFindPageResp struct {
	List []SysDictData `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 23. N/A

1. route definition

- Url: /api/v1/db/sys-dict-data/list
- Method: GET
- Request: `SysDictDataListReq`
- Response: `SysDictDataListResp`

2. request definition



```golang
type SysDictDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDictDataListResp struct {
	List []SysDictData `json:"list"`
	Total int64 `json:"total"`
}
```

### 24. N/A

1. route definition

- Url: /api/v1/db/sys-dict-data/update
- Method: POST
- Request: `SysDictDataUpdateReq`
- Response: `SysDictDataEmptyResp`

2. request definition



```golang
type SysDictDataUpdateReq struct {
	DictCode int64 `json:"dictCode"`
	DictSort *int64 `json:"dictSort,optional"`
	DictLabel *string `json:"dictLabel,optional"`
	DictValue *string `json:"dictValue,optional"`
	DictType *string `json:"dictType,optional"`
	CssClass *string `json:"cssClass,optional"`
	ListClass *string `json:"listClass,optional"`
	IsDefault *string `json:"isDefault,optional"`
	Status *int64 `json:"status,optional"`
	Default *string `json:"default,optional"`
	Remark *string `json:"remark,optional"`
}
```


3. response definition



```golang
type SysDictDataEmptyResp struct {
}
```

### 25. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/:dictId
- Method: GET
- Request: `SysDictTypeIdReq`
- Response: `SysDictType`

2. request definition



```golang
type SysDictTypeIdReq struct {
	DictId int64 `path:"dictId"`
}
```


3. response definition



```golang
type SysDictType struct {
	DictId int64 `json:"dictId"`
	DictName string `json:"dictName"`
	DictType string `json:"dictType"`
	Status int64 `json:"status"`
	Remark string `json:"remark"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 26. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/:dictId
- Method: DELETE
- Request: `SysDictTypeIdReq`
- Response: `SysDictTypeEmptyResp`

2. request definition



```golang
type SysDictTypeIdReq struct {
	DictId int64 `path:"dictId"`
}
```


3. response definition



```golang
type SysDictTypeEmptyResp struct {
}
```

### 27. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/create
- Method: POST
- Request: `SysDictTypeCreateReq`
- Response: `SysDictTypeCreateResp`

2. request definition



```golang
type SysDictTypeCreateReq struct {
	DictName string `json:"dictName,optional"`
	DictType string `json:"dictType,optional"`
	Status int64 `json:"status,optional"`
	Remark string `json:"remark,optional"`
}
```


3. response definition



```golang
type SysDictTypeCreateResp struct {
	Id int64 `json:"id"`
}
```

### 28. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/findPage
- Method: GET
- Request: `SysDictTypeListReq`
- Response: `SysDictTypeFindPageResp`

2. request definition



```golang
type SysDictTypeListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDictTypeFindPageResp struct {
	List []SysDictType `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 29. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/list
- Method: GET
- Request: `SysDictTypeListReq`
- Response: `SysDictTypeListResp`

2. request definition



```golang
type SysDictTypeListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDictTypeListResp struct {
	List []SysDictType `json:"list"`
	Total int64 `json:"total"`
}
```

### 30. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/update
- Method: POST
- Request: `SysDictTypeUpdateReq`
- Response: `SysDictTypeEmptyResp`

2. request definition



```golang
type SysDictTypeUpdateReq struct {
	DictId int64 `json:"dictId"`
	DictName *string `json:"dictName,optional"`
	DictType *string `json:"dictType,optional"`
	Status *int64 `json:"status,optional"`
	Remark *string `json:"remark,optional"`
}
```


3. response definition



```golang
type SysDictTypeEmptyResp struct {
}
```

### 31. N/A

1. route definition

- Url: /api/v1/db/sys-menu/:menuId
- Method: GET
- Request: `SysMenuIdReq`
- Response: `SysMenu`

2. request definition



```golang
type SysMenuIdReq struct {
	MenuId int64 `path:"menuId"`
}
```


3. response definition



```golang
type SysMenu struct {
	MenuId int64 `json:"menuId"`
	MenuName string `json:"menuName"`
	Title string `json:"title"`
	Icon string `json:"icon"`
	Path string `json:"path"`
	Paths string `json:"paths"`
	MenuType string `json:"menuType"`
	Action string `json:"action"`
	Permission string `json:"permission"`
	ParentId int64 `json:"parentId"`
	NoCache bool `json:"noCache"`
	Breadcrumb string `json:"breadcrumb"`
	Component string `json:"component"`
	Sort int64 `json:"sort"`
	Visible string `json:"visible"`
	IsFrame string `json:"isFrame"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 32. N/A

1. route definition

- Url: /api/v1/db/sys-menu/:menuId
- Method: DELETE
- Request: `SysMenuIdReq`
- Response: `SysMenuEmptyResp`

2. request definition



```golang
type SysMenuIdReq struct {
	MenuId int64 `path:"menuId"`
}
```


3. response definition



```golang
type SysMenuEmptyResp struct {
}
```

### 33. N/A

1. route definition

- Url: /api/v1/db/sys-menu/create
- Method: POST
- Request: `SysMenuCreateReq`
- Response: `SysMenuCreateResp`

2. request definition



```golang
type SysMenuCreateReq struct {
	MenuName string `json:"menuName"`
	Title string `json:"title,optional"`
	Icon string `json:"icon,optional"`
	Path string `json:"path"`
	Paths string `json:"paths,optional"`
	MenuType string `json:"menuType"`
	Action string `json:"action,optional"`
	Permission string `json:"permission,optional"`
	ParentId int64 `json:"parentId,optional"`
	NoCache bool `json:"noCache,optional"`
	Breadcrumb string `json:"breadcrumb,optional"`
	Component string `json:"component,optional"`
	Sort int64 `json:"sort,optional"`
	Visible string `json:"visible,optional"`
	IsFrame string `json:"isFrame,optional"`
}
```


3. response definition



```golang
type SysMenuCreateResp struct {
	Id int64 `json:"id"`
}
```

### 34. N/A

1. route definition

- Url: /api/v1/db/sys-menu/findPage
- Method: GET
- Request: `SysMenuListReq`
- Response: `SysMenuFindPageResp`

2. request definition



```golang
type SysMenuListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysMenuFindPageResp struct {
	List []SysMenu `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 35. N/A

1. route definition

- Url: /api/v1/db/sys-menu/list
- Method: GET
- Request: `SysMenuListReq`
- Response: `SysMenuListResp`

2. request definition



```golang
type SysMenuListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysMenuListResp struct {
	List []SysMenu `json:"list"`
	Total int64 `json:"total"`
}
```

### 36. N/A

1. route definition

- Url: /api/v1/db/sys-menu/update
- Method: POST
- Request: `SysMenuUpdateReq`
- Response: `SysMenuEmptyResp`

2. request definition



```golang
type SysMenuUpdateReq struct {
	MenuId int64 `json:"menuId"`
	MenuName *string `json:"menuName,optional"`
	Title *string `json:"title,optional"`
	Icon *string `json:"icon,optional"`
	Path *string `json:"path,optional"`
	Paths *string `json:"paths,optional"`
	MenuType *string `json:"menuType,optional"`
	Action *string `json:"action,optional"`
	Permission *string `json:"permission,optional"`
	ParentId *int64 `json:"parentId,optional"`
	NoCache *bool `json:"noCache,optional"`
	Breadcrumb *string `json:"breadcrumb,optional"`
	Component *string `json:"component,optional"`
	Sort *int64 `json:"sort,optional"`
	Visible *string `json:"visible,optional"`
	IsFrame *string `json:"isFrame,optional"`
}
```


3. response definition



```golang
type SysMenuEmptyResp struct {
}
```

### 37. N/A

1. route definition

- Url: /api/v1/db/sys-role/:roleId
- Method: GET
- Request: `SysRoleIdReq`
- Response: `SysRole`

2. request definition



```golang
type SysRoleIdReq struct {
	RoleId int64 `path:"roleId"`
}
```


3. response definition



```golang
type SysRole struct {
	RoleId int64 `json:"roleId"`
	RoleName string `json:"roleName"`
	Status string `json:"status"`
	RoleKey string `json:"roleKey"`
	RoleSort int64 `json:"roleSort"`
	Flag string `json:"flag"`
	Remark string `json:"remark"`
	Admin bool `json:"admin"`
	DataScope string `json:"dataScope"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 38. N/A

1. route definition

- Url: /api/v1/db/sys-role/:roleId
- Method: DELETE
- Request: `SysRoleIdReq`
- Response: `SysRoleEmptyResp`

2. request definition



```golang
type SysRoleIdReq struct {
	RoleId int64 `path:"roleId"`
}
```


3. response definition



```golang
type SysRoleEmptyResp struct {
}
```

### 39. N/A

1. route definition

- Url: /api/v1/db/sys-role/create
- Method: POST
- Request: `SysRoleCreateReq`
- Response: `SysRoleCreateResp`

2. request definition



```golang
type SysRoleCreateReq struct {
	RoleName string `json:"roleName,optional"`
	Status string `json:"status,optional"`
	RoleKey string `json:"roleKey,optional"`
	RoleSort int64 `json:"roleSort,optional"`
	Flag string `json:"flag,optional"`
	Remark string `json:"remark,optional"`
	Admin bool `json:"admin,optional"`
	DataScope string `json:"dataScope,optional"`
}
```


3. response definition



```golang
type SysRoleCreateResp struct {
	Id int64 `json:"id"`
}
```

### 40. N/A

1. route definition

- Url: /api/v1/db/sys-role/findPage
- Method: GET
- Request: `SysRoleListReq`
- Response: `SysRoleFindPageResp`

2. request definition



```golang
type SysRoleListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysRoleFindPageResp struct {
	List []SysRole `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 41. N/A

1. route definition

- Url: /api/v1/db/sys-role/list
- Method: GET
- Request: `SysRoleListReq`
- Response: `SysRoleListResp`

2. request definition



```golang
type SysRoleListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysRoleListResp struct {
	List []SysRole `json:"list"`
	Total int64 `json:"total"`
}
```

### 42. N/A

1. route definition

- Url: /api/v1/db/sys-role/update
- Method: POST
- Request: `SysRoleUpdateReq`
- Response: `SysRoleEmptyResp`

2. request definition



```golang
type SysRoleUpdateReq struct {
	RoleId int64 `json:"roleId"`
	RoleName *string `json:"roleName,optional"`
	Status *string `json:"status,optional"`
	RoleKey *string `json:"roleKey,optional"`
	RoleSort *int64 `json:"roleSort,optional"`
	Flag *string `json:"flag,optional"`
	Remark *string `json:"remark,optional"`
	Admin *bool `json:"admin,optional"`
	DataScope *string `json:"dataScope,optional"`
}
```


3. response definition



```golang
type SysRoleEmptyResp struct {
}
```

### 43. N/A

1. route definition

- Url: /api/v1/db/sys-user/:userId
- Method: GET
- Request: `SysUserIdReq`
- Response: `SysUser`

2. request definition



```golang
type SysUserIdReq struct {
	UserId int64 `path:"userId"`
}
```


3. response definition



```golang
type SysUser struct {
	UserId int64 `json:"userId"`
	Username string `json:"username"`
	Password string `json:"password"`
	NickName string `json:"nickName"`
	Phone string `json:"phone"`
	RoleId int64 `json:"roleId"`
	Salt string `json:"salt"`
	Avatar string `json:"avatar"`
	Sex string `json:"sex"`
	Email string `json:"email"`
	DeptId int64 `json:"deptId"`
	PostId int64 `json:"postId"`
	Remark string `json:"remark"`
	Status string `json:"status"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
	AllowPasswordLogin string `json:"allowPasswordLogin"`
}
```

### 44. N/A

1. route definition

- Url: /api/v1/db/sys-user/:userId
- Method: DELETE
- Request: `SysUserIdReq`
- Response: `SysUserEmptyResp`

2. request definition



```golang
type SysUserIdReq struct {
	UserId int64 `path:"userId"`
}
```


3. response definition



```golang
type SysUserEmptyResp struct {
}
```

### 45. N/A

1. route definition

- Url: /api/v1/db/sys-user/create
- Method: POST
- Request: `SysUserCreateReq`
- Response: `SysUserCreateResp`

2. request definition



```golang
type SysUserCreateReq struct {
	Username string `json:"username,optional"`
	Password string `json:"password,optional"`
	NickName string `json:"nickName,optional"`
	Phone string `json:"phone,optional"`
	RoleId int64 `json:"roleId,optional"`
	Salt string `json:"salt,optional"`
	Avatar string `json:"avatar,optional"`
	Sex string `json:"sex,optional"`
	Email string `json:"email,optional"`
	DeptId int64 `json:"deptId,optional"`
	PostId int64 `json:"postId,optional"`
	Remark string `json:"remark,optional"`
	Status string `json:"status,optional"`
	AllowPasswordLogin string `json:"allowPasswordLogin,optional"`
}
```


3. response definition



```golang
type SysUserCreateResp struct {
	Id int64 `json:"id"`
}
```

### 46. N/A

1. route definition

- Url: /api/v1/db/sys-user/findPage
- Method: GET
- Request: `SysUserListReq`
- Response: `SysUserFindPageResp`

2. request definition



```golang
type SysUserListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysUserFindPageResp struct {
	List []SysUser `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 47. N/A

1. route definition

- Url: /api/v1/db/sys-user/list
- Method: GET
- Request: `SysUserListReq`
- Response: `SysUserListResp`

2. request definition



```golang
type SysUserListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysUserListResp struct {
	List []SysUser `json:"list"`
	Total int64 `json:"total"`
}
```

### 48. N/A

1. route definition

- Url: /api/v1/db/sys-user/update
- Method: POST
- Request: `SysUserUpdateReq`
- Response: `SysUserEmptyResp`

2. request definition



```golang
type SysUserUpdateReq struct {
	UserId int64 `json:"userId"`
	Username *string `json:"username,optional"`
	Password *string `json:"password,optional"`
	NickName *string `json:"nickName,optional"`
	Phone *string `json:"phone,optional"`
	RoleId *int64 `json:"roleId,optional"`
	Salt *string `json:"salt,optional"`
	Avatar *string `json:"avatar,optional"`
	Sex *string `json:"sex,optional"`
	Email *string `json:"email,optional"`
	DeptId *int64 `json:"deptId,optional"`
	PostId *int64 `json:"postId,optional"`
	Remark *string `json:"remark,optional"`
	Status *string `json:"status,optional"`
	AllowPasswordLogin *string `json:"allowPasswordLogin,optional"`
}
```


3. response definition



```golang
type SysUserEmptyResp struct {
}
```

### 49. N/A

1. route definition

- Url: /api/v1/deptTree
- Method: GET
- Request: `ExtDeptTreeReq`
- Response: `ExtDeptTreeResp`

2. request definition



```golang
type ExtDeptTreeReq struct {
}
```


3. response definition



```golang
type ExtDeptTreeResp struct {
	Items []*ExtSysDept `json:"items"`
}
```

### 50. N/A

1. route definition

- Url: /api/v1/extFeishuConfig
- Method: GET
- Request: `ExtFeishuConfigReq`
- Response: `ExtFeishuConfigResp`

2. request definition



```golang
type ExtFeishuConfigReq struct {
}
```


3. response definition



```golang
type ExtFeishuConfigResp struct {
	AppID string `json:"appId"`
	AppSecret string `json:"appSecret"`
	RedirectURI string `json:"redirectURI"`
	BaseURL string `json:"baseURL"`
}
```

### 51. N/A

1. route definition

- Url: /api/v1/extFeishuLogin
- Method: POST
- Request: `ExtFeishuLoginReq`
- Response: `LoginResp`

2. request definition



```golang
type ExtFeishuLoginReq struct {
	Code string `json:"code"`
}
```


3. response definition



```golang
type LoginResp struct {
	Token string `json:"token"`
}
```

### 52. N/A

1. route definition

- Url: /api/v1/getinfo
- Method: GET
- Request: `GetInfoReq`
- Response: `GetInfoResp`

2. request definition



```golang
type GetInfoReq struct {
}
```


3. response definition



```golang
type GetInfoResp struct {
	Avatar string `json:"avatar"`
	DeptId int64 `json:"deptId"`
	Name string `json:"name"`
	UserId int64 `json:"userId"`
	UserName string `json:"userName"`
}
```

### 53. N/A

1. route definition

- Url: /api/v1/login
- Method: POST
- Request: `LoginReq`
- Response: `LoginResp`

2. request definition



```golang
type LoginReq struct {
	UserName string `json:"username"`
	Password string `json:"password"`
}
```


3. response definition



```golang
type LoginResp struct {
	Token string `json:"token"`
}
```

### 54. N/A

1. route definition

- Url: /api/v1/menuTree
- Method: GET
- Request: `MenuRoleReq`
- Response: `MenuRoleResp`

2. request definition



```golang
type MenuRoleReq struct {
}
```


3. response definition



```golang
type MenuRoleResp struct {
	Items []*MenuItem `json:"items"`
}
```

### 55. N/A

1. route definition

- Url: /api/v1/menurole
- Method: GET
- Request: `MenuRoleReq`
- Response: `MenuRoleResp`

2. request definition



```golang
type MenuRoleReq struct {
}
```


3. response definition



```golang
type MenuRoleResp struct {
	Items []*MenuItem `json:"items"`
}
```

### 56. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/:id
- Method: GET
- Request: `RpcCronTaskRunLogIdReq`
- Response: `RpcCronTaskRunLog`

2. request definition



```golang
type RpcCronTaskRunLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcCronTaskRunLog struct {
	Id int64 `json:"id"`
	TaskId int64 `json:"taskId"`
	WorkerId string `json:"workerId"`
	Status string `json:"status"`
	Message string `json:"message"`
	StartedAt string `json:"startedAt"`
	FinishedAt string `json:"finishedAt"`
	DurationMs int64 `json:"durationMs"`
	CreatedAt string `json:"createdAt"`
}
```

### 57. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/:id
- Method: DELETE
- Request: `RpcCronTaskRunLogIdReq`
- Response: `RpcCronTaskRunLogEmptyResp`

2. request definition



```golang
type RpcCronTaskRunLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcCronTaskRunLogEmptyResp struct {
}
```

### 58. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/create
- Method: POST
- Request: `RpcCronTaskRunLogCreateReq`
- Response: `RpcCronTaskRunLogCreateResp`

2. request definition



```golang
type RpcCronTaskRunLogCreateReq struct {
	TaskId int64 `json:"taskId"`
	WorkerId string `json:"workerId"`
	Status string `json:"status"`
	Message string `json:"message"`
	StartedAt string `json:"startedAt"`
	FinishedAt string `json:"finishedAt"`
	DurationMs int64 `json:"durationMs"`
}
```


3. response definition



```golang
type RpcCronTaskRunLogCreateResp struct {
	Id int64 `json:"id"`
}
```

### 59. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/findPage
- Method: GET
- Request: `RpcCronTaskRunLogListReq`
- Response: `RpcCronTaskRunLogFindPageResp`

2. request definition



```golang
type RpcCronTaskRunLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcCronTaskRunLogFindPageResp struct {
	List []RpcCronTaskRunLog `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 60. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/list
- Method: GET
- Request: `RpcCronTaskRunLogListReq`
- Response: `RpcCronTaskRunLogListResp`

2. request definition



```golang
type RpcCronTaskRunLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcCronTaskRunLogListResp struct {
	List []RpcCronTaskRunLog `json:"list"`
	Total int64 `json:"total"`
}
```

### 61. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/update
- Method: POST
- Request: `RpcCronTaskRunLogUpdateReq`
- Response: `RpcCronTaskRunLogEmptyResp`

2. request definition



```golang
type RpcCronTaskRunLogUpdateReq struct {
	Id int64 `json:"id"`
	TaskId *int64 `json:"taskId,optional"`
	WorkerId *string `json:"workerId,optional"`
	Status *string `json:"status,optional"`
	Message *string `json:"message,optional"`
	StartedAt *string `json:"startedAt,optional"`
	FinishedAt *string `json:"finishedAt,optional"`
	DurationMs *int64 `json:"durationMs,optional"`
}
```


3. response definition



```golang
type RpcCronTaskRunLogEmptyResp struct {
}
```

### 62. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/:id
- Method: GET
- Request: `RpcCronTaskIdReq`
- Response: `RpcCronTask`

2. request definition



```golang
type RpcCronTaskIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcCronTask struct {
	Id int64 `json:"id"`
	Name string `json:"name"`
	TaskKey string `json:"taskKey"`
	Payload string `json:"payload"`
	ScheduleType string `json:"scheduleType"`
	RunAt string `json:"runAt"`
	IntervalSeconds int64 `json:"intervalSeconds"`
	Status string `json:"status"`
	NextRunAt string `json:"nextRunAt"`
	LastRunAt string `json:"lastRunAt"`
	LockedBy string `json:"lockedBy"`
	LockedUntil string `json:"lockedUntil"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
}
```

### 63. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/:id
- Method: DELETE
- Request: `RpcCronTaskIdReq`
- Response: `RpcCronTaskEmptyResp`

2. request definition



```golang
type RpcCronTaskIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcCronTaskEmptyResp struct {
}
```

### 64. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/create
- Method: POST
- Request: `RpcCronTaskCreateReq`
- Response: `RpcCronTaskCreateResp`

2. request definition



```golang
type RpcCronTaskCreateReq struct {
	Name string `json:"name"`
	TaskKey string `json:"taskKey"`
	Payload string `json:"payload"`
	ScheduleType string `json:"scheduleType"`
	RunAt string `json:"runAt"`
	IntervalSeconds int64 `json:"intervalSeconds"`
	Status string `json:"status"`
	NextRunAt string `json:"nextRunAt,optional"`
	LastRunAt string `json:"lastRunAt,optional"`
	LockedBy string `json:"lockedBy,optional"`
	LockedUntil string `json:"lockedUntil,optional"`
}
```


3. response definition



```golang
type RpcCronTaskCreateResp struct {
	Id int64 `json:"id"`
}
```

### 65. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/findPage
- Method: GET
- Request: `RpcCronTaskListReq`
- Response: `RpcCronTaskFindPageResp`

2. request definition



```golang
type RpcCronTaskListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcCronTaskFindPageResp struct {
	List []RpcCronTask `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 66. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/list
- Method: GET
- Request: `RpcCronTaskListReq`
- Response: `RpcCronTaskListResp`

2. request definition



```golang
type RpcCronTaskListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcCronTaskListResp struct {
	List []RpcCronTask `json:"list"`
	Total int64 `json:"total"`
}
```

### 67. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/update
- Method: POST
- Request: `RpcCronTaskUpdateReq`
- Response: `RpcCronTaskEmptyResp`

2. request definition



```golang
type RpcCronTaskUpdateReq struct {
	Id int64 `json:"id"`
	Name *string `json:"name,optional"`
	TaskKey *string `json:"taskKey,optional"`
	Payload *string `json:"payload,optional"`
	ScheduleType *string `json:"scheduleType,optional"`
	RunAt *string `json:"runAt,optional"`
	IntervalSeconds *int64 `json:"intervalSeconds,optional"`
	Status *string `json:"status,optional"`
	NextRunAt *string `json:"nextRunAt,optional"`
	LastRunAt *string `json:"lastRunAt,optional"`
	LockedBy *string `json:"lockedBy,optional"`
	LockedUntil *string `json:"lockedUntil,optional"`
}
```


3. response definition



```golang
type RpcCronTaskEmptyResp struct {
}
```

### 68. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/:id
- Method: GET
- Request: `RpcSummaryDataIdReq`
- Response: `RpcSummaryData`

2. request definition



```golang
type RpcSummaryDataIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcSummaryData struct {
	Id int64 `json:"id"`
	Appid string `json:"appid"`
	RefDate string `json:"refDate"`
	Dau int64 `json:"dau"`
	NewUsers int64 `json:"newUsers"`
	NewUserRatio float64 `json:"newUserRatio"`
	AvgAcquisitionCost float64 `json:"avgAcquisitionCost"`
	AvgActiveCost float64 `json:"avgActiveCost"`
	AvgTotalCost float64 `json:"avgTotalCost"`
	LtValue float64 `json:"ltValue"`
	TotalUsersSum int64 `json:"totalUsersSum"`
	TotalRevenue float64 `json:"totalRevenue"`
	TotalExpenditure float64 `json:"totalExpenditure"`
	GrossProfit float64 `json:"grossProfit"`
	CoopProfitShare float64 `json:"coopProfitShare"`
	ProfitMargin float64 `json:"profitMargin"`
	RevTrafficOwner float64 `json:"revTrafficOwner"`
	RevInternalPurchase float64 `json:"revInternalPurchase"`
	RevCommission float64 `json:"revCommission"`
	RevTrafficRental float64 `json:"revTrafficRental"`
	RevAdSettlement float64 `json:"revAdSettlement"`
	RevTotalCalc float64 `json:"revTotalCalc"`
	ExpDailyBase float64 `json:"expDailyBase"`
	ExpInternalBuy float64 `json:"expInternalBuy"`
	ExpExternalBuy float64 `json:"expExternalBuy"`
	ExpTotalOps float64 `json:"expTotalOps"`
	Remark string `json:"remark"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
}
```

### 69. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/:id
- Method: DELETE
- Request: `RpcSummaryDataIdReq`
- Response: `RpcSummaryDataEmptyResp`

2. request definition



```golang
type RpcSummaryDataIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcSummaryDataEmptyResp struct {
}
```

### 70. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/create
- Method: POST
- Request: `RpcSummaryDataCreateReq`
- Response: `RpcSummaryDataCreateResp`

2. request definition



```golang
type RpcSummaryDataCreateReq struct {
	Appid string `json:"appid"`
	RefDate string `json:"refDate"`
	Dau int64 `json:"dau,optional"`
	NewUsers int64 `json:"newUsers,optional"`
	NewUserRatio float64 `json:"newUserRatio,optional"`
	AvgAcquisitionCost float64 `json:"avgAcquisitionCost,optional"`
	AvgActiveCost float64 `json:"avgActiveCost,optional"`
	AvgTotalCost float64 `json:"avgTotalCost,optional"`
	LtValue float64 `json:"ltValue,optional"`
	TotalUsersSum int64 `json:"totalUsersSum,optional"`
	TotalRevenue float64 `json:"totalRevenue,optional"`
	TotalExpenditure float64 `json:"totalExpenditure,optional"`
	GrossProfit float64 `json:"grossProfit,optional"`
	CoopProfitShare float64 `json:"coopProfitShare,optional"`
	ProfitMargin float64 `json:"profitMargin,optional"`
	RevTrafficOwner float64 `json:"revTrafficOwner,optional"`
	RevInternalPurchase float64 `json:"revInternalPurchase,optional"`
	RevCommission float64 `json:"revCommission,optional"`
	RevTrafficRental float64 `json:"revTrafficRental,optional"`
	RevAdSettlement float64 `json:"revAdSettlement,optional"`
	RevTotalCalc float64 `json:"revTotalCalc,optional"`
	ExpDailyBase float64 `json:"expDailyBase,optional"`
	ExpInternalBuy float64 `json:"expInternalBuy,optional"`
	ExpExternalBuy float64 `json:"expExternalBuy,optional"`
	ExpTotalOps float64 `json:"expTotalOps,optional"`
	Remark string `json:"remark,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataCreateResp struct {
	Id int64 `json:"id"`
}
```

### 71. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/findPage
- Method: GET
- Request: `RpcSummaryDataListReq`
- Response: `RpcSummaryDataFindPageResp`

2. request definition



```golang
type RpcSummaryDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataFindPageResp struct {
	List []RpcSummaryData `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 72. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/list
- Method: GET
- Request: `RpcSummaryDataListReq`
- Response: `RpcSummaryDataListResp`

2. request definition



```golang
type RpcSummaryDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataListResp struct {
	List []RpcSummaryData `json:"list"`
	Total int64 `json:"total"`
}
```

### 73. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/update
- Method: POST
- Request: `RpcSummaryDataUpdateReq`
- Response: `RpcSummaryDataEmptyResp`

2. request definition



```golang
type RpcSummaryDataUpdateReq struct {
	Id int64 `json:"id"`
	Appid *string `json:"appid,optional"`
	RefDate *string `json:"refDate,optional"`
	Dau *int64 `json:"dau,optional"`
	NewUsers *int64 `json:"newUsers,optional"`
	NewUserRatio *float64 `json:"newUserRatio,optional"`
	AvgAcquisitionCost *float64 `json:"avgAcquisitionCost,optional"`
	AvgActiveCost *float64 `json:"avgActiveCost,optional"`
	AvgTotalCost *float64 `json:"avgTotalCost,optional"`
	LtValue *float64 `json:"ltValue,optional"`
	TotalUsersSum *int64 `json:"totalUsersSum,optional"`
	TotalRevenue *float64 `json:"totalRevenue,optional"`
	TotalExpenditure *float64 `json:"totalExpenditure,optional"`
	GrossProfit *float64 `json:"grossProfit,optional"`
	CoopProfitShare *float64 `json:"coopProfitShare,optional"`
	ProfitMargin *float64 `json:"profitMargin,optional"`
	RevTrafficOwner *float64 `json:"revTrafficOwner,optional"`
	RevInternalPurchase *float64 `json:"revInternalPurchase,optional"`
	RevCommission *float64 `json:"revCommission,optional"`
	RevTrafficRental *float64 `json:"revTrafficRental,optional"`
	RevAdSettlement *float64 `json:"revAdSettlement,optional"`
	RevTotalCalc *float64 `json:"revTotalCalc,optional"`
	ExpDailyBase *float64 `json:"expDailyBase,optional"`
	ExpInternalBuy *float64 `json:"expInternalBuy,optional"`
	ExpExternalBuy *float64 `json:"expExternalBuy,optional"`
	ExpTotalOps *float64 `json:"expTotalOps,optional"`
	Remark *string `json:"remark,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataEmptyResp struct {
}
```
