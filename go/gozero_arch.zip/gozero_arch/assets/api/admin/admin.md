### 1. N/A

1. route definition

- Url: /api/v1/login
- Method: POST
- Request: `LoginReq`
- Response: `LoginResp`

2. request definition



```golang
type LoginReq struct {
	UserName string `json:"username"`
	Password string `json:"password"`
}
```


3. response definition



```golang
type LoginResp struct {
	Token string `json:"token"`
}
```

### 2. N/A

1. route definition

- Url: /users/auth/create
- Method: POST
- Request: `request`
- Response: `-`

2. request definition



```golang
type Request struct {
}
```


3. response definition


### 3. N/A

1. route definition

- Url: /users/id/:userId
- Method: GET
- Request: `request`
- Response: `response`

2. request definition



```golang
type Request struct {
}
```


3. response definition



```golang
type Response struct {
}
```

### 4. N/A

1. route definition

- Url: /api/v1/getinfo
- Method: GET
- Request: `GetInfoReq`
- Response: `GetInfoResp`

2. request definition



```golang
type GetInfoReq struct {
}
```


3. response definition



```golang
type GetInfoResp struct {
	Avatar string `json:"avatar"`
	DeptId int64 `json:"deptId"`
	Name string `json:"name"`
	UserId int64 `json:"userId"`
	UserName string `json:"userName"`
}
```

### 5. N/A

1. route definition

- Url: /db/sys-config/:id
- Method: GET
- Request: `SysConfigIdReq`
- Response: `SysConfig`

2. request definition



```golang
type SysConfigIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type SysConfig struct {
	Id int64 `json:"id"`
	ConfigName string `json:"configName"`
	ConfigKey string `json:"configKey"`
	ConfigValue string `json:"configValue"`
	ConfigType string `json:"configType"`
	IsFrontend string `json:"isFrontend"`
	Remark string `json:"remark"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 6. N/A

1. route definition

- Url: /db/sys-config/:id
- Method: DELETE
- Request: `SysConfigIdReq`
- Response: `SysConfigEmptyResp`

2. request definition



```golang
type SysConfigIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type SysConfigEmptyResp struct {
}
```

### 7. N/A

1. route definition

- Url: /db/sys-config/create
- Method: POST
- Request: `SysConfigCreateReq`
- Response: `SysConfigCreateResp`

2. request definition



```golang
type SysConfigCreateReq struct {
	ConfigName string `json:"configName"`
	ConfigKey string `json:"configKey"`
	ConfigValue string `json:"configValue"`
	ConfigType string `json:"configType"`
	IsFrontend string `json:"isFrontend"`
	Remark string `json:"remark"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
}
```


3. response definition



```golang
type SysConfigCreateResp struct {
	Id int64 `json:"id"`
}
```

### 8. N/A

1. route definition

- Url: /db/sys-config/findPage
- Method: GET
- Request: `SysConfigListReq`
- Response: `SysConfigFindPageResp`

2. request definition



```golang
type SysConfigListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysConfigFindPageResp struct {
	List []SysConfig `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 9. N/A

1. route definition

- Url: /db/sys-config/list
- Method: GET
- Request: `SysConfigListReq`
- Response: `SysConfigListResp`

2. request definition



```golang
type SysConfigListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysConfigListResp struct {
	List []SysConfig `json:"list"`
	Total int64 `json:"total"`
}
```

### 10. N/A

1. route definition

- Url: /db/sys-config/update
- Method: POST
- Request: `SysConfigUpdateReq`
- Response: `SysConfigEmptyResp`

2. request definition



```golang
type SysConfigUpdateReq struct {
	Id int64 `json:"id"`
	ConfigName *string `json:"configName,optional"`
	ConfigKey *string `json:"configKey,optional"`
	ConfigValue *string `json:"configValue,optional"`
	ConfigType *string `json:"configType,optional"`
	IsFrontend *string `json:"isFrontend,optional"`
	Remark *string `json:"remark,optional"`
	CreateBy *int64 `json:"createBy,optional"`
	UpdateBy *int64 `json:"updateBy,optional"`
}
```


3. response definition



```golang
type SysConfigEmptyResp struct {
}
```

### 11. N/A

1. route definition

- Url: /db/app-runtime-log/:id
- Method: GET
- Request: `AppRuntimeLogIdReq`
- Response: `AppRuntimeLog`

2. request definition



```golang
type AppRuntimeLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type AppRuntimeLog struct {
	Id int64 `json:"id"`
	MessageId string `json:"messageId"`
	TraceId string `json:"traceId"`
	TenantCode string `json:"tenantCode"`
	ServiceName string `json:"serviceName"`
	Level string `json:"level"`
	Caller string `json:"caller"`
	Content string `json:"content"`
	FieldsJson string `json:"fieldsJson"`
	Source string `json:"source"`
	LoggedAt string `json:"loggedAt"`
	CreatedAt string `json:"createdAt"`
}
```

### 12. N/A

1. route definition

- Url: /db/app-runtime-log/:id
- Method: DELETE
- Request: `AppRuntimeLogIdReq`
- Response: `AppRuntimeLogEmptyResp`

2. request definition



```golang
type AppRuntimeLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type AppRuntimeLogEmptyResp struct {
}
```

### 13. N/A

1. route definition

- Url: /db/app-runtime-log/create
- Method: POST
- Request: `AppRuntimeLogCreateReq`
- Response: `AppRuntimeLogCreateResp`

2. request definition



```golang
type AppRuntimeLogCreateReq struct {
	MessageId string `json:"messageId"`
	TraceId string `json:"traceId"`
	TenantCode string `json:"tenantCode"`
	ServiceName string `json:"serviceName"`
	Level string `json:"level"`
	Caller string `json:"caller"`
	Content string `json:"content"`
	FieldsJson string `json:"fieldsJson"`
	Source string `json:"source"`
	LoggedAt string `json:"loggedAt"`
}
```


3. response definition



```golang
type AppRuntimeLogCreateResp struct {
	Id int64 `json:"id"`
}
```

### 14. N/A

1. route definition

- Url: /db/app-runtime-log/findPage
- Method: GET
- Request: `AppRuntimeLogListReq`
- Response: `AppRuntimeLogFindPageResp`

2. request definition



```golang
type AppRuntimeLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogFindPageResp struct {
	List []AppRuntimeLog `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 15. N/A

1. route definition

- Url: /db/app-runtime-log/list
- Method: GET
- Request: `AppRuntimeLogListReq`
- Response: `AppRuntimeLogListResp`

2. request definition



```golang
type AppRuntimeLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogListResp struct {
	List []AppRuntimeLog `json:"list"`
	Total int64 `json:"total"`
}
```

### 16. N/A

1. route definition

- Url: /db/app-runtime-log/update
- Method: POST
- Request: `AppRuntimeLogUpdateReq`
- Response: `AppRuntimeLogEmptyResp`

2. request definition



```golang
type AppRuntimeLogUpdateReq struct {
	Id int64 `json:"id"`
	MessageId *string `json:"messageId,optional"`
	TraceId *string `json:"traceId,optional"`
	TenantCode *string `json:"tenantCode,optional"`
	ServiceName *string `json:"serviceName,optional"`
	Level *string `json:"level,optional"`
	Caller *string `json:"caller,optional"`
	Content *string `json:"content,optional"`
	FieldsJson *string `json:"fieldsJson,optional"`
	Source *string `json:"source,optional"`
	LoggedAt *string `json:"loggedAt,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogEmptyResp struct {
}
```

### 17. N/A

1. route definition

- Url: /db/sys-user/:userId
- Method: GET
- Request: `SysUserIdReq`
- Response: `SysUser`

2. request definition



```golang
type SysUserIdReq struct {
	UserId int64 `path:"userId"`
}
```


3. response definition



```golang
type SysUser struct {
	UserId int64 `json:"userId"`
	Username string `json:"username"`
	Password string `json:"password"`
	NickName string `json:"nickName"`
	Phone string `json:"phone"`
	RoleId int64 `json:"roleId"`
	Salt string `json:"salt"`
	Avatar string `json:"avatar"`
	Sex string `json:"sex"`
	Email string `json:"email"`
	DeptId int64 `json:"deptId"`
	PostId int64 `json:"postId"`
	Remark string `json:"remark"`
	Status string `json:"status"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
	AllowPasswordLogin string `json:"allowPasswordLogin"`
}
```

### 18. N/A

1. route definition

- Url: /db/sys-user/:userId
- Method: DELETE
- Request: `SysUserIdReq`
- Response: `SysUserEmptyResp`

2. request definition



```golang
type SysUserIdReq struct {
	UserId int64 `path:"userId"`
}
```


3. response definition



```golang
type SysUserEmptyResp struct {
}
```

### 19. N/A

1. route definition

- Url: /db/sys-user/create
- Method: POST
- Request: `SysUserCreateReq`
- Response: `SysUserCreateResp`

2. request definition



```golang
type SysUserCreateReq struct {
	UserId int64 `json:"userId"`
	Username string `json:"username"`
	Password string `json:"password"`
	NickName string `json:"nickName"`
	Phone string `json:"phone"`
	RoleId int64 `json:"roleId"`
	Salt string `json:"salt"`
	Avatar string `json:"avatar"`
	Sex string `json:"sex"`
	Email string `json:"email"`
	DeptId int64 `json:"deptId"`
	PostId int64 `json:"postId"`
	Remark string `json:"remark"`
	Status string `json:"status"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	AllowPasswordLogin string `json:"allowPasswordLogin"`
}
```


3. response definition



```golang
type SysUserCreateResp struct {
	Id int64 `json:"id"`
}
```

### 20. N/A

1. route definition

- Url: /db/sys-user/findPage
- Method: GET
- Request: `SysUserListReq`
- Response: `SysUserFindPageResp`

2. request definition



```golang
type SysUserListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysUserFindPageResp struct {
	List []SysUser `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 21. N/A

1. route definition

- Url: /db/sys-user/list
- Method: GET
- Request: `SysUserListReq`
- Response: `SysUserListResp`

2. request definition



```golang
type SysUserListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysUserListResp struct {
	List []SysUser `json:"list"`
	Total int64 `json:"total"`
}
```

### 22. N/A

1. route definition

- Url: /db/sys-user/update
- Method: POST
- Request: `SysUserUpdateReq`
- Response: `SysUserEmptyResp`

2. request definition



```golang
type SysUserUpdateReq struct {
	UserId int64 `json:"userId"`
	Username *string `json:"username,optional"`
	Password *string `json:"password,optional"`
	NickName *string `json:"nickName,optional"`
	Phone *string `json:"phone,optional"`
	RoleId *int64 `json:"roleId,optional"`
	Salt *string `json:"salt,optional"`
	Avatar *string `json:"avatar,optional"`
	Sex *string `json:"sex,optional"`
	Email *string `json:"email,optional"`
	DeptId *int64 `json:"deptId,optional"`
	PostId *int64 `json:"postId,optional"`
	Remark *string `json:"remark,optional"`
	Status *string `json:"status,optional"`
	CreateBy *int64 `json:"createBy,optional"`
	UpdateBy *int64 `json:"updateBy,optional"`
	AllowPasswordLogin *string `json:"allowPasswordLogin,optional"`
}
```


3. response definition



```golang
type SysUserEmptyResp struct {
}
```

### 23. N/A

1. route definition

- Url: /db/sys-menu/:menuId
- Method: GET
- Request: `SysMenuIdReq`
- Response: `SysMenu`

2. request definition



```golang
type SysMenuIdReq struct {
	MenuId int64 `path:"menuId"`
}
```


3. response definition



```golang
type SysMenu struct {
	MenuId int64 `json:"menuId"`
	MenuName string `json:"menuName"`
	Title string `json:"title"`
	Icon string `json:"icon"`
	Path string `json:"path"`
	Paths string `json:"paths"`
	MenuType string `json:"menuType"`
	Action string `json:"action"`
	Permission string `json:"permission"`
	ParentId int64 `json:"parentId"`
	NoCache bool `json:"noCache"`
	Breadcrumb string `json:"breadcrumb"`
	Component string `json:"component"`
	Sort int64 `json:"sort"`
	Visible string `json:"visible"`
	IsFrame string `json:"isFrame"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 24. N/A

1. route definition

- Url: /db/sys-menu/:menuId
- Method: DELETE
- Request: `SysMenuIdReq`
- Response: `SysMenuEmptyResp`

2. request definition



```golang
type SysMenuIdReq struct {
	MenuId int64 `path:"menuId"`
}
```


3. response definition



```golang
type SysMenuEmptyResp struct {
}
```

### 25. N/A

1. route definition

- Url: /db/sys-menu/create
- Method: POST
- Request: `SysMenuCreateReq`
- Response: `SysMenuCreateResp`

2. request definition



```golang
type SysMenuCreateReq struct {
	MenuId int64 `json:"menuId"`
	MenuName string `json:"menuName"`
	Title string `json:"title"`
	Icon string `json:"icon"`
	Path string `json:"path"`
	Paths string `json:"paths"`
	MenuType string `json:"menuType"`
	Action string `json:"action"`
	Permission string `json:"permission"`
	ParentId int64 `json:"parentId"`
	NoCache bool `json:"noCache"`
	Breadcrumb string `json:"breadcrumb"`
	Component string `json:"component"`
	Sort int64 `json:"sort"`
	Visible string `json:"visible"`
	IsFrame string `json:"isFrame"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
}
```


3. response definition



```golang
type SysMenuCreateResp struct {
	Id int64 `json:"id"`
}
```

### 26. N/A

1. route definition

- Url: /db/sys-menu/findPage
- Method: GET
- Request: `SysMenuListReq`
- Response: `SysMenuFindPageResp`

2. request definition



```golang
type SysMenuListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysMenuFindPageResp struct {
	List []SysMenu `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 27. N/A

1. route definition

- Url: /db/sys-menu/list
- Method: GET
- Request: `SysMenuListReq`
- Response: `SysMenuListResp`

2. request definition



```golang
type SysMenuListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysMenuListResp struct {
	List []SysMenu `json:"list"`
	Total int64 `json:"total"`
}
```

### 28. N/A

1. route definition

- Url: /db/sys-menu/update
- Method: POST
- Request: `SysMenuUpdateReq`
- Response: `SysMenuEmptyResp`

2. request definition



```golang
type SysMenuUpdateReq struct {
	MenuId int64 `json:"menuId"`
	MenuName *string `json:"menuName,optional"`
	Title *string `json:"title,optional"`
	Icon *string `json:"icon,optional"`
	Path *string `json:"path,optional"`
	Paths *string `json:"paths,optional"`
	MenuType *string `json:"menuType,optional"`
	Action *string `json:"action,optional"`
	Permission *string `json:"permission,optional"`
	ParentId *int64 `json:"parentId,optional"`
	NoCache *bool `json:"noCache,optional"`
	Breadcrumb *string `json:"breadcrumb,optional"`
	Component *string `json:"component,optional"`
	Sort *int64 `json:"sort,optional"`
	Visible *string `json:"visible,optional"`
	IsFrame *string `json:"isFrame,optional"`
	CreateBy *int64 `json:"createBy,optional"`
	UpdateBy *int64 `json:"updateBy,optional"`
}
```


3. response definition



```golang
type SysMenuEmptyResp struct {
}
```

