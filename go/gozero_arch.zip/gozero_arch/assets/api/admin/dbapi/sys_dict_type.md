### 1. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/:dictId
- Method: GET
- Request: `SysDictTypeIdReq`
- Response: `SysDictType`

2. request definition



```golang
type SysDictTypeIdReq struct {
	DictId int64 `path:"dictId"`
}
```


3. response definition



```golang
type SysDictType struct {
	DictId int64 `json:"dictId"`
	DictName string `json:"dictName"`
	DictType string `json:"dictType"`
	Status int64 `json:"status"`
	Remark string `json:"remark"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 2. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/:dictId
- Method: DELETE
- Request: `SysDictTypeIdReq`
- Response: `SysDictTypeEmptyResp`

2. request definition



```golang
type SysDictTypeIdReq struct {
	DictId int64 `path:"dictId"`
}
```


3. response definition



```golang
type SysDictTypeEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/create
- Method: POST
- Request: `SysDictTypeCreateReq`
- Response: `SysDictTypeCreateResp`

2. request definition



```golang
type SysDictTypeCreateReq struct {
	DictName string `json:"dictName,optional"`
	DictType string `json:"dictType,optional"`
	Status int64 `json:"status,optional"`
	Remark string `json:"remark,optional"`
}
```


3. response definition



```golang
type SysDictTypeCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/findPage
- Method: GET
- Request: `SysDictTypeListReq`
- Response: `SysDictTypeFindPageResp`

2. request definition



```golang
type SysDictTypeListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDictTypeFindPageResp struct {
	List []SysDictType `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/list
- Method: GET
- Request: `SysDictTypeListReq`
- Response: `SysDictTypeListResp`

2. request definition



```golang
type SysDictTypeListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDictTypeListResp struct {
	List []SysDictType `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /api/v1/db/sys-dict-type/update
- Method: POST
- Request: `SysDictTypeUpdateReq`
- Response: `SysDictTypeEmptyResp`

2. request definition



```golang
type SysDictTypeUpdateReq struct {
	DictId int64 `json:"dictId"`
	DictName *string `json:"dictName,optional"`
	DictType *string `json:"dictType,optional"`
	Status *int64 `json:"status,optional"`
	Remark *string `json:"remark,optional"`
}
```


3. response definition



```golang
type SysDictTypeEmptyResp struct {
}
```

