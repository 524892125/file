### 1. N/A

1. route definition

- Url: /db/sys-role/:roleId
- Method: GET
- Request: `SysRoleIdReq`
- Response: `SysRole`

2. request definition



```golang
type SysRoleIdReq struct {
	RoleId int64 `path:"roleId"`
}
```


3. response definition



```golang
type SysRole struct {
	RoleId int64 `json:"roleId"`
	RoleName string `json:"roleName"`
	Status string `json:"status"`
	RoleKey string `json:"roleKey"`
	RoleSort int64 `json:"roleSort"`
	Flag string `json:"flag"`
	Remark string `json:"remark"`
	Admin bool `json:"admin"`
	DataScope string `json:"dataScope"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 2. N/A

1. route definition

- Url: /db/sys-role/:roleId
- Method: DELETE
- Request: `SysRoleIdReq`
- Response: `SysRoleEmptyResp`

2. request definition



```golang
type SysRoleIdReq struct {
	RoleId int64 `path:"roleId"`
}
```


3. response definition



```golang
type SysRoleEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /db/sys-role/create
- Method: POST
- Request: `SysRoleCreateReq`
- Response: `SysRoleCreateResp`

2. request definition



```golang
type SysRoleCreateReq struct {
	RoleId int64 `json:"roleId"`
	RoleName string `json:"roleName"`
	Status string `json:"status"`
	RoleKey string `json:"roleKey"`
	RoleSort int64 `json:"roleSort"`
	Flag string `json:"flag"`
	Remark string `json:"remark"`
	Admin bool `json:"admin"`
	DataScope string `json:"dataScope"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
}
```


3. response definition



```golang
type SysRoleCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /db/sys-role/findPage
- Method: GET
- Request: `SysRoleListReq`
- Response: `SysRoleFindPageResp`

2. request definition



```golang
type SysRoleListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysRoleFindPageResp struct {
	List []SysRole `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /db/sys-role/list
- Method: GET
- Request: `SysRoleListReq`
- Response: `SysRoleListResp`

2. request definition



```golang
type SysRoleListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysRoleListResp struct {
	List []SysRole `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /db/sys-role/update
- Method: POST
- Request: `SysRoleUpdateReq`
- Response: `SysRoleEmptyResp`

2. request definition



```golang
type SysRoleUpdateReq struct {
	RoleId int64 `json:"roleId"`
	RoleName *string `json:"roleName,optional"`
	Status *string `json:"status,optional"`
	RoleKey *string `json:"roleKey,optional"`
	RoleSort *int64 `json:"roleSort,optional"`
	Flag *string `json:"flag,optional"`
	Remark *string `json:"remark,optional"`
	Admin *bool `json:"admin,optional"`
	DataScope *string `json:"dataScope,optional"`
	CreateBy *int64 `json:"createBy,optional"`
	UpdateBy *int64 `json:"updateBy,optional"`
}
```


3. response definition



```golang
type SysRoleEmptyResp struct {
}
```

