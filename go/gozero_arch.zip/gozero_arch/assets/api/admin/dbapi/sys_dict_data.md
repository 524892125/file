### 1. N/A

1. route definition

- Url: /db/sys-dict-data/:dictCode
- Method: GET
- Request: `SysDictDataIdReq`
- Response: `SysDictData`

2. request definition



```golang
type SysDictDataIdReq struct {
	DictCode int64 `path:"dictCode"`
}
```


3. response definition



```golang
type SysDictData struct {
	DictCode int64 `json:"dictCode"`
	DictSort int64 `json:"dictSort"`
	DictLabel string `json:"dictLabel"`
	DictValue string `json:"dictValue"`
	DictType string `json:"dictType"`
	CssClass string `json:"cssClass"`
	ListClass string `json:"listClass"`
	IsDefault string `json:"isDefault"`
	Status int64 `json:"status"`
	Default string `json:"default"`
	Remark string `json:"remark"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 2. N/A

1. route definition

- Url: /db/sys-dict-data/:dictCode
- Method: DELETE
- Request: `SysDictDataIdReq`
- Response: `SysDictDataEmptyResp`

2. request definition



```golang
type SysDictDataIdReq struct {
	DictCode int64 `path:"dictCode"`
}
```


3. response definition



```golang
type SysDictDataEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /db/sys-dict-data/create
- Method: POST
- Request: `SysDictDataCreateReq`
- Response: `SysDictDataCreateResp`

2. request definition



```golang
type SysDictDataCreateReq struct {
	DictCode int64 `json:"dictCode"`
	DictSort int64 `json:"dictSort"`
	DictLabel string `json:"dictLabel"`
	DictValue string `json:"dictValue"`
	DictType string `json:"dictType"`
	CssClass string `json:"cssClass"`
	ListClass string `json:"listClass"`
	IsDefault string `json:"isDefault"`
	Status int64 `json:"status"`
	Default string `json:"default"`
	Remark string `json:"remark"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
}
```


3. response definition



```golang
type SysDictDataCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /db/sys-dict-data/findPage
- Method: GET
- Request: `SysDictDataListReq`
- Response: `SysDictDataFindPageResp`

2. request definition



```golang
type SysDictDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDictDataFindPageResp struct {
	List []SysDictData `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /db/sys-dict-data/list
- Method: GET
- Request: `SysDictDataListReq`
- Response: `SysDictDataListResp`

2. request definition



```golang
type SysDictDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDictDataListResp struct {
	List []SysDictData `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /db/sys-dict-data/update
- Method: POST
- Request: `SysDictDataUpdateReq`
- Response: `SysDictDataEmptyResp`

2. request definition



```golang
type SysDictDataUpdateReq struct {
	DictCode int64 `json:"dictCode"`
	DictSort *int64 `json:"dictSort,optional"`
	DictLabel *string `json:"dictLabel,optional"`
	DictValue *string `json:"dictValue,optional"`
	DictType *string `json:"dictType,optional"`
	CssClass *string `json:"cssClass,optional"`
	ListClass *string `json:"listClass,optional"`
	IsDefault *string `json:"isDefault,optional"`
	Status *int64 `json:"status,optional"`
	Default *string `json:"default,optional"`
	Remark *string `json:"remark,optional"`
	CreateBy *int64 `json:"createBy,optional"`
	UpdateBy *int64 `json:"updateBy,optional"`
}
```


3. response definition



```golang
type SysDictDataEmptyResp struct {
}
```

