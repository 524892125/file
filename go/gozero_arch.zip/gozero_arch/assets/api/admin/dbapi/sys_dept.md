### 1. N/A

1. route definition

- Url: /api/v1/db/sys-dept/:deptId
- Method: GET
- Request: `SysDeptIdReq`
- Response: `SysDept`

2. request definition



```golang
type SysDeptIdReq struct {
	DeptId int64 `path:"deptId"`
}
```


3. response definition



```golang
type SysDept struct {
	DeptId int64 `json:"deptId"`
	ParentId int64 `json:"parentId"`
	DeptPath string `json:"deptPath"`
	DeptName string `json:"deptName"`
	Sort int64 `json:"sort"`
	Leader string `json:"leader"`
	Phone string `json:"phone"`
	Email string `json:"email"`
	Status int64 `json:"status"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 2. N/A

1. route definition

- Url: /api/v1/db/sys-dept/:deptId
- Method: DELETE
- Request: `SysDeptIdReq`
- Response: `SysDeptEmptyResp`

2. request definition



```golang
type SysDeptIdReq struct {
	DeptId int64 `path:"deptId"`
}
```


3. response definition



```golang
type SysDeptEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /api/v1/db/sys-dept/create
- Method: POST
- Request: `SysDeptCreateReq`
- Response: `SysDeptCreateResp`

2. request definition



```golang
type SysDeptCreateReq struct {
	ParentId int64 `json:"parentId,optional"`
	DeptPath string `json:"deptPath,optional"`
	DeptName string `json:"deptName,optional"`
	Sort int64 `json:"sort,optional"`
	Leader string `json:"leader,optional"`
	Phone string `json:"phone,optional"`
	Email string `json:"email,optional"`
	Status int64 `json:"status,optional"`
}
```


3. response definition



```golang
type SysDeptCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /api/v1/db/sys-dept/findPage
- Method: GET
- Request: `SysDeptListReq`
- Response: `SysDeptFindPageResp`

2. request definition



```golang
type SysDeptListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDeptFindPageResp struct {
	List []SysDept `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /api/v1/db/sys-dept/list
- Method: GET
- Request: `SysDeptListReq`
- Response: `SysDeptListResp`

2. request definition



```golang
type SysDeptListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysDeptListResp struct {
	List []SysDept `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /api/v1/db/sys-dept/update
- Method: POST
- Request: `SysDeptUpdateReq`
- Response: `SysDeptEmptyResp`

2. request definition



```golang
type SysDeptUpdateReq struct {
	DeptId int64 `json:"deptId"`
	ParentId *int64 `json:"parentId,optional"`
	DeptPath *string `json:"deptPath,optional"`
	DeptName *string `json:"deptName,optional"`
	Sort *int64 `json:"sort,optional"`
	Leader *string `json:"leader,optional"`
	Phone *string `json:"phone,optional"`
	Email *string `json:"email,optional"`
	Status *int64 `json:"status,optional"`
}
```


3. response definition



```golang
type SysDeptEmptyResp struct {
}
```

