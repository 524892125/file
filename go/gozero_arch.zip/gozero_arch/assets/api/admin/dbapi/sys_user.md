### 1. N/A

1. route definition

- Url: /api/v1/db/sys-user/:userId
- Method: GET
- Request: `SysUserIdReq`
- Response: `SysUser`

2. request definition



```golang
type SysUserIdReq struct {
	UserId int64 `path:"userId"`
}
```


3. response definition



```golang
type SysUser struct {
	UserId int64 `json:"userId"`
	Username string `json:"username"`
	Password string `json:"password"`
	NickName string `json:"nickName"`
	Phone string `json:"phone"`
	RoleId int64 `json:"roleId"`
	Salt string `json:"salt"`
	Avatar string `json:"avatar"`
	Sex string `json:"sex"`
	Email string `json:"email"`
	DeptId int64 `json:"deptId"`
	PostId int64 `json:"postId"`
	Remark string `json:"remark"`
	Status string `json:"status"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
	AllowPasswordLogin string `json:"allowPasswordLogin"`
}
```

### 2. N/A

1. route definition

- Url: /api/v1/db/sys-user/:userId
- Method: DELETE
- Request: `SysUserIdReq`
- Response: `SysUserEmptyResp`

2. request definition



```golang
type SysUserIdReq struct {
	UserId int64 `path:"userId"`
}
```


3. response definition



```golang
type SysUserEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /api/v1/db/sys-user/create
- Method: POST
- Request: `SysUserCreateReq`
- Response: `SysUserCreateResp`

2. request definition



```golang
type SysUserCreateReq struct {
	Username string `json:"username,optional"`
	Password string `json:"password,optional"`
	NickName string `json:"nickName,optional"`
	Phone string `json:"phone,optional"`
	RoleId int64 `json:"roleId,optional"`
	Salt string `json:"salt,optional"`
	Avatar string `json:"avatar,optional"`
	Sex string `json:"sex,optional"`
	Email string `json:"email,optional"`
	DeptId int64 `json:"deptId,optional"`
	PostId int64 `json:"postId,optional"`
	Remark string `json:"remark,optional"`
	Status string `json:"status,optional"`
	AllowPasswordLogin string `json:"allowPasswordLogin,optional"`
}
```


3. response definition



```golang
type SysUserCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /api/v1/db/sys-user/findPage
- Method: GET
- Request: `SysUserListReq`
- Response: `SysUserFindPageResp`

2. request definition



```golang
type SysUserListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysUserFindPageResp struct {
	List []SysUser `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /api/v1/db/sys-user/list
- Method: GET
- Request: `SysUserListReq`
- Response: `SysUserListResp`

2. request definition



```golang
type SysUserListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysUserListResp struct {
	List []SysUser `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /api/v1/db/sys-user/update
- Method: POST
- Request: `SysUserUpdateReq`
- Response: `SysUserEmptyResp`

2. request definition



```golang
type SysUserUpdateReq struct {
	UserId int64 `json:"userId"`
	Username *string `json:"username,optional"`
	Password *string `json:"password,optional"`
	NickName *string `json:"nickName,optional"`
	Phone *string `json:"phone,optional"`
	RoleId *int64 `json:"roleId,optional"`
	Salt *string `json:"salt,optional"`
	Avatar *string `json:"avatar,optional"`
	Sex *string `json:"sex,optional"`
	Email *string `json:"email,optional"`
	DeptId *int64 `json:"deptId,optional"`
	PostId *int64 `json:"postId,optional"`
	Remark *string `json:"remark,optional"`
	Status *string `json:"status,optional"`
	AllowPasswordLogin *string `json:"allowPasswordLogin,optional"`
}
```


3. response definition



```golang
type SysUserEmptyResp struct {
}
```

