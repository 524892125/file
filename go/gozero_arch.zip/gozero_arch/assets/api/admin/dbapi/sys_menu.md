### 1. N/A

1. route definition

- Url: /api/v1/db/sys-menu/:menuId
- Method: GET
- Request: `SysMenuIdReq`
- Response: `SysMenu`

2. request definition



```golang
type SysMenuIdReq struct {
	MenuId int64 `path:"menuId"`
}
```


3. response definition



```golang
type SysMenu struct {
	MenuId int64 `json:"menuId"`
	MenuName string `json:"menuName"`
	Title string `json:"title"`
	Icon string `json:"icon"`
	Path string `json:"path"`
	Paths string `json:"paths"`
	MenuType string `json:"menuType"`
	Action string `json:"action"`
	Permission string `json:"permission"`
	ParentId int64 `json:"parentId"`
	NoCache bool `json:"noCache"`
	Breadcrumb string `json:"breadcrumb"`
	Component string `json:"component"`
	Sort int64 `json:"sort"`
	Visible string `json:"visible"`
	IsFrame string `json:"isFrame"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 2. N/A

1. route definition

- Url: /api/v1/db/sys-menu/:menuId
- Method: DELETE
- Request: `SysMenuIdReq`
- Response: `SysMenuEmptyResp`

2. request definition



```golang
type SysMenuIdReq struct {
	MenuId int64 `path:"menuId"`
}
```


3. response definition



```golang
type SysMenuEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /api/v1/db/sys-menu/create
- Method: POST
- Request: `SysMenuCreateReq`
- Response: `SysMenuCreateResp`

2. request definition



```golang
type SysMenuCreateReq struct {
	MenuName string `json:"menuName"`
	Title string `json:"title,optional"`
	Icon string `json:"icon,optional"`
	Path string `json:"path"`
	Paths string `json:"paths,optional"`
	MenuType string `json:"menuType"`
	Action string `json:"action,optional"`
	Permission string `json:"permission,optional"`
	ParentId int64 `json:"parentId,optional"`
	NoCache bool `json:"noCache,optional"`
	Breadcrumb string `json:"breadcrumb,optional"`
	Component string `json:"component,optional"`
	Sort int64 `json:"sort,optional"`
	Visible string `json:"visible,optional"`
	IsFrame string `json:"isFrame,optional"`
}
```


3. response definition



```golang
type SysMenuCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /api/v1/db/sys-menu/findPage
- Method: GET
- Request: `SysMenuListReq`
- Response: `SysMenuFindPageResp`

2. request definition



```golang
type SysMenuListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysMenuFindPageResp struct {
	List []SysMenu `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /api/v1/db/sys-menu/list
- Method: GET
- Request: `SysMenuListReq`
- Response: `SysMenuListResp`

2. request definition



```golang
type SysMenuListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysMenuListResp struct {
	List []SysMenu `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /api/v1/db/sys-menu/update
- Method: POST
- Request: `SysMenuUpdateReq`
- Response: `SysMenuEmptyResp`

2. request definition



```golang
type SysMenuUpdateReq struct {
	MenuId int64 `json:"menuId"`
	MenuName *string `json:"menuName,optional"`
	Title *string `json:"title,optional"`
	Icon *string `json:"icon,optional"`
	Path *string `json:"path,optional"`
	Paths *string `json:"paths,optional"`
	MenuType *string `json:"menuType,optional"`
	Action *string `json:"action,optional"`
	Permission *string `json:"permission,optional"`
	ParentId *int64 `json:"parentId,optional"`
	NoCache *bool `json:"noCache,optional"`
	Breadcrumb *string `json:"breadcrumb,optional"`
	Component *string `json:"component,optional"`
	Sort *int64 `json:"sort,optional"`
	Visible *string `json:"visible,optional"`
	IsFrame *string `json:"isFrame,optional"`
}
```


3. response definition



```golang
type SysMenuEmptyResp struct {
}
```

