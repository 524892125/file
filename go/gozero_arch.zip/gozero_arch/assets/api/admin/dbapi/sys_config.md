### 1. N/A

1. route definition

- Url: /api/v1/db/sys-config/:id
- Method: GET
- Request: `SysConfigIdReq`
- Response: `SysConfig`

2. request definition



```golang
type SysConfigIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type SysConfig struct {
	Id int64 `json:"id"`
	ConfigName string `json:"configName"`
	ConfigKey string `json:"configKey"`
	ConfigValue string `json:"configValue"`
	ConfigType string `json:"configType"`
	IsFrontend string `json:"isFrontend"`
	Remark string `json:"remark"`
	CreateBy int64 `json:"createBy"`
	UpdateBy int64 `json:"updateBy"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
	DeletedAt string `json:"deletedAt"`
}
```

### 2. N/A

1. route definition

- Url: /api/v1/db/sys-config/:id
- Method: DELETE
- Request: `SysConfigIdReq`
- Response: `SysConfigEmptyResp`

2. request definition



```golang
type SysConfigIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type SysConfigEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /api/v1/db/sys-config/create
- Method: POST
- Request: `SysConfigCreateReq`
- Response: `SysConfigCreateResp`

2. request definition



```golang
type SysConfigCreateReq struct {
	ConfigName string `json:"configName,optional"`
	ConfigKey string `json:"configKey,optional"`
	ConfigValue string `json:"configValue,optional"`
	ConfigType string `json:"configType,optional"`
	IsFrontend string `json:"isFrontend,optional"`
	Remark string `json:"remark,optional"`
}
```


3. response definition



```golang
type SysConfigCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /api/v1/db/sys-config/findPage
- Method: GET
- Request: `SysConfigListReq`
- Response: `SysConfigFindPageResp`

2. request definition



```golang
type SysConfigListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysConfigFindPageResp struct {
	List []SysConfig `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /api/v1/db/sys-config/list
- Method: GET
- Request: `SysConfigListReq`
- Response: `SysConfigListResp`

2. request definition



```golang
type SysConfigListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysConfigListResp struct {
	List []SysConfig `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /api/v1/db/sys-config/update
- Method: POST
- Request: `SysConfigUpdateReq`
- Response: `SysConfigEmptyResp`

2. request definition



```golang
type SysConfigUpdateReq struct {
	Id int64 `json:"id"`
	ConfigName *string `json:"configName,optional"`
	ConfigKey *string `json:"configKey,optional"`
	ConfigValue *string `json:"configValue,optional"`
	ConfigType *string `json:"configType,optional"`
	IsFrontend *string `json:"isFrontend,optional"`
	Remark *string `json:"remark,optional"`
}
```


3. response definition



```golang
type SysConfigEmptyResp struct {
}
```

