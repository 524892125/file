### 1. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/:id
- Method: GET
- Request: `AppRuntimeLogIdReq`
- Response: `AppRuntimeLog`

2. request definition



```golang
type AppRuntimeLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type AppRuntimeLog struct {
	Id int64 `json:"id"`
	MessageId string `json:"messageId"`
	TraceId string `json:"traceId"`
	TenantCode string `json:"tenantCode"`
	ServiceName string `json:"serviceName"`
	Level string `json:"level"`
	Caller string `json:"caller"`
	Content string `json:"content"`
	FieldsJson string `json:"fieldsJson"`
	Source string `json:"source"`
	LoggedAt string `json:"loggedAt"`
	CreatedAt string `json:"createdAt"`
}
```

### 2. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/:id
- Method: DELETE
- Request: `AppRuntimeLogIdReq`
- Response: `AppRuntimeLogEmptyResp`

2. request definition



```golang
type AppRuntimeLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type AppRuntimeLogEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/create
- Method: POST
- Request: `AppRuntimeLogCreateReq`
- Response: `AppRuntimeLogCreateResp`

2. request definition



```golang
type AppRuntimeLogCreateReq struct {
	MessageId string `json:"messageId"`
	TraceId string `json:"traceId,optional"`
	TenantCode string `json:"tenantCode,optional"`
	ServiceName string `json:"serviceName"`
	Level string `json:"level"`
	Caller string `json:"caller,optional"`
	Content string `json:"content,optional"`
	FieldsJson string `json:"fieldsJson,optional"`
	Source string `json:"source,optional"`
	LoggedAt string `json:"loggedAt"`
}
```


3. response definition



```golang
type AppRuntimeLogCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/findPage
- Method: GET
- Request: `AppRuntimeLogListReq`
- Response: `AppRuntimeLogFindPageResp`

2. request definition



```golang
type AppRuntimeLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogFindPageResp struct {
	List []AppRuntimeLog `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/list
- Method: GET
- Request: `AppRuntimeLogListReq`
- Response: `AppRuntimeLogListResp`

2. request definition



```golang
type AppRuntimeLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogListResp struct {
	List []AppRuntimeLog `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /api/v1/db/app-runtime-log/update
- Method: POST
- Request: `AppRuntimeLogUpdateReq`
- Response: `AppRuntimeLogEmptyResp`

2. request definition



```golang
type AppRuntimeLogUpdateReq struct {
	Id int64 `json:"id"`
	MessageId *string `json:"messageId,optional"`
	TraceId *string `json:"traceId,optional"`
	TenantCode *string `json:"tenantCode,optional"`
	ServiceName *string `json:"serviceName,optional"`
	Level *string `json:"level,optional"`
	Caller *string `json:"caller,optional"`
	Content *string `json:"content,optional"`
	FieldsJson *string `json:"fieldsJson,optional"`
	Source *string `json:"source,optional"`
	LoggedAt *string `json:"loggedAt,optional"`
}
```


3. response definition



```golang
type AppRuntimeLogEmptyResp struct {
}
```

