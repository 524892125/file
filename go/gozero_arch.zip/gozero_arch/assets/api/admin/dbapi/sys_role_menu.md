### 1. N/A

1. route definition

- Url: /api/v1/db/sys-role-menu/:id
- Method: GET
- Request: `SysRoleMenuIdReq`
- Response: `SysRoleMenu`

2. request definition



```golang
type SysRoleMenuIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type SysRoleMenu struct {
	Id int64 `json:"id"`
	RoleId int64 `json:"roleId"`
	MenuId int64 `json:"menuId"`
}
```

### 2. N/A

1. route definition

- Url: /api/v1/db/sys-role-menu/:id
- Method: DELETE
- Request: `SysRoleMenuIdReq`
- Response: `SysRoleMenuEmptyResp`

2. request definition



```golang
type SysRoleMenuIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type SysRoleMenuEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /api/v1/db/sys-role-menu/create
- Method: POST
- Request: `SysRoleMenuCreateReq`
- Response: `SysRoleMenuCreateResp`

2. request definition



```golang
type SysRoleMenuCreateReq struct {
	RoleId int64 `json:"roleId"`
	MenuId int64 `json:"menuId"`
}
```


3. response definition



```golang
type SysRoleMenuCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /api/v1/db/sys-role-menu/findPage
- Method: GET
- Request: `SysRoleMenuListReq`
- Response: `SysRoleMenuFindPageResp`

2. request definition



```golang
type SysRoleMenuListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysRoleMenuFindPageResp struct {
	List []SysRoleMenu `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /api/v1/db/sys-role-menu/list
- Method: GET
- Request: `SysRoleMenuListReq`
- Response: `SysRoleMenuListResp`

2. request definition



```golang
type SysRoleMenuListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type SysRoleMenuListResp struct {
	List []SysRoleMenu `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /api/v1/db/sys-role-menu/update
- Method: POST
- Request: `SysRoleMenuUpdateReq`
- Response: `SysRoleMenuEmptyResp`

2. request definition



```golang
type SysRoleMenuUpdateReq struct {
	Id int64 `json:"id"`
	RoleId *int64 `json:"roleId,optional"`
	MenuId *int64 `json:"menuId,optional"`
}
```


3. response definition



```golang
type SysRoleMenuEmptyResp struct {
}
```

