### 1. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/:id
- Method: GET
- Request: `RpcSummaryDataIdReq`
- Response: `RpcSummaryData`

2. request definition



```golang
type RpcSummaryDataIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcSummaryData struct {
	Id int64 `json:"id"`
	Appid string `json:"appid"`
	RefDate string `json:"refDate"`
	Dau int64 `json:"dau"`
	NewUsers int64 `json:"newUsers"`
	NewUserRatio float64 `json:"newUserRatio"`
	AvgAcquisitionCost float64 `json:"avgAcquisitionCost"`
	AvgActiveCost float64 `json:"avgActiveCost"`
	AvgTotalCost float64 `json:"avgTotalCost"`
	LtValue float64 `json:"ltValue"`
	TotalUsersSum int64 `json:"totalUsersSum"`
	TotalRevenue float64 `json:"totalRevenue"`
	TotalExpenditure float64 `json:"totalExpenditure"`
	GrossProfit float64 `json:"grossProfit"`
	CoopProfitShare float64 `json:"coopProfitShare"`
	ProfitMargin float64 `json:"profitMargin"`
	RevTrafficOwner float64 `json:"revTrafficOwner"`
	RevInternalPurchase float64 `json:"revInternalPurchase"`
	RevCommission float64 `json:"revCommission"`
	RevTrafficRental float64 `json:"revTrafficRental"`
	RevAdSettlement float64 `json:"revAdSettlement"`
	RevTotalCalc float64 `json:"revTotalCalc"`
	ExpDailyBase float64 `json:"expDailyBase"`
	ExpInternalBuy float64 `json:"expInternalBuy"`
	ExpExternalBuy float64 `json:"expExternalBuy"`
	ExpTotalOps float64 `json:"expTotalOps"`
	Remark string `json:"remark"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
}
```

### 2. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/:id
- Method: DELETE
- Request: `RpcSummaryDataIdReq`
- Response: `RpcSummaryDataEmptyResp`

2. request definition



```golang
type RpcSummaryDataIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcSummaryDataEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/create
- Method: POST
- Request: `RpcSummaryDataCreateReq`
- Response: `RpcSummaryDataCreateResp`

2. request definition



```golang
type RpcSummaryDataCreateReq struct {
	Appid string `json:"appid"`
	RefDate string `json:"refDate"`
	Dau int64 `json:"dau,optional"`
	NewUsers int64 `json:"newUsers,optional"`
	NewUserRatio float64 `json:"newUserRatio,optional"`
	AvgAcquisitionCost float64 `json:"avgAcquisitionCost,optional"`
	AvgActiveCost float64 `json:"avgActiveCost,optional"`
	AvgTotalCost float64 `json:"avgTotalCost,optional"`
	LtValue float64 `json:"ltValue,optional"`
	TotalUsersSum int64 `json:"totalUsersSum,optional"`
	TotalRevenue float64 `json:"totalRevenue,optional"`
	TotalExpenditure float64 `json:"totalExpenditure,optional"`
	GrossProfit float64 `json:"grossProfit,optional"`
	CoopProfitShare float64 `json:"coopProfitShare,optional"`
	ProfitMargin float64 `json:"profitMargin,optional"`
	RevTrafficOwner float64 `json:"revTrafficOwner,optional"`
	RevInternalPurchase float64 `json:"revInternalPurchase,optional"`
	RevCommission float64 `json:"revCommission,optional"`
	RevTrafficRental float64 `json:"revTrafficRental,optional"`
	RevAdSettlement float64 `json:"revAdSettlement,optional"`
	RevTotalCalc float64 `json:"revTotalCalc,optional"`
	ExpDailyBase float64 `json:"expDailyBase,optional"`
	ExpInternalBuy float64 `json:"expInternalBuy,optional"`
	ExpExternalBuy float64 `json:"expExternalBuy,optional"`
	ExpTotalOps float64 `json:"expTotalOps,optional"`
	Remark string `json:"remark,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/findPage
- Method: GET
- Request: `RpcSummaryDataListReq`
- Response: `RpcSummaryDataFindPageResp`

2. request definition



```golang
type RpcSummaryDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataFindPageResp struct {
	List []RpcSummaryData `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/list
- Method: GET
- Request: `RpcSummaryDataListReq`
- Response: `RpcSummaryDataListResp`

2. request definition



```golang
type RpcSummaryDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataListResp struct {
	List []RpcSummaryData `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/update
- Method: POST
- Request: `RpcSummaryDataUpdateReq`
- Response: `RpcSummaryDataEmptyResp`

2. request definition



```golang
type RpcSummaryDataUpdateReq struct {
	Id int64 `json:"id"`
	Appid *string `json:"appid,optional"`
	RefDate *string `json:"refDate,optional"`
	Dau *int64 `json:"dau,optional"`
	NewUsers *int64 `json:"newUsers,optional"`
	NewUserRatio *float64 `json:"newUserRatio,optional"`
	AvgAcquisitionCost *float64 `json:"avgAcquisitionCost,optional"`
	AvgActiveCost *float64 `json:"avgActiveCost,optional"`
	AvgTotalCost *float64 `json:"avgTotalCost,optional"`
	LtValue *float64 `json:"ltValue,optional"`
	TotalUsersSum *int64 `json:"totalUsersSum,optional"`
	TotalRevenue *float64 `json:"totalRevenue,optional"`
	TotalExpenditure *float64 `json:"totalExpenditure,optional"`
	GrossProfit *float64 `json:"grossProfit,optional"`
	CoopProfitShare *float64 `json:"coopProfitShare,optional"`
	ProfitMargin *float64 `json:"profitMargin,optional"`
	RevTrafficOwner *float64 `json:"revTrafficOwner,optional"`
	RevInternalPurchase *float64 `json:"revInternalPurchase,optional"`
	RevCommission *float64 `json:"revCommission,optional"`
	RevTrafficRental *float64 `json:"revTrafficRental,optional"`
	RevAdSettlement *float64 `json:"revAdSettlement,optional"`
	RevTotalCalc *float64 `json:"revTotalCalc,optional"`
	ExpDailyBase *float64 `json:"expDailyBase,optional"`
	ExpInternalBuy *float64 `json:"expInternalBuy,optional"`
	ExpExternalBuy *float64 `json:"expExternalBuy,optional"`
	ExpTotalOps *float64 `json:"expTotalOps,optional"`
	Remark *string `json:"remark,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataEmptyResp struct {
}
```

