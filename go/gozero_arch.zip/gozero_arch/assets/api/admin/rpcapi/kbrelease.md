### 1. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-adv-list
- Method: GET
- Request: `RpcOceanengineAdvertiserListReq`
- Response: `RpcOceanengineAdvertiserListResp`

2. request definition



```golang
type RpcOceanengineAdvertiserListReq struct {
	AdvertiserId int64 `form:"advertiserId"`
}
```


3. response definition



```golang
type RpcOceanengineAdvertiserListResp struct {
	List []RpcOceanengineAdvertiser `json:"list"`
}
```

### 2. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-base/:id
- Method: GET
- Request: `RpcOceanengineDailyBaseIdReq`
- Response: `RpcOceanengineDailyBase`

2. request definition



```golang
type RpcOceanengineDailyBaseIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcOceanengineDailyBase struct {
	Id int64 `json:"id"`
	AdvertiserId int64 `json:"advertiserId"`
	RefDate string `json:"refDate"`
	Type string `json:"type"`
	CdpProjectId int64 `json:"cdpProjectId"`
	CdpProjectName string `json:"cdpProjectName"`
	CdpPromotionName string `json:"cdpPromotionName"`
	AppCode string `json:"appCode"`
	Gender string `json:"gender"`
	Age string `json:"age"`
	Platform string `json:"platform"`
	CityName string `json:"cityName"`
	ImageMode string `json:"imageMode"`
	StatCost float64 `json:"statCost"`
	ShowCnt int64 `json:"showCnt"`
	CpmPlatform float64 `json:"cpmPlatform"`
	ClickCnt int64 `json:"clickCnt"`
	Ctr float64 `json:"ctr"`
	Active int64 `json:"active"`
	ActiveCost float64 `json:"activeCost"`
	ActiveRegister int64 `json:"activeRegister"`
	ActivePay int64 `json:"activePay"`
	ActivePayCost float64 `json:"activePayCost"`
	ActivePayRate float64 `json:"activePayRate"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
}
```

### 3. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-base/:id
- Method: DELETE
- Request: `RpcOceanengineDailyBaseIdReq`
- Response: `RpcOceanengineDailyBaseEmptyResp`

2. request definition



```golang
type RpcOceanengineDailyBaseIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcOceanengineDailyBaseEmptyResp struct {
}
```

### 4. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-base/create
- Method: POST
- Request: `RpcOceanengineDailyBaseCreateReq`
- Response: `RpcOceanengineDailyBaseCreateResp`

2. request definition



```golang
type RpcOceanengineDailyBaseCreateReq struct {
	AdvertiserId int64 `json:"advertiserId"`
	RefDate string `json:"refDate"`
	Type string `json:"type,optional"`
	CdpProjectId int64 `json:"cdpProjectId,optional"`
	CdpProjectName string `json:"cdpProjectName,optional"`
	CdpPromotionName string `json:"cdpPromotionName,optional"`
	AppCode string `json:"appCode,optional"`
	Gender string `json:"gender,optional"`
	Age string `json:"age,optional"`
	Platform string `json:"platform,optional"`
	CityName string `json:"cityName,optional"`
	ImageMode string `json:"imageMode,optional"`
	StatCost float64 `json:"statCost,optional"`
	ShowCnt int64 `json:"showCnt,optional"`
	CpmPlatform float64 `json:"cpmPlatform,optional"`
	ClickCnt int64 `json:"clickCnt,optional"`
	Ctr float64 `json:"ctr,optional"`
	Active int64 `json:"active,optional"`
	ActiveCost float64 `json:"activeCost,optional"`
	ActiveRegister int64 `json:"activeRegister,optional"`
	ActivePay int64 `json:"activePay,optional"`
	ActivePayCost float64 `json:"activePayCost,optional"`
	ActivePayRate float64 `json:"activePayRate,optional"`
}
```


3. response definition



```golang
type RpcOceanengineDailyBaseCreateResp struct {
	Id int64 `json:"id"`
}
```

### 5. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-base/findPage
- Method: GET
- Request: `RpcOceanengineDailyBaseListReq`
- Response: `RpcOceanengineDailyBaseFindPageResp`

2. request definition



```golang
type RpcOceanengineDailyBaseListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcOceanengineDailyBaseFindPageResp struct {
	List []RpcOceanengineDailyBase `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 6. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-base/list
- Method: GET
- Request: `RpcOceanengineDailyBaseListReq`
- Response: `RpcOceanengineDailyBaseListResp`

2. request definition



```golang
type RpcOceanengineDailyBaseListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcOceanengineDailyBaseListResp struct {
	List []RpcOceanengineDailyBase `json:"list"`
	Total int64 `json:"total"`
}
```

### 7. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-base/update
- Method: POST
- Request: `RpcOceanengineDailyBaseUpdateReq`
- Response: `RpcOceanengineDailyBaseEmptyResp`

2. request definition



```golang
type RpcOceanengineDailyBaseUpdateReq struct {
	Id int64 `json:"id"`
	AdvertiserId *int64 `json:"advertiserId,optional"`
	RefDate *string `json:"refDate,optional"`
	Type *string `json:"type,optional"`
	CdpProjectId *int64 `json:"cdpProjectId,optional"`
	CdpProjectName *string `json:"cdpProjectName,optional"`
	CdpPromotionName *string `json:"cdpPromotionName,optional"`
	AppCode *string `json:"appCode,optional"`
	Gender *string `json:"gender,optional"`
	Age *string `json:"age,optional"`
	Platform *string `json:"platform,optional"`
	CityName *string `json:"cityName,optional"`
	ImageMode *string `json:"imageMode,optional"`
	StatCost *float64 `json:"statCost,optional"`
	ShowCnt *int64 `json:"showCnt,optional"`
	CpmPlatform *float64 `json:"cpmPlatform,optional"`
	ClickCnt *int64 `json:"clickCnt,optional"`
	Ctr *float64 `json:"ctr,optional"`
	Active *int64 `json:"active,optional"`
	ActiveCost *float64 `json:"activeCost,optional"`
	ActiveRegister *int64 `json:"activeRegister,optional"`
	ActivePay *int64 `json:"activePay,optional"`
	ActivePayCost *float64 `json:"activePayCost,optional"`
	ActivePayRate *float64 `json:"activePayRate,optional"`
}
```


3. response definition



```golang
type RpcOceanengineDailyBaseEmptyResp struct {
}
```

### 8. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-summary/:id
- Method: GET
- Request: `RpcOceanengineDailySummaryIdReq`
- Response: `RpcOceanengineDailySummary`

2. request definition



```golang
type RpcOceanengineDailySummaryIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcOceanengineDailySummary struct {
	Id int64 `json:"id"`
	AdvertiserId int64 `json:"advertiserId"`
	RefDate string `json:"refDate"`
	StatCost float64 `json:"statCost"`
	ShowCnt int64 `json:"showCnt"`
	CpmPlatform float64 `json:"cpmPlatform"`
	ClickCnt int64 `json:"clickCnt"`
	Ctr float64 `json:"ctr"`
	Active int64 `json:"active"`
	ActiveCost float64 `json:"activeCost"`
	ActiveRegister int64 `json:"activeRegister"`
	ActivePay int64 `json:"activePay"`
	ActivePayCost float64 `json:"activePayCost"`
	ActivePayRate float64 `json:"activePayRate"`
	AttributionConvertCost float64 `json:"attributionConvertCost"`
	AttributionConversionRate float64 `json:"attributionConversionRate"`
	AttributionBillingGameInAppRoi1day float64 `json:"attributionBillingGameInAppRoi1day"`
	AttributionBillingGameInAppRoi2days float64 `json:"attributionBillingGameInAppRoi2days"`
	AttributionBillingGameInAppRoi3days float64 `json:"attributionBillingGameInAppRoi3days"`
	AttributionBillingGameInAppRoi4days float64 `json:"attributionBillingGameInAppRoi4days"`
	AttributionBillingGameInAppRoi5days float64 `json:"attributionBillingGameInAppRoi5days"`
	AttributionBillingGameInAppRoi6days float64 `json:"attributionBillingGameInAppRoi6days"`
	AttributionBillingGameInAppRoi7days float64 `json:"attributionBillingGameInAppRoi7days"`
	AttributionNextDayOpenCnt int64 `json:"attributionNextDayOpenCnt"`
	AttributionNextDayOpenRate float64 `json:"attributionNextDayOpenRate"`
	AttributionRetention2dCnt int64 `json:"attributionRetention2dCnt"`
	AttributionRetention2dRate float64 `json:"attributionRetention2dRate"`
	AttributionRetention3dCnt int64 `json:"attributionRetention3dCnt"`
	AttributionRetention3dRate float64 `json:"attributionRetention3dRate"`
	AttributionRetention4dCnt int64 `json:"attributionRetention4dCnt"`
	AttributionRetention4dRate float64 `json:"attributionRetention4dRate"`
	AttributionRetention5dCnt int64 `json:"attributionRetention5dCnt"`
	AttributionRetention5dRate float64 `json:"attributionRetention5dRate"`
	AttributionRetention6dCnt int64 `json:"attributionRetention6dCnt"`
	AttributionRetention6dRate float64 `json:"attributionRetention6dRate"`
	AttributionRetention7dCnt int64 `json:"attributionRetention7dCnt"`
	AttributionRetention7dRate float64 `json:"attributionRetention7dRate"`
	AttributionGamePay7dCost float64 `json:"attributionGamePay7dCost"`
	AttributionMicroGame0dLtv float64 `json:"attributionMicroGame0dLtv"`
	AttributionMicroGame3dLtv float64 `json:"attributionMicroGame3dLtv"`
	AttributionMicroGame7dLtv float64 `json:"attributionMicroGame7dLtv"`
	AttributionMicroGame0dRoi float64 `json:"attributionMicroGame0dRoi"`
	AttributionMicroGame3dRoi float64 `json:"attributionMicroGame3dRoi"`
	AttributionMicroGame7dRoi float64 `json:"attributionMicroGame7dRoi"`
	AttributionMicroGameIaapLtv7dRoi float64 `json:"attributionMicroGameIaapLtv7dRoi"`
	AttributionMicroGameIaapIapRoi8days float64 `json:"attributionMicroGameIaapIapRoi8days"`
	AttributionMicroGameIaapIaa7dRoi float64 `json:"attributionMicroGameIaapIaa7dRoi"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
}
```

### 9. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-summary/:id
- Method: DELETE
- Request: `RpcOceanengineDailySummaryIdReq`
- Response: `RpcOceanengineDailySummaryEmptyResp`

2. request definition



```golang
type RpcOceanengineDailySummaryIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcOceanengineDailySummaryEmptyResp struct {
}
```

### 10. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-summary/create
- Method: POST
- Request: `RpcOceanengineDailySummaryCreateReq`
- Response: `RpcOceanengineDailySummaryCreateResp`

2. request definition



```golang
type RpcOceanengineDailySummaryCreateReq struct {
	AdvertiserId int64 `json:"advertiserId"`
	RefDate string `json:"refDate"`
	StatCost float64 `json:"statCost,optional"`
	ShowCnt int64 `json:"showCnt,optional"`
	CpmPlatform float64 `json:"cpmPlatform,optional"`
	ClickCnt int64 `json:"clickCnt,optional"`
	Ctr float64 `json:"ctr,optional"`
	Active int64 `json:"active,optional"`
	ActiveCost float64 `json:"activeCost,optional"`
	ActiveRegister int64 `json:"activeRegister,optional"`
	ActivePay int64 `json:"activePay,optional"`
	ActivePayCost float64 `json:"activePayCost,optional"`
	ActivePayRate float64 `json:"activePayRate,optional"`
	AttributionConvertCost float64 `json:"attributionConvertCost,optional"`
	AttributionConversionRate float64 `json:"attributionConversionRate,optional"`
	AttributionBillingGameInAppRoi1day float64 `json:"attributionBillingGameInAppRoi1day,optional"`
	AttributionBillingGameInAppRoi2days float64 `json:"attributionBillingGameInAppRoi2days,optional"`
	AttributionBillingGameInAppRoi3days float64 `json:"attributionBillingGameInAppRoi3days,optional"`
	AttributionBillingGameInAppRoi4days float64 `json:"attributionBillingGameInAppRoi4days,optional"`
	AttributionBillingGameInAppRoi5days float64 `json:"attributionBillingGameInAppRoi5days,optional"`
	AttributionBillingGameInAppRoi6days float64 `json:"attributionBillingGameInAppRoi6days,optional"`
	AttributionBillingGameInAppRoi7days float64 `json:"attributionBillingGameInAppRoi7days,optional"`
	AttributionNextDayOpenCnt int64 `json:"attributionNextDayOpenCnt,optional"`
	AttributionNextDayOpenRate float64 `json:"attributionNextDayOpenRate,optional"`
	AttributionRetention2dCnt int64 `json:"attributionRetention2dCnt,optional"`
	AttributionRetention2dRate float64 `json:"attributionRetention2dRate,optional"`
	AttributionRetention3dCnt int64 `json:"attributionRetention3dCnt,optional"`
	AttributionRetention3dRate float64 `json:"attributionRetention3dRate,optional"`
	AttributionRetention4dCnt int64 `json:"attributionRetention4dCnt,optional"`
	AttributionRetention4dRate float64 `json:"attributionRetention4dRate,optional"`
	AttributionRetention5dCnt int64 `json:"attributionRetention5dCnt,optional"`
	AttributionRetention5dRate float64 `json:"attributionRetention5dRate,optional"`
	AttributionRetention6dCnt int64 `json:"attributionRetention6dCnt,optional"`
	AttributionRetention6dRate float64 `json:"attributionRetention6dRate,optional"`
	AttributionRetention7dCnt int64 `json:"attributionRetention7dCnt,optional"`
	AttributionRetention7dRate float64 `json:"attributionRetention7dRate,optional"`
	AttributionGamePay7dCost float64 `json:"attributionGamePay7dCost,optional"`
	AttributionMicroGame0dLtv float64 `json:"attributionMicroGame0dLtv,optional"`
	AttributionMicroGame3dLtv float64 `json:"attributionMicroGame3dLtv,optional"`
	AttributionMicroGame7dLtv float64 `json:"attributionMicroGame7dLtv,optional"`
	AttributionMicroGame0dRoi float64 `json:"attributionMicroGame0dRoi,optional"`
	AttributionMicroGame3dRoi float64 `json:"attributionMicroGame3dRoi,optional"`
	AttributionMicroGame7dRoi float64 `json:"attributionMicroGame7dRoi,optional"`
	AttributionMicroGameIaapLtv7dRoi float64 `json:"attributionMicroGameIaapLtv7dRoi,optional"`
	AttributionMicroGameIaapIapRoi8days float64 `json:"attributionMicroGameIaapIapRoi8days,optional"`
	AttributionMicroGameIaapIaa7dRoi float64 `json:"attributionMicroGameIaapIaa7dRoi,optional"`
}
```


3. response definition



```golang
type RpcOceanengineDailySummaryCreateResp struct {
	Id int64 `json:"id"`
}
```

### 11. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-summary/findPage
- Method: GET
- Request: `RpcOceanengineDailySummaryListReq`
- Response: `RpcOceanengineDailySummaryFindPageResp`

2. request definition



```golang
type RpcOceanengineDailySummaryListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcOceanengineDailySummaryFindPageResp struct {
	List []RpcOceanengineDailySummary `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 12. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-summary/list
- Method: GET
- Request: `RpcOceanengineDailySummaryListReq`
- Response: `RpcOceanengineDailySummaryListResp`

2. request definition



```golang
type RpcOceanengineDailySummaryListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcOceanengineDailySummaryListResp struct {
	List []RpcOceanengineDailySummary `json:"list"`
	Total int64 `json:"total"`
}
```

### 13. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/oceanengine-daily-summary/update
- Method: POST
- Request: `RpcOceanengineDailySummaryUpdateReq`
- Response: `RpcOceanengineDailySummaryEmptyResp`

2. request definition



```golang
type RpcOceanengineDailySummaryUpdateReq struct {
	Id int64 `json:"id"`
	AdvertiserId *int64 `json:"advertiserId,optional"`
	RefDate *string `json:"refDate,optional"`
	StatCost *float64 `json:"statCost,optional"`
	ShowCnt *int64 `json:"showCnt,optional"`
	CpmPlatform *float64 `json:"cpmPlatform,optional"`
	ClickCnt *int64 `json:"clickCnt,optional"`
	Ctr *float64 `json:"ctr,optional"`
	Active *int64 `json:"active,optional"`
	ActiveCost *float64 `json:"activeCost,optional"`
	ActiveRegister *int64 `json:"activeRegister,optional"`
	ActivePay *int64 `json:"activePay,optional"`
	ActivePayCost *float64 `json:"activePayCost,optional"`
	ActivePayRate *float64 `json:"activePayRate,optional"`
	AttributionConvertCost *float64 `json:"attributionConvertCost,optional"`
	AttributionConversionRate *float64 `json:"attributionConversionRate,optional"`
	AttributionBillingGameInAppRoi1day *float64 `json:"attributionBillingGameInAppRoi1day,optional"`
	AttributionBillingGameInAppRoi2days *float64 `json:"attributionBillingGameInAppRoi2days,optional"`
	AttributionBillingGameInAppRoi3days *float64 `json:"attributionBillingGameInAppRoi3days,optional"`
	AttributionBillingGameInAppRoi4days *float64 `json:"attributionBillingGameInAppRoi4days,optional"`
	AttributionBillingGameInAppRoi5days *float64 `json:"attributionBillingGameInAppRoi5days,optional"`
	AttributionBillingGameInAppRoi6days *float64 `json:"attributionBillingGameInAppRoi6days,optional"`
	AttributionBillingGameInAppRoi7days *float64 `json:"attributionBillingGameInAppRoi7days,optional"`
	AttributionNextDayOpenCnt *int64 `json:"attributionNextDayOpenCnt,optional"`
	AttributionNextDayOpenRate *float64 `json:"attributionNextDayOpenRate,optional"`
	AttributionRetention2dCnt *int64 `json:"attributionRetention2dCnt,optional"`
	AttributionRetention2dRate *float64 `json:"attributionRetention2dRate,optional"`
	AttributionRetention3dCnt *int64 `json:"attributionRetention3dCnt,optional"`
	AttributionRetention3dRate *float64 `json:"attributionRetention3dRate,optional"`
	AttributionRetention4dCnt *int64 `json:"attributionRetention4dCnt,optional"`
	AttributionRetention4dRate *float64 `json:"attributionRetention4dRate,optional"`
	AttributionRetention5dCnt *int64 `json:"attributionRetention5dCnt,optional"`
	AttributionRetention5dRate *float64 `json:"attributionRetention5dRate,optional"`
	AttributionRetention6dCnt *int64 `json:"attributionRetention6dCnt,optional"`
	AttributionRetention6dRate *float64 `json:"attributionRetention6dRate,optional"`
	AttributionRetention7dCnt *int64 `json:"attributionRetention7dCnt,optional"`
	AttributionRetention7dRate *float64 `json:"attributionRetention7dRate,optional"`
	AttributionGamePay7dCost *float64 `json:"attributionGamePay7dCost,optional"`
	AttributionMicroGame0dLtv *float64 `json:"attributionMicroGame0dLtv,optional"`
	AttributionMicroGame3dLtv *float64 `json:"attributionMicroGame3dLtv,optional"`
	AttributionMicroGame7dLtv *float64 `json:"attributionMicroGame7dLtv,optional"`
	AttributionMicroGame0dRoi *float64 `json:"attributionMicroGame0dRoi,optional"`
	AttributionMicroGame3dRoi *float64 `json:"attributionMicroGame3dRoi,optional"`
	AttributionMicroGame7dRoi *float64 `json:"attributionMicroGame7dRoi,optional"`
	AttributionMicroGameIaapLtv7dRoi *float64 `json:"attributionMicroGameIaapLtv7dRoi,optional"`
	AttributionMicroGameIaapIapRoi8days *float64 `json:"attributionMicroGameIaapIapRoi8days,optional"`
	AttributionMicroGameIaapIaa7dRoi *float64 `json:"attributionMicroGameIaapIaa7dRoi,optional"`
}
```


3. response definition



```golang
type RpcOceanengineDailySummaryEmptyResp struct {
}
```

### 14. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/:id
- Method: GET
- Request: `RpcSummaryDataIdReq`
- Response: `RpcSummaryData`

2. request definition



```golang
type RpcSummaryDataIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcSummaryData struct {
	Id int64 `json:"id"`
	Appid string `json:"appid"`
	RefDate string `json:"refDate"`
	Dau int64 `json:"dau"`
	NewUsers int64 `json:"newUsers"`
	NewUserRatio float64 `json:"newUserRatio"`
	AvgAcquisitionCost float64 `json:"avgAcquisitionCost"`
	AvgActiveCost float64 `json:"avgActiveCost"`
	AvgTotalCost float64 `json:"avgTotalCost"`
	LtValue float64 `json:"ltValue"`
	TotalUsersSum int64 `json:"totalUsersSum"`
	TotalRevenue float64 `json:"totalRevenue"`
	TotalExpenditure float64 `json:"totalExpenditure"`
	GrossProfit float64 `json:"grossProfit"`
	CoopProfitShare float64 `json:"coopProfitShare"`
	ProfitMargin float64 `json:"profitMargin"`
	RevTrafficOwner float64 `json:"revTrafficOwner"`
	RevInternalPurchase float64 `json:"revInternalPurchase"`
	RevCommission float64 `json:"revCommission"`
	RevTrafficRental float64 `json:"revTrafficRental"`
	RevAdSettlement float64 `json:"revAdSettlement"`
	RevTotalCalc float64 `json:"revTotalCalc"`
	ExpDailyBase float64 `json:"expDailyBase"`
	ExpInternalBuy float64 `json:"expInternalBuy"`
	ExpExternalBuy float64 `json:"expExternalBuy"`
	ExpTotalOps float64 `json:"expTotalOps"`
	Remark string `json:"remark"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
}
```

### 15. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/:id
- Method: DELETE
- Request: `RpcSummaryDataIdReq`
- Response: `RpcSummaryDataEmptyResp`

2. request definition



```golang
type RpcSummaryDataIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcSummaryDataEmptyResp struct {
}
```

### 16. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/create
- Method: POST
- Request: `RpcSummaryDataCreateReq`
- Response: `RpcSummaryDataCreateResp`

2. request definition



```golang
type RpcSummaryDataCreateReq struct {
	Appid string `json:"appid"`
	RefDate string `json:"refDate"`
	Dau int64 `json:"dau,optional"`
	NewUsers int64 `json:"newUsers,optional"`
	NewUserRatio float64 `json:"newUserRatio,optional"`
	AvgAcquisitionCost float64 `json:"avgAcquisitionCost,optional"`
	AvgActiveCost float64 `json:"avgActiveCost,optional"`
	AvgTotalCost float64 `json:"avgTotalCost,optional"`
	LtValue float64 `json:"ltValue,optional"`
	TotalUsersSum int64 `json:"totalUsersSum,optional"`
	TotalRevenue float64 `json:"totalRevenue,optional"`
	TotalExpenditure float64 `json:"totalExpenditure,optional"`
	GrossProfit float64 `json:"grossProfit,optional"`
	CoopProfitShare float64 `json:"coopProfitShare,optional"`
	ProfitMargin float64 `json:"profitMargin,optional"`
	RevTrafficOwner float64 `json:"revTrafficOwner,optional"`
	RevInternalPurchase float64 `json:"revInternalPurchase,optional"`
	RevCommission float64 `json:"revCommission,optional"`
	RevTrafficRental float64 `json:"revTrafficRental,optional"`
	RevAdSettlement float64 `json:"revAdSettlement,optional"`
	RevTotalCalc float64 `json:"revTotalCalc,optional"`
	ExpDailyBase float64 `json:"expDailyBase,optional"`
	ExpInternalBuy float64 `json:"expInternalBuy,optional"`
	ExpExternalBuy float64 `json:"expExternalBuy,optional"`
	ExpTotalOps float64 `json:"expTotalOps,optional"`
	Remark string `json:"remark,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataCreateResp struct {
	Id int64 `json:"id"`
}
```

### 17. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/findPage
- Method: GET
- Request: `RpcSummaryDataListReq`
- Response: `RpcSummaryDataFindPageResp`

2. request definition



```golang
type RpcSummaryDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataFindPageResp struct {
	List []RpcSummaryData `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 18. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/list
- Method: GET
- Request: `RpcSummaryDataListReq`
- Response: `RpcSummaryDataListResp`

2. request definition



```golang
type RpcSummaryDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataListResp struct {
	List []RpcSummaryData `json:"list"`
	Total int64 `json:"total"`
}
```

### 19. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/summary-data/update
- Method: POST
- Request: `RpcSummaryDataUpdateReq`
- Response: `RpcSummaryDataEmptyResp`

2. request definition



```golang
type RpcSummaryDataUpdateReq struct {
	Id int64 `json:"id"`
	Appid *string `json:"appid,optional"`
	RefDate *string `json:"refDate,optional"`
	Dau *int64 `json:"dau,optional"`
	NewUsers *int64 `json:"newUsers,optional"`
	NewUserRatio *float64 `json:"newUserRatio,optional"`
	AvgAcquisitionCost *float64 `json:"avgAcquisitionCost,optional"`
	AvgActiveCost *float64 `json:"avgActiveCost,optional"`
	AvgTotalCost *float64 `json:"avgTotalCost,optional"`
	LtValue *float64 `json:"ltValue,optional"`
	TotalUsersSum *int64 `json:"totalUsersSum,optional"`
	TotalRevenue *float64 `json:"totalRevenue,optional"`
	TotalExpenditure *float64 `json:"totalExpenditure,optional"`
	GrossProfit *float64 `json:"grossProfit,optional"`
	CoopProfitShare *float64 `json:"coopProfitShare,optional"`
	ProfitMargin *float64 `json:"profitMargin,optional"`
	RevTrafficOwner *float64 `json:"revTrafficOwner,optional"`
	RevInternalPurchase *float64 `json:"revInternalPurchase,optional"`
	RevCommission *float64 `json:"revCommission,optional"`
	RevTrafficRental *float64 `json:"revTrafficRental,optional"`
	RevAdSettlement *float64 `json:"revAdSettlement,optional"`
	RevTotalCalc *float64 `json:"revTotalCalc,optional"`
	ExpDailyBase *float64 `json:"expDailyBase,optional"`
	ExpInternalBuy *float64 `json:"expInternalBuy,optional"`
	ExpExternalBuy *float64 `json:"expExternalBuy,optional"`
	ExpTotalOps *float64 `json:"expTotalOps,optional"`
	Remark *string `json:"remark,optional"`
}
```


3. response definition



```golang
type RpcSummaryDataEmptyResp struct {
}
```

### 20. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/wechat-daily-data/:id
- Method: GET
- Request: `RpcWechatDailyDataIdReq`
- Response: `RpcWechatDailyData`

2. request definition



```golang
type RpcWechatDailyDataIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcWechatDailyData struct {
	Id int64 `json:"id"`
	Appid string `json:"appid"`
	RefDate string `json:"refDate"`
	ActiveUsers int64 `json:"activeUsers"`
	AvgActiveUserStaySeconds float64 `json:"avgActiveUserStaySeconds"`
	ActiveUserRetention1d float64 `json:"activeUserRetention1d"`
	ActiveUserRetention7d float64 `json:"activeUserRetention7d"`
	RegisteredUsers int64 `json:"registeredUsers"`
	RegisteredUserRetention1d float64 `json:"registeredUserRetention1d"`
	RegisteredUserRetention7d float64 `json:"registeredUserRetention7d"`
	RegisteredUserAgeProfile string `json:"registeredUserAgeProfile"`
	RegisteredUserGenderProfile string `json:"registeredUserGenderProfile"`
	RegisteredUserProvinceProfile string `json:"registeredUserProvinceProfile"`
	RegisteredUserCityProfile string `json:"registeredUserCityProfile"`
	RegisteredUserDeviceProfile string `json:"registeredUserDeviceProfile"`
	PaidUsers int64 `json:"paidUsers"`
	PayPenetrationRate float64 `json:"payPenetrationRate"`
	NewPaidUsers int64 `json:"newPaidUsers"`
	PaidUserRetention1d float64 `json:"paidUserRetention1d"`
	PaidUserRetention7d float64 `json:"paidUserRetention7d"`
	NewPaidUserRetention1d float64 `json:"newPaidUserRetention1d"`
	NewPaidUserRetention7d float64 `json:"newPaidUserRetention7d"`
	PaymentAmount float64 `json:"paymentAmount"`
	PaidUserArppu float64 `json:"paidUserArppu"`
	NewPaymentAmount float64 `json:"newPaymentAmount"`
	NewPaidUserArppu float64 `json:"newPaidUserArppu"`
	AdRevenueAfterShare float64 `json:"adRevenueAfterShare"`
	AdLtv1d float64 `json:"adLtv1d"`
	AdLtv3d float64 `json:"adLtv3d"`
	AdLtv7d float64 `json:"adLtv7d"`
	AdLtv30d float64 `json:"adLtv30d"`
	ItemLtv1d float64 `json:"itemLtv1d"`
	ItemLtv3d float64 `json:"itemLtv3d"`
	ItemLtv7d float64 `json:"itemLtv7d"`
	ItemLtv30d float64 `json:"itemLtv30d"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
}
```

### 21. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/wechat-daily-data/:id
- Method: DELETE
- Request: `RpcWechatDailyDataIdReq`
- Response: `RpcWechatDailyDataEmptyResp`

2. request definition



```golang
type RpcWechatDailyDataIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcWechatDailyDataEmptyResp struct {
}
```

### 22. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/wechat-daily-data/create
- Method: POST
- Request: `RpcWechatDailyDataCreateReq`
- Response: `RpcWechatDailyDataCreateResp`

2. request definition



```golang
type RpcWechatDailyDataCreateReq struct {
	Appid string `json:"appid"`
	RefDate string `json:"refDate"`
	ActiveUsers int64 `json:"activeUsers,optional"`
	AvgActiveUserStaySeconds float64 `json:"avgActiveUserStaySeconds,optional"`
	ActiveUserRetention1d float64 `json:"activeUserRetention1d,optional"`
	ActiveUserRetention7d float64 `json:"activeUserRetention7d,optional"`
	RegisteredUsers int64 `json:"registeredUsers,optional"`
	RegisteredUserRetention1d float64 `json:"registeredUserRetention1d,optional"`
	RegisteredUserRetention7d float64 `json:"registeredUserRetention7d,optional"`
	RegisteredUserAgeProfile string `json:"registeredUserAgeProfile,optional"`
	RegisteredUserGenderProfile string `json:"registeredUserGenderProfile,optional"`
	RegisteredUserProvinceProfile string `json:"registeredUserProvinceProfile,optional"`
	RegisteredUserCityProfile string `json:"registeredUserCityProfile,optional"`
	RegisteredUserDeviceProfile string `json:"registeredUserDeviceProfile,optional"`
	PaidUsers int64 `json:"paidUsers,optional"`
	PayPenetrationRate float64 `json:"payPenetrationRate,optional"`
	NewPaidUsers int64 `json:"newPaidUsers,optional"`
	PaidUserRetention1d float64 `json:"paidUserRetention1d,optional"`
	PaidUserRetention7d float64 `json:"paidUserRetention7d,optional"`
	NewPaidUserRetention1d float64 `json:"newPaidUserRetention1d,optional"`
	NewPaidUserRetention7d float64 `json:"newPaidUserRetention7d,optional"`
	PaymentAmount float64 `json:"paymentAmount,optional"`
	PaidUserArppu float64 `json:"paidUserArppu,optional"`
	NewPaymentAmount float64 `json:"newPaymentAmount,optional"`
	NewPaidUserArppu float64 `json:"newPaidUserArppu,optional"`
	AdRevenueAfterShare float64 `json:"adRevenueAfterShare,optional"`
	AdLtv1d float64 `json:"adLtv1d,optional"`
	AdLtv3d float64 `json:"adLtv3d,optional"`
	AdLtv7d float64 `json:"adLtv7d,optional"`
	AdLtv30d float64 `json:"adLtv30d,optional"`
	ItemLtv1d float64 `json:"itemLtv1d,optional"`
	ItemLtv3d float64 `json:"itemLtv3d,optional"`
	ItemLtv7d float64 `json:"itemLtv7d,optional"`
	ItemLtv30d float64 `json:"itemLtv30d,optional"`
}
```


3. response definition



```golang
type RpcWechatDailyDataCreateResp struct {
	Id int64 `json:"id"`
}
```

### 23. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/wechat-daily-data/findPage
- Method: GET
- Request: `RpcWechatDailyDataListReq`
- Response: `RpcWechatDailyDataFindPageResp`

2. request definition



```golang
type RpcWechatDailyDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcWechatDailyDataFindPageResp struct {
	List []RpcWechatDailyData `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 24. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/wechat-daily-data/list
- Method: GET
- Request: `RpcWechatDailyDataListReq`
- Response: `RpcWechatDailyDataListResp`

2. request definition



```golang
type RpcWechatDailyDataListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcWechatDailyDataListResp struct {
	List []RpcWechatDailyData `json:"list"`
	Total int64 `json:"total"`
}
```

### 25. N/A

1. route definition

- Url: /api/v1/rpc/kbrelease/wechat-daily-data/update
- Method: POST
- Request: `RpcWechatDailyDataUpdateReq`
- Response: `RpcWechatDailyDataEmptyResp`

2. request definition



```golang
type RpcWechatDailyDataUpdateReq struct {
	Id int64 `json:"id"`
	Appid *string `json:"appid,optional"`
	RefDate *string `json:"refDate,optional"`
	ActiveUsers *int64 `json:"activeUsers,optional"`
	AvgActiveUserStaySeconds *float64 `json:"avgActiveUserStaySeconds,optional"`
	ActiveUserRetention1d *float64 `json:"activeUserRetention1d,optional"`
	ActiveUserRetention7d *float64 `json:"activeUserRetention7d,optional"`
	RegisteredUsers *int64 `json:"registeredUsers,optional"`
	RegisteredUserRetention1d *float64 `json:"registeredUserRetention1d,optional"`
	RegisteredUserRetention7d *float64 `json:"registeredUserRetention7d,optional"`
	RegisteredUserAgeProfile *string `json:"registeredUserAgeProfile,optional"`
	RegisteredUserGenderProfile *string `json:"registeredUserGenderProfile,optional"`
	RegisteredUserProvinceProfile *string `json:"registeredUserProvinceProfile,optional"`
	RegisteredUserCityProfile *string `json:"registeredUserCityProfile,optional"`
	RegisteredUserDeviceProfile *string `json:"registeredUserDeviceProfile,optional"`
	PaidUsers *int64 `json:"paidUsers,optional"`
	PayPenetrationRate *float64 `json:"payPenetrationRate,optional"`
	NewPaidUsers *int64 `json:"newPaidUsers,optional"`
	PaidUserRetention1d *float64 `json:"paidUserRetention1d,optional"`
	PaidUserRetention7d *float64 `json:"paidUserRetention7d,optional"`
	NewPaidUserRetention1d *float64 `json:"newPaidUserRetention1d,optional"`
	NewPaidUserRetention7d *float64 `json:"newPaidUserRetention7d,optional"`
	PaymentAmount *float64 `json:"paymentAmount,optional"`
	PaidUserArppu *float64 `json:"paidUserArppu,optional"`
	NewPaymentAmount *float64 `json:"newPaymentAmount,optional"`
	NewPaidUserArppu *float64 `json:"newPaidUserArppu,optional"`
	AdRevenueAfterShare *float64 `json:"adRevenueAfterShare,optional"`
	AdLtv1d *float64 `json:"adLtv1d,optional"`
	AdLtv3d *float64 `json:"adLtv3d,optional"`
	AdLtv7d *float64 `json:"adLtv7d,optional"`
	AdLtv30d *float64 `json:"adLtv30d,optional"`
	ItemLtv1d *float64 `json:"itemLtv1d,optional"`
	ItemLtv3d *float64 `json:"itemLtv3d,optional"`
	ItemLtv7d *float64 `json:"itemLtv7d,optional"`
	ItemLtv30d *float64 `json:"itemLtv30d,optional"`
}
```


3. response definition



```golang
type RpcWechatDailyDataEmptyResp struct {
}
```

