### 1. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/:id
- Method: GET
- Request: `RpcCronTaskRunLogIdReq`
- Response: `RpcCronTaskRunLog`

2. request definition



```golang
type RpcCronTaskRunLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcCronTaskRunLog struct {
	Id int64 `json:"id"`
	TaskId int64 `json:"taskId"`
	WorkerId string `json:"workerId"`
	Status string `json:"status"`
	Message string `json:"message"`
	StartedAt string `json:"startedAt"`
	FinishedAt string `json:"finishedAt"`
	DurationMs int64 `json:"durationMs"`
	CreatedAt string `json:"createdAt"`
}
```

### 2. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/:id
- Method: DELETE
- Request: `RpcCronTaskRunLogIdReq`
- Response: `RpcCronTaskRunLogEmptyResp`

2. request definition



```golang
type RpcCronTaskRunLogIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcCronTaskRunLogEmptyResp struct {
}
```

### 3. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/create
- Method: POST
- Request: `RpcCronTaskRunLogCreateReq`
- Response: `RpcCronTaskRunLogCreateResp`

2. request definition



```golang
type RpcCronTaskRunLogCreateReq struct {
	TaskId int64 `json:"taskId"`
	WorkerId string `json:"workerId"`
	Status string `json:"status"`
	Message string `json:"message"`
	StartedAt string `json:"startedAt"`
	FinishedAt string `json:"finishedAt"`
	DurationMs int64 `json:"durationMs"`
}
```


3. response definition



```golang
type RpcCronTaskRunLogCreateResp struct {
	Id int64 `json:"id"`
}
```

### 4. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/findPage
- Method: GET
- Request: `RpcCronTaskRunLogListReq`
- Response: `RpcCronTaskRunLogFindPageResp`

2. request definition



```golang
type RpcCronTaskRunLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcCronTaskRunLogFindPageResp struct {
	List []RpcCronTaskRunLog `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 5. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/list
- Method: GET
- Request: `RpcCronTaskRunLogListReq`
- Response: `RpcCronTaskRunLogListResp`

2. request definition



```golang
type RpcCronTaskRunLogListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcCronTaskRunLogListResp struct {
	List []RpcCronTaskRunLog `json:"list"`
	Total int64 `json:"total"`
}
```

### 6. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task-run-log/update
- Method: POST
- Request: `RpcCronTaskRunLogUpdateReq`
- Response: `RpcCronTaskRunLogEmptyResp`

2. request definition



```golang
type RpcCronTaskRunLogUpdateReq struct {
	Id int64 `json:"id"`
	TaskId *int64 `json:"taskId,optional"`
	WorkerId *string `json:"workerId,optional"`
	Status *string `json:"status,optional"`
	Message *string `json:"message,optional"`
	StartedAt *string `json:"startedAt,optional"`
	FinishedAt *string `json:"finishedAt,optional"`
	DurationMs *int64 `json:"durationMs,optional"`
}
```


3. response definition



```golang
type RpcCronTaskRunLogEmptyResp struct {
}
```

### 7. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/:id
- Method: GET
- Request: `RpcCronTaskIdReq`
- Response: `RpcCronTask`

2. request definition



```golang
type RpcCronTaskIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcCronTask struct {
	Id int64 `json:"id"`
	Name string `json:"name"`
	TaskKey string `json:"taskKey"`
	Payload string `json:"payload"`
	ScheduleType string `json:"scheduleType"`
	RunAt string `json:"runAt"`
	IntervalSeconds int64 `json:"intervalSeconds"`
	Status string `json:"status"`
	NextRunAt string `json:"nextRunAt"`
	LastRunAt string `json:"lastRunAt"`
	LockedBy string `json:"lockedBy"`
	LockedUntil string `json:"lockedUntil"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
}
```

### 8. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/:id
- Method: DELETE
- Request: `RpcCronTaskIdReq`
- Response: `RpcCronTaskEmptyResp`

2. request definition



```golang
type RpcCronTaskIdReq struct {
	Id int64 `path:"id"`
}
```


3. response definition



```golang
type RpcCronTaskEmptyResp struct {
}
```

### 9. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/create
- Method: POST
- Request: `RpcCronTaskCreateReq`
- Response: `RpcCronTaskCreateResp`

2. request definition



```golang
type RpcCronTaskCreateReq struct {
	Name string `json:"name"`
	TaskKey string `json:"taskKey"`
	Payload string `json:"payload"`
	ScheduleType string `json:"scheduleType"`
	RunAt string `json:"runAt"`
	IntervalSeconds int64 `json:"intervalSeconds"`
	Status string `json:"status"`
	NextRunAt string `json:"nextRunAt,optional"`
	LastRunAt string `json:"lastRunAt,optional"`
	LockedBy string `json:"lockedBy,optional"`
	LockedUntil string `json:"lockedUntil,optional"`
}
```


3. response definition



```golang
type RpcCronTaskCreateResp struct {
	Id int64 `json:"id"`
}
```

### 10. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/findPage
- Method: GET
- Request: `RpcCronTaskListReq`
- Response: `RpcCronTaskFindPageResp`

2. request definition



```golang
type RpcCronTaskListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcCronTaskFindPageResp struct {
	List []RpcCronTask `json:"list"`
	PageIndex int64 `json:"pageIndex"`
	PageSize int64 `json:"pageSize"`
	Count int64 `json:"count"`
}
```

### 11. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/list
- Method: GET
- Request: `RpcCronTaskListReq`
- Response: `RpcCronTaskListResp`

2. request definition



```golang
type RpcCronTaskListReq struct {
	Page int64 `form:"page,optional"`
	PageSize int64 `form:"pageSize,optional"`
}
```


3. response definition



```golang
type RpcCronTaskListResp struct {
	List []RpcCronTask `json:"list"`
	Total int64 `json:"total"`
}
```

### 12. N/A

1. route definition

- Url: /api/v1/rpc/cron/cron-task/update
- Method: POST
- Request: `RpcCronTaskUpdateReq`
- Response: `RpcCronTaskEmptyResp`

2. request definition



```golang
type RpcCronTaskUpdateReq struct {
	Id int64 `json:"id"`
	Name *string `json:"name,optional"`
	TaskKey *string `json:"taskKey,optional"`
	Payload *string `json:"payload,optional"`
	ScheduleType *string `json:"scheduleType,optional"`
	RunAt *string `json:"runAt,optional"`
	IntervalSeconds *int64 `json:"intervalSeconds,optional"`
	Status *string `json:"status,optional"`
	NextRunAt *string `json:"nextRunAt,optional"`
	LastRunAt *string `json:"lastRunAt,optional"`
	LockedBy *string `json:"lockedBy,optional"`
	LockedUntil *string `json:"lockedUntil,optional"`
}
```


3. response definition



```golang
type RpcCronTaskEmptyResp struct {
}
```

