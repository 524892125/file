<template>
  <a-input
    v-if="fieldType === 'input'"
    v-bind="fieldProps"
    v-model:value="innerValue"
    :placeholder="placeholder"
    allow-clear
  />
  <a-input-password
    v-else-if="fieldType === 'password'"
    v-bind="fieldProps"
    v-model:value="innerValue"
    :placeholder="placeholder"
    allow-clear
  />
  <a-textarea
    v-else-if="fieldType === 'textarea'"
    v-bind="fieldProps"
    v-model:value="innerValue"
    :placeholder="placeholder"
    :rows="fieldProps.rows ?? 4"
    allow-clear
  />
  <a-input-number
    v-else-if="fieldType === 'input-number' || fieldType === 'number'"
    v-bind="fieldProps"
    v-model:value="innerValue"
    :placeholder="placeholder"
    style="width: 100%"
  />
  <a-select
    v-else-if="fieldType === 'select'"
    v-bind="fieldProps"
    v-model:value="innerValue"
    :options="dictOptions"
    :placeholder="placeholder"
    :loading="dictLoading"
    allow-clear
    style="width: 100%"
  />
  <a-radio-group
    v-else-if="fieldType === 'radio'"
    v-bind="fieldProps"
    v-model:value="innerValue"
    :options="dictOptions"
  />
  <a-checkbox-group
    v-else-if="fieldType === 'checkbox'"
    v-bind="fieldProps"
    v-model:value="innerValue"
    :options="dictOptions"
  />
  <a-switch
    v-else-if="fieldType === 'switch'"
    v-bind="fieldProps"
    :checked="innerValue"
    @update:checked="innerValue = $event"
  />
  <a-tree-select
    v-else-if="fieldType === 'tree-select'"
    v-bind="fieldProps"
    v-model:value="innerValue"
    :tree-data="dictOptions"
    :field-names="fieldNames"
    :placeholder="placeholder"
    :loading="dictLoading"
    allow-clear
    style="width: 100%"
  />
  <a-cascader
    v-else-if="fieldType === 'cascader'"
    v-bind="fieldProps"
    v-model:value="innerValue"
    :options="dictOptions"
    :field-names="fieldNames"
    :placeholder="placeholder"
    allow-clear
    style="width: 100%"
  />
  <a-range-picker
    v-else-if="fieldType === 'range'"
    v-bind="fieldProps"
    v-model:value="innerValue"
    style="width: 100%"
  />
  <a-time-picker
    v-else-if="fieldType === 'time'"
    v-bind="fieldProps"
    v-model:value="innerValue"
    :placeholder="placeholder"
    style="width: 100%"
  />
  <a-date-picker
    v-else
    v-bind="datePickerProps"
    v-model:value="innerValue"
    :placeholder="placeholder"
    style="width: 100%"
  />
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import type { CrudColumn } from './types'
import { normalizeOptions } from './helpers'

defineOptions({ name: 'CrudField' })

const props = defineProps<{
  column: CrudColumn
  modelValue?: any
  value?: any
  mode?: 'search' | 'form'
}>()

const emit = defineEmits<{
  (event: 'update:modelValue', value: any): void
  (event: 'update:value', value: any): void
}>()

const innerValue = computed({
  get: () => props.value ?? props.modelValue,
  set: (value) => {
    emit('update:modelValue', value)
    emit('update:value', value)
  },
})

const fieldType = computed(() => props.column.searchFormType || props.column.formType || 'input')
const placeholder = computed(() => props.column.searchPlaceholder || `请输入${props.column.title}`)
const fieldNames = computed(() => props.column.dict?.props || { label: 'label', value: 'value', children: 'children' })
const fieldProps = computed(() => ({ ...(props.column.fieldProps || {}), ...(props.column.componentProps || {}) }))
const asyncDictData = ref<any[]>([])
const dictLoading = ref(false)

const dictOptions = computed(() => {
  const data = props.column.dict?.data
  const source = typeof data === 'function' ? asyncDictData.value : data
  return normalizeOptions(source, fieldNames.value.label, fieldNames.value.value, fieldNames.value.children)
})

watch(
  () => props.column.dict?.data,
  async (loader) => {
    if (typeof loader !== 'function') {
      asyncDictData.value = []
      return
    }
    dictLoading.value = true
    try {
      const data = await loader()
      asyncDictData.value = Array.isArray(data) ? data : []
    } finally {
      dictLoading.value = false
    }
  },
  { immediate: true }
)

const datePickerProps = computed(() => {
  const pickerMap: Record<string, string> = {
    month: 'month',
    year: 'year',
    week: 'week',
    quarter: 'quarter',
  }
  return {
    ...fieldProps.value,
    picker: pickerMap[fieldType.value],
  }
})
</script>
