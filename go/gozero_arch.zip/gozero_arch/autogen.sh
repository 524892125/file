#!/usr/bin/env bash

set -euo pipefail
shopt -s nullglob


ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TPL_DIR="${ROOT_DIR}/tools/goctl/tpl_1.10.1"

server=(
  "user"
  "admin"
)

cd tools/autogen && python3 autogen.py && cd ../../

for s in "${server[@]}"; do
  # ...................................create api swagger docs...................................
  bash tools/goctl/goctl-api-build.sh "apps/${s}/api/${s}.api" "apps/${s}/api" "apps/${s}/api" "assets" "${s}"

  cd apps/${s}/rpc/
  goctl rpc protoc "${s}.proto" --go_out=./ --go-grpc_out=./ --zrpc_out=./ --style=goZero --home "${TPL_DIR}"
  cd ../../../

  sql_files=( assets/sql/${s}/*.sql )
  if (( ${#sql_files[@]} == 0 )); then
    echo "skip model ddl: no sql files under assets/sql/${s}/"
    continue
  fi

  printf '%s\n' "${sql_files[@]}"

  for sql_file in "${sql_files[@]}"; do
    echo "$sql_file"
    mkdir -p "apps/${s}/model"
    goctl model mysql ddl --src "$sql_file" --dir "apps/${s}/model" --style goZero --home "${TPL_DIR}"
  done
done
