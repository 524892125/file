#!/usr/bin/env bash

set -euo pipefail
shopt -s nullglob

declare -A DB_MAP=(
  ["user"]="go-admin-user"
  ["admin"]="go-admin-common"
  ["kbrelease"]="go-admin-kbrelease"
  ["cron"]="go-admin-cron"
)

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TPL_DIR="${ROOT_DIR}/tools/goctl/tpl_1.10.1"
GENERATE_UI_REACT="${GENERATE_UI_REACT:-1}"

server=(
  "user"
  "admin"
  "kbrelease"
  "cron"
)

cd tools/autogen && python3 autogen.py && cd ../../
python3 tools/autogen/autogen_pg_sql_api.py --root "${ROOT_DIR}"
python3 tools/autogen/autogen_api_imports.py --root "${ROOT_DIR}"

for s in "${server[@]}"; do
  DATABASE_NAME="${DB_MAP[$s]:-}"
  if [[ -z "${DATABASE_NAME}" ]]; then
    echo "❌ No database config for service: $s"
    exit 1
  fi
  DATABASE_URL="postgres://postgres:123456@127.0.0.1:5432/${DATABASE_NAME}?sslmode=disable"
  echo "🚀 Service: $s → DB: $DATABASE_NAME"

  sql_files=( assets/sql/${s}/*.sql )
  if (( ${#sql_files[@]} == 0 )); then
    echo "skip model ddl: no sql files under assets/sql/${s}/"
  else
    model_sql_files=()
    mapfile -t model_sql_files < <(python3 tools/autogen/sql_gen_filter.py --target model "${sql_files[@]}")

    if (( ${#model_sql_files[@]} == 0 )); then
      echo "skip model ddl: no @gen model sql files under assets/sql/${s}/"
    else
      printf '%s\n' "${model_sql_files[@]}"

      for sql_file in "${model_sql_files[@]}"; do
        echo "Applying DDL: $sql_file"
        mkdir -p "apps/${s}/model"
        psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$sql_file"

        TABLE_REF=$(grep -iE 'CREATE[[:space:]]+TABLE' "$sql_file" | head -n1 | sed -E 's/.*CREATE[[:space:]]+TABLE([[:space:]]+IF[[:space:]]+NOT[[:space:]]+EXISTS)?[[:space:]]+//I; s/[[:space:]]*\(.*//')
        SCHEMA_NAME=$(echo "$TABLE_REF" | awk -F. 'NF>1 {gsub(/"/, "", $1); print $1}')
        TABLE_NAME=$(echo "$TABLE_REF" | awk -F. '{gsub(/"/, "", $NF); print $NF}')
        SCHEMA_NAME="${SCHEMA_NAME:-public}"

        if [[ -z "$TABLE_NAME" ]]; then
          echo "❌ Failed to parse table name from $sql_file"
          continue
        fi

        echo "✅ Table: ${SCHEMA_NAME}.${TABLE_NAME}"
        echo "Generating goctl pg model for ${TABLE_NAME}"
        goctl model pg datasource \
          --url "$DATABASE_URL" \
          --schema "$SCHEMA_NAME" \
          --table "$TABLE_NAME" \
          --dir "apps/${s}/model" \
          --style goZero \
          --home "${TPL_DIR}"
      done
    fi
  fi

  python3 tools/autogen/autogen_model_audit_columns.py --root "${ROOT_DIR}" --service "${s}"
  python3 tools/autogen/autogen_svc_models.py --root "${ROOT_DIR}" --service "${s}"

  # ...................................create api swagger docs...................................
  logic_dir="apps/${s}/api/internal/logic"
  logic_snapshot=""
  if [[ -d "$logic_dir" ]]; then
    logic_snapshot="$(mktemp)"
    find "$logic_dir" -maxdepth 1 -type f -name '*Logic.go' -printf '%f\n' | sort > "$logic_snapshot"
  fi

  python3 tools/autogen/autogen_api_imports.py --root "${ROOT_DIR}" --service "${s}"
  GOCTL_API_PRESERVE_EXISTING_LOGIC=1 bash tools/goctl/goctl-api-build.sh "apps/${s}/api/${s}.api" "apps/${s}/api" "apps/${s}/api" "assets" "${s}"
  python3 tools/autogen/autogen_api_routes.py --root "${ROOT_DIR}" --service "${s}"
  python3 tools/autogen/autogen_ui_ts_sync.py --root "${ROOT_DIR}" --service "${s}"
  if [[ "${GENERATE_UI_REACT}" == "1" ]]; then
    python3 tools/autogen/autogen_ui_react_api.py --root "${ROOT_DIR}" --service "${s}"
  fi
  dbapi_args=(--root "${ROOT_DIR}" --service "${s}")
  if [[ -n "$logic_snapshot" ]]; then
    dbapi_args+=(--skip-existing-logic-list "$logic_snapshot")
  fi
  python3 tools/autogen/autogen_dbapi_list.py "${dbapi_args[@]}"
  if [[ -n "$logic_snapshot" ]]; then
    rm -f "$logic_snapshot"
  fi
  python3 tools/autogen/autogen_ui_pages.py --root "${ROOT_DIR}" --service "${s}"
  if [[ "${GENERATE_UI_REACT}" == "1" ]]; then
    python3 tools/autogen/autogen_ui_react_pages.py --root "${ROOT_DIR}" --service "${s}" --skip-routes --use-shared-crud
  fi

  python3 tools/autogen/autogen_pg_sql_rpc.py --root "${ROOT_DIR}" --service "${s}"
  rpc_logic_dir="apps/${s}/rpc/internal/logic"
  rpc_logic_snapshot=""
  if [[ -d "$rpc_logic_dir" ]]; then
    rpc_logic_snapshot="$(mktemp)"
    find "$rpc_logic_dir" -maxdepth 1 -type f -name '*Logic.go' -printf '%f\n' | sort > "$rpc_logic_snapshot"
  fi
  cd apps/${s}/rpc/
  goctl rpc protoc "${s}.proto" --go_out=./ --go-grpc_out=./ --zrpc_out=./ --style=goZero --home "${TPL_DIR}"
  cd ../../../
  python3 tools/autogen/autogen_rpc_svc_models.py --root "${ROOT_DIR}" --service "${s}" --database "${DATABASE_NAME}"
  rpccrud_args=(--root "${ROOT_DIR}" --service "${s}")
  if [[ -n "$rpc_logic_snapshot" ]]; then
    rpccrud_args+=(--skip-existing-logic-list "$rpc_logic_snapshot")
  fi
  python3 tools/autogen/autogen_rpccrud_logic.py "${rpccrud_args[@]}"
  if [[ -n "$rpc_logic_snapshot" ]]; then
    rm -f "$rpc_logic_snapshot"
  fi
done

if [[ "${GENERATE_UI_REACT}" == "1" ]]; then
  (cd ui-react && pnpm gen:routes)
fi

python3 tools/autogen/autogen_api2rpc.py --root "${ROOT_DIR}" --phase pre-api
GOCTL_API_PRESERVE_EXISTING_LOGIC=1 bash tools/goctl/goctl-api-build.sh "apps/admin/api/admin.api" "apps/admin/api" "apps/admin/api" "assets" "admin"
python3 tools/autogen/autogen_api2rpc.py --root "${ROOT_DIR}" --phase post-api
