type {{.upperStartCamelObject}}PageField struct {
	Field string
	Value any
	Op    string
}

func (m *default{{.upperStartCamelObject}}Model) FindPageByFields(ctx context.Context, page, pageNum int64, fields []{{.upperStartCamelObject}}PageField) ([]*{{.upperStartCamelObject}}, int64, error) {
	if page < 1 {
		page = 1
	}
	if pageNum < 1 {
		pageNum = 10
	}
	offset := (page - 1) * pageNum
	where, args := m.build{{.upperStartCamelObject}}PageWhere(fields)

	var total int64
	countQuery := fmt.Sprintf("select count(1) from %s%s", m.table, where)
	{{if .withCache}}err := m.QueryRowNoCacheCtx(ctx, &total, countQuery, args...){{else}}err := m.conn.QueryRowCtx(ctx, &total, countQuery, args...){{end}}
	if err != nil {
		return nil, 0, err
	}

	query := fmt.Sprintf("select %s from %s%s limit {{if .postgreSql}}$%d offset $%d{{else}}? offset ?{{end}}", {{.lowerStartCamelObject}}Rows, m.table, where{{if .postgreSql}}, len(args)+1, len(args)+2{{end}})
	args = append(args, pageNum, offset)
	var resp []*{{.upperStartCamelObject}}
	{{if .withCache}}err = m.QueryRowsNoCacheCtx(ctx, &resp, query, args...){{else}}err = m.conn.QueryRowsCtx(ctx, &resp, query, args...){{end}}
	switch err {
	case nil:
		return resp, total, nil
	{{if .withCache}}case sqlc.ErrNotFound:{{else}}case sqlx.ErrNotFound:{{end}}
		return nil, 0, ErrNotFound
	default:
		return nil, 0, err
	}
}

func (m *default{{.upperStartCamelObject}}Model) build{{.upperStartCamelObject}}PageWhere(fields []{{.upperStartCamelObject}}PageField) (string, []any) {
	if len(fields) == 0 {
		return "", nil
	}

	allowed := make(map[string]string, len({{.lowerStartCamelObject}}FieldNames)*2)
	for _, field := range {{.lowerStartCamelObject}}FieldNames {
		column := strings.Trim(field, "`\"")
		allowed[column] = field
		allowed[{{.lowerStartCamelObject}}SnakeToLowerCamel(column)] = field
	}

	conditions := make([]string, 0, len(fields))
	args := make([]any, 0, len(fields))
	for _, item := range fields {
		column, ok := allowed[item.Field]
		if !ok || item.Value == nil {
			continue
		}

		op := strings.ToLower(strings.TrimSpace(item.Op))
		switch op {
		case "", "=", "eq":
			op = "="
		case "like":
			op = "like"
		case ">", "gt":
			op = ">"
		case ">=", "gte":
			op = ">="
		case "<", "lt":
			op = "<"
		case "<=", "lte":
			op = "<="
		default:
			continue
		}

		args = append(args, item.Value)
		{{if .postgreSql}}conditions = append(conditions, fmt.Sprintf("%s %s $%d", column, op, len(args))){{else}}conditions = append(conditions, fmt.Sprintf("%s %s ?", column, op)){{end}}
	}

	if len(conditions) == 0 {
		return "", nil
	}
	return " where " + strings.Join(conditions, " and "), args
}

func {{.lowerStartCamelObject}}SnakeToLowerCamel(value string) string {
	parts := strings.Split(value, "_")
	if len(parts) == 0 {
		return value
	}
	for index := 1; index < len(parts); index++ {
		if parts[index] == "" {
			continue
		}
		parts[index] = strings.ToUpper(parts[index][:1]) + parts[index][1:]
	}
	return strings.Join(parts, "")
}
