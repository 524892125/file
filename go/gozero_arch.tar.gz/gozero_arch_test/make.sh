#!/usr/bin/env bash

server=(
  "user"
  "admin"
)

for s in "${server[@]}"; do
    go build -o ./bin/${s}-api ./apps/${s}/api/${s}.go
    cp ./apps/${s}/api/etc/* ./bin/etc/

    go build -o ./bin/${s} ./apps/${s}/rpc/${s}.go
    cp ./apps/${s}/rpc/etc/* ./bin/etc/
done