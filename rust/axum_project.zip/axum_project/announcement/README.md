# announcement

Axum Web API scaffold for the announcement service.

## Structure

- `src/main.rs`: server entrypoint
- `src/config`: environment configuration
- `src/routes`: route registration
- `src/handlers`: request/controller layer
- `src/services`: business logic layer
- `src/models`: DTO and data models
- `src/db`: database pools
- `src/middleware`: middleware
- `src/errors`: API error responses
- `src/utils`: shared helpers

## Run

Copy `.env.example` to `.env`, adjust database URLs, then run:

```bash
cargo run
```

Health check:

```bash
curl http://127.0.0.1:3000/health
```
