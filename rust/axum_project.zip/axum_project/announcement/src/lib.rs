pub mod config;
pub mod db;
pub mod errors;
pub mod handlers;
pub mod mappers;
pub mod middleware;
pub mod models;
pub mod routes;
pub mod services;
pub mod utils;

use axum::Router;

use crate::{config::Settings, db::pool::AppPool, services::Services};

#[derive(Clone)]
pub struct AppState {
    pub settings: Settings,
    pub pool: AppPool,
    pub services: Services,
}

impl AppState {
    pub async fn build(settings: Settings) -> anyhow::Result<Self> {
        let pool = AppPool::connect(&settings).await?;
        let services = Services::build(&pool).await?;

        Ok(Self {
            settings,
            pool,
            services,
        })
    }
}

pub fn create_app(state: AppState) -> Router {
    routes::create_router(state)
}
