use anyhow::Result;
use sqlx::MySqlPool;

use crate::models::notice::NoticeRule;

pub async fn load_active_rules(pool: &MySqlPool) -> Result<Vec<NoticeRule>> {
    let rows = sqlx::query_as::<_, NoticeRule>(
        r#"
        SELECT
            id, title, content, start, end, server, sort, status, picture, type, env
        FROM gm_tools_announcement
        WHERE status = 2
          AND start < NOW()
          AND end > NOW()
        ORDER BY sort DESC, id DESC
        "#,
    )
    .fetch_all(pool)
    .await?;

    Ok(rows)
}
