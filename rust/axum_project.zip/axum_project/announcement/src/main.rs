use anyhow::Result;
use announcement::{config::Settings, create_app, AppState};
use tracing::info;

#[tokio::main]
async fn main() -> Result<()> {
    let settings = Settings::from_env()?;
    settings.init_tracing();
    let bind_addr = settings.bind_addr();

    let state = AppState::build(settings).await?;
    let app = create_app(state);

    let listener = tokio::net::TcpListener::bind(bind_addr).await?;
    info!("server listening on {}", listener.local_addr()?);

    axum::serve(listener, app)
        .with_graceful_shutdown(shutdown_signal())
        .await?;

    Ok(())
}

async fn shutdown_signal() {
    let ctrl_c = async {
        let _ = tokio::signal::ctrl_c().await;
    };

    #[cfg(unix)]
    let terminate = async {
        use tokio::signal::unix::{signal, SignalKind};
        if let Ok(mut sigterm) = signal(SignalKind::terminate()) {
            let _ = sigterm.recv().await;
        }
    };

    #[cfg(not(unix))]
    let terminate = std::future::pending::<()>();

    tokio::select! {
        _ = ctrl_c => {}
        _ = terminate => {}
    }
}
