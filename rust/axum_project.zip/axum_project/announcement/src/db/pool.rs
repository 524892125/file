use anyhow::Result;
use sqlx::{mysql::MySqlPoolOptions, postgres::PgPoolOptions, MySqlPool, PgPool};

use crate::config::Settings;

#[derive(Clone)]
pub struct AppPool {
    pub mysql: MySqlPool,
    pub postgres: PgPool,
}

impl AppPool {
    pub async fn connect(settings: &Settings) -> Result<Self> {
        let mysql = MySqlPoolOptions::new()
            .max_connections(settings.mysql_max_conn)
            .connect(&settings.mysql_url)
            .await?;

        let postgres = PgPoolOptions::new()
            .max_connections(settings.postgres_max_conn)
            .connect(&settings.postgres_url)
            .await?;

        Ok(Self { mysql, postgres })
    }

    pub fn mysql(&self) -> &MySqlPool {
        &self.mysql
    }
}
