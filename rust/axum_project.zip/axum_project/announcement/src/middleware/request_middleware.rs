use axum::{
    body::Body,
    extract::Request,
    http::HeaderValue,
    middleware::Next,
    response::Response,
};
use tracing::info;

pub async fn request_logger(req: Request, next: Next) -> Response {
    let request_id = chrono::Local::now().format("%H:%M:%S%.3f").to_string();

    let ip = req
        .headers()
        .get("x-forwarded-for")
        .and_then(|v| v.to_str().ok())
        .map(|s| s.split(',').next().unwrap_or("").trim().to_string())
        .unwrap_or_else(|| {
            req.extensions()
                .get::<axum::extract::ConnectInfo<std::net::SocketAddr>>()
                .map(|ci| ci.0.ip().to_string())
                .unwrap_or_default()
        });

    let method = req.method().clone();
    let path = req.uri().path().to_string();
    let query = req.uri().query().unwrap_or("").to_string();

    let (parts, body) = req.into_parts();
    let bytes = axum::body::to_bytes(body, 2 * 1024 * 1024).await.unwrap_or_default();
    let body_str = String::from_utf8_lossy(&bytes);
    let body_display = if body_str.len() > 2000 {
        &body_str[..2000]
    } else {
        &body_str
    };

    info!("{request_id} {ip} {method} {path} {query} {body_display}");

    let req = Request::from_parts(parts, Body::from(bytes));
    let mut response = next.run(req).await;
    response
        .headers_mut()
        .insert("x-request-id", HeaderValue::from_str(&request_id).unwrap());
    response
}
