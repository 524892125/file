use axum::{body::Body, http::Request, middleware::Next, response::Response};

pub async fn auth(req: Request<Body>, next: Next) -> Response {
    next.run(req).await
}
