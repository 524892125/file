use serde::{Deserialize, Serialize};
use sqlx::FromRow;

#[derive(Debug, Clone, Deserialize)]
pub struct NoticeRequest {
    pub channel: String,
}

#[derive(Debug, Clone, FromRow)]
pub struct NoticeRule {
    pub id: i64,
    pub title: Option<String>,
    pub content: Option<String>,
    pub start: chrono::NaiveDateTime,
    pub end: chrono::NaiveDateTime,
    pub server: String,
    pub sort: Option<i32>,
    pub status: Option<i32>,
    pub picture: Option<String>,
    #[sqlx(rename = "type")]
    pub notice_type: Option<i32>,
    pub env: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
pub struct NoticeResponse {
    pub id: i64,
    pub title: Option<String>,
    pub content: Option<String>,
    #[serde(rename = "startTime")]
    pub start_time: String,
    #[serde(rename = "lastTime")]
    pub last_time: i64,
    #[serde(rename = "priority")]
    pub priority: Option<i32>,
    pub status: Option<i32>,
    pub picture: Option<String>,
    #[serde(rename = "type")]
    pub notice_type: Option<i32>,
}

impl NoticeRule {
    pub fn into_response(self) -> NoticeResponse {
        NoticeResponse {
            id: self.id,
            title: self.title,
            content: self.content,
            start_time: self.start.format("%Y-%m-%d %H:%M:%S").to_string(),
            last_time: self.end.and_utc().timestamp(),
            priority: self.sort,
            status: self.status,
            picture: self.picture,
            notice_type: self.notice_type,
        }
    }
}
