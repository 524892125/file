use axum::{http::StatusCode, Json};
use serde_json::json;

pub async fn login() -> (StatusCode, Json<serde_json::Value>) {
    (
        StatusCode::OK,
        Json(json!({
            "token": "demo-token"
        })),
    )
}
