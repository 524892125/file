use axum::{
    extract::State,
    http::{header, StatusCode},
    response::IntoResponse,
    Form,
};

use crate::{models::notice::NoticeRequest, AppState};

pub async fn notice(
    State(state): State<AppState>,
    Form(body): Form<NoticeRequest>,
) -> impl IntoResponse {
    let result = state.services.notice.get(&body).await;
    let payload = serde_json::to_string(&result).unwrap_or_else(|_| "[]".to_string());
    let body = format!("\u{feff}{payload}");

    (
        StatusCode::OK,
        [(header::CONTENT_TYPE, "text/plain;charset=UTF-8")],
        body,
    )
}
