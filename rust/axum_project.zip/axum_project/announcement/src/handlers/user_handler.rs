use axum::{extract::Path, http::StatusCode, Json};
use serde_json::json;

pub async fn list() -> (StatusCode, Json<serde_json::Value>) {
    (StatusCode::OK, Json(json!({ "items": [] })))
}

pub async fn detail(Path(id): Path<String>) -> (StatusCode, Json<serde_json::Value>) {
    (
        StatusCode::OK,
        Json(json!({
            "id": id,
            "name": "demo"
        })),
    )
}
