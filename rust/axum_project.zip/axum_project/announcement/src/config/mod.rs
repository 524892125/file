use std::{env, net::SocketAddr};

use anyhow::{Context, Result};
use tracing_subscriber::{fmt, EnvFilter};

#[derive(Clone, Debug)]
pub struct Settings {
    pub host: String,
    pub port: u16,
    pub log_level: String,
    pub mysql_url: String,
    pub postgres_url: String,
    pub redis_url: String,
    pub mysql_max_conn: u32,
    pub postgres_max_conn: u32,
}

impl Settings {
    pub fn from_env() -> Result<Self> {
        dotenvy::dotenv().ok();

        Ok(Self {
            host: env::var("HOST").unwrap_or_else(|_| "0.0.0.0".to_string()),
            port: env::var("PORT")
                .unwrap_or_else(|_| "3000".to_string())
                .parse()
                .context("invalid PORT")?,
            log_level: env::var("RUST_LOG").unwrap_or_else(|_| "info".to_string()),
            mysql_url: env::var("MYSQL_URL").context("missing MYSQL_URL")?,
            postgres_url: env::var("POSTGRES_URL").context("missing POSTGRES_URL")?,
            redis_url: env::var("REDIS_URL").context("missing REDIS_URL")?,
            mysql_max_conn: env::var("MYSQL_MAX_CONN")
                .unwrap_or_else(|_| "50".to_string())
                .parse()
                .context("invalid MYSQL_MAX_CONN")?,
            postgres_max_conn: env::var("POSTGRES_MAX_CONN")
                .unwrap_or_else(|_| "50".to_string())
                .parse()
                .context("invalid POSTGRES_MAX_CONN")?,
        })
    }

    pub fn bind_addr(&self) -> SocketAddr {
        format!("{}:{}", self.host, self.port)
            .parse()
            .expect("valid bind address")
    }

    pub fn init_tracing(&self) {
        let filter = EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new(&self.log_level));
        let _ = fmt().with_env_filter(filter).try_init();
    }
}
