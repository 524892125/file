use std::{env, net::SocketAddr, path::PathBuf};

use anyhow::{Context, Result};
use tracing_subscriber::{fmt, layer::SubscriberExt, util::SubscriberInitExt, Layer, EnvFilter};

#[derive(Clone, Debug)]
pub struct Settings {
    pub host: String,
    pub port: u16,
    pub log_level: String,
    pub log_to_file: bool,
    pub log_dir: PathBuf,
    pub mysql_url: String,
    pub postgres_url: String,
    pub redis_url: String,
    pub mysql_max_conn: u32,
    pub postgres_max_conn: u32,
}

impl Settings {
    pub fn from_env() -> Result<Self> {
        dotenvy::dotenv().ok();

        Ok(Self {
            host: env::var("HOST").unwrap_or_else(|_| "0.0.0.0".to_string()),
            port: env::var("PORT")
                .unwrap_or_else(|_| "3000".to_string())
                .parse()
                .context("invalid PORT")?,
            log_level: env::var("RUST_LOG").unwrap_or_else(|_| "info".to_string()),
            log_to_file: env::var("LOG").unwrap_or_else(|_| "false".to_string()) == "true",
            log_dir: env::var("LOG_DIR")
                .map(PathBuf::from)
                .unwrap_or_else(|_| PathBuf::from("logs")),
            mysql_url: env::var("MYSQL_URL").context("missing MYSQL_URL")?,
            postgres_url: env::var("POSTGRES_URL").context("missing POSTGRES_URL")?,
            redis_url: env::var("REDIS_URL").context("missing REDIS_URL")?,
            mysql_max_conn: env::var("MYSQL_MAX_CONN")
                .unwrap_or_else(|_| "50".to_string())
                .parse()
                .context("invalid MYSQL_MAX_CONN")?,
            postgres_max_conn: env::var("POSTGRES_MAX_CONN")
                .unwrap_or_else(|_| "50".to_string())
                .parse()
                .context("invalid POSTGRES_MAX_CONN")?,
        })
    }

    pub fn bind_addr(&self) -> SocketAddr {
        format!("{}:{}", self.host, self.port)
            .parse()
            .expect("valid bind address")
    }

    pub fn init_tracing(&self) {
        let filter = EnvFilter::try_from_default_env()
            .unwrap_or_else(|_| EnvFilter::new(&self.log_level));

        if self.log_to_file {
            let _ = std::fs::create_dir_all(&self.log_dir);
            let file_appender =
                tracing_appender::rolling::RollingFileAppender::builder()
                    .rotation(tracing_appender::rolling::Rotation::DAILY)
                    .filename_prefix("announcement")
                    .filename_suffix("log")
                    .max_log_files(30)
                    .build(&self.log_dir)
                    .expect("failed to create log file appender");

            let (non_blocking, guard) = tracing_appender::non_blocking(file_appender);
            // guard must outlive the subscriber; leak is safe for a long-running server
            std::mem::forget(guard);

            tracing_subscriber::registry()
                .with(fmt::layer().with_filter(filter.clone()))
                .with(
                    fmt::layer()
                        .with_ansi(false)
                        .with_writer(non_blocking)
                        .with_filter(filter),
                )
                .init();
        } else {
            let _ = fmt().with_env_filter(filter).try_init();
        }
    }
}
