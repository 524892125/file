use std::{
    collections::{BTreeMap, HashMap},
    sync::Arc,
};

use anyhow::Result;
use sqlx::MySqlPool;
use tokio::sync::RwLock;

use crate::{
    mappers,
    models::notice::{NoticeRequest, NoticeResponse, NoticeRule},
    utils::time::now_second,
};

type NoticeRuleMap = HashMap<String, BTreeMap<i64, Vec<NoticeRule>>>;

#[derive(Clone)]
pub struct NoticeService {
    pool: MySqlPool,
    rules: Arc<RwLock<NoticeRuleMap>>,
}

impl NoticeService {
    pub fn new(pool: MySqlPool) -> Self {
        Self {
            pool,
            rules: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    pub async fn init(&self) -> Result<()> {
        self.reload_rules_from_db().await
    }

    pub async fn get(&self, param: &NoticeRequest) -> Vec<NoticeResponse> {
        let channel = param.channel.trim();
        let current_map = self.rules.read().await;
        let Some(time_map) = current_map.get(channel) else {
            return Vec::new();
        };

        let current_time = now_second();
        let mut result = Vec::new();

        for (_start, items) in time_map.range(..=current_time) {
            for item in items {
                if current_time <= item.end.and_utc().timestamp() {
                    result.push(item.clone().into_response());
                }
            }
        }

        result.sort_by(|a, b| b.priority.cmp(&a.priority));
        result
    }

    pub async fn reload_rules_from_db(&self) -> Result<()> {
        let db_rules = mappers::notice::load_active_rules(&self.pool).await?;
        let mut new_rule_map: NoticeRuleMap = HashMap::new();

        for rule in db_rules {
            let start_second = rule.start.and_utc().timestamp();
            for server in rule.server.split(',') {
                let server = server.trim();
                if server.is_empty() {
                    continue;
                }

                new_rule_map
                    .entry(server.to_string())
                    .or_default()
                    .entry(start_second)
                    .or_default()
                    .push(rule.clone());
            }
        }

        *self.rules.write().await = new_rule_map;
        Ok(())
    }
}
