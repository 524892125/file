pub mod auth_service;
pub mod notice_service;
pub mod user_service;

use crate::db::pool::AppPool;
use notice_service::NoticeService;

#[derive(Clone)]
pub struct Services {
    pub notice: NoticeService,
}

impl Services {
    pub async fn build(pool: &AppPool) -> anyhow::Result<Self> {
        let notice = NoticeService::new(pool.mysql().clone());
        notice.init().await?;

        Ok(Self { notice })
    }
}
