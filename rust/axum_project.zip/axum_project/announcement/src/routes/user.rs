use axum::{routing::get, Router};

use crate::{handlers::user_handler, AppState};

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/users", get(user_handler::list))
        .route("/users/{id}", get(user_handler::detail))
}
