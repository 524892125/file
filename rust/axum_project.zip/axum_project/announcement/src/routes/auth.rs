use axum::{routing::post, Router};

use crate::{handlers::auth_handler, AppState};

pub fn router() -> Router<AppState> {
    Router::new().route("/login", post(auth_handler::login))
}
