use axum::{routing::post, Router};

use crate::{handlers::notice_handler, AppState};

pub fn router() -> Router<AppState> {
    Router::new().route("/notice", post(notice_handler::notice))
}
