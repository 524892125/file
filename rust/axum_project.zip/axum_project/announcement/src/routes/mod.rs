use axum::{middleware, routing::get, Router};

use crate::{handlers, middleware::request_middleware, AppState};

pub mod auth;
pub mod notice;
pub mod user;

pub fn create_router(state: AppState) -> Router {
    Router::<AppState>::new()
        .route("/health", get(handlers::health::health))
        .route("/version", get(handlers::health::version))
        .merge(notice::router())
        .nest("/api/v1", user::router())
        .nest("/api/v1/auth", auth::router())
        .with_state(state)
        .layer(middleware::from_fn(request_middleware::request_logger))
}
