---
name: gitcommit
description: Create intelligent Git commits with Chinese conventional commit messages following the ~/.gitmessage template format. Use this skill whenever the user asks to commit, push, or save changes to Git, or says phrases like "提交代码", "git commit", "保存修改", or wants to stage and commit their work. This skill handles git add, generates appropriate commit messages in Chinese, commits changes, and can optionally push to remote.
---

# Git Commit with Intelligent Messages

创建符合规范的中文 Git 提交，遵循 ~/.gitmessage 模板格式。

## 核心原则

- **使用中文**: 所有提交信息使用中文描述
- **遵循 Conventional Commits**: 使用类型(作用域): 描述的格式
- **简洁明了**: 简短描述不超过 50 字符
- **不含自动生成标识**: 不要添加 "Generated with Claude Code" 或 "Co-Authored-By" 等脚注

## 提交类型

根据修改内容选择合适的类型：

- **feat**: 新功能 (feature)
- **fix**: 修复 bug
- **docs**: 文档更新
- **style**: 代码格式调整（不影响逻辑）
- **refactor**: 代码重构（既不修复 bug 也不增加功能）
- **perf**: 性能优化
- **test**: 添加或修改测试
- **chore**: 构建过程或辅助工具的变动

## 提交流程

### 第一步: 分析变更

执行以下命令查看当前状态：

```bash
git status
git diff --staged
git diff
```

### 第二步: 确定提交内容和类型

基于变更内容确定：
1. **提交类型**: 使用上述类型之一
2. **作用域** (可选): 影响的模块、组件或文件
3. **简短描述**: 简洁概括做了什么（不超过 50 字符）
4. **详细描述** (可选): 解释为什么做这个修改，动机是什么

### 第三步: 添加文件到暂存区

根据用户意图添加文件：
- 如果用户说"提交所有"或未指定文件：`git add -A`
- 如果用户指定了文件：`git add <files>`

### 第四步: 生成并执行提交

#### 格式模板

```
<类型>(<可选的作用域>): <简短描述>

<详细描述（可选）>

<可选的脚注>
- BREAKING CHANGE: 不兼容变更说明
- Ref #123, Closes #456
```

#### 提交命令

```bash
git commit -m "<简短描述>" -m "<详细描述（如果有）>"
```

**重要**: 不要添加以下内容：
- ❌ 🤖 Generated with [Claude Code](https://claude.ai/code)
- ❌ Co-Authored-By: ...

### 第五步: 推送到远程（可选）

如果用户要求推送或使用了"push"关键词：
```bash
git push
```

## 示例

### 示例 1: 新功能

**变更**: 添加了用户登录功能

```bash
git add -A
git commit -m "feat(auth): 添加用户登录功能" \
  -m "本次修改引入了 JWT 令牌验证机制，以提升登录过程的安全性。"
```

### 示例 2: 修复 Bug

**变更**: 修复了登录时的空指针异常

```bash
git add server/auth/login.go
git commit -m "fix(auth): 修复登录时的空指针异常" \
  -m "在用户不存在的情况下，未正确处理 nil 指针，导致服务崩溃。
现在返回友好的错误提示而不是 panic。"
```

### 示例 3: 代码重构

**变更**: 重构了用户管理器

```bash
git add server/hall/user_manager.go
git commit -m "refactor(user): 重构用户管理器"
```

### 示例 4: 文档更新

**变更**: 更新了 README 文件

```bash
git add README.md
git commit -m "docs: 更新 README 安装说明"
```

## 用户意图识别

当用户使用以下表达时，应该触发此技能：

- "提交代码"
- "commit"
- "git commit"
- "保存修改"
- "提交并推送"
- "commit and push"
- "提交当前更改"
- "生成提交信息"

## 智能分析策略

1. **查看 git diff**:
   - 分析文件变更的路径和内容
   - 识别涉及的模块（从路径推断作用域）

2. **确定提交类型**:
   - 新增文件或功能 → `feat`
   - 修复、修复bug → `fix`
   - .md 文件变更 → `docs`
   - 测试文件 → `test`
   - 配置文件、构建脚本 → `chore`
   - 代码结构调整 → `refactor`
   - 性能相关改进 → `perf`

3. **生成简短描述**:
   - 使用动词开头（添加、修复、重构、更新）
   - 说明"做了什么"
   - 控制在 50 字符以内

4. **决定是否添加详细描述**:
   - 复杂变更或跨文件修改应该添加
   - 简单的单文件修改可以省略

## 错误处理

如果出现以下情况：

- **没有变更**: 提示用户当前没有需要提交的更改
- **合并冲突**: 建议用户先解决冲突
- **提交失败**: 显示错误信息并建议解决方案

## 工作流程总结

1. 运行 `git status` 和 `git diff` 了解变更
2. 根据变更内容确定提交类型和作用域
3. 生成符合规范的中文提交信息
4. 执行 `git add` 和 `git commit`
5. 如果用户要求推送，执行 `git push`
6. 报告操作结果
